package com.lerzaplayer.ui.videos

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.model.ViewMode
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors

@Composable
fun VideoListScreen(
    videos: List<VideoItem>,
    viewMode: ViewMode,
    onVideoClick: (VideoItem) -> Unit,
    onViewModeToggle: () -> Unit,
    onScanDevice: () -> Unit,
    onToggleFavorite: (VideoItem) -> Unit,
    onHideInVault: (VideoItem) -> Unit,
    onDelete: (VideoItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${videos.size} Videos Available",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textSecondary
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onViewModeToggle,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (viewMode == ViewMode.GRID) LerzaIcons.GridView else LerzaIcons.ListView,
                        contentDescription = "Toggle View",
                        tint = colors.textPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        if (videos.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No videos found on device", color = colors.textSecondary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = onScanDevice) {
                        Text("Scan Device")
                    }
                }
            }
        } else if (viewMode == ViewMode.GRID) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 90.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { clip = true }
            ) {
                items(videos, key = { it.id }) { video ->
                    VideoGridCard(
                        video = video,
                        onClick = { onVideoClick(video) },
                        onToggleFavorite = { onToggleFavorite(video) },
                        onHideInVault = { onHideInVault(video) },
                        onDelete = { onDelete(video) }
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 90.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { clip = true }
            ) {
                items(videos, key = { it.id }) { video ->
                    VideoListRow(
                        video = video,
                        onClick = { onVideoClick(video) },
                        onToggleFavorite = { onToggleFavorite(video) },
                        onHideInVault = { onHideInVault(video) },
                        onDelete = { onDelete(video) }
                    )
                }
            }
        }
    }
}

@Composable
fun VideoGridCard(
    video: VideoItem,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onHideInVault: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    var menuExpanded by remember { mutableStateOf(false) }

    val imageRequest = remember(video.contentUri, video.id) {
        ImageRequest.Builder(context)
            .data(video.contentUri)
            .videoFrameMillis(1000)
            .size(360, 200)
            .memoryCacheKey("vthumb_${video.id}")
            .diskCacheKey("vthumb_${video.id}")
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .crossfade(150)
            .build()
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(colors.card)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(105.dp)
                .background(Color(0xFF141720))
        ) {
            AsyncImage(
                model = imageRequest,
                contentDescription = video.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.75f))
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
                Text(
                    text = video.durationFormatted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF00B0FF))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "HD",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = video.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = video.folderName,
                    fontSize = 11.sp,
                    color = colors.textSecondary
                )
            }

            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.MoreVert,
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(colors.surface)
                ) {
                    DropdownMenuItem(
                        text = { Text("Hide in Vault", color = colors.textPrimary) },
                        leadingIcon = { Icon(LerzaIcons.VisibilityOff, null, tint = colors.textPrimary) },
                        onClick = { menuExpanded = false; onHideInVault() }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = Color(0xFFFF334B)) },
                        leadingIcon = { Icon(LerzaIcons.Delete, null, tint = Color(0xFFFF334B)) },
                        onClick = { menuExpanded = false; onDelete() }
                    )
                }
            }
        }
    }
}

@Composable
fun VideoListRow(
    video: VideoItem,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onHideInVault: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    var menuExpanded by remember { mutableStateOf(false) }

    val imageRequest = remember(video.contentUri, video.id) {
        ImageRequest.Builder(context)
            .data(video.contentUri)
            .videoFrameMillis(1000)
            .size(240, 150)
            .memoryCacheKey("vthumb_${video.id}")
            .diskCacheKey("vthumb_${video.id}")
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .crossfade(150)
            .build()
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(width = 80.dp, height = 50.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF141720))
        ) {
            AsyncImage(
                model = imageRequest,
                contentDescription = video.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(3.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.Black.copy(alpha = 0.75f))
                    .padding(horizontal = 3.dp, vertical = 1.dp)
            ) {
                Text(
                    text = video.durationFormatted,
                    fontSize = 9.sp,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = video.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "Device Videos • ${video.folderName}",
                fontSize = 12.sp,
                color = colors.textSecondary
            )
        }

        Box {
            IconButton(onClick = { menuExpanded = true }) {
                Icon(
                    imageVector = LerzaIcons.MoreVert,
                    contentDescription = null,
                    tint = colors.textSecondary
                )
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                modifier = Modifier.background(colors.surface)
            ) {
                DropdownMenuItem(
                    text = { Text("Hide in Vault", color = colors.textPrimary) },
                    onClick = { menuExpanded = false; onHideInVault() }
                )
                DropdownMenuItem(
                    text = { Text("Delete", color = Color(0xFFFF334B)) },
                    onClick = { menuExpanded = false; onDelete() }
                )
            }
        }
    }
}
