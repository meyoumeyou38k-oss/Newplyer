package com.lerzaplayer.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import kotlinx.coroutines.launch

data class ThemeColorItem(
    val id: String,
    val name: String,
    val primaryColor: Color,
    val isDark: Boolean = true
)

val LARK_THEMES = listOf(
    ThemeColorItem("AMOLED Black", "Default Dark", Color(0xFF00E5FF), isDark = true),
    ThemeColorItem("Sky Blue", "Sky Blue", Color(0xFF2979FF), isDark = true),
    ThemeColorItem("Mint Green", "Emerald Green", Color(0xFF00E676), isDark = true),
    ThemeColorItem("Neon Pink", "Rose Pink", Color(0xFFFF4081), isDark = true),
    ThemeColorItem("Sunset Orange", "Vibrant Orange", Color(0xFFFF6D00), isDark = true),
    ThemeColorItem("Royal Purple", "Purple Neon", Color(0xFF7C4DFF), isDark = true),
    ThemeColorItem("Pure White", "Pure Light", Color(0xFF1E60F2), isDark = false)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current

    val currentThemeName by prefManager.themeFlow.collectAsState(initial = "AMOLED Black")
    val wallpaperUri by prefManager.wallpaperUriFlow.collectAsState(initial = null)
    val wallpaperOpacity by prefManager.wallpaperOpacityFlow.collectAsState(initial = 0.75f)

    var modeSelection by remember { mutableStateOf("Dark") } // Dark, Light, System
    var selectedColorId by remember { mutableStateOf(currentThemeName) }

    val activeThemeItem = remember(selectedColorId) {
        LARK_THEMES.find { it.id == selectedColorId } ?: LARK_THEMES[0]
    }

    // گیلری سے وال پیپر تصویر چننے کا لانچر
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            scope.launch {
                prefManager.setWallpaperUri(uri.toString())
            }
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(onClick = onBack) {
                        Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Text(
                        text = "Theme",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                // Medium view indicator matching Screenshot 2
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color(0xFF2979FF),
                    contentColor = Color.White
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Menu, contentDescription = null, modifier = Modifier.size(14.dp))
                        Text("Medium", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        containerColor = Color(0xFF0F1215)
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(6.dp))

            // 1. اوپر اصلی فون کا لائیو کارڈ پریویو (Live Phone Preview Screen - Screenshot 2)
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .weight(1f)
                    .clip(RoundedCornerShape(28.dp))
                    .border(2.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(28.dp))
                    .background(if (modeSelection == "Light") Color(0xFFF5F6FA) else Color(0xFF0B0E11))
            ) {
                // اگر وال پیپر لگا ہو تو پریویو میں بھی نظر آئے
                if (!wallpaperUri.isNullOrBlank()) {
                    AsyncImage(
                        model = wallpaperUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = wallpaperOpacity))
                    )
                }

                // لائیو ڈمی گانوں کی لسٹ (Lark Player Preview)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    // کارڈ کا ٹاپ ہیڈر
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Lark Player",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (modeSelection == "Light") Color.Black else Color.White
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                            Icon(Icons.Default.Tune, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // ٹیبز (Videos, Songs, Playlists)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = activeThemeItem.primaryColor,
                            contentColor = Color.White
                        ) {
                            Text("Songs", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.08f),
                            contentColor = Color.Gray
                        ) {
                            Text("Videos", fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.08f),
                            contentColor = Color.Gray
                        ) {
                            Text("Playlists", fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // گانوں کی ڈمی لسٹ
                    listOf(
                        "Crazy In Love With Your Smile" to "Don Juan",
                        "Heart Skips A Beat" to "Hariel",
                        "Beach Memories" to "Nattan",
                        "Can't Stop This Feeling" to "Henrique & Juliano",
                        "Blue Eyes That Saw My Soul" to "Mc Poze"
                    ).forEach { (title, artist) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(activeThemeItem.primaryColor.copy(alpha = 0.4f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = title,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (modeSelection == "Light") Color.Black else Color.White,
                                    maxLines = 1
                                )
                                Text(text = artist, fontSize = 9.sp, color = Color.Gray, maxLines = 1)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Dark / Light / System موڈ سلیکٹر (اسکرین شاٹ 2 کے مطابق)
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF1B2228),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("Dark" to Icons.Default.DarkMode, "Light" to Icons.Default.LightMode, "System" to Icons.Default.SettingsBrightness).forEach { (mode, icon) ->
                        val isSelected = modeSelection == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(24.dp))
                                .background(if (isSelected) Color(0xFF2979FF) else Color.Transparent)
                                .clickable {
                                    modeSelection = mode
                                    if (mode == "Light") {
                                        scope.launch { prefManager.setTheme("Pure White") }
                                    } else {
                                        scope.launch { prefManager.setTheme(selectedColorId) }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isSelected) Color.White else Color.Gray,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = mode,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else Color.Gray
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3. وال پیپر اوپیسٹی سلائیڈر (جب گیلری سے فوٹو لگی ہو)
            if (!wallpaperUri.isNullOrBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Opacity: ${(wallpaperOpacity * 100).toInt()}%",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        modifier = Modifier.width(76.dp)
                    )
                    Slider(
                        value = wallpaperOpacity,
                        onValueChange = { scope.launch { prefManager.setWallpaperOpacity(it) } },
                        valueRange = 0.2f..0.95f,
                        colors = SliderDefaults.colors(
                            thumbColor = activeThemeItem.primaryColor,
                            activeTrackColor = activeThemeItem.primaryColor
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { scope.launch { prefManager.setWallpaperUri(null) } }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Remove Wallpaper", tint = Color(0xFFFF5252))
                    }
                }
            }

            // 4. نیچے رنگوں کے گول سرکلز اور گیلری فوٹو کا بٹن (Screenshot 2 Bottom Bar)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp)
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // گیلری سے فوٹو لگانے کا بٹن (Photo Gallery Button)
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1E2832))
                        .border(1.5.dp, Color.White.copy(alpha = 0.2f), CircleShape)
                        .clickable { photoPickerLauncher.launch(arrayOf("image/*")) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = "Pick Wallpaper",
                        tint = Color(0xFF2979FF),
                        modifier = Modifier.size(22.dp)
                    )
                }

                // سلیکٹڈ مارک والا سرکل (Black)
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.Black)
                        .border(
                            width = 2.dp,
                            color = if (selectedColorId == "AMOLED Black") Color.White else Color.Transparent,
                            shape = CircleShape
                        )
                        .clickable {
                            selectedColorId = "AMOLED Black"
                            scope.launch { prefManager.setTheme("AMOLED Black") }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedColorId == "AMOLED Black") {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }

                // باقی تمام رنگین تھیم سرکلز (Blue, Green, Pink, Orange, Purple)
                LARK_THEMES.filter { it.id != "AMOLED Black" && it.id != "Pure White" }.forEach { themeItem ->
                    val isSel = selectedColorId == themeItem.id
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(themeItem.primaryColor)
                            .border(
                                width = 2.dp,
                                color = if (isSel) Color.White else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable {
                                selectedColorId = themeItem.id
                                scope.launch { prefManager.setTheme(themeItem.id) }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSel) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                        }
                    }
                }
            }
        }
    }
}