package com.lerzaplayer.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onScanMedia: () -> Unit,
    onOpenVault: () -> Unit = {},
    recentlyDeleted: List<RecentlyDeletedEntity> = emptyList(),
    onPlayRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onRestoreRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onPermanentlyDeleteRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current

    val currentTheme by prefManager.themeFlow.collectAsState(initial = "AMOLED Black")
    val sleepMinutes by (context.applicationContext as? com.lerzaplayer.LerzaApp)?.playerManager?.sleepTimerRemainingMinutes?.collectAsState() ?: remember { mutableIntStateOf(0) }
    val playerManager = (context.applicationContext as? com.lerzaplayer.LerzaApp)?.playerManager

    // اندرونی نیویگیشن اسٹیٹس
    var currentSubScreen by remember { mutableStateOf<String?>(null) } // "theme", "notification", "sleep_timer"
    var showSleepTimerSheet by remember { mutableStateOf(false) }

    // بیک پریس ہینڈلر
    BackHandler(enabled = currentSubScreen != null) {
        currentSubScreen = null
    }

    // اگر تھیم اسکرین کھلی ہو تو وہ دکھائیں
    if (currentSubScreen == "theme") {
        ThemeScreen(
            prefManager = prefManager,
            onBack = { currentSubScreen = null }
        )
        return
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Settings",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        },
        containerColor = Color(0xFF0C0E10)
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // کارڈ 1: Playtime & Backup (اسکرین شاٹ 1 کے مطابق)
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.PlayCircleOutline,
                        title = "Playtime",
                        badge = "2h 7m",
                        onClick = {}
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.CloudSync,
                        title = "Backup & restore",
                        badge = "Log in",
                        onClick = {
                            Toast.makeText(context, "Local backup active", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }

            // کارڈ 2: Theme & Sleep Timer & Remove Ads (اسکرین شاٹ 1 کے مطابق)
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.Palette,
                        title = "Theme",
                        badge = "Classic / Medium",
                        onClick = {
                            // تھیم اسکرین کھولیں جہاں لائیو پریویو اور فوٹو وال پیپر ہے
                            currentSubScreen = "theme"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Alarm,
                        title = "Sleep timer",
                        badge = if (sleepMinutes > 0) "$sleepMinutes min" else "Off",
                        onClick = {
                            showSleepTimerSheet = true
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Block,
                        title = "Audio Equalizer",
                        badge = "10-Band EQ",
                        onClick = onOpenEqualizer
                    )
                }
            }

            // کارڈ 3: Hidden Files & Recently Deleted & Settings (اسکرین شاٹ 1 کے مطابق)
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.VisibilityOff,
                        title = "Hidden files",
                        badge = "Vault",
                        onClick = onOpenVault
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.DeleteOutline,
                        title = "Recently deleted",
                        badge = "${recentlyDeleted.size} files",
                        onClick = {
                            currentSubScreen = "recently_deleted"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Headphones,
                        title = "Playback settings",
                        onClick = onOpenEqualizer
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.NotificationsNone,
                        title = "Notification settings",
                        onClick = {
                            currentSubScreen = "notification"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Language,
                        title = "Language",
                        badge = "English",
                        onClick = {
                            Toast.makeText(context, "Language: English & Urdu available", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }

            // کارڈ 4: Feedback & About
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.MailOutline,
                        title = "Feedback",
                        onClick = {
                            val intent = Intent(Intent.ACTION_SENDTO).apply {
                                data = Uri.parse("mailto:support@lerzaplayer.com")
                                putExtra(Intent.EXTRA_SUBJECT, "Lerza Player Feedback")
                            }
                            runCatching { context.startActivity(intent) }
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Info,
                        title = "About",
                        badge = "2026.14.7",
                        onClick = {}
                    )
                }
            }
        }
    }

    // اسکرین شاٹ 3: Sleep Timer باٹم شیٹ (Turn off, 10m, 20m, 30m, 60m, Custom)
    if (showSleepTimerSheet && playerManager != null) {
        ModalBottomSheet(
            onDismissRequest = { showSleepTimerSheet = false },
            containerColor = Color(0xFF181C20),
            contentColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 30.dp)
            ) {
                Text(
                    text = "Sleep timer",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Turn off
                SleepTimerOptionRow(
                    title = "Turn off",
                    isSelected = sleepMinutes == 0,
                    onClick = {
                        playerManager.setSleepTimer(0)
                        showSleepTimerSheet = false
                    }
                )

                listOf(10, 20, 30, 60).forEach { mins ->
                    SleepTimerOptionRow(
                        title = "$mins minutes later",
                        isSelected = sleepMinutes == mins,
                        onClick = {
                            playerManager.setSleepTimer(mins)
                            showSleepTimerSheet = false
                            Toast.makeText(context, "Playback will pause in $mins minutes", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    // اسکرین شاٹ 5: Notification Settings Screen
    if (currentSubScreen == "notification") {
        var newMediaNotif by remember { mutableStateOf(true) }
        var pushNotif by remember { mutableStateOf(true) }

        Scaffold(
            topBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { currentSubScreen = null }) {
                        Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Notification settings",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            containerColor = Color(0xFF0C0E10)
        ) { pad ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(22.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("New media notification", fontSize = 16.sp, color = Color.White)
                    Switch(
                        checked = newMediaNotif,
                        onCheckedChange = { newMediaNotif = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = Color(0xFF2979FF))
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Push notification", fontSize = 16.sp, color = Color.White)
                        Text("Recommend music I might like", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(
                        checked = pushNotif,
                        onCheckedChange = { pushNotif = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = Color(0xFF2979FF))
                    )
                }
            }
        }
    }

    // Recently Deleted لسٹ سب اسکرین
    if (currentSubScreen == "recently_deleted") {
        Scaffold(
            topBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { currentSubScreen = null }) {
                        Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Recently deleted (${recentlyDeleted.size})",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            containerColor = Color(0xFF0C0E10)
        ) { pad ->
            if (recentlyDeleted.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(pad),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Trash is empty. Deleted items remain here for 30 days.", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(pad)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(recentlyDeleted.size) { idx ->
                        val item = recentlyDeleted[idx]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF171B1E))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { onPlayRecentlyDeleted(item) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF2979FF).copy(alpha = 0.15f))
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color(0xFF2979FF))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.originalName, color = Color.White, fontSize = 13.sp, maxLines = 1)
                                Text("Auto-deletes in 30 days", color = Color(0xFFFFB020), fontSize = 10.sp)
                            }
                            Button(
                                onClick = { onRestoreRecentlyDeleted(item) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Restore", fontSize = 11.sp)
                            }
                            IconButton(onClick = { onPermanentlyDeleteRecentlyDeleted(item) }) {
                                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color(0xFFFF5252))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsGroupCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF171B1E),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            content()
        }
    }
}

@Composable
private fun LarkSettingsRow(
    icon: ImageVector,
    title: String,
    badge: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.8f),
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            fontSize = 15.sp,
            color = Color.White,
            modifier = Modifier.weight(1f)
        )
        if (badge != null) {
            Text(
                text = badge,
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.35f),
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun SettingsDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(0.6.dp)
            .background(Color.White.copy(alpha = 0.06f))
    )
}

@Composable
private fun SleepTimerOptionRow(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            fontSize = 15.sp,
            color = if (isSelected) Color(0xFF2979FF) else Color.White
        )
        if (isSelected) {
            Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF2979FF))
        }
    }
}