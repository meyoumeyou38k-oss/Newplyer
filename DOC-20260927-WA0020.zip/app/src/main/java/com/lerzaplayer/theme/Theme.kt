package com.lerzaplayer.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// واحد اور مستند Palette کلاس جس میں accent اور divider دونوں موجود ہیں
data class LerzaColorPalette(
    val primary: Color,
    val primaryVariant: Color,
    val accent: Color,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val divider: Color,
    val isDark: Boolean
)

val LocalLerzaColors = staticCompositionLocalOf {
    LerzaColorPalette(
        primary = LerzaBlue,
        primaryVariant = LerzaBlueDark,
        accent = LerzaBlue,
        background = DarkBackground,
        surface = DarkSurface,
        surfaceVariant = DarkSurfaceVariant,
        textPrimary = DarkTextPrimary,
        textSecondary = DarkTextSecondary,
        divider = DarkDivider,
        isDark = true
    )
}

object LerzaTheme {
    val colors: LerzaColorPalette
        @Composable
        @ReadOnlyComposable
        get() = LocalLerzaColors.current
}

// تھیم کے منتخب رنگ کے مطابق Palette تیار کرنے کا فنکشن
fun getLerzaPalette(themeColor: Color, isDark: Boolean): LerzaColorPalette {
    return if (isDark) {
        LerzaColorPalette(
            primary = themeColor,
            primaryVariant = themeColor.copy(alpha = 0.8f),
            accent = themeColor,
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurfaceVariant,
            textPrimary = DarkTextPrimary,
            textSecondary = DarkTextSecondary,
            divider = DarkDivider,
            isDark = true
        )
    } else {
        LerzaColorPalette(
            primary = themeColor,
            primaryVariant = themeColor.copy(alpha = 0.8f),
            accent = themeColor,
            background = LightBackground,
            surface = LightSurface,
            surfaceVariant = LightSurfaceVariant,
            textPrimary = LightTextPrimary,
            textSecondary = LightTextSecondary,
            divider = LightDivider,
            isDark = false
        )
    }
}

@Composable
fun LerzaPlayerTheme(
    themeColor: Color = LerzaBlue,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val lerzaPalette = getLerzaPalette(themeColor, darkTheme)

    val materialColorScheme = if (darkTheme) {
        darkColorScheme(
            primary = lerzaPalette.primary,
            secondary = lerzaPalette.accent,
            background = lerzaPalette.background,
            surface = lerzaPalette.surface,
            onPrimary = Color.White,
            onBackground = lerzaPalette.textPrimary,
            onSurface = lerzaPalette.textPrimary
        )
    } else {
        lightColorScheme(
            primary = lerzaPalette.primary,
            secondary = lerzaPalette.accent,
            background = lerzaPalette.background,
            surface = lerzaPalette.surface,
            onPrimary = Color.White,
            onBackground = lerzaPalette.textPrimary,
            onSurface = lerzaPalette.textPrimary
        )
    }

    CompositionLocalProvider(
        LocalLerzaColors provides lerzaPalette
    ) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            content = content
        )
    }
}