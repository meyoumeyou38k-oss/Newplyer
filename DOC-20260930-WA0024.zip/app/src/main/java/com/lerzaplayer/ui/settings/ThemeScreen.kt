package com.lerzaplayer.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.*
import kotlinx.coroutines.launch

data class LarkColorCircle(
    val id: String,
    val title: String,
    val circleColor: Color,
    val isNone: Boolean = false
)

val THEME_CIRCLES = listOf(
    LarkColorCircle("Emerald", "Electric Emerald", LarkEmerald),
    LarkColorCircle("Indigo", "Deep Indigo", LarkIndigo),
    LarkColorCircle("Coral", "Sunset Coral", LarkCoral),
    LarkColorCircle("Green", "Mint Green", LarkGreen),
    LarkColorCircle("Blue", "Lerza Blue", LerzaBlue),
    LarkColorCircle("Purple", "Royal Purple", LarkPurple),
    LarkColorCircle("Orange", "Sunset Orange", LarkOrange),
    LarkColorCircle("Red", "Crimson Red", LarkRed),
    LarkColorCircle("Pink", "Rose Pink", LarkPink),
    LarkColorCircle("Cyan", "Ocean Cyan", LarkCyan),
    LarkColorCircle("Amber", "Golden Amber", LarkAmber),
    LarkColorCircle("Lavender", "Soft Lavender", Color(0xFF9C27B0))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current
    val currentThemeColor = ThemeManager.currentThemeColor
    val currentThemeName = ThemeManager.currentThemeName
    val currentMode = ThemeManager.currentThemeMode
    val wallpaperUri by prefManager.wallpaperUriFlow.collectAsState(initial = null)
    val wallpaperOpacity by prefManager.wallpaperOpacityFlow.collectAsState(initial = 0.75f)
    val songDensity by prefManager.songItemDensityFlow.collectAsState(initial = 1.20f)

    var liveDensity by remember { mutableFloatStateOf(1.20f) }
    LaunchedEffect(songDensity) { liveDensity = songDensity }

    var liveOpacity by remember { mutableFloatStateOf(0.75f) }
    LaunchedEffect(wallpaperOpacity) { liveOpacity = wallpaperOpacity }

    val animatedColor by animateColorAsState(
        targetValue = currentThemeColor,
        animationSpec = tween(300),
        label = "ThemePreviewColor"
    )
    val onTextColor = getContrastTextColor(animatedColor)
    val isSystemDark = androidx.compose.foundation.isSystemInDarkTheme()
    val isDarkTheme = when (currentMode) {
        "Dark" -> true
        "Light" -> false
        else -> isSystemDark
    }
    val headerTextColor = if (isDarkTheme) Color.White else Color(0xFF111417)

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            scope.launch { prefManager.setWallpaperUri(uri.toString()) }
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = headerTextColor,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Theme &",
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold,
                            color = headerTextColor,
                            lineHeight = 22.sp
                        )
                        Text(
                            text = "Customization",
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold,
                            color = headerTextColor,
                            lineHeight = 22.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = animatedColor,
                    shadowElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = onTextColor
                        )
                        Text(
                            text = currentThemeName,
                            color = onTextColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        },
        containerColor = colors.background,
        modifier = modifier.fillMaxSize()
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            // 1. Live Preview Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = colors.card),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .padding(vertical = 12.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    if (wallpaperUri != null) {
                        AsyncImage(
                            model = Uri.parse(wallpaperUri),
                            contentDescription = "Custom Wallpaper",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(24.dp))
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(colors.background.copy(alpha = 1f - liveOpacity))
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Preview Player",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = colors.textPrimary
                                )
                                Text(
                                    text = "Real-time Theme Styling",
                                    fontSize = 12.sp,
                                    color = colors.textSecondary
                                )
                            }
                            Surface(
                                shape = CircleShape,
                                color = animatedColor.copy(alpha = 0.2f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    tint = animatedColor,
                                    modifier = Modifier
                                        .padding(8.dp)
                                        .size(20.dp)
                                )
                            }
                        }

                        // Mock Song item inside preview
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = colors.surface.copy(alpha = 0.85f),
                            border = BorderStroke(1.dp, animatedColor.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(animatedColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = onTextColor,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Sample Melody Track",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp,
                                        color = colors.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Lerza Premium Audio",
                                        fontSize = 12.sp,
                                        color = colors.textSecondary
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(animatedColor)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 2. Custom Wallpaper Section
            Text(
                text = "CUSTOM WALLPAPER",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textSecondary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = colors.card),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "App Background Wallpaper",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = colors.textPrimary
                            )
                            Text(
                                text = if (wallpaperUri != null) "Custom image active" else "No image set",
                                fontSize = 12.sp,
                                color = colors.textSecondary
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (wallpaperUri != null) {
                                OutlinedButton(
                                    onClick = {
                                        scope.launch { prefManager.setWallpaperUri(null) }
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF334B))
                                ) {
                                    Text("Remove", fontSize = 12.sp)
                                }
                            }
                            Button(
                                onClick = {
                                    photoPickerLauncher.launch(arrayOf("image/*"))
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = animatedColor)
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp), tint = onTextColor)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (wallpaperUri == null) "Select" else "Change", fontSize = 12.sp, color = onTextColor)
                            }
                        }
                    }

                    if (wallpaperUri != null) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Background Opacity (${(liveOpacity * 100).toInt()}%)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = colors.textPrimary
                        )
                        Slider(
                            value = liveOpacity,
                            onValueChange = { liveOpacity = it },
                            onValueChangeFinished = {
                                scope.launch { prefManager.setWallpaperOpacity(liveOpacity) }
                            },
                            valueRange = 0.2f..0.95f,
                            colors = SliderDefaults.colors(
                                thumbColor = animatedColor,
                                activeTrackColor = animatedColor
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 3. Density / Size Customization
            Text(
                text = "TRACK LIST ITEM SIZE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textSecondary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = colors.card),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Item Height & Thumbnail Size",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            color = colors.textPrimary
                        )
                        Text(
                            text = when {
                                liveDensity < 1.05f -> "Compact"
                                liveDensity > 1.25f -> "Large"
                                else -> "Standard"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = animatedColor
                        )
                    }

                    Slider(
                        value = liveDensity,
                        onValueChange = { liveDensity = it },
                        onValueChangeFinished = {
                            scope.launch { prefManager.setSongItemDensity(liveDensity) }
                        },
                        valueRange = 0.90f..1.40f,
                        colors = SliderDefaults.colors(
                            thumbColor = animatedColor,
                            activeTrackColor = animatedColor
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 4. Color Mode (Light / Dark)
            Text(
                text = "APPEARANCE MODE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textSecondary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                listOf("Light", "Dark").forEach { mode ->
                    val isSelected = currentMode == mode
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                ThemeManager.setMode(context, mode)
                            },
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected) animatedColor else colors.card,
                        border = if (isSelected) null else BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (mode == "Dark") Icons.Default.DarkMode else Icons.Default.LightMode,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = if (isSelected) onTextColor else Color(0xFF94A3B8)
                                )
                                Text(
                                    text = mode,
                                    fontSize = 14.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) onTextColor else Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }
            }

            // 5. Theme Palette Circles (Filtered without White & None)
            Text(
                text = "ACCENT COLOR",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textSecondary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                THEME_CIRCLES.forEach { circleItem ->
                    val isSel = currentThemeColor.value == circleItem.circleColor.value
                    val checkColor = getContrastTextColor(circleItem.circleColor)

                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(circleItem.circleColor)
                            .border(
                                width = if (isSel) 2.5.dp else 1.dp,
                                color = if (isSel) Color.White else Color.White.copy(alpha = 0.25f),
                                shape = CircleShape
                            )
                            .clickable {
                                ThemeManager.setTheme(context, circleItem.circleColor, circleItem.id)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSel) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = checkColor,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}