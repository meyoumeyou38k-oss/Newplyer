package com.lerzaplayer.theme

import androidx.compose.ui.graphics.Color

// Accent Colors for 10 Themes
val NeonGreen = Color(0xFF00E676)
val ElectricBlue = Color(0xFF2979FF)
val VividPurple = Color(0xFFB388FF)
val DeepPurple = Color(0xFF7C4DFF)
val CrimsonRed = Color(0xFFFF1744)
val SunsetOrange = Color(0xFFFF9100)
val NeonPink = Color(0xFFFF4081)
val OceanTeal = Color(0xFF00E5FF)

// Background & Surface palettes
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkSurfaceVariant = Color(0xFF2C2C2C)

val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF0A0A0A)
val AmoledSurfaceVariant = Color(0xFF141414)

// Liquid Glass & Premium White Palette
val LiquidGlassBackground = Color(0xFFF5F7FB)
val LiquidGlassSurface = Color(0xFFFFFFFF)
val LiquidGlassSurfaceVariant = Color(0xFFEBF0F7)
val LiquidGlassBorder = Color(0xFFE2E8F0)
val LiquidGlassOnSurface = Color(0xFF0F172A)
val LiquidGlassOnSurfaceVariant = Color(0xFF64748B)
val LarkGreen = Color(0xFF00C853)
val LarkAqua = Color(0xFF00B0FF)

val LightBackground = Color(0xFFF5F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEBF0F7)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF64748B)
