package com.lerzaplayer.data.repository

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class MediaRepository(private val context: Context) {
    private val database = AppDatabase.getDatabase(context)
    private val vaultDao = database.vaultDao()

    suspend fun getAllSongs(): List<SongItem> = withContext(Dispatchers.IO) {
        val hiddenUris = try {
            vaultDao.getAllHiddenUrisList().toSet()
        } catch (_: Throwable) {
            emptySet()
        }

        val songList = mutableListOf<SongItem>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.ALBUM_ID
        )

        // Only include media with size > 1KB or duration > 3 seconds to avoid corrupted or zero-byte files
        val selection = "${MediaStore.Audio.Media.SIZE} > 1024 OR ${MediaStore.Audio.Media.DURATION} > 3000"
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )

            cursor?.use {
                val idCol = it.getColumnIndex(MediaStore.Audio.Media._ID)
                val titleCol = it.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val artistCol = it.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val albumCol = it.getColumnIndex(MediaStore.Audio.Media.ALBUM)
                val durCol = it.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val dataCol = it.getColumnIndex(MediaStore.Audio.Media.DATA)
                val sizeCol = it.getColumnIndex(MediaStore.Audio.Media.SIZE)
                val dateCol = it.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
                val albumIdCol = it.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)

                while (it.moveToNext()) {
                    val id = if (idCol >= 0 && !it.isNull(idCol)) it.getLong(idCol) else -1L
                    if (id <= 0) continue

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    if (hiddenUris.contains(contentUri.toString())) {
                        continue
                    }

                    val title = if (titleCol >= 0 && !it.isNull(titleCol)) it.getString(titleCol) ?: "" else ""
                    val artist = if (artistCol >= 0 && !it.isNull(artistCol)) it.getString(artistCol) ?: "" else ""
                    val album = if (albumCol >= 0 && !it.isNull(albumCol)) it.getString(albumCol) ?: "" else ""
                    val duration = if (durCol >= 0 && !it.isNull(durCol)) it.getLong(durCol) else 0L
                    val data = if (dataCol >= 0 && !it.isNull(dataCol)) it.getString(dataCol) ?: "" else ""
                    val size = if (sizeCol >= 0 && !it.isNull(sizeCol)) it.getLong(sizeCol) else 0L
                    val dateAdded = if (dateCol >= 0 && !it.isNull(dateCol)) it.getLong(dateCol) else 0L
                    val albumId = if (albumIdCol >= 0 && !it.isNull(albumIdCol)) it.getLong(albumIdCol) else -1L

                    // Skip very short sounds (< 2s)
                    if (duration in 1..2000) continue

                    val artworkUri = if (albumId > 0) {
                        ContentUris.withAppendedId(
                            Uri.parse("content://media/external/audio/albumart"),
                            albumId
                        )
                    } else {
                        contentUri
                    }

                    val cleanTitle = if (title.isNotBlank()) {
                        title
                    } else if (data.isNotBlank()) {
                        val fileName = data.substringAfterLast('/').substringBeforeLast('.')
                        fileName.ifBlank { "Track $id" }
                    } else {
                        "Track $id"
                    }

                    val cleanArtist = if (artist.isBlank() || artist.contains("<unknown>", ignoreCase = true)) {
                        "Unknown Artist"
                    } else {
                        artist
                    }

                    val cleanAlbum = if (album.isBlank() || album.contains("<unknown>", ignoreCase = true)) {
                        "Unknown Album"
                    } else {
                        album
                    }

                    songList.add(
                        SongItem(
                            id = id,
                            title = cleanTitle,
                            artist = cleanArtist,
                            album = cleanAlbum,
                            durationMs = duration,
                            contentUri = contentUri,
                            albumArtUri = artworkUri,
                            dataPath = data,
                            sizeBytes = size,
                            dateAddedSecs = dateAdded
                        )
                    )
                }
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        songList
    }

    suspend fun getAllVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val hiddenUris = try {
            vaultDao.getAllHiddenUrisList().toSet()
        } catch (_: Throwable) {
            emptySet()
        }

        val videoList = mutableListOf<VideoItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )

        val selection = "${MediaStore.Video.Media.SIZE} > 1024 OR ${MediaStore.Video.Media.DURATION} > 1000"
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )

            cursor?.use {
                val idCol = it.getColumnIndex(MediaStore.Video.Media._ID)
                val titleCol = it.getColumnIndex(MediaStore.Video.Media.TITLE)
                val durCol = it.getColumnIndex(MediaStore.Video.Media.DURATION)
                val dataCol = it.getColumnIndex(MediaStore.Video.Media.DATA)
                val sizeCol = it.getColumnIndex(MediaStore.Video.Media.SIZE)
                val dateCol = it.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)
                val widthCol = it.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightCol = it.getColumnIndex(MediaStore.Video.Media.HEIGHT)
                val bucketCol = it.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                while (it.moveToNext()) {
                    val id = if (idCol >= 0 && !it.isNull(idCol)) it.getLong(idCol) else -1L
                    if (id <= 0) continue

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    if (hiddenUris.contains(contentUri.toString())) {
                        continue
                    }

                    val title = if (titleCol >= 0 && !it.isNull(titleCol)) it.getString(titleCol) ?: "" else ""
                    val duration = if (durCol >= 0 && !it.isNull(durCol)) it.getLong(durCol) else 0L
                    val data = if (dataCol >= 0 && !it.isNull(dataCol)) it.getString(dataCol) ?: "" else ""
                    val size = if (sizeCol >= 0 && !it.isNull(sizeCol)) it.getLong(sizeCol) else 0L
                    val dateAdded = if (dateCol >= 0 && !it.isNull(dateCol)) it.getLong(dateCol) else 0L
                    val width = if (widthCol >= 0 && !it.isNull(widthCol)) it.getInt(widthCol) else 0
                    val height = if (heightCol >= 0 && !it.isNull(heightCol)) it.getInt(heightCol) else 0
                    val bucketName = if (bucketCol >= 0 && !it.isNull(bucketCol)) it.getString(bucketCol) ?: "" else ""

                    val folder = if (bucketName.isNotBlank()) {
                        bucketName
                    } else if (data.isNotBlank()) {
                        val parent = data.substringBeforeLast('/')
                        parent.substringAfterLast('/').ifBlank { "Videos" }
                    } else {
                        "Videos"
                    }

                    val cleanTitle = if (title.isNotBlank()) {
                        title
                    } else if (data.isNotBlank()) {
                        val fileName = data.substringAfterLast('/').substringBeforeLast('.')
                        fileName.ifBlank { "Video $id" }
                    } else {
                        "Video $id"
                    }

                    videoList.add(
                        VideoItem(
                            id = id,
                            title = cleanTitle,
                            durationMs = duration,
                            contentUri = contentUri,
                            thumbnailUri = contentUri,
                            folderName = folder,
                            dataPath = data,
                            sizeBytes = size,
                            dateAddedSecs = dateAdded,
                            width = width,
                            height = height
                        )
                    )
                }
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        videoList
    }

    fun findMatchingVideoForSong(song: SongItem, allVideos: List<VideoItem>): VideoItem? {
        val cleanSongTitle = cleanName(song.title)
        if (cleanSongTitle.length < 3) return null

        val cleanArtist = cleanName(song.artist)

        for (video in allVideos) {
            val cleanVideoTitle = cleanName(video.title)
            val titleMatch = cleanVideoTitle.contains(cleanSongTitle) || cleanSongTitle.contains(cleanVideoTitle)
            if (titleMatch) return video

            if (cleanArtist != "unknown" && cleanArtist.length > 3 && cleanVideoTitle.contains(cleanArtist)) {
                return video
            }
        }
        return null
    }

    private fun cleanName(raw: String): String {
        return raw.lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9]"), " ")
            .trim()
    }

    fun groupIntoAlbums(songs: List<SongItem>): List<AlbumItem> {
        return songs.groupBy { it.album }
            .map { (albumName, albumSongs) ->
                val first = albumSongs.first()
                AlbumItem(
                    id = first.id,
                    name = albumName,
                    artist = first.artist,
                    songCount = albumSongs.size,
                    artworkUri = first.albumArtUri
                )
            }
    }

    fun groupIntoArtists(songs: List<SongItem>): List<ArtistItem> {
        return songs.groupBy { it.artist }
            .map { (artistName, artistSongs) ->
                val albumCount = artistSongs.map { it.album }.distinct().size
                ArtistItem(
                    id = artistSongs.first().id,
                    name = artistName,
                    trackCount = artistSongs.size,
                    albumCount = albumCount
                )
            }
    }

    fun groupIntoFolders(songs: List<SongItem>, videos: List<VideoItem>): List<FolderItem> {
        val folderMap = mutableMapOf<String, Pair<Int, Int>>()

        songs.forEach { song ->
            val dir = File(song.dataPath).parent ?: "Music"
            val current = folderMap.getOrDefault(dir, Pair(0, 0))
            folderMap[dir] = Pair(current.first + 1, current.second)
        }

        videos.forEach { video ->
            val dir = File(video.dataPath).parent ?: "Video"
            val current = folderMap.getOrDefault(dir, Pair(0, 0))
            folderMap[dir] = Pair(current.first, current.second + 1)
        }

        return folderMap.map { (path, counts) ->
            FolderItem(
                name = File(path).name.ifEmpty { "Storage" },
                path = path,
                songCount = counts.first,
                videoCount = counts.second
            )
        }
    }
}
