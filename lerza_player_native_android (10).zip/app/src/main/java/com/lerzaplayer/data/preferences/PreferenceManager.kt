package com.lerzaplayer.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.ViewMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "lerza_preferences")

class PreferenceManager(private val context: Context) {
    companion object {
        private val KEY_THEME = stringPreferencesKey("app_theme")
        private val KEY_SORT = stringPreferencesKey("sort_option")
        private val KEY_VIEW_MODE = stringPreferencesKey("view_mode")
        private val KEY_RESUME_PLAYBACK = booleanPreferencesKey("resume_playback")
        private val KEY_AUTO_PLAY = booleanPreferencesKey("auto_play")
        private val KEY_SLEEP_TIMER = intPreferencesKey("sleep_timer_minutes")
        private val KEY_VAULT_PIN_HASH = stringPreferencesKey("vault_pin_hash")
        private val KEY_VAULT_PATTERN_HASH = stringPreferencesKey("vault_pattern_hash")
        private val KEY_VAULT_AUTO_LOCK_TIMEOUT = intPreferencesKey("vault_auto_lock_timeout")
    }

    val selectedTheme: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[KEY_THEME] ?: "Liquid Glass"
    }

    suspend fun setTheme(themeName: String) {
        context.dataStore.edit { preferences ->
            preferences[KEY_THEME] = themeName
        }
    }

    val sortOption: Flow<SortOption> = context.dataStore.data.map { preferences ->
        val name = preferences[KEY_SORT] ?: SortOption.DATE_ADDED.name
        try {
            SortOption.valueOf(name)
        } catch (_: Exception) {
            SortOption.DATE_ADDED
        }
    }

    suspend fun setSortOption(option: SortOption) {
        context.dataStore.edit { it[KEY_SORT] = option.name }
    }

    val viewMode: Flow<ViewMode> = context.dataStore.data.map { preferences ->
        val name = preferences[KEY_VIEW_MODE] ?: ViewMode.LIST.name
        try {
            ViewMode.valueOf(name)
        } catch (_: Exception) {
            ViewMode.LIST
        }
    }

    suspend fun setViewMode(mode: ViewMode) {
        context.dataStore.edit { it[KEY_VIEW_MODE] = mode.name }
    }

    val resumePlayback: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[KEY_RESUME_PLAYBACK] ?: true
    }

    suspend fun setResumePlayback(enabled: Boolean) {
        context.dataStore.edit { it[KEY_RESUME_PLAYBACK] = enabled }
    }

    val autoPlay: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[KEY_AUTO_PLAY] ?: true
    }

    suspend fun setAutoPlay(enabled: Boolean) {
        context.dataStore.edit { it[KEY_AUTO_PLAY] = enabled }
    }

    val vaultPinHash: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[KEY_VAULT_PIN_HASH]
    }

    suspend fun setVaultPinHash(hash: String?) {
        context.dataStore.edit { preferences ->
            if (hash == null) preferences.remove(KEY_VAULT_PIN_HASH)
            else preferences[KEY_VAULT_PIN_HASH] = hash
        }
    }

    val vaultPatternHash: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[KEY_VAULT_PATTERN_HASH]
    }

    suspend fun setVaultPatternHash(hash: String?) {
        context.dataStore.edit { preferences ->
            if (hash == null) preferences.remove(KEY_VAULT_PATTERN_HASH)
            else preferences[KEY_VAULT_PATTERN_HASH] = hash
        }
    }
}
