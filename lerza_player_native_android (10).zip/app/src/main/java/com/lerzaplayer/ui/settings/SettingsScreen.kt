package com.lerzaplayer.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    prefManager: PreferenceManager,
    playerManager: PlayerManager,
    onOpenVault: () -> Unit,
    onRescanMedia: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val currentTheme by prefManager.selectedTheme.collectAsState(initial = "Liquid Glass")
    val resumePlayback by prefManager.resumePlayback.collectAsState(initial = true)
    val autoPlay by prefManager.autoPlay.collectAsState(initial = true)

    var sleepDialog by remember { mutableStateOf(false) }
    var scanNotice by remember { mutableStateOf(false) }

    val themesList = listOf(
        Pair("Liquid Glass", Color(0xFFF5F7FB)),
        Pair("Light", Color(0xFFFFFFFF)),
        Pair("Green", Color(0xFF00E676)),
        Pair("Blue", Color(0xFF2979FF)),
        Pair("Purple", Color(0xFF7C4DFF)),
        Pair("Red", Color(0xFFFF1744)),
        Pair("Orange", Color(0xFFFF9100)),
        Pair("Pink", Color(0xFFFF4081)),
        Pair("Teal", Color(0xFF00E5FF)),
        Pair("AMOLED", Color(0xFF000000))
    )

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "Settings",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // APPEARANCE: 10 Themes Selector
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "APPEARANCE",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Select Theme (Current: $currentTheme)",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Theme Swatches Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            themesList.take(5).forEach { (name, color) ->
                                ThemeSwatch(
                                    name = name,
                                    color = color,
                                    isSelected = currentTheme.equals(name, ignoreCase = true),
                                    onClick = {
                                        scope.launch { prefManager.setTheme(name) }
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            themesList.drop(5).forEach { (name, color) ->
                                ThemeSwatch(
                                    name = name,
                                    color = color,
                                    isSelected = currentTheme.equals(name, ignoreCase = true),
                                    onClick = {
                                        scope.launch { prefManager.setTheme(name) }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // PLAYBACK SETTINGS
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "PLAYBACK",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        ListItem(
                            headlineContent = { Text("Resume Playback") },
                            supportingContent = { Text("Remember last played audio position") },
                            trailingContent = {
                                Switch(
                                    checked = resumePlayback,
                                    onCheckedChange = { scope.launch { prefManager.setResumePlayback(it) } }
                                )
                            }
                        )
                        ListItem(
                            headlineContent = { Text("Auto Play Next") },
                            supportingContent = { Text("Automatically play subsequent tracks") },
                            trailingContent = {
                                Switch(
                                    checked = autoPlay,
                                    onCheckedChange = { scope.launch { prefManager.setAutoPlay(it) } }
                                )
                            }
                        )
                        ListItem(
                            headlineContent = { Text("Sleep Timer") },
                            supportingContent = { Text("Automatically pause after timeout") },
                            leadingContent = { Icon(Icons.Default.Timer, contentDescription = null) },
                            modifier = Modifier.clickable { sleepDialog = true }
                        )
                    }
                }
            }

            // LIBRARY & SECURITY
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "LIBRARY & PRIVACY",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        ListItem(
                            headlineContent = { Text("Scan Media") },
                            supportingContent = { Text("Rescan device for new audio & video files") },
                            leadingContent = { Icon(Icons.Default.Refresh, contentDescription = null) },
                            modifier = Modifier.clickable {
                                onRescanMedia()
                                scanNotice = true
                            }
                        )
                        ListItem(
                            headlineContent = { Text("Private Vault") },
                            supportingContent = { Text("Manage hidden songs and videos with PIN") },
                            leadingContent = { Icon(Icons.Default.Security, contentDescription = null) },
                            modifier = Modifier.clickable { onOpenVault() }
                        )
                        ListItem(
                            headlineContent = { Text("Equalizer") },
                            supportingContent = { Text("System audio enhancements & bass boost") },
                            leadingContent = { Icon(Icons.Default.Equalizer, contentDescription = null) },
                            modifier = Modifier.clickable { playerManager.setupEqualizer() }
                        )
                    }
                }
            }

            // ABOUT (Zero Ads)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "ABOUT LERZA PLAYER",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Lerza Player v1.0.0",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "100% Native Android, Offline-First Music & Video Player. Completely ad-free, private, and fast.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    if (sleepDialog) {
        val options = listOf(10, 20, 30, 45, 60)
        AlertDialog(
            onDismissRequest = { sleepDialog = false },
            title = { Text("Set Sleep Timer") },
            text = {
                Column {
                    options.forEach { mins ->
                        TextButton(
                            onClick = {
                                playerManager.setSleepTimer(mins)
                                sleepDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("$mins Minutes")
                        }
                    }
                    TextButton(
                        onClick = {
                            playerManager.cancelSleepTimer()
                            sleepDialog = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Turn Off Timer", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { sleepDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (scanNotice) {
        AlertDialog(
            onDismissRequest = { scanNotice = false },
            title = { Text("Media Scan") },
            text = { Text("Media scan requested. Refreshing device music and video indexes.") },
            confirmButton = {
                TextButton(onClick = { scanNotice = false }) { Text("OK") }
            }
        )
    }
}

@Composable
fun ThemeSwatch(
    name: String,
    color: Color,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(color)
                .border(
                    width = if (isSelected) 3.dp else 1.dp,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray,
                    shape = CircleShape
                )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
