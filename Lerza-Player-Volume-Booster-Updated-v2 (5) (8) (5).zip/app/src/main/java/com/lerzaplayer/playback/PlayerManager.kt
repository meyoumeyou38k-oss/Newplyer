package com.lerzaplayer.playback

import android.content.Context
import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.MediaMetadata
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

 data class EqualizerSnapshot(
    val bandCentersHz: List<Int> = emptyList(),
    val minimumBandLevel: Short = 0,
    val maximumBandLevel: Short = 0,
    val presetNames: List<String> = emptyList(),
    val bandLevels: List<Short> = emptyList(),
    val selectedPreset: Int? = null,
    val supported: Boolean = false
)

class PlayerManager private constructor(private val context: Context) {

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context).build()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val _currentSong = MutableStateFlow<SongItem?>(null)
    val currentSong: StateFlow<SongItem?> = _currentSong.asStateFlow()

    private val _currentVideo = MutableStateFlow<VideoItem?>(null)
    val currentVideo: StateFlow<VideoItem?> = _currentVideo.asStateFlow()

    private val _queue = MutableStateFlow<List<SongItem>>(emptyList())
    val queue: StateFlow<List<SongItem>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_ALL)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()


    private val _sleepTimerRemainingMinutes = MutableStateFlow(0)
    val sleepTimerRemainingMinutes: StateFlow<Int> = _sleepTimerRemainingMinutes.asStateFlow()

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var sleepTimerJob: Job? = null

    private val _equalizerSnapshot = MutableStateFlow(EqualizerSnapshot())
    val equalizerSnapshot: StateFlow<EqualizerSnapshot> = _equalizerSnapshot.asStateFlow()
    private var selectedEqualizerPreset: Int? = null

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                _isPlaying.value = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)
                } else if (playbackState == Player.STATE_ENDED) {
                    playNextTrack()
                }
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                initAudioEffects()
            }
        })

        scope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _currentPosition.value = exoPlayer.currentPosition
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)
                }
                delay(400)
            }
        }

        initAudioEffects()
    }

    private fun initAudioEffects() {
        try {
            val audioSessionId = exoPlayer.audioSessionId
            if (audioSessionId != 0) {
                releaseAudioEffects()
                equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
                bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
                virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
                publishEqualizerSnapshot()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            _equalizerSnapshot.value = EqualizerSnapshot()
        }
    }

    private fun releaseAudioEffects() {
        try {
            equalizer?.release()
            bassBoost?.release()
            virtualizer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            equalizer = null
            bassBoost = null
            virtualizer = null
            _equalizerSnapshot.value = EqualizerSnapshot()
        }
    }

    private fun publishEqualizerSnapshot() {
        try {
            val eq = equalizer ?: run {
                _equalizerSnapshot.value = EqualizerSnapshot()
                return
            }
            val range = eq.bandLevelRange
            val bandCount = eq.numberOfBands.toInt()
            val presetCount = eq.numberOfPresets.toInt()
            _equalizerSnapshot.value = EqualizerSnapshot(
                bandCentersHz = (0 until bandCount).map { band ->
                    eq.getCenterFreq(band.toShort()).coerceAtLeast(0) / 1000
                },
                minimumBandLevel = range[0],
                maximumBandLevel = range[1],
                presetNames = (0 until presetCount).map { preset -> eq.getPresetName(preset.toShort()) },
                bandLevels = (0 until bandCount).map { band -> eq.getBandLevel(band.toShort()) },
                selectedPreset = selectedEqualizerPreset,
                supported = bandCount > 0
            )
        } catch (e: Exception) {
            e.printStackTrace()
            _equalizerSnapshot.value = EqualizerSnapshot()
        }
    }

    fun playSongList(songs: List<SongItem>, startIndex: Int) {
        if (songs.isEmpty() || startIndex !in songs.indices) return
        _queue.value = songs
        _currentIndex.value = startIndex
        val song = songs[startIndex]
        _currentSong.value = song
        _currentVideo.value = null

        exoPlayer.setMediaItem(mediaItemFor(song))
        exoPlayer.prepare()
        exoPlayer.play()
        ContextCompat.startForegroundService(context, Intent(context, PlaybackService::class.java))
    }

    fun setPlaylist(songs: List<SongItem>, startIndex: Int) {
        playSongList(songs, startIndex)
    }

    fun playSong(song: SongItem) {
        playSongList(listOf(song), 0)
    }

    /** Inserts a song immediately after the current track without interrupting playback. */
    fun playNext(song: SongItem) {
        val songs = _queue.value
        if (songs.isEmpty()) {
            playSong(song)
            return
        }

        val insertionIndex = (_currentIndex.value + 1).coerceIn(0, songs.size)
        _queue.value = songs.toMutableList().apply { add(insertionIndex, song) }
    }

        .setUri(song.contentUri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(song.album)
                .setArtworkUri(song.albumArtUri)
                .build()
        )
        .build()
    fun addToQueue(song: SongItem) {
        _queue.value = _queue.value + song
    }

    fun removeFromQueue(index: Int) {
        if (index in _queue.value.indices) {
            val currentList = _queue.value.toMutableList()
            currentList.removeAt(index)
            _queue.value = currentList
            if (index < _currentIndex.value) {
                _currentIndex.value = (_currentIndex.value - 1).coerceAtLeast(0)
            }
        }
    }

    fun clearQueue() {
        _queue.value = emptyList()
        _currentSong.value = null
        exoPlayer.stop()
    }

    fun playPause() {
        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
    }

    fun play() {
        exoPlayer.play()
    }

    fun pause() {
        exoPlayer.pause()
    }

    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs)
        _currentPosition.value = positionMs
    }

    fun playNextTrack() {
        val songs = _queue.value
        if (songs.isEmpty()) return

        if (_repeatMode.value == Player.REPEAT_MODE_ONE) {
            seekTo(0)
            play()
            return
        }

        val nextIndex = if (_isShuffle.value) songs.indices.random() else (_currentIndex.value + 1) % songs.size
        if (nextIndex == 0 && _repeatMode.value == Player.REPEAT_MODE_OFF) {
            exoPlayer.pause()
            seekTo(0)
            return
        }

        _currentIndex.value = nextIndex
        val song = songs[nextIndex]
        _currentSong.value = song
        _currentVideo.value = null
        exoPlayer.setMediaItem(mediaItemFor(song))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun playPreviousTrack() {
        val songs = _queue.value
        if (songs.isEmpty()) return
        if (exoPlayer.currentPosition > 3000L) {
            seekTo(0)
            return
        }

        val previousIndex = if (_currentIndex.value > 0) _currentIndex.value - 1 else songs.size - 1
        _currentIndex.value = previousIndex
        val song = songs[previousIndex]
        _currentSong.value = song
        _currentVideo.value = null
        exoPlayer.setMediaItem(mediaItemFor(song))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun toggleShuffle() {
        _isShuffle.value = !_isShuffle.value
    }

    fun cycleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
            else -> Player.REPEAT_MODE_ALL
        }
        exoPlayer.repeatMode = _repeatMode.value
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        exoPlayer.playbackParameters = PlaybackParameters(speed)
    }


    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _sleepTimerRemainingMinutes.value = minutes.coerceAtLeast(0)
        if (minutes <= 0) return

        sleepTimerJob = scope.launch {
            var remaining = minutes
            while (remaining > 0) {
                delay(60_000)
                remaining--
                _sleepTimerRemainingMinutes.value = remaining
            }
            pause()
        }
    }

    fun setEqualizerPreset(presetIndex: Short) {
        try {
            val eq = equalizer ?: return
            if (presetIndex < 0 || presetIndex >= eq.numberOfPresets) return
            eq.usePreset(presetIndex)
            selectedEqualizerPreset = presetIndex.toInt()
            publishEqualizerSnapshot()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setEqualizerBand(band: Short, level: Short) {
        try {
            val eq = equalizer ?: return
            if (band.toInt() in 0 until eq.numberOfBands.toInt()) {
                val range = eq.bandLevelRange
                eq.setBandLevel(band, level.coerceIn(range[0], range[1]))
                selectedEqualizerPreset = null
                publishEqualizerSnapshot()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setBassBoostStrength(strength: Short) {
        try {
            bassBoost?.setStrength(strength.coerceIn(0, 1000))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setVirtualizerStrength(strength: Short) {
        try {
            virtualizer?.setStrength(strength.coerceIn(0, 1000))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun release() {
        sleepTimerJob?.cancel()
        scope.cancel()
        releaseAudioEffects()
        exoPlayer.release()
    }

    companion object {
        @Volatile
        private var INSTANCE: PlayerManager? = null

        fun getInstance(context: Context): PlayerManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PlayerManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
