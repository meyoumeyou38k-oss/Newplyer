@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@file:androidx.media3.common.util.UnstableApi
@file:Suppress("UnsafeOptInUsageError", "OPT_IN_USAGE_DEFAULT", "DEPRECATION")

package com.lerzaplayer.ui.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.net.Uri
import android.provider.Settings
import android.util.Rational
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.playback.PlaytimeTracker
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

enum class VideoGestureMode {
    VOLUME,
    BRIGHTNESS
}

enum class DoubleTapSide {
    LEFT,
    RIGHT
}

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@androidx.media3.common.util.UnstableApi
@Composable
fun VideoPlayerScreen(
    video: VideoItem,
    onClose: () -> Unit,
    onPreviousVideo: () -> Unit = {},
    onNextVideo: () -> Unit = {},
    onPlayAsAudio: () -> Unit = {},
    onDeleteVideo: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()
    val activeThemeColor = remember(ThemeManager.currentThemeColor) { ThemeManager.currentThemeColor }

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager }
    val maxAudioVolume = remember(audioManager) {
        audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15
    }

    // AudioSession and LoudnessEnhancer for 300% Volume Boost
    var audioSessionId by remember { mutableIntStateOf(0) }
    var loudnessEnhancer by remember { mutableStateOf<LoudnessEnhancer?>(null) }
    var volumePercent by remember { mutableIntStateOf(100) }

    // ExoPlayer initialization
    val exoPlayer = remember(video.id, video.contentUri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.contentUri))
            prepare()
            playWhenReady = true
        }
    }

    // Playback state variables
    var isPlaying by remember { mutableStateOf(true) }
    var currentPos by remember { mutableLongStateOf(0L) }
    var totalDur by remember { mutableLongStateOf(if (video.duration > 0) video.duration else 1L) }
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPos by remember { mutableFloatStateOf(0f) }

    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var isLandscape by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }

    // Dialog & Menu visibility states
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showAudioTracks by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var isLooping by remember { mutableStateOf(false) }

    // Long press 6x speed fast-forward state
    var is6xFastForwarding by remember { mutableStateOf(false) }

    // Pinch-to-zoom & pan states
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var zoomOffsetX by remember { mutableFloatStateOf(0f) }
    var zoomOffsetY by remember { mutableFloatStateOf(0f) }

    // Vertical Swipe Gesture HUD Overlay States (Brightness on Left 25%, Volume 0-300% on Right 25%)
    var activeGesture by remember { mutableStateOf<VideoGestureMode?>(null) }
    var gestureProgress by remember { mutableFloatStateOf(0f) }
    var gestureHideJob by remember { mutableStateOf<Job?>(null) }

    // Double-tap Seek Chaining states (+10s, +20s, +30s... on Right; -10s, -20s, -30s... on Left)
    var doubleTapSide by remember { mutableStateOf<DoubleTapSide?>(null) }
    var accumulatedSeekSeconds by remember { mutableIntStateOf(0) }
    var doubleTapResetJob by remember { mutableStateOf<Job?>(null) }

    // Back button behavior: If in landscape mode, pressing back returns to portrait first!
    BackHandler(enabled = isLandscape) {
        isLandscape = false
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }

    // Synchronize initial volume
    LaunchedEffect(Unit) {
        val curVol = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: (maxAudioVolume / 2)
        volumePercent = ((curVol.toFloat() / maxAudioVolume.coerceAtLeast(1).toFloat()) * 100f).toInt().coerceIn(0, 100)
    }

    // Apply volume boost up to 300%
    fun applyVolumeAndBoost(targetPercent: Int) {
        val clampedPercent = targetPercent.coerceIn(0, 300)
        volumePercent = clampedPercent
        if (clampedPercent <= 100) {
            val streamVol = ((clampedPercent / 100f) * maxAudioVolume).toInt().coerceIn(0, maxAudioVolume)
            audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, streamVol, 0)
            try {
                loudnessEnhancer?.apply {
                    setTargetGain(0)
                    enabled = false
                }
            } catch (_: Exception) {}
        } else {
            // Hardware Boost active (>100% up to 300%)
            audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, maxAudioVolume, 0)
            try {
                if (loudnessEnhancer == null && audioSessionId != 0 && audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
                    loudnessEnhancer = LoudnessEnhancer(audioSessionId)
                }
                val boostGainMb = ((clampedPercent - 100) * 35).coerceAtLeast(0)
                loudnessEnhancer?.apply {
                    enabled = true
                    setTargetGain(boostGainMb)
                }
            } catch (_: Exception) {}
        }
    }

    // Player Event Listener
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    val d = exoPlayer.duration
                    if (d > 0) {
                        totalDur = d
                    }
                } else if (playbackState == Player.STATE_ENDED) {
                    if (!isLooping) {
                        onNextVideo()
                    }
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onAudioSessionIdChanged(newAudioSessionId: Int) {
                audioSessionId = newAudioSessionId
                if (newAudioSessionId != C.AUDIO_SESSION_ID_UNSET && newAudioSessionId != 0) {
                    try {
                        loudnessEnhancer?.release()
                        loudnessEnhancer = LoudnessEnhancer(newAudioSessionId).apply {
                            if (volumePercent > 100) {
                                enabled = true
                                setTargetGain((volumePercent - 100) * 35)
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            try {
                loudnessEnhancer?.release()
                loudnessEnhancer = null
            } catch (_: Exception) {}
            exoPlayer.release()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Handle seamless next video transition: Reset timeline and position immediately without bug
    LaunchedEffect(video.id) {
        currentPos = 0L
        scrubPos = 0f
        isScrubbing = false
        totalDur = if (video.duration > 0) video.duration else 1L
        isPlaying = true
        controlsVisible = true
        zoomScale = 1f
        zoomOffsetX = 0f
        zoomOffsetY = 0f
    }

    // Auto-hide controls timer: Paused when 3-dots menu or any dialog is open
    LaunchedEffect(controlsVisible, showMoreMenu, showSpeedDialog, showInfoDialog, showAudioTracks, showDeleteConfirm) {
        if (controlsVisible && !isLocked && !showMoreMenu && !showSpeedDialog && !showInfoDialog && !showAudioTracks && !showDeleteConfirm) {
            delay(4200)
            controlsVisible = false
        }
    }

    // Continuous progress tracker loop
    LaunchedEffect(exoPlayer) {
        while (isActive) {
            if (exoPlayer.isPlaying && !isScrubbing) {
                currentPos = exoPlayer.currentPosition
                val d = exoPlayer.duration
                if (d > 0) {
                    totalDur = d
                }
                PlaytimeTracker.addVideoTime(context, 350L)
            }
            delay(350)
        }
    }

    // Audio track options
    val audioTrackOptions = remember(exoPlayer.currentTracks) {
        exoPlayer.currentTracks.groups
            .filter { it.type == C.TRACK_TYPE_AUDIO }
            .flatMap { group ->
                (0 until group.length).map { index ->
                    val format = group.getTrackFormat(index)
                    AudioTrackOption(
                        group = group.mediaTrackGroup,
                        index = index,
                        label = format.label ?: format.language ?: "Audio ${index + 1}"
                    )
                }
            }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            // 1. Gesture detection: Left 25% for Brightness, Right 25% for Volume (Single full swipe 0 to 100% / 0 to 300%)
            .pointerInput(isLocked) {
                if (!isLocked) {
                    var totalDragY = 0f
                    var initialValue = 0f
                    val screenHeight = size.height.toFloat()
                    val screenWidth = size.width.toFloat()

                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            if (offset.y >= screenHeight * 0.72f) return@detectVerticalDragGestures
                            
                            val isLeft25 = offset.x <= (screenWidth * 0.25f)
                            val isRight25 = offset.x >= (screenWidth * 0.75f)

                            // Only activate swipe if touched in the left 25% or right 25% zones
                            if (!isLeft25 && !isRight25) {
                                activeGesture = null
                                return@detectVerticalDragGestures
                            }

                            gestureHideJob?.cancel()
                            totalDragY = 0f

                            if (isRight25) {
                                // Right 25%: Volume Control (0 to 300% Boost)
                                activeGesture = VideoGestureMode.VOLUME
                                initialValue = volumePercent.toFloat()
                                gestureProgress = initialValue
                            } else {
                                // Left 25%: Screen Brightness Control (0 to 100%)
                                activeGesture = VideoGestureMode.BRIGHTNESS
                                val curBrightness = activity?.window?.attributes?.screenBrightness ?: -1f
                                val brVal = if (curBrightness < 0f) {
                                    try {
                                        Settings.System.getInt(
                                            context.contentResolver,
                                            Settings.System.SCREEN_BRIGHTNESS
                                        ) / 255f
                                    } catch (_: Exception) { 0.5f }
                                } else curBrightness
                                initialValue = (brVal * 100f).coerceIn(0f, 100f)
                                gestureProgress = initialValue
                            }
                        },
                        onVerticalDrag = { change, dragAmount ->
                            if (activeGesture == null) return@detectVerticalDragGestures
                            change.consume()
                            totalDragY -= dragAmount
                            // Swipe ratio: Full height of the swipe area covers the complete range (0 to 100% or 0 to 300%)
                            val dragFraction = totalDragY / (screenHeight * 0.60f)

                            if (activeGesture == VideoGestureMode.VOLUME) {
                                // Volume: can reach from 0% to 300% in a single smooth swipe
                                val newVol = (initialValue + dragFraction * 300f).coerceIn(0f, 300f)
                                gestureProgress = newVol
                                applyVolumeAndBoost(newVol.toInt())
                            } else if (activeGesture == VideoGestureMode.BRIGHTNESS) {
                                // Brightness: 0 to 100% in a single smooth swipe
                                val newBr = (initialValue + dragFraction * 100f).coerceIn(0f, 100f)
                                gestureProgress = newBr
                                val lp = activity?.window?.attributes
                                if (lp != null) {
                                    lp.screenBrightness = (newBr / 100f).coerceIn(0.01f, 1.0f)
                                    activity.window.attributes = lp
                                }
                            }
                        },
                        onDragEnd = {
                            gestureHideJob = scope.launch {
                                delay(1200)
                                activeGesture = null
                            }
                        },
                        onDragCancel = {
                            activeGesture = null
                        }
                    )
                }
            }
            // 2. Tap, Double-Tap with Consecutive Chaining (+/-10s, +/-20s...), and Long-Press (6x Speed)
            .pointerInput(isLocked, playbackSpeed, totalDur) {
                detectTapGestures(
                    onPress = { offset ->
                        if (!isLocked) {
                            val originalSpeed = playbackSpeed
                            var isSpeeding = false
                            try {
                                val released = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                    tryAwaitRelease()
                                }
                                if (released == null) {
                                    isSpeeding = true
                                    is6xFastForwarding = true
                                    exoPlayer.playbackParameters = PlaybackParameters(6.0f)
                                    tryAwaitRelease()
                                }
                            } finally {
                                if (isSpeeding) {
                                    is6xFastForwarding = false
                                    exoPlayer.playbackParameters = PlaybackParameters(originalSpeed)
                                }
                            }
                        }
                    },
                    onTap = {
                        if (!isLocked) {
                            if (doubleTapSide != null && accumulatedSeekSeconds != 0) {
                                val isRight = doubleTapSide == DoubleTapSide.RIGHT
                                val step = if (isRight) 10 else -10
                                accumulatedSeekSeconds += step

                                val newTarget = (exoPlayer.currentPosition + (step * 1000L)).coerceIn(0L, totalDur)
                                exoPlayer.seekTo(newTarget)
                                currentPos = newTarget

                                doubleTapResetJob?.cancel()
                                doubleTapResetJob = scope.launch {
                                    delay(750)
                                    doubleTapSide = null
                                    accumulatedSeekSeconds = 0
                                }
                            } else {
                                controlsVisible = !controlsVisible
                            }
                        } else {
                            controlsVisible = true
                        }
                    },
                    onDoubleTap = { offset ->
                        if (!isLocked) {
                            val isRight = offset.x >= (size.width / 2f)
                            doubleTapSide = if (isRight) DoubleTapSide.RIGHT else DoubleTapSide.LEFT
                            accumulatedSeekSeconds = if (isRight) 10 else -10

                            val newTarget = (exoPlayer.currentPosition + (accumulatedSeekSeconds * 1000L)).coerceIn(0L, totalDur)
                            exoPlayer.seekTo(newTarget)
                            currentPos = newTarget

                            doubleTapResetJob?.cancel()
                            doubleTapResetJob = scope.launch {
                                delay(750)
                                doubleTapSide = null
                                accumulatedSeekSeconds = 0
                            }
                        }
                    }
                )
            }
    ) {
        // Video Viewport with Pinch-To-Zoom & Pan
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    this.resizeMode = resizeMode
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { playerView ->
                playerView.player = exoPlayer
                playerView.resizeMode = resizeMode
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = zoomScale,
                    scaleY = zoomScale,
                    translationX = zoomOffsetX,
                    translationY = zoomOffsetY
                )
                .pointerInput(isLocked) {
                    if (!isLocked) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val newScale = (zoomScale * zoom).coerceIn(1f, 5.0f)
                            zoomScale = newScale
                            if (newScale > 1f) {
                                val maxPanX = (size.width * (newScale - 1f)) / 2f
                                val maxPanY = (size.height * (newScale - 1f)) / 2f
                                zoomOffsetX = (zoomOffsetX + pan.x * newScale).coerceIn(-maxPanX, maxPanX)
                                zoomOffsetY = (zoomOffsetY + pan.y * newScale).coerceIn(-maxPanY, maxPanY)
                            } else {
                                zoomOffsetX = 0f
                                zoomOffsetY = 0f
                            }
                        }
                    }
                }
        )

        // ═══════════════════════════════════════════════════════════════
        // SCREENSHOT 2: LEFT SIDE BRIGHTNESS HUD (Vertical Pill Slider)
        // ═══════════════════════════════════════════════════════════════
        AnimatedVisibility(
            visible = activeGesture == VideoGestureMode.BRIGHTNESS,
            enter = fadeIn(tween(150)),
            exit = fadeOut(tween(250)),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 24.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.BrightnessMedium,
                    contentDescription = "Brightness",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "${gestureProgress.toInt()}%",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Box(
                    modifier = Modifier
                        .width(32.dp)
                        .height(160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(alpha = 0.28f)),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    val fillFrac = (gestureProgress / 100f).coerceIn(0f, 1f)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(fillFrac)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White)
                    )
                }
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // SCREENSHOT 1: RIGHT SIDE VOLUME HUD (Vertical Pill Slider with 300% Boost)
        // ═══════════════════════════════════════════════════════════════
        AnimatedVisibility(
            visible = activeGesture == VideoGestureMode.VOLUME,
            enter = fadeIn(tween(150)),
            exit = fadeOut(tween(250)),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 24.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val isBoosted = gestureProgress > 100f
                Icon(
                    imageVector = if (gestureProgress <= 0f) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                    contentDescription = "Volume",
                    tint = if (isBoosted) activeThemeColor else Color.White,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "${gestureProgress.toInt()}%",
                    color = if (isBoosted) activeThemeColor else Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Box(
                    modifier = Modifier
                        .width(32.dp)
                        .height(160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(alpha = 0.28f)),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    val fillFrac = (gestureProgress / 300f).coerceIn(0f, 1f)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(fillFrac)
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isBoosted) activeThemeColor else Color.White)
                    )
                }
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // 6X SPEED LONG-PRESS HUD PILL (Top Center)
        // ═══════════════════════════════════════════════════════════════
        AnimatedVisibility(
            visible = is6xFastForwarding,
            enter = fadeIn(tween(120)),
            exit = fadeOut(tween(200)),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 68.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.Black.copy(alpha = 0.85f),
                border = BorderStroke(1.5.dp, activeThemeColor),
                shadowElevation = 10.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.FastForward,
                        contentDescription = null,
                        tint = activeThemeColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "6X Speed",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // DOUBLE-TAP SEEK OVERLAYS (+10s, +20s on Right; -10s, -20s on Left)
        // ═══════════════════════════════════════════════════════════════
        AnimatedVisibility(
            visible = doubleTapSide == DoubleTapSide.RIGHT,
            enter = fadeIn(tween(100)),
            exit = fadeOut(tween(200)),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 40.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.72f),
                border = BorderStroke(1.2.dp, activeThemeColor.copy(alpha = 0.8f))
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.FastForward,
                        contentDescription = "Forward",
                        tint = activeThemeColor,
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = "+${accumulatedSeekSeconds}s",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = doubleTapSide == DoubleTapSide.LEFT,
            enter = fadeIn(tween(100)),
            exit = fadeOut(tween(200)),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 40.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.72f),
                border = BorderStroke(1.2.dp, activeThemeColor.copy(alpha = 0.8f))
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.FastRewind,
                        contentDescription = "Rewind",
                        tint = activeThemeColor,
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = "${accumulatedSeekSeconds}s",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // ═══════════════════════════════════════════════════════════════
        // SCREENSHOT 3: OVERLAY CONTROLS (Top Bar, Action Row, Timeline, Bottom Row)
        // ═══════════════════════════════════════════════════════════════
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(200)),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.50f))
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                // Top Bar: Back Button, Video Title, 3-Dots Menu Button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        VideoGlassIconButton(
                            icon = LerzaIcons.ArrowBack,
                            contentDescription = "Back",
                            onClick = {
                                if (isLandscape) {
                                    isLandscape = false
                                    activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                } else {
                                    onClose()
                                }
                            }
                        )
                        Text(
                            text = video.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!isLocked) {
                            Box {
                                VideoGlassIconButton(
                                    icon = LerzaIcons.MoreVert,
                                    contentDescription = "Options",
                                    onClick = { showMoreMenu = true }
                                )

                                // 3-Dots Menu: Deep Dark Charcoal Background with High-Contrast Options
                                DropdownMenu(
                                    expanded = showMoreMenu,
                                    onDismissRequest = { showMoreMenu = false },
                                    modifier = Modifier
                                        .background(Color(0xFF0F131A))
                                        .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(14.dp))
                                ) {
                                    VideoMenuItem(
                                        icon = LerzaIcons.Share,
                                        title = "Share",
                                        accentTint = Color(0xFF38BDF8),
                                        onClick = {
                                            showMoreMenu = false
                                            runCatching {
                                                val share = Intent(Intent.ACTION_SEND).apply {
                                                    type = "video/*"
                                                    putExtra(Intent.EXTRA_STREAM, video.contentUri)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(share, "Share video"))
                                            }
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.Videocam,
                                        title = "Floating window",
                                        accentTint = Color(0xFF2DD4BF),
                                        onClick = {
                                            showMoreMenu = false
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                runCatching {
                                                    activity?.enterPictureInPictureMode(
                                                        PictureInPictureParams.Builder()
                                                            .setAspectRatio(Rational(16, 9))
                                                            .build()
                                                    )
                                                }
                                            }
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.Repeat,
                                        title = if (isLooping) "Repeat: One" else "Repeat: Off",
                                        accentTint = Color(0xFFA78BFA),
                                        onClick = {
                                            isLooping = !isLooping
                                            exoPlayer.repeatMode = if (isLooping) {
                                                Player.REPEAT_MODE_ONE
                                            } else {
                                                Player.REPEAT_MODE_OFF
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.AspectRatio,
                                        title = "Scale adjust",
                                        accentTint = Color(0xFF34D399),
                                        onClick = {
                                            resizeMode = when (resizeMode) {
                                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.ScreenRotation,
                                        title = if (isLandscape) "Switch to Portrait" else "Switch to Landscape",
                                        accentTint = Color(0xFF60A5FA),
                                        onClick = {
                                            isLandscape = !isLandscape
                                            activity?.requestedOrientation = if (isLandscape) {
                                                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                            } else {
                                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.Info,
                                        title = "Video details",
                                        accentTint = Color(0xFFFBBF24),
                                        onClick = {
                                            showMoreMenu = false
                                            showInfoDialog = true
                                        }
                                    )
                                    HorizontalDivider(color = Color.White.copy(alpha = 0.12f), thickness = 0.8.dp)
                                    VideoMenuItem(
                                        icon = LerzaIcons.Delete,
                                        title = "Delete video",
                                        accentTint = Color(0xFFFF4D4D),
                                        textColor = Color(0xFFFF4D4D),
                                        onClick = {
                                            showMoreMenu = false
                                            showDeleteConfirm = true
                                        }
                                    )
                                }
                            }
                        } else {
                            VideoGlassIconButton(
                                icon = LerzaIcons.Lock,
                                contentDescription = "Unlock controls",
                                tint = activeThemeColor,
                                onClick = { isLocked = false }
                            )
                        }
                    }
                }

                // Bottom Panel: Actions Row (with Rotate Button) + Timeline Scrubber + Bottom Playback Buttons
                if (!isLocked) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // 1. Actions Row: Headphones, Speedometer, Lock, ROTATE, AspectRatio
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Audio only / headphone
                            IconButton(onClick = onPlayAsAudio, modifier = Modifier.size(44.dp)) {
                                Icon(
                                    imageVector = LerzaIcons.Headphones,
                                    contentDescription = "Play as audio",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            // Speedometer with speed label
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { showSpeedDialog = true }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = LerzaIcons.Speed,
                                    contentDescription = "Playback speed",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    text = "${playbackSpeed}x",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Lock screen controls
                            IconButton(
                                onClick = {
                                    isLocked = true
                                    controlsVisible = false
                                },
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = LerzaIcons.Lock,
                                    contentDescription = "Lock controls",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            // Screen Rotation Button (Rotates video to 16:9 full landscape / portrait)
                            IconButton(
                                onClick = {
                                    isLandscape = !isLandscape
                                    activity?.requestedOrientation = if (isLandscape) {
                                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    } else {
                                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                    }
                                },
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = LerzaIcons.ScreenRotation,
                                    contentDescription = "Rotate video",
                                    tint = if (isLandscape) activeThemeColor else Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            // Aspect Ratio
                            IconButton(
                                onClick = {
                                    resizeMode = when (resizeMode) {
                                        AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                        AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    }
                                },
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = LerzaIcons.AspectRatio,
                                    contentDescription = "Scale adjust",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        // 2. Timeline Progress Bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val curSec = if (isScrubbing) (scrubPos * totalDur).toLong() / 1000L else currentPos / 1000L
                            val totSec = totalDur / 1000L

                            Text(
                                text = "%d:%02d".format(curSec / 60, curSec % 60),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(42.dp),
                                textAlign = TextAlign.Start
                            )

                            val progressFraction = if (totalDur > 0) {
                                if (isScrubbing) scrubPos else (currentPos.toFloat() / totalDur.toFloat()).coerceIn(0f, 1f)
                            } else 0f

                            Slider(
                                value = progressFraction,
                                onValueChange = { frac ->
                                    isScrubbing = true
                                    scrubPos = frac
                                },
                                onValueChangeFinished = {
                                    val target = (scrubPos * totalDur).toLong().coerceIn(0L, totalDur)
                                    exoPlayer.seekTo(target)
                                    currentPos = target
                                    isScrubbing = false
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = activeThemeColor,
                                    activeTrackColor = activeThemeColor,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(28.dp)
                            )

                            Text(
                                text = "%d:%02d".format(totSec / 60, totSec % 60),
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(42.dp),
                                textAlign = TextAlign.End
                            )
                        }

                        // 3. Bottom Playback Controls
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.Black.copy(alpha = 0.40f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
                                modifier = Modifier.size(52.dp)
                            ) {
                                IconButton(onClick = onPreviousVideo, modifier = Modifier.fillMaxSize()) {
                                    Icon(
                                        imageVector = LerzaIcons.SkipPrevious,
                                        contentDescription = "Previous video",
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(28.dp))

                            Surface(
                                shape = CircleShape,
                                color = Color.Black.copy(alpha = 0.48f),
                                border = BorderStroke(1.2.dp, Color.White.copy(alpha = 0.28f)),
                                modifier = Modifier.size(68.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        if (exoPlayer.isPlaying) {
                                            exoPlayer.pause()
                                            isPlaying = false
                                        } else {
                                            exoPlayer.play()
                                            isPlaying = true
                                        }
                                    },
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) LerzaIcons.Pause else LerzaIcons.PlayArrow,
                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                        tint = Color.White,
                                        modifier = Modifier.size(34.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(28.dp))

                            Surface(
                                shape = CircleShape,
                                color = Color.Black.copy(alpha = 0.40f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
                                modifier = Modifier.size(52.dp)
                            ) {
                                IconButton(onClick = onNextVideo, modifier = Modifier.fillMaxSize()) {
                                    Icon(
                                        imageVector = LerzaIcons.SkipNext,
                                        contentDescription = "Next video",
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Speed Dialog
        if (showSpeedDialog) {
            AlertDialog(
                onDismissRequest = { showSpeedDialog = false },
                title = { Text("Playback Speed", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (playbackSpeed == spd) activeThemeColor.copy(alpha = 0.25f) else Color.Transparent)
                                    .clickable {
                                        playbackSpeed = spd
                                        exoPlayer.playbackParameters = PlaybackParameters(spd)
                                        showSpeedDialog = false
                                    }
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (spd == 1.0f) "1.0x (Normal)" else "${spd}x",
                                    color = if (playbackSpeed == spd) activeThemeColor else Color.White,
                                    fontWeight = if (playbackSpeed == spd) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSpeedDialog = false }) {
                        Text("Cancel", color = activeThemeColor)
                    }
                },
                containerColor = Color(0xFF131922)
            )
        }

        // Info Dialog
        if (showInfoDialog) {
            AlertDialog(
                onDismissRequest = { showInfoDialog = false },
                title = { Text("Video Details", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Title: ${video.title}", color = Color.White, fontSize = 13.sp)
                        Text("Duration: ${video.durationFormatted}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text("Resolution: ${video.resolution}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text("Folder: ${video.folderName}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text("Location: ${video.path}", color = Color.Gray, fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showInfoDialog = false }) {
                        Text("OK", color = activeThemeColor)
                    }
                },
                containerColor = Color(0xFF131922)
            )
        }

        // Audio Tracks Dialog
        if (showAudioTracks) {
            AlertDialog(
                onDismissRequest = { showAudioTracks = false },
                title = { Text("Audio Track", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    if (audioTrackOptions.isEmpty()) {
                        Text("No alternate audio tracks are available for this video.", color = Color.White.copy(alpha = 0.8f))
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            audioTrackOptions.forEach { option ->
                                TextButton(
                                    onClick = {
                                        exoPlayer.trackSelectionParameters =
                                            exoPlayer.trackSelectionParameters.buildUpon()
                                                .setOverrideForType(TrackSelectionOverride(option.group, option.index))
                                                .build()
                                        showAudioTracks = false
                                    }
                                ) {
                                    Text(option.label, color = activeThemeColor)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showAudioTracks = false }) {
                        Text("Close", color = activeThemeColor)
                    }
                },
                containerColor = Color(0xFF131922)
            )
        }

        // Delete Confirm Dialog
        if (showDeleteConfirm) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirm = false },
                title = { Text("Delete this video?", color = Color.White, fontWeight = FontWeight.Bold) },
                text = { Text("This removes the video from device storage permanently.", color = Color.White.copy(alpha = 0.8f)) },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showDeleteConfirm = false
                            onDeleteVideo()
                            onClose()
                        }
                    ) { Text("Delete", color = Color(0xFFFF334B), fontWeight = FontWeight.Bold) }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel", color = Color.White) }
                },
                containerColor = Color(0xFF131922)
            )
        }
    }
}

@Composable
private fun VideoGlassIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String?,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Surface(
        shape = CircleShape,
        color = Color.Black.copy(alpha = 0.40f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
        modifier = Modifier.size(40.dp)
    ) {
        IconButton(onClick = onClick, modifier = Modifier.fillMaxSize()) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = tint,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun VideoMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    accentTint: Color = Color(0xFF00E5FF),
    textColor: Color = Color.White,
    onClick: () -> Unit
) {
    DropdownMenuItem(
        text = {
            Text(
                text = title,
                color = textColor,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.SemiBold
            )
        },
        leadingIcon = {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentTint.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentTint,
                    modifier = Modifier.size(17.dp)
                )
            }
        },
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
    )
}

private data class AudioTrackOption(
    val group: TrackGroup,
    val index: Int,
    val label: String
)