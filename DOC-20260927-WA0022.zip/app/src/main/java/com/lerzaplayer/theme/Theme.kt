package com.lerzaplayer.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// مکمل اور مستند Palette کلاس جس میں تمام فیلڈز شامل ہیں
data class LerzaColorPalette(
    val primary: Color,
    val primaryVariant: Color,
    val accent: Color,
    val secondary: Color = accent,
    val card: Color,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val divider: Color,
    val isDark: Boolean
)

val LocalLerzaColors = staticCompositionLocalOf {
    LerzaColorPalette(
        primary = LerzaBlue,
        primaryVariant = LerzaBlueDark,
        accent = LerzaBlue,
        secondary = LerzaBlue,
        card = DarkSurface,
        background = DarkBackground,
        surface = DarkSurface,
        surfaceVariant = DarkSurfaceVariant,
        textPrimary = DarkTextPrimary,
        textSecondary = DarkTextSecondary,
        divider = DarkDivider,
        isDark = true
    )
}

object LerzaTheme {
    val colors: LerzaColorPalette
        @Composable
        @ReadOnlyComposable
        get() = LocalLerzaColors.current
}

// تھیم کے نام کے مطابق رنگ حاصل کرنا
fun getColorByThemeName(themeName: String): Color {
    return when (themeName.lowercase()) {
        "blue", "default" -> LerzaBlue
        "green" -> LarkGreen
        "purple" -> LarkPurple
        "orange" -> LarkOrange
        "red" -> LarkRed
        "pink" -> LarkPink
        "cyan" -> LarkCyan
        "amber", "yellow" -> LarkAmber
        else -> LerzaBlue
    }
}

// مرکزی فنکشن Palette بنانے کے لیے
fun getLerzaPalette(themeColor: Color, isDark: Boolean = true): LerzaColorPalette {
    return if (isDark) {
        LerzaColorPalette(
            primary = themeColor,
            primaryVariant = themeColor.copy(alpha = 0.8f),
            accent = themeColor,
            secondary = themeColor,
            card = DarkSurface,
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurfaceVariant,
            textPrimary = DarkTextPrimary,
            textSecondary = DarkTextSecondary,
            divider = DarkDivider,
            isDark = true
        )
    } else {
        LerzaColorPalette(
            primary = themeColor,
            primaryVariant = themeColor.copy(alpha = 0.8f),
            accent = themeColor,
            secondary = themeColor,
            card = LightSurface,
            background = LightBackground,
            surface = LightSurface,
            surfaceVariant = LightSurfaceVariant,
            textPrimary = LightTextPrimary,
            textSecondary = LightTextSecondary,
            divider = LightDivider,
            isDark = false
        )
    }
}

// -------------------------------------------------------------
// buildLarkTheme فنکشنز (جو ThemeScreen.kt میں کال ہو رہے ہیں)
// -------------------------------------------------------------

// جب کلر پاس کیا جائے: buildLarkTheme(color) یا buildLarkTheme(color, isDark)
fun buildLarkTheme(
    themeColor: Color = LerzaBlue,
    isDark: Boolean = true
): LerzaColorPalette {
    return getLerzaPalette(themeColor, isDark)
}

// جب نام پاس کیا جائے: buildLarkTheme("Green") یا buildLarkTheme("Red", isDark)
fun buildLarkTheme(
    themeName: String,
    isDark: Boolean = true
): LerzaColorPalette {
    return getLerzaPalette(getColorByThemeName(themeName), isDark)
}

@Composable
fun LerzaPlayerTheme(
    themeName: String = "Blue",
    themeColor: Color? = null,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val activeColor = themeColor ?: getColorByThemeName(themeName)
    val lerzaPalette = getLerzaPalette(activeColor, darkTheme)

    val materialColorScheme = if (darkTheme) {
        darkColorScheme(
            primary = lerzaPalette.primary,
            secondary = lerzaPalette.accent,
            background = lerzaPalette.background,
            surface = lerzaPalette.surface,
            surfaceVariant = lerzaPalette.surfaceVariant,
            onPrimary = Color.White,
            onBackground = lerzaPalette.textPrimary,
            onSurface = lerzaPalette.textPrimary
        )
    } else {
        lightColorScheme(
            primary = lerzaPalette.primary,
            secondary = lerzaPalette.accent,
            background = lerzaPalette.background,
            surface = lerzaPalette.surface,
            surfaceVariant = lerzaPalette.surfaceVariant,
            onPrimary = Color.White,
            onBackground = lerzaPalette.textPrimary,
            onSurface = lerzaPalette.textPrimary
        )
    }

    CompositionLocalProvider(
        LocalLerzaColors provides lerzaPalette
    ) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            content = content
        )
    }
}