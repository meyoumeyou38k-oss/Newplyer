package com.lerzaplayer.ui.search

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import com.lerzaplayer.ui.common.SongItemRow
import kotlinx.coroutines.launch

@Composable
fun SearchScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onBack: () -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onAddToQueue: (SongItem) -> Unit,
    onOpenYouTube: (String) -> Unit = {},
    prefManager: PreferenceManager? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val colors = LocalLerzaColors.current
    val activeColor = ThemeManager.currentThemeColor
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    val pm = remember { prefManager ?: PreferenceManager(context) }
    val searchHistory by pm.searchHistoryFlow.collectAsState(
        initial = listOf("ghmagh", "tututu", "Sad mood", "new release", "Arjit Singh", "Aura player")
    )

    BackHandler { onBack() }

    LaunchedEffect(Unit) {
        try { focusRequester.requestFocus() } catch (_: Exception) {}
    }

    var selectedFilterCategory by remember { mutableStateOf("All") }

    // اسکورنگ سسٹم
    fun computeSongMatchScore(q: String, song: SongItem): Int {
        if (q.isBlank()) return 1
        val cleanQ = q.trim().lowercase()
        val titleLower = song.title.lowercase().trim()
        val artistLower = song.artist.lowercase().trim()

        if (titleLower == cleanQ) return 100000
        if (titleLower.startsWith(cleanQ)) return 50000 - titleLower.length
        
        val words = titleLower.split(" ", "_", "-", ".", "(", ")").filter { it.isNotBlank() }
        for (w in words) {
            if (w == cleanQ) return 30000
            if (w.startsWith(cleanQ)) return 25000
        }
        val idx = titleLower.indexOf(cleanQ)
        if (idx >= 0) return 10000 - idx * 10
        if (artistLower.startsWith(cleanQ)) return 5000
        if (artistLower.contains(cleanQ)) return 2000

        var qi = 0
        for (ch in titleLower) {
            if (qi < cleanQ.length && ch == cleanQ[qi]) qi++
        }
        if (qi == cleanQ.length) return 800
        return 0
    }

    fun computeVideoMatchScore(q: String, video: VideoItem): Int {
        if (q.isBlank()) return 1
        val cleanQ = q.trim().lowercase()
        val titleLower = video.title.lowercase().trim()

        if (titleLower == cleanQ) return 100000
        if (titleLower.startsWith(cleanQ)) return 50000 - titleLower.length
        val words = titleLower.split(" ", "_", "-", ".", "(", ")").filter { it.isNotBlank() }
        for (w in words) {
            if (w.startsWith(cleanQ)) return 25000
        }
        val idx = titleLower.indexOf(cleanQ)
        if (idx >= 0) return 10000 - idx * 10
        return 0
    }

    val rankedSongs = remember(query, songs, selectedFilterCategory) {
        if (query.isBlank() && selectedFilterCategory == "All") {
            emptyList()
        } else {
            val q = query.trim()
            songs.mapNotNull { song ->
                val categoryPass = when (selectedFilterCategory) {
                    "Sad" -> listOf("sad", "dard", "gham", "judai", "dil", "slow", "bewafa").any { kw -> song.title.contains(kw, true) || song.artist.contains(kw, true) }
                    "Punjabi" -> listOf("sidhu", "moose", "praak", "ammy", "diljit", "punjabi", "jatt", "ishtar").any { kw -> song.title.contains(kw, true) || song.artist.contains(kw, true) }
                    "Remix" -> listOf("remix", "bass", "dj", "party", "dance", "beat").any { kw -> song.title.contains(kw, true) }
                    "Videos" -> false
                    else -> true
                }
                if (!categoryPass) null
                else {
                    val score = computeSongMatchScore(q, song)
                    if (score > 0) Pair(song, score) else null
                }
            }.sortedByDescending { it.second }
             .map { it.first }
        }
    }

    val matchedArtists = remember(query, songs) {
        if (query.isBlank()) emptyList()
        else {
            val q = query.trim().lowercase()
            songs.map { it.artist }
                .distinct()
                .filter { it.lowercase().startsWith(q) || it.lowercase().contains(q) }
                .take(6)
        }
    }

    val rankedVideos = remember(query, videos, selectedFilterCategory, rankedSongs) {
        if (query.isBlank()) emptyList()
        else if (selectedFilterCategory == "Songs" || selectedFilterCategory == "Artists") emptyList()
        else {
            val q = query.trim()
            videos.mapNotNull { video ->
                val score = computeVideoMatchScore(q, video)
                if (score > 0) Pair(video, score) else null
            }.sortedByDescending { it.second }
             .map { it.first }
        }
    }

    val hasAnyResults = rankedSongs.isNotEmpty() || rankedVideos.isNotEmpty() || matchedArtists.isNotEmpty()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        // ٹاپ ہیڈر اور سرچ بار
        Surface(
            color = colors.surface,
            shadowElevation = 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = LerzaIcons.ArrowBack,
                            contentDescription = "Back",
                            tint = colors.textPrimary
                        )
                    }

                    TextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = {
                            Text(
                                text = "Search music and YouTube...",
                                color = colors.textSecondary,
                                fontSize = 14.sp
                            )
                        },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            cursorColor = activeColor
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(focusRequester)
                    )

                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(
                                imageVector = LerzaIcons.Close,
                                contentDescription = "Clear",
                                tint = colors.textSecondary
                            )
                        }
                    }
                }

                // فلٹر ٹیبز (All, Songs, Artists, Videos, Sad)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val filterChips = listOf("All", "Songs", "Artists", "Videos", "Sad", "Punjabi", "Remix")
                    filterChips.forEach { chip ->
                        val isSelected = selectedFilterCategory == chip
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) activeColor else colors.card)
                                .clickable { selectedFilterCategory = chip }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = chip,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) colors.onPrimary else colors.textSecondary
                            )
                        }
                    }
                }
            }
        }

        // جب کوئری خالی ہو -> History اور Sites دکھائیں (اسکرین شاٹ کے مطابق)
        if (query.isBlank() && selectedFilterCategory == "All") {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // History سیکشن
                if (searchHistory.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "History",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Row(
                                modifier = Modifier
                                    .clickable { scope.launch { pm.clearSearchHistory() } }
                                    .padding(4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Clear History",
                                    tint = colors.textSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Clear",
                                    fontSize = 12.sp,
                                    color = colors.textSecondary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // ہسٹری چپس
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            searchHistory.forEach { item ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .border(1.dp, activeColor.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                                        .background(activeColor.copy(alpha = 0.08f))
                                        .clickable {
                                            query = item
                                            scope.launch { pm.addSearchQuery(item) }
                                        }
                                        .padding(horizontal = 14.dp, vertical = 7.dp)
                                ) {
                                    Text(
                                        text = item,
                                        fontSize = 13.sp,
                                        color = colors.textPrimary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }

                // Sites سیکشن (یوٹیوب آئیکون کے ساتھ)
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Sites",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { onOpenYouTube("") }
                            .padding(4.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White,
                            shadowElevation = 4.dp,
                            modifier = Modifier.size(56.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Surface(
                                    color = Color(0xFFFF0000),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.size(width = 30.dp, height = 22.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "YouTube",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "YouTube",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = colors.textPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // نیچے سمری ٹیکسٹ
                Box(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Instant Search across ${songs.size} songs & ${videos.size} videos",
                        color = colors.textSecondary.copy(alpha = 0.6f),
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            // جب یوزر سرچ کر رہا ہو
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
            ) {
                // 🌟 یوٹیوب سرچ بینر (اسکرین شاٹ 2 کے مطابق: <query> - Search in Youtube ↗)
                if (query.isNotBlank()) {
                    item {
                        Surface(
                            color = colors.card,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .clickable {
                                    scope.launch { pm.addSearchQuery(query) }
                                    onOpenYouTube(query)
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Surface(
                                        color = Color(0xFFFF0000),
                                        shape = CircleShape,
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.PlayArrow,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "$query - Search in Youtube",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowOutward,
                                    contentDescription = "Search",
                                    tint = colors.textSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                // اگر لوکل فائلز میں کوئی رزلٹ نہ ملا ہو (اسکرین شاٹ 2 کا ایمپٹی اسٹیٹ)
                if (query.isNotBlank() && !hasAnyResults) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 80.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = colors.card,
                                    modifier = Modifier.size(72.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Search,
                                            contentDescription = null,
                                            tint = colors.textSecondary.copy(alpha = 0.5f),
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "No results of your music & video",
                                    color = colors.textSecondary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                // آرٹسٹ رزلٹس
                if (matchedArtists.isNotEmpty() && selectedFilterCategory != "Videos") {
                    item {
                        Text(
                            text = "ARTISTS (${matchedArtists.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeColor,
                            modifier = Modifier.padding(start = 4.dp, top = 12.dp, bottom = 6.dp)
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            matchedArtists.forEach { artistName ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(colors.card)
                                        .clickable { query = artistName }
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = artistName,
                                        fontSize = 13.sp,
                                        color = colors.textPrimary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }

                // گانے
                if (rankedSongs.isNotEmpty() && selectedFilterCategory != "Videos") {
                    item {
                        Text(
                            text = "SONGS (${rankedSongs.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeColor,
                            modifier = Modifier.padding(start = 4.dp, top = 12.dp, bottom = 6.dp)
                        )
                    }
                    items(rankedSongs, key = { "s_${it.id}" }) { song ->
                        SongItemRow(
                            song = song,
                            isPlaying = isPlaying,
                            isCurrent = currentSong?.id == song.id,
                            isMultiSelectActive = false,
                            isSelected = false,
                            onSongClick = {
                                scope.launch { pm.addSearchQuery(song.title) }
                                onSongClick(song)
                            },
                            onSongLongClick = {},
                            onToggleSelect = {},
                            onToggleFavorite = { onToggleFavoriteSong(song) },
                            onPlayNext = {},
                            onAddToQueue = { onAddToQueue(song) },
                            onAddToPlaylist = {},
                            onHideInVault = {},
                            onDelete = {}
                        )
                    }
                }

                // ویڈیوز
                if (rankedVideos.isNotEmpty() && selectedFilterCategory != "Songs" && selectedFilterCategory != "Artists") {
                    item {
                        Text(
                            text = "VIDEOS (${rankedVideos.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeColor,
                            modifier = Modifier.padding(start = 4.dp, top = 16.dp, bottom = 6.dp)
                        )
                    }
                    items(rankedVideos, key = { "v_${it.id}" }) { video ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    scope.launch { pm.addSearchQuery(video.title) }
                                    onVideoClick(video)
                                }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            AsyncImage(
                                model = video.contentUri,
                                contentDescription = video.title,
                                modifier = Modifier
                                    .size(width = 64.dp, height = 48.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(colors.card)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = video.title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = colors.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Video • ${video.formattedDuration}",
                                    fontSize = 11.sp,
                                    color = colors.textSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
