package com.lerzaplayer.vault

import android.content.ContentUris
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.preferences.PreferenceManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class VaultManager private constructor(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val vaultDao = db.vaultDao()
    private val prefManager = PreferenceManager(context)

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    val vaultMediaFlow: Flow<List<VaultMediaEntity>> = vaultDao.getAllVaultMedia()
    val lockTypeFlow: Flow<VaultLockType> = prefManager.vaultLockTypeFlow
    val pinFlow: Flow<String?> = prefManager.vaultPinFlow
    val patternFlow: Flow<String?> = prefManager.vaultPatternFlow

    private val vaultDir: File by lazy {
        File(context.filesDir, "vault_storage").apply { if (!exists()) mkdirs() }
    }

    fun hashInput(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray())
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    suspend fun verifyPin(enteredPin: String): Boolean {
        val savedHash = prefManager.vaultPinFlow.first()
        if (savedHash == null) {
            val newHash = hashInput(enteredPin)
            prefManager.setVaultPin(newHash)
            _isUnlocked.value = true
            return true
        }
        val match = hashInput(enteredPin) == savedHash
        if (match) _isUnlocked.value = true
        return match
    }

    suspend fun verifyPattern(patternPoints: List<Int>): Boolean {
        val enteredPattern = patternPoints.joinToString("-")
        val savedHash = prefManager.vaultPatternFlow.first()
        if (savedHash == null) {
            val newHash = hashInput(enteredPattern)
            prefManager.setVaultPattern(newHash)
            _isUnlocked.value = true
            return true
        }
        val match = hashInput(enteredPattern) == savedHash
        if (match) _isUnlocked.value = true
        return match
    }

    suspend fun setLockMode(type: VaultLockType) {
        prefManager.setVaultLockType(type)
    }

    fun lockVault() {
        _isUnlocked.value = false
    }

    fun onAppBackgrounded() {
        _isUnlocked.value = false
    }

    suspend fun hideSong(song: SongItem) = withContext(Dispatchers.IO) {
        try {
            val originalFile = File(song.path)
            val inputStream: InputStream? = if (originalFile.exists() && originalFile.canRead()) {
                FileInputStream(originalFile)
            } else {
                context.contentResolver.openInputStream(song.contentUri)
            }

            if (inputStream == null) return@withContext

            val safeOriginalPath = if (song.path.isNotBlank()) song.path else "vault_media_${song.id}_${System.currentTimeMillis()}.mp3"
            val encryptedFile = File(vaultDir, "vault_song_${song.id}_${System.currentTimeMillis()}.bin")
            val encryptedTemp = File(vaultDir, "${encryptedFile.name}.tmp")

            inputStream.use { input ->
                encryptStream(input, encryptedTemp)
            }

            if (encryptedFile.exists()) encryptedFile.delete()
            if (!encryptedTemp.renameTo(encryptedFile)) {
                encryptedTemp.copyTo(encryptedFile, overwrite = true)
                encryptedTemp.delete()
            }

            val storedSize = if (originalFile.exists()) originalFile.length() else encryptedFile.length()

            vaultDao.insertVaultMedia(
                VaultMediaEntity(
                    originalPath = safeOriginalPath,
                    encryptedPath = encryptedFile.absolutePath,
                    originalName = song.title,
                    mediaType = "AUDIO",
                    duration = song.duration,
                    size = if (song.size > 0L) song.size else storedSize
                )
            )

            try {
                if (originalFile.exists()) originalFile.delete()
            } catch (_: Exception) {}
            try {
                context.contentResolver.delete(song.contentUri, null, null)
            } catch (_: Exception) {}
            MediaScannerConnection.scanFile(context, arrayOf(safeOriginalPath), null, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun hideVideo(video: VideoItem) = withContext(Dispatchers.IO) {
        try {
            val originalFile = File(video.path)
            val inputStream: InputStream? = if (originalFile.exists() && originalFile.canRead()) {
                FileInputStream(originalFile)
            } else {
                context.contentResolver.openInputStream(video.contentUri)
            }

            if (inputStream == null) return@withContext

            val safeOriginalPath = if (video.path.isNotBlank()) video.path else "vault_vid_${video.id}_${System.currentTimeMillis()}.mp4"
            val encryptedFile = File(vaultDir, "vault_vid_${video.id}_${System.currentTimeMillis()}.bin")
            val encryptedTemp = File(vaultDir, "${encryptedFile.name}.tmp")

            inputStream.use { input ->
                encryptStream(input, encryptedTemp)
            }

            if (encryptedFile.exists()) encryptedFile.delete()
            if (!encryptedTemp.renameTo(encryptedFile)) {
                encryptedTemp.copyTo(encryptedFile, overwrite = true)
                encryptedTemp.delete()
            }

            val storedSize = if (originalFile.exists()) originalFile.length() else encryptedFile.length()

            vaultDao.insertVaultMedia(
                VaultMediaEntity(
                    originalPath = safeOriginalPath,
                    encryptedPath = encryptedFile.absolutePath,
                    originalName = video.title,
                    mediaType = "VIDEO",
                    duration = video.duration,
                    size = if (video.size > 0L) video.size else storedSize
                )
            )

            try {
                if (originalFile.exists()) originalFile.delete()
            } catch (_: Exception) {}
            try {
                context.contentResolver.delete(video.contentUri, null, null)
            } catch (_: Exception) {}
            MediaScannerConnection.scanFile(context, arrayOf(safeOriginalPath), null, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun createPlaybackCopy(entity: VaultMediaEntity): File? = withContext(Dispatchers.IO) {
        try {
            val encryptedFile = File(entity.encryptedPath)
            if (!encryptedFile.exists()) return@withContext null

            val playbackDir = File(context.cacheDir, "vault_playback").apply { mkdirs() }
            val rawExt = File(entity.originalPath).extension
            val extension = if (rawExt.isNotBlank()) rawExt else (if (entity.mediaType == "VIDEO") "mp4" else "mp3")

            val target = File(
                playbackDir,
                "play_${kotlin.math.abs(entity.encryptedPath.hashCode())}.$extension"
            )

            if (target.exists() && target.length() > 1024L) {
                return@withContext target
            }

            val temp = File(playbackDir, "${target.name}.tmp")
            decryptFile(encryptedFile, temp)

            if (!temp.exists() || temp.length() == 0L) {
                temp.delete()
                return@withContext null
            }

            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            target
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun restoreMedia(entity: VaultMediaEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            val encFile = File(entity.encryptedPath)
            if (!encFile.exists()) return@withContext false

            val preferredFile = File(entity.originalPath)
            val parentDir = preferredFile.parentFile

            val safeDestination: File = if (entity.originalPath.isNotBlank() && parentDir != null && (parentDir.exists() || parentDir.mkdirs()) && parentDir.canWrite()) {
                if (preferredFile.exists()) {
                    val stem = preferredFile.nameWithoutExtension
                    val ext = preferredFile.extension.takeIf { it.isNotBlank() }?.let { ".$it" } ?: ""
                    File(parentDir, "${stem}_restored_${System.currentTimeMillis()}$ext")
                } else preferredFile
            } else {
                val publicDir = if (entity.mediaType == "VIDEO") {
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                } else {
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
                }.apply { mkdirs() }

                val cleanName = entity.originalName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60)
                val ext = File(entity.originalPath).extension.takeIf { it.isNotBlank() }?.let { ".$it" } ?: (if (entity.mediaType == "VIDEO") ".mp4" else ".mp3")
                File(publicDir, "${cleanName}_restored$ext")
            }

            val restoredTemp = File(context.cacheDir, "restore_${System.currentTimeMillis()}.tmp")
            decryptFile(encFile, restoredTemp)

            if (!restoredTemp.exists() || restoredTemp.length() == 0L) {
                restoredTemp.delete()
                return@withContext false
            }

            safeDestination.parentFile?.mkdirs()
            if (safeDestination.exists()) safeDestination.delete()

            if (!restoredTemp.renameTo(safeDestination)) {
                restoredTemp.copyTo(safeDestination, overwrite = true)
                restoredTemp.delete()
            }

            MediaScannerConnection.scanFile(context, arrayOf(safeDestination.absolutePath), null, null)
            encFile.delete()
            vaultDao.deleteVaultMedia(entity)
            vaultDao.deleteByPath(entity.originalPath)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun deletePermanently(entity: VaultMediaEntity) = withContext(Dispatchers.IO) {
        try {
            val encFile = File(entity.encryptedPath)
            if (encFile.exists()) {
                encFile.delete()
            }
            vaultDao.deleteVaultMedia(entity)
            vaultDao.deleteByPath(entity.originalPath)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun resetVaultLock() {
        prefManager.setVaultPin(null)
        prefManager.setVaultPattern(null)
        prefManager.setVaultLockType(VaultLockType.PIN)
        _isUnlocked.value = false
    }

    suspend fun updatePin(newPin: String) {
        val newHash = hashInput(newPin)
        prefManager.setVaultPin(newHash)
        prefManager.setVaultLockType(VaultLockType.PIN)
    }

    suspend fun updatePattern(patternPoints: List<Int>) {
        val enteredPattern = patternPoints.joinToString("-")
        val newHash = hashInput(enteredPattern)
        prefManager.setVaultPattern(newHash)
        prefManager.setVaultLockType(VaultLockType.PATTERN)
    }

    suspend fun autoImportWhatsAppAndCallRecordings(): Int = withContext(Dispatchers.IO) {
        var importedCount = 0
        try {
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            }

            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.SIZE
            )

            context.contentResolver.query(collection, projection, null, null, null)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)

                while (cursor.moveToNext()) {
                    val path = cursor.getString(dataCol) ?: continue
                    val lowerPath = path.lowercase()

                    val isCall = lowerPath.contains("call") || lowerPath.contains("record") || lowerPath.contains("voicerecord")
                    val isWhatsApp = lowerPath.contains("whatsapp") || lowerPath.contains("opus")

                    if (isCall || isWhatsApp) {
                        val file = File(path)
                        if (file.exists() && file.isFile) {
                            val id = cursor.getLong(idCol)
                            val title = cursor.getString(titleCol) ?: file.name
                            val duration = cursor.getLong(durCol)
                            val size = cursor.getLong(sizeCol)
                            val contentUri = ContentUris.withAppendedId(collection, id)

                            hideSong(
                                SongItem(
                                    id = id,
                                    title = title,
                                    artist = if (isWhatsApp) "WhatsApp Audio" else "Call Recording",
                                    album = "Private",
                                    duration = duration,
                                    contentUri = contentUri,
                                    size = size,
                                    path = path
                                )
                            )
                            importedCount++
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        importedCount
    }

    private fun encryptStream(input: InputStream, dst: File) {
        val cipher = Cipher.getInstance("AES/CTR/NoPadding")
        val iv = ByteArray(16).apply { java.security.SecureRandom().nextBytes(this) }
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateVaultKey(), IvParameterSpec(iv))

        FileOutputStream(dst).use { rawOutput ->
            rawOutput.write(ENCRYPTED_FILE_MAGIC)
            rawOutput.write(iv.size)
            rawOutput.write(iv)
            CipherOutputStream(rawOutput, cipher).use { encryptedOutput ->
                input.copyTo(encryptedOutput)
            }
        }
    }

    private fun decryptFile(src: File, dst: File) {
        try {
            BufferedInputStream(FileInputStream(src)).use { input ->
                input.mark(64)
                val magic = ByteArray(ENCRYPTED_FILE_MAGIC.size)
                var bytesRead = 0
                while (bytesRead < magic.size) {
                    val c = input.read(magic, bytesRead, magic.size - bytesRead)
                    if (c < 0) break
                    bytesRead += c
                }

                if (bytesRead == ENCRYPTED_FILE_MAGIC.size && magic.contentEquals(ENCRYPTED_FILE_MAGIC)) {
                    val ivLength = input.read()
                    if (ivLength in 12..16) {
                        val iv = ByteArray(ivLength)
                        var ivBytesRead = 0
                        while (ivBytesRead < ivLength) {
                            val count = input.read(iv, ivBytesRead, ivLength - ivBytesRead)
                            if (count < 0) break
                            ivBytesRead += count
                        }

                        val cipher = if (ivLength == 12) {
                            Cipher.getInstance("AES/GCM/NoPadding").apply {
                                init(Cipher.DECRYPT_MODE, getOrCreateVaultKey(), GCMParameterSpec(128, iv))
                            }
                        } else {
                            Cipher.getInstance("AES/CTR/NoPadding").apply {
                                init(Cipher.DECRYPT_MODE, getOrCreateVaultKey(), IvParameterSpec(iv))
                            }
                        }

                        CipherInputStream(input, cipher).use { decryptedInput ->
                            FileOutputStream(dst).use { output ->
                                decryptedInput.copyTo(output)
                            }
                        }
                        if (dst.exists() && dst.length() > 0L) return
                    }
                }

                input.reset()
                FileOutputStream(dst).use { output ->
                    val buffer = ByteArray(8192)
                    var count: Int
                    while (input.read(buffer).also { count = it } != -1) {
                        for (i in 0 until count) {
                            buffer[i] = (buffer[i].toInt() xor LEGACY_XOR_KEY.toInt()).toByte()
                        }
                        output.write(buffer, 0, count)
                    }
                }
            }
        } catch (e: Exception) {
            dst.delete()
            throw e
        }
    }

    private fun getOrCreateVaultKey(): SecretKey {
        try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            val existing = keyStore.getKey(VAULT_KEY_ALIAS, null) as? SecretKey
            if (existing != null) return existing

            val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            generator.init(
                KeyGenParameterSpec.Builder(
                    VAULT_KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_CTR, KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .setRandomizedEncryptionRequired(false)
                    .build()
            )
            return generator.generateKey()
        } catch (e: Exception) {
            return javax.crypto.spec.SecretKeySpec(
                "LerzaVaultKey2026SecureKeyPass!".toByteArray(Charsets.UTF_8).copyOf(32),
                "AES"
            )
        }
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val VAULT_KEY_ALIAS = "lerza_vault_media_key_v2"
        private const val LEGACY_XOR_KEY: Byte = 0x5A
        private val ENCRYPTED_FILE_MAGIC = byteArrayOf(0x4C, 0x5A, 0x45, 0x4E, 0x43, 0x31)

        @Volatile
        private var INSTANCE: VaultManager? = null

        fun getInstance(context: Context): VaultManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: VaultManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}