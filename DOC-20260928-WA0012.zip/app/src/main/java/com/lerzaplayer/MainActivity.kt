package com.lerzaplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.FavoriteEntity
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.repository.DeletionResult
import com.lerzaplayer.data.repository.MediaRepository
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaPlayerTheme
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import com.lerzaplayer.ui.home.HomeScreen
import com.lerzaplayer.ui.player.FullPlayerScreen
import com.lerzaplayer.ui.player.VideoPlayerScreen
import com.lerzaplayer.ui.search.SearchScreen
import com.lerzaplayer.ui.settings.SettingsScreen
import com.lerzaplayer.ui.settings.ThemeScreen
import com.lerzaplayer.ui.vault.VaultScreen
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

enum class AppDestination {
    HOME,
    SETTINGS,
    VAULT,
    SEARCH,
    THEME
}

class MainActivity : ComponentActivity() {

    private lateinit var mediaRepository: MediaRepository
    private lateinit var playerManager: PlayerManager

    private var isVolumePopupVisible by mutableStateOf(false)
    private var currentVolumePercent by mutableIntStateOf(100)
    private var volumeDismissJob: Job? = null

    private var pendingDeleteEntity: RecentlyDeletedEntity? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (::mediaRepository.isInitialized) mediaRepository.refreshMedia()
    }

    private val scopedStorageDeleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            pendingDeleteEntity?.let { entity ->
                lifecycleScope.launch {
                    mediaRepository.confirmPendingDeletion(entity)
                    Toast.makeText(this@MainActivity, "Moved to Recently Deleted (30 days)", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            pendingDeleteEntity?.let { entity ->
                lifecycleScope.launch {
                    mediaRepository.cancelPendingDeletion(entity)
                }
            }
        }
        pendingDeleteEntity = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        ThemeManager.init(this)
        val app = application as LerzaApp
        mediaRepository = MediaRepository(this)
        playerManager = app.playerManager
        playerManager.syncVolumeFromSystem()
        currentVolumePercent = playerManager.loudnessGain.value

        requestRequiredPermissions()

        setContent {
            val prefManager = app.preferenceManager
            val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
            val scope = rememberCoroutineScope()

            val songs by mediaRepository.getSongsFlow(songSort).collectAsState(initial = emptyList())
            val videos by mediaRepository.getVideosFlow(SortOption.DATE_ADDED_DESC).collectAsState(initial = emptyList())
            val recentlyDeleted by mediaRepository.getRecentlyDeletedFlow().collectAsState(initial = emptyList())

            val activeLoudnessGain by playerManager.loudnessGain.collectAsState()
            LaunchedEffect(activeLoudnessGain) {
                currentVolumePercent = activeLoudnessGain
            }

            var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
            var isFullPlayerVisible by remember { mutableStateOf(false) }
            var activePlayingVideo by remember { mutableStateOf<VideoItem?>(null) }
            var songToDeleteConfirm by remember { mutableStateOf<SongItem?>(null) }
            var videoToDeleteConfirm by remember { mutableStateOf<VideoItem?>(null) }

            BackHandler(enabled = activePlayingVideo != null) {
                activePlayingVideo = null
            }

            BackHandler(enabled = activePlayingVideo == null && isFullPlayerVisible) {
                isFullPlayerVisible = false
            }

            BackHandler(enabled = activePlayingVideo == null && !isFullPlayerVisible && currentDestination != AppDestination.HOME) {
                currentDestination = if (currentDestination == AppDestination.THEME) AppDestination.SETTINGS else AppDestination.HOME
            }

            LerzaPlayerTheme(themeColor = ThemeManager.currentThemeColor) {
                val themeColors = LocalLerzaColors.current

                SideEffect {
                    window.statusBarColor = themeColors.surface.toArgb()
                    window.navigationBarColor = themeColors.background.toArgb()
                    WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !themeColors.isDark
                    WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !themeColors.isDark
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    when (currentDestination) {
                        AppDestination.HOME -> {
                            HomeScreen(
                                songs = songs,
                                videos = videos,
                                playerManager = playerManager,
                                prefManager = prefManager,
                                onSearchClick = { currentDestination = AppDestination.SEARCH },
                                onSettingsClick = { currentDestination = AppDestination.SETTINGS },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                onExpandFullPlayer = { isFullPlayerVisible = true },
                                onPlayVideo = { video ->
                                    playerManager.pause()
                                    activePlayingVideo = video
                                },
                                onToggleFavoriteSong = { song ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (song.isFavorite) {
                                            favDao.removeFavorite(song.id, "AUDIO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                        }
                                    }
                                },
                                onToggleFavoriteVideo = { video ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (video.isFavorite) {
                                            favDao.removeFavorite(video.id, "VIDEO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(video.id, "VIDEO"))
                                        }
                                    }
                                },
                                onHideSongInVault = { song ->
                                    scope.launch {
                                        app.vaultManager.hideSong(song)
                                        mediaRepository.refreshMedia()
                                    }
                                },
                                onHideVideoInVault = { video ->
                                    scope.launch {
                                        app.vaultManager.hideVideo(video)
                                        mediaRepository.refreshMedia()
                                    }
                                },
                                onDeleteSong = { song ->
                                    songToDeleteConfirm = song
                                },
                                onDeleteVideo = { video ->
                                    videoToDeleteConfirm = video
                                },
                                onScanDevice = {
                                    mediaRepository.refreshMedia()
                                }
                            )
                        }

                        AppDestination.SETTINGS -> {
                            SettingsScreen(
                                prefManager = prefManager,
                                onBack = { currentDestination = AppDestination.HOME },
                                onOpenEqualizer = { isFullPlayerVisible = true },
                                onScanMedia = { mediaRepository.refreshMedia() },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                recentlyDeleted = recentlyDeleted,
                                onPlayRecentlyDeleted = { item ->
                                    val backupFile = File(item.backupPath)
                                    if (backupFile.exists()) {
                                        val playableUri = Uri.fromFile(backupFile)
                                        playerManager.playSong(
                                            SongItem(
                                                id = item.id,
                                                title = item.originalName,
                                                artist = "Recently Deleted (30 Days)",
                                                album = "Trash",
                                                duration = item.duration,
                                                contentUri = playableUri,
                                                size = item.size,
                                                path = backupFile.absolutePath,
                                                mimeType = if (item.mediaType == "AUDIO") "audio/*" else "video/*"
                                            )
                                        )
                                        isFullPlayerVisible = true
                                    } else {
                                        Toast.makeText(this@MainActivity, "File expired or removed", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onRestoreRecentlyDeleted = { item ->
                                    scope.launch {
                                        mediaRepository.restoreRecentlyDeleted(item)
                                        Toast.makeText(this@MainActivity, "Restored back to phone storage!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onPermanentlyDeleteRecentlyDeleted = { item ->
                                    scope.launch {
                                        mediaRepository.permanentlyDeleteRecentlyDeleted(item)
                                        Toast.makeText(this@MainActivity, "Permanently deleted", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }

                        AppDestination.THEME -> {
                            ThemeScreen(
                                prefManager = prefManager,
                                onBack = { currentDestination = AppDestination.SETTINGS }
                            )
                        }

                        AppDestination.VAULT -> {
                            VaultScreen(
                                vaultManager = app.vaultManager,
                                onBack = {
                                    playerManager.clearQueue()
                                    isFullPlayerVisible = false
                                    currentDestination = AppDestination.HOME
                                },
                                onPlayMedia = { entity ->
                                    scope.launch {
                                        val playableFile = app.vaultManager.createPlaybackCopy(entity)
                                        if (playableFile != null && playableFile.exists() && playableFile.length() > 0L) {
                                            val playableUri = Uri.fromFile(playableFile)
                                            val playableId = kotlin.math.abs(entity.originalPath.hashCode()).toLong()
                                            if (entity.mediaType == "AUDIO") {
                                                playerManager.playSong(
                                                    SongItem(
                                                        id = playableId,
                                                        title = entity.originalName,
                                                        artist = "Private Vault",
                                                        album = "Private Vault",
                                                        duration = entity.duration,
                                                        contentUri = playableUri,
                                                        size = playableFile.length(),
                                                        path = playableFile.absolutePath,
                                                        mimeType = "audio/*"
                                                    )
                                                )
                                                isFullPlayerVisible = true
                                            } else {
                                                activePlayingVideo = VideoItem(
                                                    id = playableId,
                                                    title = entity.originalName,
                                                    duration = entity.duration,
                                                    contentUri = playableUri,
                                                    size = playableFile.length(),
                                                    path = playableFile.absolutePath,
                                                    folderName = "Private Vault"
                                                )
                                            }
                                        } else {
                                            Toast.makeText(this@MainActivity, "Preparing file for playback failed", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            )
                        }

                        AppDestination.SEARCH -> {
                            val currentSong by playerManager.currentSong.collectAsState()
                            val isPlaying by playerManager.isPlaying.collectAsState()
                            SearchScreen(
                                songs = songs,
                                videos = videos,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                onSongClick = { song ->
                                    val index = songs.indexOfFirst { it.id == song.id }
                                    if (index != -1) {
                                        playerManager.playSongList(songs, index)
                                    } else {
                                        playerManager.playSong(song)
                                    }
                                    isFullPlayerVisible = true
                                },
                                onVideoClick = { video ->
                                    playerManager.pause()
                                    activePlayingVideo = video
                                },
                                onBack = { currentDestination = AppDestination.HOME },
                                onToggleFavoriteSong = { song ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (song.isFavorite) {
                                            favDao.removeFavorite(song.id, "AUDIO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                        }
                                    }
                                },
                                onAddToQueue = { song -> playerManager.addToQueue(song) }
                            )
                        }
                    }

                    // Delete Song Confirmation Dialog
                    songToDeleteConfirm?.let { song ->
                        AlertDialog(
                            onDismissRequest = { songToDeleteConfirm = null },
                            title = { Text("Delete song?", fontWeight = FontWeight.Bold) },
                            text = {
                                Text("\"${song.title}\" will be removed from your device and moved to Recently Deleted in Settings for 30 days.")
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        val targetSong = song
                                        songToDeleteConfirm = null
                                        if (playerManager.currentSong.value?.id == targetSong.id) {
                                            playerManager.pause()
                                            playerManager.clearQueue()
                                        }
                                        scope.launch {
                                            when (val result = mediaRepository.deleteMedia(targetSong)) {
                                                is DeletionResult.Success -> {
                                                    Toast.makeText(this@MainActivity, "Deleted & moved to 30-day Trash", Toast.LENGTH_SHORT).show()
                                                }
                                                is DeletionResult.RequiresConsent -> {
                                                    pendingDeleteEntity = result.pendingItem
                                                    scopedStorageDeleteLauncher.launch(
                                                        IntentSenderRequest.Builder(result.intentSender).build()
                                                    )
                                                }
                                                is DeletionResult.Failure -> {
                                                    Toast.makeText(this@MainActivity, result.error, Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF334B))
                                ) {
                                    Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { songToDeleteConfirm = null }) {
                                    Text("Cancel")
                                }
                            }
                        )
                    }

                    // Delete Video Confirmation Dialog
                    videoToDeleteConfirm?.let { video ->
                        AlertDialog(
                            onDismissRequest = { videoToDeleteConfirm = null },
                            title = { Text("Delete video?", fontWeight = FontWeight.Bold) },
                            text = {
                                Text("\"${video.title}\" will be deleted from your device and moved to Recently Deleted for 30 days.")
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        val targetVideo = video
                                        videoToDeleteConfirm = null
                                        scope.launch {
                                            when (val result = mediaRepository.deleteMedia(targetVideo)) {
                                                is DeletionResult.Success -> {
                                                    Toast.makeText(this@MainActivity, "Deleted & moved to 30-day Trash", Toast.LENGTH_SHORT).show()
                                                }
                                                is DeletionResult.RequiresConsent -> {
                                                    pendingDeleteEntity = result.pendingItem
                                                    scopedStorageDeleteLauncher.launch(
                                                        IntentSenderRequest.Builder(result.intentSender).build()
                                                    )
                                                }
                                                is DeletionResult.Failure -> {
                                                    Toast.makeText(this@MainActivity, result.error, Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF334B))
                                ) {
                                    Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { videoToDeleteConfirm = null }) {
                                    Text("Cancel")
                                }
                            }
                        )
                    }

                    // Full Player Overlay
                    AnimatedVisibility(
                        visible = isFullPlayerVisible,
                        enter = slideInVertically(initialOffsetY = { it }),
                        exit = slideOutVertically(targetOffsetY = { it })
                    ) {
                        FullPlayerScreen(
                            playerManager = playerManager,
                            onCollapse = { isFullPlayerVisible = false },
                            onFavoriteToggle = { song ->
                                scope.launch {
                                    val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                    if (song.isFavorite) {
                                        favDao.removeFavorite(song.id, "AUDIO")
                                    } else {
                                        favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                    }
                                }
                            }
                        )
                    }

                    // Video Player Overlay
                    activePlayingVideo?.let { vid ->
                        VideoPlayerScreen(
                            video = vid,
                            onClose = { activePlayingVideo = null },
                            onPreviousVideo = {
                                val index = videos.indexOfFirst { it.id == vid.id }
                                if (index > 0) activePlayingVideo = videos[index - 1]
                            },
                            onNextVideo = {
                                val index = videos.indexOfFirst { it.id == vid.id }
                                if (index >= 0 && index < videos.lastIndex) {
                                    activePlayingVideo = videos[index + 1]
                                }
                            },
                            onPlayAsAudio = {
                                playerManager.playSong(
                                    SongItem(
                                        id = vid.id,
                                        title = vid.title,
                                        artist = "Video audio",
                                        album = vid.folderName,
                                        duration = vid.duration,
                                        contentUri = vid.contentUri,
                                        albumArtUri = vid.contentUri,
                                        size = vid.size,
                                        path = vid.path,
                                        mimeType = "audio/*"
                                    )
                                )
                                activePlayingVideo = null
                                isFullPlayerVisible = true
                            },
                            onDeleteVideo = {
                                videoToDeleteConfirm = vid
                            }
                        )
                    }

                    // Global Volume Popup
                    AnimatedVisibility(
                        visible = isVolumePopupVisible,
                        enter = fadeIn() + slideInVertically(initialOffsetY = { -50 }),
                        exit = fadeOut() + slideOutVertically(targetOffsetY = { -50 }),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 48.dp)
                    ) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.85f)),
                            modifier = Modifier
                                .padding(horizontal = 24.dp)
                                .fillMaxWidth(0.85f)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Volume Boost: $currentVolumePercent%",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Slider(
                                    value = currentVolumePercent.toFloat(),
                                    onValueChange = { newValue ->
                                        currentVolumePercent = newValue.toInt()
                                        playerManager.setLoudnessGain(currentVolumePercent)
                                        triggerVolumePopup()
                                    },
                                    valueRange = 1f..300f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = themeColors.primary,
                                        activeTrackColor = themeColors.primary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::playerManager.isInitialized) {
            playerManager.syncVolumeFromSystem()
            currentVolumePercent = playerManager.loudnessGain.value
        }
    }

    private fun triggerVolumePopup() {
        isVolumePopupVisible = true
        volumeDismissJob?.cancel()
        volumeDismissJob = lifecycleScope.launch {
            delay(1500)
            isVolumePopupVisible = false
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                playerManager.syncVolumeFromSystem()
                val targetVol = (playerManager.loudnessGain.value + 10).coerceAtMost(300)
                currentVolumePercent = targetVol
                playerManager.setLoudnessGain(targetVol)
                triggerVolumePopup()
                return true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                playerManager.syncVolumeFromSystem()
                val targetVol = (playerManager.loudnessGain.value - 10).coerceAtLeast(1)
                currentVolumePercent = targetVol
                playerManager.setLoudnessGain(targetVol)
                triggerVolumePopup()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun requestRequiredPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        startActivity(intent)
                    } catch (_: Exception) {}
                }
            }
        }
    }
}