package com.lerzaplayer.ui.playlists

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.PlaylistEntity
import androidx.compose.ui.platform.LocalContext
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow

@Composable
fun PlaylistsScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem, List<SongItem>, Int) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current

    var selectedPlaylistTitle by remember { mutableStateOf<String?>(null) }
    var selectedPlaylistSongs by remember { mutableStateOf<List<SongItem>>(emptyList()) }

    var showCreateDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val playlistDao = remember { com.lerzaplayer.data.database.AppDatabase.getDatabase(context).playlistDao() }
    val customPlaylists by playlistDao.getAllPlaylists().collectAsState(initial = emptyList())

    BackHandler(enabled = selectedPlaylistTitle != null) {
        selectedPlaylistTitle = null
        selectedPlaylistSongs = emptyList()
    }

    if (selectedPlaylistTitle != null) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(colors.background)
        ) {
            Surface(
                color = colors.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { selectedPlaylistTitle = null }) {
                            Icon(
                                imageVector = LerzaIcons.ArrowBack,
                                contentDescription = "Back",
                                tint = colors.textPrimary
                            )
                        }
                        Column {
                            Text(
                                text = selectedPlaylistTitle ?: "Playlist",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${selectedPlaylistSongs.size} tracks",
                                fontSize = 12.sp,
                                color = colors.textSecondary
                            )
                        }
                    }

                    if (selectedPlaylistSongs.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                onSongClick(selectedPlaylistSongs[0], selectedPlaylistSongs, 0)
                            }
                        ) {
                            Icon(
                                imageVector = LerzaIcons.PlayArrow,
                                contentDescription = "Play all",
                                tint = colors.primary
                            )
                        }
                    }
                }
            }

            if (selectedPlaylistSongs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No songs in this playlist yet.",
                        color = colors.textSecondary,
                        fontSize = 14.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = 8.dp, bottom = 90.dp)
                ) {
                    items(selectedPlaylistSongs, key = { it.id }) { song ->
                        SongItemRow(
                            song = song,
                            isPlaying = isPlaying && currentSong?.id == song.id,
                            isMultiSelectActive = false,
                            isSelected = false,
                            onSongClick = {
                                val idx = selectedPlaylistSongs.indexOfFirst { it.id == song.id }
                                onSongClick(song, selectedPlaylistSongs, if (idx != -1) idx else 0)
                            },
                            onSongLongClick = {},
                            onToggleSelect = {},
                            onToggleFavorite = { onToggleFavorite(song) },
                            onPlayNext = {},
                            onAddToQueue = {},
                            onAddToPlaylist = {},
                            onHideInVault = { onHideInVault(song) },
                            onDelete = { onDelete(song) }
                        )
                    }
                }
            }
        }
        return
    }

    // Default System/Smart Playlists
    val likedSongs = remember(songs) { songs.filter { it.isFavorite } }
    val recentlyPlayed = remember(songs) { songs.take(15) }
    val mostPlayed = remember(songs) { songs.sortedByDescending { it.duration }.take(15) }
    val withLyrics = remember(songs) { songs.take(10) }

    val sadSongs = remember(songs) {
        songs.filter {
            it.title.contains("sad", ignoreCase = true) ||
            it.title.contains("dard", ignoreCase = true) ||
            it.artist.contains("arijit", ignoreCase = true) ||
            it.artist.contains("atif", ignoreCase = true)
        }.ifEmpty { songs.take(6) }
    }

    val punjabiHits = remember(songs) {
        songs.filter {
            it.title.contains("punjabi", ignoreCase = true) ||
            it.title.contains("sidhu", ignoreCase = true) ||
            it.artist.contains("sidhu", ignoreCase = true) ||
            it.artist.contains("diljit", ignoreCase = true) ||
            it.artist.contains("karan", ignoreCase = true)
        }.ifEmpty { songs.take(6) }
    }

    val romanticSongs = remember(songs) {
        songs.filter {
            it.title.contains("love", ignoreCase = true) ||
            it.title.contains("ishq", ignoreCase = true) ||
            it.artist.contains("shreya", ignoreCase = true)
        }.ifEmpty { songs.take(6) }
    }

    val remixParty = remember(songs) {
        songs.filter {
            it.title.contains("remix", ignoreCase = true) ||
            it.title.contains("bass", ignoreCase = true) ||
            it.title.contains("dj", ignoreCase = true)
        }.ifEmpty { songs.take(6) }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.card),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showCreateDialog = true }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = LerzaIcons.Add,
                        contentDescription = "Add new",
                        tint = Color(0xFF1E60F2),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Add new",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        }

        item {
            PlaylistCardRow(
                title = "Liked songs",
                count = likedSongs.size,
                icon = LerzaIcons.Favorite,
                previewSongs = likedSongs.take(2),
                gradient = listOf(Color(0xFFFF334B), Color(0xFF880E4F)),
                coverUri = likedSongs.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Liked songs"
                    selectedPlaylistSongs = likedSongs
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "Recently played",
                count = recentlyPlayed.size,
                icon = LerzaIcons.History,
                previewSongs = recentlyPlayed.take(2),
                gradient = listOf(Color(0xFF651FFF), Color(0xFF311B92)),
                coverUri = recentlyPlayed.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Recently played"
                    selectedPlaylistSongs = recentlyPlayed
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "Most played",
                count = mostPlayed.size,
                icon = LerzaIcons.Equalizer,
                previewSongs = mostPlayed.take(2),
                gradient = listOf(Color(0xFFFF6D00), Color(0xFFBF360C)),
                coverUri = mostPlayed.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Most played"
                    selectedPlaylistSongs = mostPlayed
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "With Lyrics",
                count = withLyrics.size,
                icon = LerzaIcons.Lyrics,
                previewSongs = withLyrics.take(2),
                gradient = listOf(Color(0xFF00E5FF), Color(0xFF006064)),
                coverUri = withLyrics.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "With Lyrics"
                    selectedPlaylistSongs = withLyrics
                }
            )
        }

        item {
            Text(
                text = "SMART AUTO PLAYLISTS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = Color(0xFF1E60F2),
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
        }

        item {
            PlaylistCardRow(
                title = "Sad Songs Special",
                count = sadSongs.size,
                icon = LerzaIcons.Audiotrack,
                previewSongs = sadSongs.take(2),
                gradient = listOf(Color(0xFF7E57C2), Color(0xFF311B92)),
                coverUri = sadSongs.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Sad Songs Special"
                    selectedPlaylistSongs = sadSongs
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "Punjabi Hits",
                count = punjabiHits.size,
                icon = LerzaIcons.Headphones,
                previewSongs = punjabiHits.take(2),
                gradient = listOf(Color(0xFFFF9100), Color(0xFFE65100)),
                coverUri = punjabiHits.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Punjabi Hits"
                    selectedPlaylistSongs = punjabiHits
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "Romantic & Soulful",
                count = romanticSongs.size,
                icon = LerzaIcons.Favorite,
                previewSongs = romanticSongs.take(2),
                gradient = listOf(Color(0xFFEC407A), Color(0xFF880E4F)),
                coverUri = romanticSongs.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Romantic & Soulful"
                    selectedPlaylistSongs = romanticSongs
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "Remix & Bass Party",
                count = remixParty.size,
                icon = LerzaIcons.Tune,
                previewSongs = remixParty.take(2),
                gradient = listOf(Color(0xFF00E676), Color(0xFF1B5E20)),
                coverUri = remixParty.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Remix & Bass Party"
                    selectedPlaylistSongs = remixParty
                }
            )
        }

        // 🌟 یوزر کی کسٹم پلے لسٹس (Room Database سے لائیو لوڈ ہوتی ہیں)
        items(customPlaylists, key = { it.id }) { playlist ->
            val itemsFlow = remember(playlist.id) { playlistDao.getItemsForPlaylist(playlist.id) }
            val playlistItems by itemsFlow.collectAsState(initial = emptyList())
            val playlistSongs = remember(songs, playlistItems) {
                val songMap = songs.associateBy { it.id }
                playlistItems.mapNotNull { songMap[it.songId] }
            }

            PlaylistCardRow(
                title = playlist.name,
                count = playlistSongs.size,
                icon = LerzaIcons.PlaylistAdd,
                previewSongs = playlistSongs.take(2),
                gradient = listOf(Color(0xFF1E60F2), Color(0xFF0D47A1)),
                coverUri = playlistSongs.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = playlist.name
                    selectedPlaylistSongs = playlistSongs
                }
            )
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create New Playlist", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    label = { Text("Playlist Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val trimmed = newPlaylistName.trim()
                        if (trimmed.isNotBlank()) {
                            scope.launch {
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                    playlistDao.insertPlaylist(com.lerzaplayer.data.database.PlaylistEntity(name = trimmed))
                                }
                                newPlaylistName = ""
                                showCreateDialog = false
                            }
                        }
                    }
                ) {
                    Text("Create", fontWeight = FontWeight.Bold, color = Color(0xFF1E60F2))
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel", color = colors.textSecondary)
                }
            }
        )
    }
}

@Composable
fun PlaylistCardRow(
    title: String,
    count: Int,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    previewSongs: List<SongItem>,
    gradient: List<Color>,
    coverUri: Uri? = null,
    onClick: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Card(
        colors = CardDefaults.cardColors(containerColor = colors.card),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(gradient)),
                contentAlignment = Alignment.Center
            ) {
                if (coverUri != null) {
                    AsyncImage(
                        model = coverUri,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (count > 0) "$count" else "No songs yet",
                        fontSize = 12.sp,
                        color = colors.textSecondary
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                if (previewSongs.isNotEmpty()) {
                    previewSongs.take(2).forEach { song ->
                        Text(
                            text = "♬ ${song.title}",
                            fontSize = 12.sp,
                            color = colors.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                } else {
                    Text(
                        text = "Tap to open and play tracks",
                        fontSize = 12.sp,
                        color = colors.textSecondary.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}