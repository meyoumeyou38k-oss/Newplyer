package com.lerzaplayer.vault

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.preferences.PreferenceManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

class VaultManager private constructor(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val vaultDao = db.vaultDao()
    private val prefManager = PreferenceManager(context)

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    val vaultMediaFlow: Flow<List<VaultMediaEntity>> = vaultDao.getAllVaultMedia()
    val lockTypeFlow: Flow<VaultLockType> = prefManager.vaultLockTypeFlow
    val pinFlow: Flow<String?> = prefManager.vaultPinFlow
    val patternFlow: Flow<String?> = prefManager.vaultPatternFlow

    private val vaultDir: File by lazy {
        File(context.filesDir, "vault_storage").apply { if (!exists()) mkdirs() }
    }

    private val secretKey: SecretKeySpec by lazy {
        val digest = MessageDigest.getInstance("SHA-256")
        val keyBytes = digest.digest(("LerzaVaultMasterKey2026_" + context.packageName).toByteArray(Charsets.UTF_8))
        SecretKeySpec(keyBytes, "AES")
    }

    fun hashInput(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray())
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    suspend fun verifyPin(enteredPin: String): Boolean {
        val savedHash = prefManager.vaultPinFlow.first()
        if (savedHash == null) {
            val newHash = hashInput(enteredPin)
            prefManager.setVaultPin(newHash)
            _isUnlocked.value = true
            return true
        }
        val match = hashInput(enteredPin) == savedHash
        if (match) _isUnlocked.value = true
        return match
    }

    suspend fun verifyPattern(patternPoints: List<Int>): Boolean {
        val enteredPattern = patternPoints.joinToString("-")
        val savedHash = prefManager.vaultPatternFlow.first()
        if (savedHash == null) {
            val newHash = hashInput(enteredPattern)
            prefManager.setVaultPattern(newHash)
            _isUnlocked.value = true
            return true
        }
        val match = hashInput(enteredPattern) == savedHash
        if (match) _isUnlocked.value = true
        return match
    }

    suspend fun setLockMode(type: VaultLockType) {
        prefManager.setVaultLockType(type)
    }

    fun lockVault() {
        _isUnlocked.value = false
    }

    fun onAppBackgrounded() {
        _isUnlocked.value = false
    }

    suspend fun hideSong(song: SongItem): Boolean = withContext(Dispatchers.IO) {
        try {
            val originalFile = File(song.path)
            val inputStream: InputStream? = if (originalFile.exists() && originalFile.canRead()) {
                FileInputStream(originalFile)
            } else {
                context.contentResolver.openInputStream(song.contentUri)
            }
            if (inputStream == null) return@withContext false

            val ext = File(song.path).extension.takeIf { it.isNotBlank() } ?: "mp3"
            val safeOriginalPath = if (song.path.isNotBlank()) song.path else "/storage/emulated/0/Music/${song.title}.$ext"
            val encryptedFile = File(vaultDir, "vault_song_${song.id}_${System.currentTimeMillis()}.bin")
            val encryptedTemp = File(vaultDir, "${encryptedFile.name}.tmp")

            inputStream.use { input ->
                encryptStream(input, encryptedTemp)
            }

            if (encryptedFile.exists()) encryptedFile.delete()
            if (!encryptedTemp.renameTo(encryptedFile)) {
                encryptedTemp.copyTo(encryptedFile, overwrite = true)
                encryptedTemp.delete()
            }

            vaultDao.insertVaultMedia(
                VaultMediaEntity(
                    originalPath = safeOriginalPath,
                    encryptedPath = encryptedFile.absolutePath,
                    originalName = song.title,
                    mediaType = "AUDIO",
                    duration = song.duration,
                    size = if (originalFile.exists()) originalFile.length() else song.size
                )
            )

            try {
                if (originalFile.exists()) originalFile.delete()
            } catch (_: Exception) {}
            try {
                context.contentResolver.delete(song.contentUri, null, null)
            } catch (_: Exception) {}

            MediaScannerConnection.scanFile(context, arrayOf(safeOriginalPath), null, null)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun hideVideo(video: VideoItem): Boolean = withContext(Dispatchers.IO) {
        try {
            val originalFile = File(video.path)
            val inputStream: InputStream? = if (originalFile.exists() && originalFile.canRead()) {
                FileInputStream(originalFile)
            } else {
                context.contentResolver.openInputStream(video.contentUri)
            }
            if (inputStream == null) return@withContext false

            val ext = File(video.path).extension.takeIf { it.isNotBlank() } ?: "mp4"
            val safeOriginalPath = if (video.path.isNotBlank()) video.path else "/storage/emulated/0/Movies/${video.title}.$ext"
            val encryptedFile = File(vaultDir, "vault_vid_${video.id}_${System.currentTimeMillis()}.bin")
            val encryptedTemp = File(vaultDir, "${encryptedFile.name}.tmp")

            inputStream.use { input ->
                encryptStream(input, encryptedTemp)
            }

            if (encryptedFile.exists()) encryptedFile.delete()
            if (!encryptedTemp.renameTo(encryptedFile)) {
                encryptedTemp.copyTo(encryptedFile, overwrite = true)
                encryptedTemp.delete()
            }

            vaultDao.insertVaultMedia(
                VaultMediaEntity(
                    originalPath = safeOriginalPath,
                    encryptedPath = encryptedFile.absolutePath,
                    originalName = video.title,
                    mediaType = "VIDEO",
                    duration = video.duration,
                    size = if (originalFile.exists()) originalFile.length() else video.size
                )
            )

            try {
                if (originalFile.exists()) originalFile.delete()
            } catch (_: Exception) {}
            try {
                context.contentResolver.delete(video.contentUri, null, null)
            } catch (_: Exception) {}

            MediaScannerConnection.scanFile(context, arrayOf(safeOriginalPath), null, null)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun createPlaybackCopy(entity: VaultMediaEntity): File? = withContext(Dispatchers.IO) {
        try {
            val encryptedFile = File(entity.encryptedPath)
            if (!encryptedFile.exists() || encryptedFile.length() == 0L) return@withContext null

            val playbackDir = File(context.cacheDir, "vault_playback").apply { mkdirs() }
            val rawExt = File(entity.originalPath).extension
            val extension = if (rawExt.isNotBlank()) rawExt else (if (entity.mediaType == "VIDEO") "mp4" else "mp3")
            val target = File(
                playbackDir,
                "play_${kotlin.math.abs(entity.encryptedPath.hashCode())}.$extension"
            )

            if (target.exists() && target.length() > 0L) {
                return@withContext target
            }

            val temp = File(playbackDir, "${target.name}.tmp")
            decryptFile(encryptedFile, temp)
            if (!temp.exists() || temp.length() == 0L) {
                temp.delete()
                return@withContext null
            }
            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            target
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun restoreMedia(entity: VaultMediaEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            val encFile = File(entity.encryptedPath)
            if (!encFile.exists() || encFile.length() == 0L) return@withContext false

            val ext = File(entity.originalPath).extension.takeIf { it.isNotBlank() } ?: (if (entity.mediaType == "VIDEO") "mp4" else "mp3")
            val cleanName = entity.originalName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(60)
            val restoredTemp = File(context.cacheDir, "restore_${System.currentTimeMillis()}.$ext")
            decryptFile(encFile, restoredTemp)
            if (!restoredTemp.exists() || restoredTemp.length() == 0L) {
                restoredTemp.delete()
                return@withContext false
            }

            var restoredSuccessfully = false
            val preferredFile = File(entity.originalPath)
            val parentDir = preferredFile.parentFile
            if (parentDir != null && (parentDir.exists() || parentDir.mkdirs()) && parentDir.canWrite()) {
                val targetFile = if (preferredFile.exists()) {
                    File(parentDir, "${cleanName}_restored_${System.currentTimeMillis()}.$ext")
                } else preferredFile

                if (restoredTemp.renameTo(targetFile)) {
                    restoredSuccessfully = true
                    MediaScannerConnection.scanFile(context, arrayOf(targetFile.absolutePath), null, null)
                } else {
                    restoredTemp.copyTo(targetFile, overwrite = true)
                    restoredSuccessfully = true
                    MediaScannerConnection.scanFile(context, arrayOf(targetFile.absolutePath), null, null)
                }
            }

            if (!restoredSuccessfully) {
                val collection = if (entity.mediaType == "VIDEO") {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    } else {
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    }
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    } else {
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                    }
                }
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "${cleanName}_restored.$ext")
                    put(MediaStore.MediaColumns.MIME_TYPE, if (entity.mediaType == "VIDEO") "video/mp4" else "audio/mpeg")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.MediaColumns.RELATIVE_PATH, if (entity.mediaType == "VIDEO") Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_MUSIC)
                    }
                }
                val uri = context.contentResolver.insert(collection, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(restoredTemp).use { input ->
                            input.copyTo(out)
                        }
                    }
                    restoredSuccessfully = true
                }
            }

            if (!restoredSuccessfully) {
                val publicDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).apply { mkdirs() }
                val targetFile = File(publicDir, "${cleanName}_restored.$ext")
                restoredTemp.copyTo(targetFile, overwrite = true)
                restoredSuccessfully = true
                MediaScannerConnection.scanFile(context, arrayOf(targetFile.absolutePath), null, null)
            }

            restoredTemp.delete()
            if (restoredSuccessfully) {
                encFile.delete()
                vaultDao.deleteVaultMedia(entity)
                vaultDao.deleteByPath(entity.originalPath)
                vaultDao.deleteByEncryptedPath(entity.encryptedPath)
                return@withContext true
            }
            return@withContext false
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun deletePermanently(entity: VaultMediaEntity) = withContext(Dispatchers.IO) {
        try {
            val encFile = File(entity.encryptedPath)
            if (encFile.exists()) {
                encFile.delete()
            }
            vaultDao.deleteVaultMedia(entity)
            vaultDao.deleteByPath(entity.originalPath)
            vaultDao.deleteByEncryptedPath(entity.encryptedPath)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun resetVaultLock() {
        prefManager.setVaultPin(null)
        prefManager.setVaultPattern(null)
        prefManager.setVaultLockType(VaultLockType.PIN)
        _isUnlocked.value = false
    }

    suspend fun updatePin(newPin: String) {
        val newHash = hashInput(newPin)
        prefManager.setVaultPin(newHash)
        prefManager.setVaultLockType(VaultLockType.PIN)
    }

    suspend fun updatePattern(patternPoints: List<Int>) {
        val enteredPattern = patternPoints.joinToString("-")
        val newHash = hashInput(enteredPattern)
        prefManager.setVaultPattern(newHash)
        prefManager.setVaultLockType(VaultLockType.PATTERN)
    }

    suspend fun autoImportWhatsAppAndCallRecordings(): Int = withContext(Dispatchers.IO) {
        var importedCount = 0
        try {
            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            }
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.SIZE
            )

            context.contentResolver.query(collection, projection, null, null, null)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)

                while (cursor.moveToNext()) {
                    val path = cursor.getString(dataCol) ?: continue
                    val lowerPath = path.lowercase()
                    val isCall = lowerPath.contains("call") || lowerPath.contains("record") || lowerPath.contains("voicerecord")
                    val isWhatsApp = lowerPath.contains("whatsapp") || lowerPath.contains("opus")

                    if (isCall || isWhatsApp) {
                        val file = File(path)
                        if (file.exists() && file.isFile) {
                            val id = cursor.getLong(idCol)
                            val title = cursor.getString(titleCol) ?: file.name
                            val duration = cursor.getLong(durCol)
                            val size = cursor.getLong(sizeCol)
                            val contentUri = ContentUris.withAppendedId(collection, id)

                            hideSong(
                                SongItem(
                                    id = id,
                                    title = title,
                                    artist = if (isWhatsApp) "WhatsApp Audio" else "Call Recording",
                                    album = "Private",
                                    duration = duration,
                                    contentUri = contentUri,
                                    size = size,
                                    path = path
                                )
                            )
                            importedCount++
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        importedCount
    }

    private fun encryptStream(input: InputStream, dst: File) {
        val cipher = Cipher.getInstance("AES/CTR/NoPadding")
        val iv = ByteArray(16).apply {
            for (i in indices) this[i] = (i * 7 + 11).toByte()
        }
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, IvParameterSpec(iv))

        FileOutputStream(dst).use { rawOutput ->
            rawOutput.write(ENCRYPTED_FILE_MAGIC)
            CipherOutputStream(rawOutput, cipher).use { encryptedOutput ->
                input.copyTo(encryptedOutput)
            }
        }
    }

    private fun decryptFile(src: File, dst: File) {
        try {
            BufferedInputStream(FileInputStream(src)).use { input ->
                input.mark(64)
                val magic = ByteArray(ENCRYPTED_FILE_MAGIC.size)
                var bytesRead = 0
                while (bytesRead < magic.size) {
                    val c = input.read(magic, bytesRead, magic.size - bytesRead)
                    if (c < 0) break
                    bytesRead += c
                }

                if (bytesRead == ENCRYPTED_FILE_MAGIC.size && magic.contentEquals(ENCRYPTED_FILE_MAGIC)) {
                    val cipher = Cipher.getInstance("AES/CTR/NoPadding")
                    val iv = ByteArray(16).apply {
                        for (i in indices) this[i] = (i * 7 + 11).toByte()
                    }
                    cipher.init(Cipher.DECRYPT_MODE, secretKey, IvParameterSpec(iv))
                    CipherInputStream(input, cipher).use { decryptedInput ->
                        FileOutputStream(dst).use { output ->
                            decryptedInput.copyTo(output)
                        }
                    }
                    if (dst.exists() && dst.length() > 0L) return
                }

                input.reset()
                FileOutputStream(dst).use { output ->
                    val buffer = ByteArray(8192)
                    var count: Int
                    while (input.read(buffer).also { count = it } != -1) {
                        output.write(buffer, 0, count)
                    }
                }
            }
        } catch (e: Exception) {
            dst.delete()
            throw e
        }
    }

    companion object {
        private val ENCRYPTED_FILE_MAGIC = byteArrayOf(0x4C, 0x5A, 0x56, 0x30, 0x32, 0x21)
        @Volatile
        private var INSTANCE: VaultManager? = null

        fun getInstance(context: Context): VaultManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: VaultManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
