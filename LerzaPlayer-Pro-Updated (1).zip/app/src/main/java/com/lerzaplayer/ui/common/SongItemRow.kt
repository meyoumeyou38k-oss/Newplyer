package com.lerzaplayer.ui.common

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongItemRow(
    song: SongItem,
    isPlaying: Boolean,
    isCurrent: Boolean,
    isMultiSelectActive: Boolean,
    isSelected: Boolean,
    onSongClick: () -> Unit,
    onSongLongClick: () -> Unit,
    onToggleSelect: () -> Unit,
    onToggleFavorite: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onHideInVault: () -> Unit,
    onDelete: () -> Unit,
    densityScale: Float = 1.15f,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var menuExpanded by remember { mutableStateOf(false) }

    val thumbSize = (44f * densityScale).coerceIn(40f, 68f).dp
    val verticalPadding = (6f * densityScale).coerceIn(4f, 14f).dp
    val titleSize = (13.5f * densityScale).coerceIn(13f, 18f).sp
    val artistSize = (11f * densityScale).coerceIn(10f, 14f).sp

    val rowBackground = when {
        isSelected -> colors.primary.copy(alpha = 0.15f)
        isCurrent -> colors.primary.copy(alpha = 0.10f)
        else -> Color.Transparent
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(rowBackground)
            .combinedClickable(
                onClick = {
                    if (isMultiSelectActive) onToggleSelect() else onSongClick()
                },
                onLongClick = onSongLongClick
            )
            .padding(horizontal = 14.dp, vertical = verticalPadding),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isMultiSelectActive) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelect() },
                colors = CheckboxDefaults.colors(
                    checkedColor = colors.primary,
                    uncheckedColor = colors.textSecondary
                ),
                modifier = Modifier.padding(end = 6.dp)
            )
        }

        Box(
            modifier = Modifier
                .size(thumbSize)
                .clip(RoundedCornerShape(10.dp))
                .background(colors.card),
            contentAlignment = Alignment.Center
        ) {
            if (song.albumArtUri != null) {
                AsyncImage(
                    model = song.albumArtUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = LerzaIcons.MusicNote,
                    contentDescription = null,
                    tint = colors.textSecondary.copy(alpha = 0.6f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = song.title,
                fontSize = titleSize,
                fontWeight = FontWeight.SemiBold,
                color = if (isCurrent) colors.primary else colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "${song.artist} • ${song.durationFormatted}",
                    fontSize = artistSize,
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (song.isFavorite) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (song.isFavorite) Color(0xFFFF334B) else colors.textSecondary.copy(alpha = 0.6f),
                    modifier = Modifier.size(20.dp)
                )
            }
            IconButton(
                onClick = { menuExpanded = true },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = LerzaIcons.MoreVert,
                    contentDescription = "Options",
                    tint = colors.textSecondary.copy(alpha = 0.7f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }

    if (menuExpanded) {
        ModalBottomSheet(
            onDismissRequest = { menuExpanded = false },
            containerColor = colors.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 18.dp)
            ) {
                Text(song.title, color = colors.textPrimary, fontWeight = FontWeight.Bold, maxLines = 1)
                Spacer(modifier = Modifier.height(12.dp))
                DropdownMenuItem(
                    text = { Text("Play next") },
                    leadingIcon = { Icon(LerzaIcons.PlayArrow, null) },
                    onClick = { menuExpanded = false; onPlayNext() }
                )
                DropdownMenuItem(
                    text = { Text("Add to queue") },
                    leadingIcon = { Icon(LerzaIcons.QueueMusic, null) },
                    onClick = { menuExpanded = false; onAddToQueue() }
                )
                DropdownMenuItem(
                    text = { Text("Hide in vault") },
                    leadingIcon = { Icon(LerzaIcons.VisibilityOff, null) },
                    onClick = { menuExpanded = false; onHideInVault() }
                )
                DropdownMenuItem(
                    text = { Text("Delete", color = Color(0xFFFF334B)) },
                    leadingIcon = { Icon(LerzaIcons.Delete, null, tint = Color(0xFFFF334B)) },
                    onClick = { menuExpanded = false; onDelete() }
                )
            }
        }
    }
}
