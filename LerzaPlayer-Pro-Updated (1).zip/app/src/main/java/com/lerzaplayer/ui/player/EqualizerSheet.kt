package com.lerzaplayer.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.DynamicArtPalette
import com.lerzaplayer.theme.LocalLerzaColors
import kotlin.math.roundToInt

data class LarkPreset(
    val id: String,
    val name: String,
    val icon: ImageVector,
    val isBooster: Boolean = false,
    val bands: List<Int>,
    val bassStrength: Int = 0
)

val LARK_PRESETS = listOf(
    LarkPreset("custom", "Custom", Icons.Default.GraphicEq, isBooster = true, bands = listOf(0,0,0,0,0,0,0,0,0,0), bassStrength = 0),
    LarkPreset("bass_booster", "Bass booster", Icons.Default.VolumeUp, isBooster = true, bands = listOf(7, 6, 5, 3, 1, 0, 0, 0, 1, 2), bassStrength = 950),
    LarkPreset("vocal_booster", "Vocal booster", Icons.Default.Mic, isBooster = true, bands = listOf(-2, -2, -1, 1, 4, 5, 3, 1, 0, -1), bassStrength = 100),
    LarkPreset("treble_booster", "Treble booster", Icons.Default.SettingsVoice, isBooster = true, bands = listOf(-1, -1, 0, 0, 1, 2, 4, 6, 7, 7), bassStrength = 0),
    LarkPreset("normal", "Normal", Icons.Default.SentimentSatisfied, isBooster = false, bands = listOf(0,0,0,0,0,0,0,0,0,0), bassStrength = 0),
    LarkPreset("pop", "Pop", Icons.Default.MusicNote, isBooster = false, bands = listOf(-1, 1, 3, 4, 3, 1, -1, -1, 1, 2), bassStrength = 300),
    LarkPreset("hiphop", "HipHop", Icons.Default.Headphones, isBooster = false, bands = listOf(5, 4, 2, 1, -1, -1, 1, 2, 3, 3), bassStrength = 750),
    LarkPreset("rock", "Rock", Icons.Default.Whatshot, isBooster = false, bands = listOf(4, 3, 2, -1, -2, -1, 2, 3, 4, 4), bassStrength = 500),
    LarkPreset("electronic", "Electronic", Icons.Default.Bolt, isBooster = false, bands = listOf(4, 3, 1, 0, -2, 2, 1, 2, 4, 5), bassStrength = 650),
    LarkPreset("heavy_metal", "Heavy metal", Icons.Default.ElectricBolt, isBooster = false, bands = listOf(3, 2, 0, 0, -1, 1, 3, 4, 2, 0), bassStrength = 450),
    LarkPreset("rnb", "R&B", Icons.Default.Nightlife, isBooster = false, bands = listOf(3, 6, 4, 1, -2, -1, 2, 3, 4, 4), bassStrength = 700),
    LarkPreset("folk", "Folk", Icons.Default.Audiotrack, isBooster = false, bands = listOf(2, 1, 0, 2, 2, 1, 0, 1, 1, 0), bassStrength = 200),
    LarkPreset("dance", "Dance", Icons.Default.Album, isBooster = false, bands = listOf(5, 4, 2, 0, 2, 3, 4, 3, 2, 0), bassStrength = 800),
    LarkPreset("jazz", "Jazz", Icons.Default.QueueMusic, isBooster = false, bands = listOf(3, 3, 2, 0, -1, -1, 0, 2, 3, 4), bassStrength = 350),
    LarkPreset("classic", "Classic", Icons.Default.Piano, isBooster = false, bands = listOf(4, 3, 2, 2, -1, -1, 0, 2, 3, 3), bassStrength = 250),
    LarkPreset("latin", "Latin", Icons.Default.LibraryMusic, isBooster = false, bands = listOf(2, 1, 0, 0, -1, -1, 0, 2, 3, 4), bassStrength = 300)
)

val FREQUENCIES_10 = listOf("31", "63", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerSheet(
    playerManager: PlayerManager,
    dynamicPalette: DynamicArtPalette? = null,
    onDismiss: () -> Unit
) {
    val enabled by playerManager.equalizerEnabled.collectAsState()
    val virtualBands by playerManager.virtual10Bands.collectAsState()
    val activePresetId by playerManager.activePresetId.collectAsState()
    val themeColors = LocalLerzaColors.current

    val accentColor = dynamicPalette?.accentColor ?: themeColors.primary
    val dominantColor = dynamicPalette?.dominantColor ?: themeColors.surface
    val sheetBackgroundColor = Color(
        red = (dominantColor.red * 0.16f).coerceIn(0.06f, 0.15f),
        green = (dominantColor.green * 0.16f).coerceIn(0.06f, 0.15f),
        blue = (dominantColor.blue * 0.16f).coerceIn(0.07f, 0.17f),
        alpha = 0.98f
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = sheetBackgroundColor,
        contentColor = Color.White,
        dragHandle = {
            Box(
                Modifier
                    .padding(top = 10.dp, bottom = 4.dp)
                    .width(36.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.25f))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Equalizer",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Switch(
                    checked = enabled,
                    onCheckedChange = { playerManager.setEqualizerEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = accentColor,
                        uncheckedThumbColor = Color.Gray,
                        uncheckedTrackColor = Color.White.copy(alpha = 0.15f)
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .padding(horizontal = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                FREQUENCIES_10.forEachIndexed { index, freqLabel ->
                    val bandVal = virtualBands.getOrElse(index) { 0 }
                    val displayVal = if (bandVal > 0) "+$bandVal" else "$bandVal"
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = displayVal,
                            fontSize = 11.sp,
                            fontWeight = if (bandVal != 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (bandVal != 0 && enabled) accentColor else Color.White.copy(alpha = 0.45f)
                        )
                        LarkVerticalSlider(
                            value = bandVal,
                            range = -10..10,
                            accentColor = accentColor,
                            enabled = enabled,
                            onValueChange = { newVal ->
                                playerManager.setVirtual10Band(index, newVal)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .width(28.dp)
                                .padding(vertical = 4.dp)
                        )
                        Text(
                            text = freqLabel,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color.White.copy(alpha = 0.08f))
            )
            Spacer(modifier = Modifier.height(16.dp))

            val boosterPresets = remember { LARK_PRESETS.filter { it.isBooster } }
            PresetGrid(
                presets = boosterPresets,
                activePresetId = activePresetId,
                accentColor = accentColor,
                enabled = enabled,
                onSelectPreset = { preset -> playerManager.applyLarkPreset(preset) }
            )

            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color.White.copy(alpha = 0.08f))
            )
            Spacer(modifier = Modifier.height(12.dp))

            val genrePresets = remember { LARK_PRESETS.filter { !it.isBooster } }
            PresetGrid(
                presets = genrePresets,
                activePresetId = activePresetId,
                accentColor = accentColor,
                enabled = enabled,
                onSelectPreset = { preset -> playerManager.applyLarkPreset(preset) }
            )
        }
    }
}

@Composable
private fun PresetGrid(
    presets: List<LarkPreset>,
    activePresetId: String,
    accentColor: Color,
    enabled: Boolean,
    onSelectPreset: (LarkPreset) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        val chunked = presets.chunked(2)
        chunked.forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowItems.forEach { preset ->
                    val isSelected = activePresetId == preset.id
                    val isDarkText = accentColor.luminance() > 0.45f
                    val selectedTextColor = if (isDarkText) Color(0xFF101719) else Color.White
                    val unselectedBg = Color(0xFF1A2226)

                    Surface(
                        onClick = { if (enabled) onSelectPreset(preset) },
                        shape = RoundedCornerShape(18.dp),
                        color = if (isSelected) accentColor else unselectedBg,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) accentColor else Color.White.copy(alpha = 0.06f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(72.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(
                                imageVector = preset.icon,
                                contentDescription = null,
                                tint = if (isSelected) selectedTextColor else Color.White.copy(alpha = 0.7f),
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = preset.name,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                color = if (isSelected) selectedTextColor else Color.White.copy(alpha = 0.88f)
                            )
                        }
                    }
                }
                if (rowItems.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun LarkVerticalSlider(
    value: Int,
    range: IntRange = -10..10,
    accentColor: Color,
    enabled: Boolean,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalRange = (range.last - range.first).coerceAtLeast(1)
    val fraction = ((value - range.first).toFloat() / totalRange.toFloat()).coerceIn(0f, 1f)

    Box(
        modifier = modifier
            .fillMaxHeight()
            .then(
                if (enabled) {
                    Modifier
                        .pointerInput(range) {
                            fun updateY(y: Float) {
                                val trackH = (size.height - 24f).coerceAtLeast(1f)
                                val amount = (1f - ((y - 12f) / trackH)).coerceIn(0f, 1f)
                                val computed = (range.first + amount * totalRange).roundToInt()
                                onValueChange(computed.coerceIn(range.first, range.last))
                            }
                            detectTapGestures { updateY(it.y) }
                        }
                        .pointerInput(range) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                val trackH = (size.height - 24f).coerceAtLeast(1f)
                                val amount = (1f - ((change.position.y - 12f) / trackH)).coerceIn(0f, 1f)
                                val computed = (range.first + amount * totalRange).roundToInt()
                                onValueChange(computed.coerceIn(range.first, range.last))
                            }
                        }
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight()
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f))
        )
        Box(
            modifier = Modifier
                .width(8.dp)
                .height(1.dp)
                .background(Color.White.copy(alpha = 0.25f))
        )
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val trackH = (size.height - 24.dp.toPx()).coerceAtLeast(1f)
            val thumbY = (size.height - 12.dp.toPx()) - (fraction * trackH)
            val pillWidth = 8.dp.toPx()
            val pillHeight = 22.dp.toPx()
            drawRoundRect(
                color = if (enabled) accentColor else Color.Gray,
                topLeft = androidx.compose.ui.geometry.Offset((size.width - pillWidth) / 2f, thumbY - pillHeight / 2f),
                size = androidx.compose.ui.geometry.Size(pillWidth, pillHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(pillWidth / 2f, pillWidth / 2f)
            )
        }
    }
}
