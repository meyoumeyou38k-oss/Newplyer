package com.lerzaplayer.lyrics

import android.content.Context
import android.media.MediaMetadataRetriever
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.LyricsEntity
import com.lerzaplayer.data.model.LyricLine
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SongLyrics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object LyricsManager {
    suspend fun getLyricsForSong(context: Context, song: SongItem): SongLyrics = withContext(Dispatchers.IO) {
        val db = AppDatabase.getDatabase(context)

        val cached = db.lyricsDao().getLyrics(song.id)
        if (cached != null) {
            val lines = parseJsonToLyrics(cached.lyricsJson)
            if (lines.isNotEmpty()) {
                return@withContext SongLyrics(song.id, lines, isGenerated = !cached.isUserSaved)
            }
        }

        val embeddedLyrics = extractEmbeddedLyrics(context, song)
        if (embeddedLyrics.isNotEmpty()) {
            saveLyrics(context, song.id, embeddedLyrics, isUserSaved = true)
            return@withContext SongLyrics(song.id, embeddedLyrics, isGenerated = false)
        }

        if (song.path.isNotEmpty()) {
            try {
                val lrcPath = song.path.substringBeforeLast(".") + ".lrc"
                val lrcFile = File(lrcPath)
                if (lrcFile.exists() && lrcFile.canRead()) {
                    val lrcLines = parseLrcContent(lrcFile.readText())
                    if (lrcLines.isNotEmpty()) {
                        saveLyrics(context, song.id, lrcLines, isUserSaved = true)
                        return@withContext SongLyrics(song.id, lrcLines, isGenerated = false)
                    }
                }
            } catch (_: Exception) {}
        }

        val generatedLines = generateAILyricsBySong(song, "Original")
        saveLyrics(context, song.id, generatedLines, isUserSaved = false)
        SongLyrics(song.id, generatedLines, isGenerated = true)
    }

    private fun extractEmbeddedLyrics(context: Context, song: SongItem): List<LyricLine> {
        val retriever = MediaMetadataRetriever()
        try {
            if (song.path.isNotBlank() && File(song.path).exists()) {
                retriever.setDataSource(song.path)
            } else {
                retriever.setDataSource(context, song.contentUri)
            }
            val rawLyrics = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_COMPILATION)
            } else null ?: retriever.extractMetadata(1000)

            if (!rawLyrics.isNullOrBlank()) {
                if (rawLyrics.contains("[") && rawLyrics.contains("]")) {
                    val parsed = parseLrcContent(rawLyrics)
                    if (parsed.isNotEmpty()) return parsed
                } else {
                    return convertPlainTextToSynced(rawLyrics, song.duration)
                }
            }
        } catch (_: Exception) {
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
        return emptyList()
    }

    private fun convertPlainTextToSynced(plainLyrics: String, duration: Long): List<LyricLine> {
        val lines = plainLyrics.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        val dur = if (duration > 15000L) duration else 180000L
        val stepMs = (dur - 4000L) / lines.size.coerceAtLeast(1)
        val result = mutableListOf<LyricLine>()
        lines.forEachIndexed { index, text ->
            val timeMs = (index * stepMs).coerceAtMost(dur - 1000L)
            val sec = timeMs / 1000
            val min = sec / 60
            val s = sec % 60
            result.add(LyricLine(timeMs, text, "%02d:%02d".format(min, s)))
        }
        return result
    }

    suspend fun saveLyrics(context: Context, songId: Long, lines: List<LyricLine>, isUserSaved: Boolean = false) = withContext(Dispatchers.IO) {
        val array = JSONArray()
        lines.forEach { line ->
            val obj = JSONObject()
            obj.put("timestampMs", line.timestampMs)
            obj.put("text", line.text)
            obj.put("timeFormatted", line.timeFormatted)
            array.put(obj)
        }
        val entity = LyricsEntity(
            songId = songId,
            lyricsJson = array.toString(),
            isUserSaved = isUserSaved
        )
        AppDatabase.getDatabase(context).lyricsDao().insertLyrics(entity)
    }

    private fun parseJsonToLyrics(json: String): List<LyricLine> {
        val list = mutableListOf<LyricLine>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    LyricLine(
                        timestampMs = obj.getLong("timestampMs"),
                        text = obj.getString("text"),
                        timeFormatted = obj.getString("timeFormatted")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun parseLrcContent(content: String): List<LyricLine> {
        val result = mutableListOf<LyricLine>()
        content.lines().forEach { rawLine ->
            val line = rawLine.trim()
            val open = line.indexOf('[')
            val close = line.indexOf(']')
            if (open >= 0 && close > open) {
                val timeStr = line.substring(open + 1, close)
                val text = line.substring(close + 1).trim()
                val colonIdx = timeStr.indexOf(':')
                if (colonIdx > 0) {
                    val min = timeStr.substring(0, colonIdx).toLongOrNull() ?: 0L
                    val rest = timeStr.substring(colonIdx + 1)
                    val dotIdx = rest.indexOf('.')
                    val sec = if (dotIdx > 0) rest.substring(0, dotIdx).toLongOrNull() ?: 0L else rest.toLongOrNull() ?: 0L
                    val ms = if (dotIdx > 0 && dotIdx < rest.length - 1) {
                        val msPart = rest.substring(dotIdx + 1)
                        if (msPart.length == 2) (msPart.toLongOrNull() ?: 0L) * 10 else (msPart.toLongOrNull() ?: 0L)
                    } else 0L
                    val totalMs = (min * 60 + sec) * 1000 + ms
                    if (text.isNotEmpty()) {
                        result.add(LyricLine(totalMs, text, "%02d:%02d".format(min, sec)))
                    }
                }
            }
        }
        return result.sortedBy { it.timestampMs }
    }

    fun generateAILyricsBySong(song: SongItem, targetLanguage: String): List<LyricLine> {
        val dur = if (song.duration > 15000L) song.duration else 180000L
        val title = song.title.trim()
        val artist = if (song.artist.contains("unknown", ignoreCase = true)) "Lerza Audio" else song.artist.trim()

        val verses = listOf(
            "[Music Intro]",
            "$title - $artist",
            "Listen to the melody in rhythm and soul",
            "[Acoustic Solo]",
            "Moments and memories carried by the song",
            "Harmonies rising into the night",
            "[Instrumental Break]",
            "Feel the harmony and music flow",
            "[Outro - Fading Sound]"
        )

        val stepMs = (dur - 4000L) / verses.size.coerceAtLeast(1)
        val list = mutableListOf<LyricLine>()
        verses.forEachIndexed { index, text ->
            val timeMs = (index * stepMs).coerceAtMost(dur - 1000L)
            val sec = timeMs / 1000
            val min = sec / 60
            val s = sec % 60
            list.add(LyricLine(timeMs, text, "%02d:%02d".format(min, s)))
        }
        return list
    }
}
