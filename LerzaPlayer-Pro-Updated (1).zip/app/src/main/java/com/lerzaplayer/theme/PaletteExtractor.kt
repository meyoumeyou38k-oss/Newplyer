package com.lerzaplayer.theme

import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import kotlin.math.abs

data class DynamicArtPalette(
    val dominantColor: Color,
    val accentColor: Color,
    val deepDarkColor: Color,
    val softLightBackground: Color
)

object PaletteExtractor {
    private val aestheticHueList = listOf(
        PalettePreset(Color(0xFFE88A9E), Color(0xFFFF4081), Color(0xFF2C0B18), Color(0xFFFFF0F3)),
        PalettePreset(Color(0xFF48C9B0), Color(0xFF1ABC9C), Color(0xFF0B2521), Color(0xFFEFFBF9)),
        PalettePreset(Color(0xFF5DADE2), Color(0xFF00B0FF), Color(0xFF0A1D2E), Color(0xFFF0F8FF)),
        PalettePreset(Color(0xFFF39C12), Color(0xFFFF6F00), Color(0xFF2E1903), Color(0xFFFFF7ED)),
        PalettePreset(Color(0xFFA569BD), Color(0xFF8E24AA), Color(0xFF230D2B), Color(0xFFF9F0FC)),
        PalettePreset(Color(0xFFF1948A), Color(0xFFFF5252), Color(0xFF2D0E0E), Color(0xFFFFF1F0)),
        PalettePreset(Color(0xFF52BE80), Color(0xFF00C853), Color(0xFF0E2818), Color(0xFFF0FDF4)),
        PalettePreset(Color(0xFFF4D03F), Color(0xFFFFB300), Color(0xFF282003), Color(0xFFFFFBEB)),
        PalettePreset(Color(0xFF7D85E8), Color(0xFF651FFF), Color(0xFF13152E), Color(0xFFF3F4FE)),
        PalettePreset(Color(0xFF38B2AC), Color(0xFF00E5FF), Color(0xFF0A2422), Color(0xFFEDFCFB))
    )

    fun extractPalette(bitmap: Bitmap?, seedKey: Long): DynamicArtPalette {
        if (bitmap != null) {
            try {
                val w = bitmap.width
                val h = bitmap.height
                val p1 = bitmap.getPixel(w / 4, h / 4)
                val p2 = bitmap.getPixel(w / 2, h / 2)
                val p3 = bitmap.getPixel(3 * w / 4, 3 * h / 4)
                val c1 = Color(p1)
                val c2 = Color(p2)
                val c3 = Color(p3)
                val dominant = if (isVibrant(c1)) c1 else if (isVibrant(c2)) c2 else c3
                val accent = if (c2 != dominant && isVibrant(c2)) c2 else if (c3 != dominant) c3 else Color(0xFF00E5FF)
                val deep = Color(
                    red = (dominant.red * 0.15f).coerceIn(0.04f, 0.2f),
                    green = (dominant.green * 0.15f).coerceIn(0.04f, 0.2f),
                    blue = (dominant.blue * 0.15f).coerceIn(0.05f, 0.25f),
                    alpha = 1f
                )
                val softLight = Color(
                    red = dominant.red + (1f - dominant.red) * 0.76f,
                    green = dominant.green + (1f - dominant.green) * 0.76f,
                    blue = dominant.blue + (1f - dominant.blue) * 0.76f,
                    alpha = 1f
                )
                return DynamicArtPalette(dominant, accent, deep, softLight)
            } catch (_: Exception) {}
        }
        val hash = abs(seedKey.hashCode())
        val picked = aestheticHueList[hash % aestheticHueList.size]
        return DynamicArtPalette(
            dominantColor = picked.dominant,
            accentColor = picked.accent,
            deepDarkColor = picked.deep,
            softLightBackground = picked.softLight
        )
    }

    private fun isVibrant(color: Color): Boolean {
        val max = maxOf(color.red, color.green, color.blue)
        val min = minOf(color.red, color.green, color.blue)
        val saturation = if (max == 0f) 0f else (max - min) / max
        return saturation > 0.25f && max > 0.2f
    }

    private data class PalettePreset(
        val dominant: Color,
        val accent: Color,
        val deep: Color,
        val softLight: Color
    )
}
