# Lerza Player Pro - Android Source Code (Updated)

This updated project includes the new official App Icon and Transparent Brand Logo:
- **App Icon**: Fully integrated across standard mipmap densities (`mdpi`, `hdpi`, `xhdpi`, `xxhdpi`, `xxxhdpi`, `anydpi-v26`) and `@drawable/app_icon`.
- **Transparent Logo**: Integrated into `AutoHidingHeader`, notification status icons, and `@drawable/brand_logo.png` / `@drawable/ic_logo_transparent.png`.
- **Zero Asset Conflicts**: Clean single-format resource files without double extension collisions (`.jpg` vs `.png`).
- **Complete Build Support**: Includes Gradle 8.7 wrapper, Android SDK 34 target, Jetpack Compose 2024.06.00, Media3 ExoPlayer, and Room Database.

## How to Build APK
```bash
chmod +x ./gradlew
./gradlew assembleDebug
```
The output APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`
