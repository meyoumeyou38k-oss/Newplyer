package com.lerzaplayer.ui.home

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.albums.AlbumsScreen
import com.lerzaplayer.ui.artists.ArtistsScreen
import com.lerzaplayer.ui.common.AddToPlaylistDialog
import com.lerzaplayer.ui.common.AutoHidingHeader
import com.lerzaplayer.ui.common.MultiSelectActionBar
import com.lerzaplayer.ui.common.TabsRow
import com.lerzaplayer.ui.folders.FoldersScreen
import com.lerzaplayer.ui.player.MiniPlayer
import com.lerzaplayer.ui.playlists.PlaylistsScreen
import com.lerzaplayer.ui.songs.SongListScreen
import com.lerzaplayer.ui.videos.VideoListScreen
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    playerManager: PlayerManager,
    prefManager: PreferenceManager,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onOpenVault: () -> Unit,
    onExpandFullPlayer: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onToggleFavoriteVideo: (VideoItem) -> Unit,
    onHideSongInVault: (SongItem) -> Unit,
    onHideVideoInVault: (VideoItem) -> Unit,
    onDeleteSong: (SongItem) -> Unit,
    onDeleteVideo: (VideoItem) -> Unit,
    onScanDevice: () -> Unit
) {
    val context = LocalContext.current
    val colors = LocalLerzaColors.current
    val scope = rememberCoroutineScope()

    val tabs = remember {
        listOf("VIDEOS", "SONGS", "PLAYLISTS", "FOLDERS", "ALBUMS", "ARTISTS")
    }
    val pagerState = rememberPagerState(initialPage = 1, pageCount = { tabs.size })

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()
    val songSort by prefManager.songSortFlow.collectAsState(initial = com.lerzaplayer.data.model.SortOption.DATE_ADDED_DESC)
    val videoSort by prefManager.videoSortFlow.collectAsState(initial = com.lerzaplayer.data.model.SortOption.DATE_ADDED_DESC)
    val videoViewMode by prefManager.videoViewModeFlow.collectAsState(initial = com.lerzaplayer.data.model.ViewMode.GRID)

    var isMultiSelectMode by remember { mutableStateOf(false) }
    val selectedSongIds = remember { mutableStateListOf<Long>() }
    var songsForPlaylistDialog by remember { mutableStateOf<List<SongItem>>(emptyList()) }

    BackHandler(enabled = isMultiSelectMode) {
        selectedSongIds.clear()
        isMultiSelectMode = false
    }

    Scaffold(
        containerColor = colors.background,
        topBar = {
            AutoHidingHeader(
                onSearchClick = onSearchClick,
                onSettingsClick = onSettingsClick,
                onScanClick = onScanDevice,
                tabs = {
                    TabsRow(
                        tabs = tabs,
                        selectedTabIndex = pagerState.currentPage,
                        onTabSelected = { index ->
                            scope.launch { pagerState.animateScrollToPage(index) }
                        }
                    )
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                when (page) {
                    0 -> {
                        VideoListScreen(
                            videos = videos,
                            viewMode = videoViewMode,
                            sortOption = videoSort,
                            onVideoClick = onPlayVideo,
                            onViewModeChanged = { mode ->
                                scope.launch { prefManager.setVideoViewMode(mode) }
                            },
                            onSortChanged = { option ->
                                scope.launch { prefManager.setVideoSort(option) }
                            },
                            onToggleFavorite = onToggleFavoriteVideo,
                            onHideInVault = onHideVideoInVault,
                            onDelete = onDeleteVideo
                        )
                    }
                    1 -> {
                        SongListScreen(
                            songs = songs,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            sortOption = songSort,
                            isMultiSelectActive = isMultiSelectMode,
                            selectedSongIds = selectedSongIds,
                            onSongClick = { song, list, index ->
                                if (isMultiSelectMode) {
                                    if (selectedSongIds.contains(song.id)) {
                                        selectedSongIds.remove(song.id)
                                        if (selectedSongIds.isEmpty()) isMultiSelectMode = false
                                    } else {
                                        selectedSongIds.add(song.id)
                                    }
                                } else {
                                    playerManager.playSongList(list, index)
                                }
                            },
                            onSongLongClick = { id ->
                                isMultiSelectMode = true
                                if (!selectedSongIds.contains(id)) selectedSongIds.add(id)
                            },
                            onSortChanged = { option ->
                                scope.launch { prefManager.setSongSort(option) }
                            },
                            onToggleFavorite = onToggleFavoriteSong,
                            onPlayNext = { playerManager.playNext(it) },
                            onAddToQueue = { playerManager.addToQueue(it) },
                            onAddToPlaylist = { song -> songsForPlaylistDialog = listOf(song) },
                            onHideInVault = onHideSongInVault,
                            onDelete = onDeleteSong
                        )
                    }
                    2 -> {
                        PlaylistsScreen(
                            songs = songs,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            onSongClick = { song, list, index ->
                                playerManager.playSongList(list, index)
                                onExpandFullPlayer()
                            },
                            onToggleFavorite = onToggleFavoriteSong,
                            onHideInVault = onHideSongInVault,
                            onDelete = onDeleteSong
                        )
                    }
                    3 -> {
                        FoldersScreen(
                            songs = songs,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            onSongClick = { song, list, index ->
                                playerManager.playSongList(list, index)
                                onExpandFullPlayer()
                            },
                            onToggleFavorite = onToggleFavoriteSong,
                            onHideInVault = onHideSongInVault,
                            onDelete = onDeleteSong
                        )
                    }
                    4 -> {
                        AlbumsScreen(
                            songs = songs,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            onSongClick = { song, list, index ->
                                playerManager.playSongList(list, index)
                                onExpandFullPlayer()
                            },
                            onToggleFavorite = onToggleFavoriteSong,
                            onHideInVault = onHideSongInVault,
                            onDelete = onDeleteSong
                        )
                    }
                    5 -> {
                        ArtistsScreen(
                            songs = songs,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            onSongClick = { song, list, index ->
                                playerManager.playSongList(list, index)
                                onExpandFullPlayer()
                            },
                            onToggleFavorite = onToggleFavoriteSong,
                            onHideInVault = onHideSongInVault,
                            onDelete = onDeleteSong
                        )
                    }
                }
            }

            if (currentSong != null && !isMultiSelectMode) {
                MiniPlayer(
                    currentSong = currentSong,
                    isPlaying = isPlaying,
                    onExpand = onExpandFullPlayer,
                    onPlayPause = { playerManager.playPause() },
                    onNext = { playerManager.playNextTrack() },
                    onOpenQueue = onExpandFullPlayer,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 4.dp)
                )
            }

            // 🌟 گانوں کو پلے لسٹ میں شامل کرنے کا خودکار ڈائیلاگ
            if (songsForPlaylistDialog.isNotEmpty()) {
                AddToPlaylistDialog(
                    songs = songsForPlaylistDialog,
                    onDismiss = {
                        songsForPlaylistDialog = emptyList()
                        if (isMultiSelectMode) {
                            selectedSongIds.clear()
                            isMultiSelectMode = false
                        }
                    }
                )
            }

            // 🌟 ملٹی سلیکٹ ایکشن بار
            MultiSelectActionBar(
                visible = isMultiSelectMode,
                selectedCount = selectedSongIds.size,
                onClearSelection = {
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onSelectAll = {
                    selectedSongIds.clear()
                    selectedSongIds.addAll(songs.map { it.id })
                },
                onAddToPlaylistSelected = {
                    val selected = songs.filter { selectedSongIds.contains(it.id) }
                    if (selected.isNotEmpty()) {
                        songsForPlaylistDialog = selected
                    }
                },
                onAddToQueueSelected = {
                    songs.filter { selectedSongIds.contains(it.id) }
                        .forEach { playerManager.addToQueue(it) }
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onPlayNextSelected = {
                    songs.filter { selectedSongIds.contains(it.id) }
                        .asReversed()
                        .forEach { playerManager.playNext(it) }
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onShareSelected = {
                    val selectedSongs = songs.filter { selectedSongIds.contains(it.id) }
                    if (selectedSongs.isNotEmpty()) {
                        val shareIntent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                            type = "audio/*"
                            putParcelableArrayListExtra(
                                Intent.EXTRA_STREAM,
                                ArrayList(selectedSongs.map { it.contentUri })
                            )
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share songs"))
                    }
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onHideSelected = {
                    songs.filter { selectedSongIds.contains(it.id) }
                        .forEach(onHideSongInVault)
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onDeleteSelected = {
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}