package com.lerzaplayer.playback

import android.content.ContentUris
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.content.pm.PackageManager
import android.Manifest
import android.os.Build
import com.lerzaplayer.data.repository.ThumbnailExtractor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Watches MediaStore for newly indexed audio and video while the app process is alive. */
class MediaDownloadMonitor(context: Context) {
    private val appContext = context.applicationContext
    private val resolver = appContext.contentResolver
    private val preferences = appContext.getSharedPreferences("media_download_monitor", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val seenIds = preferences.getStringSet("seen_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
    private var scanJob: Job? = null
    @Volatile private var isStarted = false

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean, uri: Uri?) {
            scheduleScan()
        }

        override fun onChange(selfChange: Boolean) {
            scheduleScan()
        }
    }

    @Synchronized
    fun start() {
        if (isStarted || !hasMediaPermission()) return

        // On the first run, treat files already on the device as existing library content.
        if (!preferences.getBoolean("initialized", false)) {
            val existing = queryExistingIds()
            synchronized(seenIds) { seenIds.addAll(existing) }
            persistSeenIds()
            preferences.edit().putBoolean("initialized", true).apply()
        }

        resolver.registerContentObserver(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, observer)
        resolver.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, observer)
        isStarted = true
    }

    @Synchronized
    fun stop() {
        if (!isStarted) return
        runCatching { resolver.unregisterContentObserver(observer) }
        isStarted = false
    }

    private fun hasMediaPermission(): Boolean {
        val audioPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        val videoPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return appContext.checkSelfPermission(audioPermission) == PackageManager.PERMISSION_GRANTED ||
            appContext.checkSelfPermission(videoPermission) == PackageManager.PERMISSION_GRANTED
    }

    @Synchronized
    private fun scheduleScan() {
        if (!isStarted) return
        scanJob?.cancel()
        scanJob = scope.launch {
            delay(700)
            scanAudio()
            scanVideos()
        }
    }

    private suspend fun scanAudio() = withContext(Dispatchers.IO) {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.IS_MUSIC,
            MediaStore.Audio.Media.DURATION
        )
        runCatching {
            resolver.query(collection, projection, null, null, "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val musicIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_MUSIC)
                val durationIndex = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (cursor.moveToNext()) {
                    if (cursor.getInt(musicIndex) == 0 || cursor.getLong(durationIndex) <= 10_000L) continue
                    val id = cursor.getLong(idIndex)
                    if (!markAsNew("audio", id)) continue
                    val title = cursor.getString(titleIndex)?.takeIf(String::isNotBlank) ?: "Unknown title"
                    val artist = cursor.getString(artistIndex)?.takeIf { it.isNotBlank() && it != "<unknown>" }
                        ?: "Unknown artist"
                    val mediaUri = ContentUris.withAppendedId(collection, id)
                    val artwork = ThumbnailExtractor.getSongCover(appContext, mediaUri, id)
                    NotificationHelper.showNewMediaNotification(
                        appContext, "New song downloaded", title, artist, artwork, "audio:$id"
                    )
                }
            }
        }
    }

    private suspend fun scanVideos() = withContext(Dispatchers.IO) {
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE)
        runCatching {
            resolver.query(collection, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { cursor ->
                val idIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idIndex)
                    if (!markAsNew("video", id)) continue
                    val title = cursor.getString(titleIndex)?.takeIf(String::isNotBlank) ?: "New video"
                    val mediaUri = ContentUris.withAppendedId(collection, id)
                    val thumbnail = ThumbnailExtractor.getVideoThumbnail(appContext, mediaUri, id)
                    NotificationHelper.showNewMediaNotification(
                        appContext, "New video downloaded", title, "Added to your device", thumbnail, "video:$id"
                    )
                }
            }
        }
    }

    private fun markAsNew(type: String, id: Long): Boolean {
        val key = "$type:$id"
        val added = synchronized(seenIds) { seenIds.add(key) }
        if (added) persistSeenIds()
        return added
    }

    private fun queryExistingIds(): Set<String> {
        val result = mutableSetOf<String>()
        listOf(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to MediaStore.Audio.Media._ID,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI to MediaStore.Video.Media._ID
        ).forEach { (collection, idColumn) ->
            val type = if (collection == MediaStore.Audio.Media.EXTERNAL_CONTENT_URI) "audio" else "video"
            runCatching {
                resolver.query(collection, arrayOf(idColumn), null, null, null)?.use { cursor ->
                    val index = cursor.getColumnIndexOrThrow(idColumn)
                    while (cursor.moveToNext()) result.add("$type:${cursor.getLong(index)}")
                }
            }
        }
        return result
    }

    private fun persistSeenIds() {
        synchronized(seenIds) {
            preferences.edit().putStringSet("seen_ids", HashSet(seenIds)).apply()
        }
    }

    fun release() {
        stop()
        scope.cancel()
    }
}
