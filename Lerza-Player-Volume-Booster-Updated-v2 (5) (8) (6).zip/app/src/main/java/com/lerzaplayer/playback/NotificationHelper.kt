package com.lerzaplayer.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaStyleNotificationHelper
import com.lerzaplayer.MainActivity
import com.lerzaplayer.R
import com.lerzaplayer.data.model.SongItem

object NotificationHelper {
    const val CHANNEL_PLAYBACK_ID = "lerza_playback_channel"
    const val CHANNEL_REMINDER_ID = "lerza_reminder_channel"
    const val CHANNEL_DOWNLOAD_ID = "lerza_new_media_channel"
    const val NOTIFICATION_ID = 1001
    const val REMINDER_NOTIFICATION_ID = 2001
    private const val NEW_MEDIA_NOTIFICATION_ID_BASE = 3000

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(
                NotificationChannel(CHANNEL_PLAYBACK_ID, "Playback Controls", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Now playing controls and song timeline"
                    setShowBadge(false)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
            )
            notificationManager.createNotificationChannel(
                NotificationChannel(CHANNEL_REMINDER_ID, "Music Recommendations & Reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Music recommendations and listening reminders"
                    enableVibration(true)
                }
            )
            notificationManager.createNotificationChannel(
                NotificationChannel(CHANNEL_DOWNLOAD_ID, "New downloads", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Notifies you when a new song or video is added to your device"
                    setShowBadge(true)
                }
            )
        }
    }

    fun buildMediaNotification(
        context: Context,
        song: SongItem?,
        isPlaying: Boolean,
        albumArt: Bitmap?,
        currentPosition: Long = 0L,
        duration: Long = 0L,
        mediaSession: MediaSession? = null
    ): Notification {
        createNotificationChannels(context)

        val mainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val mainPendingIntent = PendingIntent.getActivity(
            context, 0, mainIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val prevPending = servicePendingIntent(context, 1, PlaybackService.ACTION_PREV)
        val playPausePending = servicePendingIntent(
            context, 2, if (isPlaying) PlaybackService.ACTION_PAUSE else PlaybackService.ACTION_PLAY
        )
        val nextPending = servicePendingIntent(context, 3, PlaybackService.ACTION_NEXT)

        val builder = NotificationCompat.Builder(context, CHANNEL_PLAYBACK_ID)
            .setSmallIcon(R.drawable.ic_logo_transparent)
            .setContentTitle(song?.title ?: "Lerza Player Pro")
            .setContentText(song?.artist ?: "Ready to Play")
            .setSubText("Lerza Player Pro")
            .setContentIntent(mainPendingIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(isPlaying)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_previous, "Previous", prevPending)
            .addAction(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (isPlaying) "Pause" else "Play",
                playPausePending
            )
            .addAction(android.R.drawable.ic_media_next, "Next", nextPending)

        // Media3's MediaStyle attaches the MediaSession token. Android then renders the
        // real seek/timeline controls and keeps them synchronized with ExoPlayer's position.
        if (mediaSession != null) {
            builder.setStyle(
                MediaStyleNotificationHelper.MediaStyle(mediaSession)
                    .setShowActionsInCompactView(0, 1, 2)
            )
        }
        if (albumArt != null) builder.setLargeIcon(albumArt)

        return builder.build()
    }

    private fun servicePendingIntent(context: Context, requestCode: Int, action: String): PendingIntent {
        val intent = Intent(context, PlaybackService::class.java).setAction(action)
        return PendingIntent.getService(
            context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun showNewMediaNotification(
        context: Context,
        heading: String,
        title: String,
        detail: String,
        thumbnail: Bitmap?,
        mediaKey: String
    ) {
        createNotificationChannels(context)
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context, mediaKey.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(context, CHANNEL_DOWNLOAD_ID)
            .setSmallIcon(R.drawable.ic_logo_transparent)
            .setContentTitle(heading)
            .setContentText(title)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$title\n$detail"))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setOnlyAlertOnce(true)
        if (thumbnail != null) builder.setLargeIcon(thumbnail)

        val notificationId = NEW_MEDIA_NOTIFICATION_ID_BASE + (mediaKey.hashCode() and 0x7fffffff) % 100000
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        runCatching { notificationManager.notify(notificationId, builder.build()) }
    }

    fun showInactivityReminder(context: Context, songTitle: String, artist: String) {
        createNotificationChannels(context)
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDER_ID)
            .setSmallIcon(R.drawable.ic_logo_transparent)
            .setContentTitle("Missing your tunes? Play \"$songTitle\"")
            .setContentText("Tap to resume listening to $artist!")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Your favorite song \"$songTitle\" by $artist is ready. Tap to open Lerza Player Pro!")
            )
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(REMINDER_NOTIFICATION_ID, notification)
    }
}
