package com.lerzaplayer.ui.home

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lerzaplayer.data.model.*
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.AutoHidingHeader
import com.lerzaplayer.ui.common.MultiSelectActionBar
import com.lerzaplayer.ui.common.TabsRow
import com.lerzaplayer.ui.common.WallpaperBackground
import com.lerzaplayer.ui.player.MiniPlayer
import com.lerzaplayer.ui.songs.SongListScreen
import com.lerzaplayer.ui.videos.VideoListScreen
import com.lerzaplayer.ui.playlists.PlaylistsScreen
import com.lerzaplayer.ui.folders.FoldersScreen
import com.lerzaplayer.ui.albums.AlbumsScreen
import com.lerzaplayer.ui.artists.ArtistsScreen
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    playerManager: PlayerManager,
    prefManager: PreferenceManager,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onOpenVault: () -> Unit,
    onExpandFullPlayer: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onToggleFavoriteVideo: (VideoItem) -> Unit,
    onHideSongInVault: (SongItem) -> Unit,
    onHideVideoInVault: (VideoItem) -> Unit,
    onDeleteSong: (SongItem) -> Unit,
    onDeleteVideo: (VideoItem) -> Unit,
    onScanDevice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()
    val wallpaperUri by prefManager.wallpaperUriFlow.collectAsState(initial = null)
    val wallpaperOpacity by prefManager.wallpaperOpacityFlow.collectAsState(initial = 0.75f)
    val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
    val videoViewMode by prefManager.videoViewModeFlow.collectAsState(initial = ViewMode.GRID)

    val pagerState = rememberPagerState(initialPage = 1, pageCount = { 6 })

    var headerVisible by remember { mutableStateOf(true) }
    val nestedScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -10f) {
                    headerVisible = false
                } else if (available.y > 10f) {
                    headerVisible = true
                }
                return Offset.Zero
            }
        }
    }

    var isMultiSelectMode by remember { mutableStateOf(false) }
    val selectedSongIds = remember { mutableStateListOf<Long>() }

    BackHandler(enabled = isMultiSelectMode) {
        isMultiSelectMode = false
        selectedSongIds.clear()
    }

    BackHandler(enabled = !isMultiSelectMode && pagerState.currentPage != 1) {
        scope.launch { pagerState.animateScrollToPage(1) }
    }

    fun toggleSongSelection(id: Long) {
        if (selectedSongIds.contains(id)) {
            selectedSongIds.remove(id)
            if (selectedSongIds.isEmpty()) isMultiSelectMode = false
        } else {
            selectedSongIds.add(id)
        }
    }

    WallpaperBackground(
        wallpaperUri = wallpaperUri,
        opacity = wallpaperOpacity
    ) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .nestedScroll(nestedScrollConnection)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                AutoHidingHeader(
                    visible = headerVisible,
                    onSearchClick = onSearchClick,
                    onSettingsClick = onSettingsClick
                )

                TabsRow(
                    selectedTab = pagerState.currentPage,
                    onTabSelected = { index ->
                        scope.launch { pagerState.animateScrollToPage(index) }
                    }
                )

                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.weight(1f)
                ) { page ->
                    when (page) {
                        0 -> {
                            VideoListScreen(
                                videos = videos,
                                viewMode = videoViewMode,
                                onVideoClick = onPlayVideo,
                                onViewModeToggle = {
                                    scope.launch {
                                        val nextMode = if (videoViewMode == ViewMode.GRID) ViewMode.LIST else ViewMode.GRID
                                        prefManager.setVideoViewMode(nextMode)
                                    }
                                },
                                onScanDevice = onScanDevice,
                                onToggleFavorite = onToggleFavoriteVideo,
                                onHideInVault = onHideVideoInVault,
                                onDelete = onDeleteVideo
                            )
                        }
                        1 -> {
                            SongListScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                currentSort = songSort,
                                selectedSongIds = selectedSongIds.toSet(),
                                isMultiSelectMode = isMultiSelectMode,
                                onSongClick = { song, index ->
                                    playerManager.playSongList(songs, index)
                                    onExpandFullPlayer()
                                },
                                onToggleSelect = ::toggleSongSelection,
                                onStartMultiSelect = { id ->
                                    isMultiSelectMode = true
                                    if (!selectedSongIds.contains(id)) selectedSongIds.add(id)
                                },
                                onSortChanged = { option ->
                                    scope.launch { prefManager.setSongSort(option) }
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onPlayNext = { playerManager.playNext(it) },
                                onAddToQueue = { playerManager.addToQueue(it) },
                                onAddToPlaylist = { },
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                        2 -> {
                            PlaylistsScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                onSongClick = { song, list, index ->
                                    playerManager.playSongList(list, index)
                                    onExpandFullPlayer()
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                        3 -> {
                            FoldersScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                onSongClick = { song, list, index ->
                                    playerManager.playSongList(list, index)
                                    onExpandFullPlayer()
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                        4 -> {
                            AlbumsScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                onSongClick = { song, list, index ->
                                    playerManager.playSongList(list, index)
                                    onExpandFullPlayer()
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                        else -> {
                            ArtistsScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                onSongClick = { song, list, index ->
                                    playerManager.playSongList(list, index)
                                    onExpandFullPlayer()
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                    }
                }
            }

            if (currentSong != null && !isMultiSelectMode) {
                MiniPlayer(
                    currentSong = currentSong,
                    isPlaying = isPlaying,
                    onExpand = onExpandFullPlayer,
                    onPlayPause = { playerManager.playPause() },
                    onNext = { playerManager.playNextTrack() },
                    onOpenQueue = onExpandFullPlayer,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }

            MultiSelectActionBar(
                visible = isMultiSelectMode,
                selectedCount = selectedSongIds.size,
                onClearSelection = {
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onSelectAll = {
                    selectedSongIds.clear()
                    selectedSongIds.addAll(songs.map { it.id })
                },
                onAddToQueueSelected = {
                    songs.filter { selectedSongIds.contains(it.id) }
                        .forEach { playerManager.addToQueue(it) }
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onPlayNextSelected = {
                    songs.filter { selectedSongIds.contains(it.id) }
                        .asReversed()
                        .forEach { playerManager.playNext(it) }
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onShareSelected = {
                    val selectedSongs = songs.filter { selectedSongIds.contains(it.id) }
                    if (selectedSongs.isNotEmpty()) {
                        val shareIntent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                            type = "audio/*"
                            putParcelableArrayListExtra(
                                Intent.EXTRA_STREAM,
                                ArrayList(selectedSongs.map { it.contentUri })
                            )
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share songs"))
                    }
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onHideSelected = {
                    songs.filter { selectedSongIds.contains(it.id) }
                        .forEach(onHideSongInVault)
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onDeleteSelected = {
                    songs.filter { selectedSongIds.contains(it.id) }
                        .forEach(onDeleteSong)
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}
