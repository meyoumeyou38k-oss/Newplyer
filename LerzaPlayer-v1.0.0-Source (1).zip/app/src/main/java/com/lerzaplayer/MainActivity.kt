package com.lerzaplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.FavoriteEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.repository.MediaRepository
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaPlayerTheme
import com.lerzaplayer.ui.home.HomeScreen
import com.lerzaplayer.ui.player.FullPlayerScreen
import com.lerzaplayer.ui.player.VideoPlayerScreen
import com.lerzaplayer.ui.settings.SettingsScreen
import com.lerzaplayer.ui.vault.VaultScreen
import kotlinx.coroutines.launch

enum class AppDestination {
    HOME,
    SETTINGS,
    VAULT,
    SEARCH
}

class MainActivity : ComponentActivity() {

    private lateinit var mediaRepository: MediaRepository
    private lateinit var playerManager: PlayerManager

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Permissions handled
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as LerzaApp
        mediaRepository = MediaRepository(this)
        playerManager = app.playerManager

        requestRequiredPermissions()

        setContent {
            val prefManager = app.preferenceManager
            val currentTheme by prefManager.themeFlow.collectAsState(initial = "Pure White")
            val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
            val scope = rememberCoroutineScope()

            val songs by mediaRepository.getSongsFlow(songSort).collectAsState(initial = emptyList())
            val videos by mediaRepository.getVideosFlow(SortOption.DATE_ADDED_DESC).collectAsState(initial = emptyList())

            var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
            var isFullPlayerVisible by remember { mutableStateOf(false) }
            var activePlayingVideo by remember { mutableStateOf<VideoItem?>(null) }

            LerzaPlayerTheme(themeName = currentTheme) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Navigation Views
                    when (currentDestination) {
                        AppDestination.HOME -> {
                            HomeScreen(
                                songs = songs,
                                videos = videos,
                                playerManager = playerManager,
                                prefManager = prefManager,
                                onSearchClick = { currentDestination = AppDestination.SEARCH },
                                onSettingsClick = { currentDestination = AppDestination.SETTINGS },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                onExpandFullPlayer = { isFullPlayerVisible = true },
                                onPlayVideo = { video -> activePlayingVideo = video },
                                onToggleFavoriteSong = { song ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (song.isFavorite) {
                                            favDao.removeFavorite(song.id, "AUDIO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                        }
                                    }
                                },
                                onToggleFavoriteVideo = { video ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (video.isFavorite) {
                                            favDao.removeFavorite(video.id, "VIDEO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(video.id, "VIDEO"))
                                        }
                                    }
                                },
                                onHideSongInVault = { song ->
                                    scope.launch { app.vaultManager.hideSong(song) }
                                },
                                onHideVideoInVault = { video ->
                                    scope.launch { app.vaultManager.hideVideo(video) }
                                },
                                onDeleteSong = { song ->
                                    scope.launch { mediaRepository.deleteMedia(song.contentUri) }
                                },
                                onDeleteVideo = { video ->
                                    scope.launch { mediaRepository.deleteMedia(video.contentUri) }
                                },
                                onScanDevice = {
                                    // Trigger rescan
                                }
                            )
                        }
                        AppDestination.SETTINGS -> {
                            SettingsScreen(
                                prefManager = prefManager,
                                onBack = { currentDestination = AppDestination.HOME },
                                onOpenEqualizer = { isFullPlayerVisible = true },
                                onScanMedia = { /* Scan */ }
                            )
                        }
                        AppDestination.VAULT -> {
                            VaultScreen(
                                vaultManager = app.vaultManager,
                                onBack = { currentDestination = AppDestination.HOME }
                            )
                        }
                        AppDestination.SEARCH -> {
                            // Search view
                            HomeScreen(
                                songs = songs,
                                videos = videos,
                                playerManager = playerManager,
                                prefManager = prefManager,
                                onSearchClick = {},
                                onSettingsClick = { currentDestination = AppDestination.SETTINGS },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                onExpandFullPlayer = { isFullPlayerVisible = true },
                                onPlayVideo = { video -> activePlayingVideo = video },
                                onToggleFavoriteSong = {},
                                onToggleFavoriteVideo = {},
                                onHideSongInVault = {},
                                onHideVideoInVault = {},
                                onDeleteSong = {},
                                onDeleteVideo = {},
                                onScanDevice = {}
                            )
                        }
                    }

                    // Full Player Overlay (Slide in / Swipe down to collapse)
                    AnimatedVisibility(
                        visible = isFullPlayerVisible,
                        enter = slideInVertically(initialOffsetY = { it }),
                        exit = slideOutVertically(targetOffsetY = { it })
                    ) {
                        FullPlayerScreen(
                            playerManager = playerManager,
                            onCollapse = { isFullPlayerVisible = false }
                        )
                    }

                    // Video Player Overlay
                    activePlayingVideo?.let { vid ->
                        VideoPlayerScreen(
                            video = vid,
                            onClose = { activePlayingVideo = null }
                        )
                    }
                }
            }
        }
    }

    private fun requestRequiredPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }
}
