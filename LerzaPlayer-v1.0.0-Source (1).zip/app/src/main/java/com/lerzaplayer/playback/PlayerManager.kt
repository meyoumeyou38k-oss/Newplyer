package com.lerzaplayer.playback

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PlayerManager private constructor(private val context: Context) {

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context).build()

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val _currentSong = MutableStateFlow<SongItem?>(null)
    val currentSong: StateFlow<SongItem?> = _currentSong.asStateFlow()

    private val _currentVideo = MutableStateFlow<VideoItem?>(null)
    val currentVideo: StateFlow<VideoItem?> = _currentVideo.asStateFlow()

    private val _queue = MutableStateFlow<List<SongItem>>(emptyList())
    val queue: StateFlow<List<SongItem>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_ALL) // REPEAT_MODE_OFF, REPEAT_MODE_ONE, REPEAT_MODE_ALL
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _volumeBoostPercent = MutableStateFlow(100) // 100%, 150%, 200%, 300%
    val volumeBoostPercent: StateFlow<Int> = _volumeBoostPercent.asStateFlow()

    private val _sleepTimerRemainingMinutes = MutableStateFlow(0)
    val sleepTimerRemainingMinutes: StateFlow<Int> = _sleepTimerRemainingMinutes.asStateFlow()

    // Audio effects
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null

    private var sleepTimerJob: Job? = null

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                _isPlaying.value = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)
                } else if (playbackState == Player.STATE_ENDED) {
                    playNextTrack()
                }
            }
        })

        // Periodic ticker for playback position
        scope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _currentPosition.value = exoPlayer.currentPosition
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)
                }
                delay(400)
            }
        }

        initAudioEffects()
    }

    private fun initAudioEffects() {
        try {
            val audioSessionId = exoPlayer.audioSessionId
            if (audioSessionId != 0) {
                equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
                bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
                virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun playSongList(songs: List<SongItem>, startIndex: Int) {
        if (songs.isEmpty() || startIndex !in songs.indices) return
        _queue.value = songs
        _currentIndex.value = startIndex
        val song = songs[startIndex]
        _currentSong.value = song
        _currentVideo.value = null

        val mediaItem = MediaItem.fromUri(song.contentUri)
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun playNext(song: SongItem) {
        val currentList = _queue.value.toMutableList()
        val insertPos = (_currentIndex.value + 1).coerceAtMost(currentList.size)
        currentList.add(insertPos, song)
        _queue.value = currentList
    }

    fun addToQueue(song: SongItem) {
        val currentList = _queue.value.toMutableList()
        currentList.add(song)
        _queue.value = currentList
    }

    fun removeFromQueue(index: Int) {
        if (index in _queue.value.indices) {
            val currentList = _queue.value.toMutableList()
            currentList.removeAt(index)
            _queue.value = currentList
            if (index < _currentIndex.value) {
                _currentIndex.value = (_currentIndex.value - 1).coerceAtLeast(0)
            }
        }
    }

    fun clearQueue() {
        _queue.value = emptyList()
        _currentSong.value = null
        exoPlayer.stop()
    }

    fun playPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            exoPlayer.play()
        }
    }

    fun play() {
        exoPlayer.play()
    }

    fun pause() {
        exoPlayer.pause()
    }

    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs)
        _currentPosition.value = positionMs
    }

    fun playNextTrack() {
        val q = _queue.value
        if (q.isEmpty()) return

        if (_repeatMode.value == Player.REPEAT_MODE_ONE) {
            seekTo(0)
            play()
            return
        }

        val nextIndex = if (_isShuffle.value) {
            q.indices.random()
        } else {
            (_currentIndex.value + 1) % q.size
        }

        if (nextIndex == 0 && _repeatMode.value == Player.REPEAT_MODE_OFF) {
            exoPlayer.pause()
            seekTo(0)
            return
        }

        _currentIndex.value = nextIndex
        val song = q[nextIndex]
        _currentSong.value = song
        exoPlayer.setMediaItem(MediaItem.fromUri(song.contentUri))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun playPreviousTrack() {
        val q = _queue.value
        if (q.isEmpty()) return

        if (exoPlayer.currentPosition > 3000L) {
            seekTo(0)
            return
        }

        val prevIndex = if (_currentIndex.value > 0) _currentIndex.value - 1 else q.size - 1
        _currentIndex.value = prevIndex
        val song = q[prevIndex]
        _currentSong.value = song
        exoPlayer.setMediaItem(MediaItem.fromUri(song.contentUri))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun toggleShuffle() {
        _isShuffle.value = !_isShuffle.value
    }

    fun cycleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
            else -> Player.REPEAT_MODE_ALL
        }
        exoPlayer.repeatMode = _repeatMode.value
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        exoPlayer.playbackParameters = PlaybackParameters(speed)
    }

    fun setVolumeBoostPercent(percent: Int) {
        _volumeBoostPercent.value = percent
        val volumeMultiplier = (percent.toFloat() / 100f).coerceIn(0.1f, 3.0f)
        exoPlayer.volume = volumeMultiplier
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _sleepTimerRemainingMinutes.value = minutes
        if (minutes <= 0) return

        sleepTimerJob = scope.launch {
            var left = minutes
            while (left > 0) {
                delay(60000)
                left--
                _sleepTimerRemainingMinutes.value = left
            }
            pause()
        }
    }

    fun setEqualizerPreset(presetIndex: Short) {
        try {
            equalizer?.usePreset(presetIndex)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setBassBoostStrength(strength: Short) {
        try {
            bassBoost?.setStrength(strength)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setVirtualizerStrength(strength: Short) {
        try {
            virtualizer?.setStrength(strength)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: PlayerManager? = null

        fun getInstance(context: Context): PlayerManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PlayerManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
