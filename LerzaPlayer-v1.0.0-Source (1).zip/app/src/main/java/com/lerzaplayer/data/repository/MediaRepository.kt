package com.lerzaplayer.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File

class MediaRepository(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val favoriteDao = db.favoriteDao()
    private val vaultDao = db.vaultDao()

    fun getSongsFlow(sortOption: SortOption): Flow<List<SongItem>> {
        return combine(
            favoriteDao.getAllFavorites(),
            vaultDao.getAllVaultMedia()
        ) { favorites, vaultMedia ->
            val favSet = favorites.filter { it.mediaType == "AUDIO" }.map { it.mediaId }.toSet()
            val hiddenPaths = vaultMedia.map { it.originalPath }.toSet()
            querySongs(sortOption, favSet, hiddenPaths)
        }.flowOn(Dispatchers.IO)
    }

    fun getVideosFlow(sortOption: SortOption): Flow<List<VideoItem>> {
        return combine(
            favoriteDao.getAllFavorites(),
            vaultDao.getAllVaultMedia()
        ) { favorites, vaultMedia ->
            val favSet = favorites.filter { it.mediaType == "VIDEO" }.map { it.mediaId }.toSet()
            val hiddenPaths = vaultMedia.map { it.originalPath }.toSet()
            queryVideos(sortOption, favSet, hiddenPaths)
        }.flowOn(Dispatchers.IO)
    }

    suspend fun querySongs(
        sortOption: SortOption,
        favSet: Set<Long> = emptySet(),
        hiddenPaths: Set<String> = emptySet()
    ): List<SongItem> = withContext(Dispatchers.IO) {
        val songList = mutableListOf<SongItem>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.ALBUM_ID
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 10000"
        val sortOrder = when (sortOption) {
            SortOption.TITLE_ASC -> "${MediaStore.Audio.Media.TITLE} ASC"
            SortOption.ARTIST_ASC -> "${MediaStore.Audio.Media.ARTIST} ASC"
            SortOption.DURATION_DESC -> "${MediaStore.Audio.Media.DURATION} DESC"
            SortOption.SIZE_DESC -> "${MediaStore.Audio.Media.SIZE} DESC"
            SortOption.DATE_ADDED_DESC -> "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        }

        try {
            context.contentResolver.query(collection, projection, selection, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

                val artBaseUri = Uri.parse("content://media/external/audio/albumart")

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val path = cursor.getString(dataCol) ?: ""
                    if (hiddenPaths.contains(path)) continue

                    val title = cursor.getString(titleCol) ?: "Unknown Title"
                    val artist = cursor.getString(artistCol) ?: "Unknown Artist"
                    val album = cursor.getString(albumCol) ?: "Unknown Album"
                    val duration = cursor.getLong(durationCol)
                    val size = cursor.getLong(sizeCol)
                    val dateAdded = cursor.getLong(dateCol)
                    val mime = cursor.getString(mimeCol) ?: "audio/mpeg"
                    val albumId = cursor.getLong(albumIdCol)

                    val contentUri = ContentUris.withAppendedId(collection, id)
                    val albumArtUri = ContentUris.withAppendedId(artBaseUri, albumId)

                    songList.add(
                        SongItem(
                            id = id,
                            title = title,
                            artist = if (artist == "<unknown>") "Device Storage" else artist,
                            album = album,
                            duration = duration,
                            contentUri = contentUri,
                            albumArtUri = albumArtUri,
                            size = size,
                            dateAdded = dateAdded,
                            path = path,
                            mimeType = mime,
                            isFavorite = favSet.contains(id),
                            hasLyrics = true
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        songList
    }

    suspend fun queryVideos(
        sortOption: SortOption,
        favSet: Set<Long> = emptySet(),
        hiddenPaths: Set<String> = emptySet()
    ): List<VideoItem> = withContext(Dispatchers.IO) {
        val videoList = mutableListOf<VideoItem>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DATA
        )

        val sortOrder = when (sortOption) {
            SortOption.TITLE_ASC -> "${MediaStore.Video.Media.TITLE} ASC"
            SortOption.DURATION_DESC -> "${MediaStore.Video.Media.DURATION} DESC"
            SortOption.SIZE_DESC -> "${MediaStore.Video.Media.SIZE} DESC"
            else -> "${MediaStore.Video.Media.DATE_ADDED} DESC"
        }

        try {
            context.contentResolver.query(collection, projection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val path = cursor.getString(dataCol) ?: ""
                    if (hiddenPaths.contains(path)) continue

                    val title = cursor.getString(titleCol) ?: "Video $id"
                    val duration = cursor.getLong(durationCol)
                    val size = cursor.getLong(sizeCol)
                    val dateAdded = cursor.getLong(dateCol)

                    val folderName = try {
                        File(path).parentFile?.name ?: "Videos"
                    } catch (_: Exception) {
                        "Videos"
                    }

                    val contentUri = ContentUris.withAppendedId(collection, id)

                    videoList.add(
                        VideoItem(
                            id = id,
                            title = title,
                            duration = duration,
                            contentUri = contentUri,
                            size = size,
                            dateAdded = dateAdded,
                            path = path,
                            folderName = folderName,
                            isFavorite = favSet.contains(id)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        videoList
    }

    suspend fun deleteMedia(uri: Uri) = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.delete(uri, null, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
