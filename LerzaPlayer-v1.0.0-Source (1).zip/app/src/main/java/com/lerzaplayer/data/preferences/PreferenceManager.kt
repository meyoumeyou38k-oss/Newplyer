package com.lerzaplayer.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.data.model.ViewMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "lerza_preferences")

class PreferenceManager(private val context: Context) {

    companion object {
        val KEY_THEME = stringPreferencesKey("app_theme")
        val KEY_SONG_SORT = stringPreferencesKey("song_sort")
        val KEY_VIDEO_SORT = stringPreferencesKey("video_sort")
        val KEY_VIDEO_VIEW_MODE = stringPreferencesKey("video_view_mode")
        val KEY_AUTO_PLAY = booleanPreferencesKey("auto_play")
        val KEY_RESUME_PLAYBACK = booleanPreferencesKey("resume_playback")
        val KEY_WALLPAPER_URI = stringPreferencesKey("custom_wallpaper_uri")
        val KEY_WALLPAPER_PRESET_ID = stringPreferencesKey("wallpaper_preset_id")
        val KEY_WALLPAPER_OPACITY = floatPreferencesKey("wallpaper_opacity")
        val KEY_VAULT_PIN = stringPreferencesKey("vault_pin_hash")
        val KEY_VAULT_PATTERN = stringPreferencesKey("vault_pattern_hash")
        val KEY_VAULT_LOCK_TYPE = stringPreferencesKey("vault_lock_type")
        val KEY_AUDIO_SPEED = floatPreferencesKey("audio_speed")
        val KEY_BASS_BOOST = intPreferencesKey("bass_boost_level")
        val KEY_VIRTUALIZER = booleanPreferencesKey("virtualizer_enabled")
        val KEY_EQ_PRESET = intPreferencesKey("eq_preset_index")

        const val THEME_AMOLED = "AMOLED Black"
        const val THEME_WHITE = "Pure White"
        const val THEME_ROSE = "Soft Rose"
        const val THEME_MINT = "Mint Sage"
        const val THEME_SKY = "Pastel Sky"
        const val THEME_LAVENDER = "Soft Lavender"
        const val THEME_AMBER = "Sunset Amber"
    }

    val themeFlow: Flow<String> = context.dataStore.data.map { it[KEY_THEME] ?: THEME_WHITE }
    val songSortFlow: Flow<SortOption> = context.dataStore.data.map {
        val name = it[KEY_SONG_SORT] ?: SortOption.DATE_ADDED_DESC.name
        try { SortOption.valueOf(name) } catch (_: Exception) { SortOption.DATE_ADDED_DESC }
    }
    val videoViewModeFlow: Flow<ViewMode> = context.dataStore.data.map {
        val name = it[KEY_VIDEO_VIEW_MODE] ?: ViewMode.GRID.name
        try { ViewMode.valueOf(name) } catch (_: Exception) { ViewMode.GRID }
    }
    val wallpaperUriFlow: Flow<String?> = context.dataStore.data.map { it[KEY_WALLPAPER_URI] }
    val wallpaperPresetIdFlow: Flow<String> = context.dataStore.data.map { it[KEY_WALLPAPER_PRESET_ID] ?: "default_nature" }
    val wallpaperOpacityFlow: Flow<Float> = context.dataStore.data.map { it[KEY_WALLPAPER_OPACITY] ?: 0.75f }

    val vaultPinFlow: Flow<String?> = context.dataStore.data.map { it[KEY_VAULT_PIN] }
    val vaultPatternFlow: Flow<String?> = context.dataStore.data.map { it[KEY_VAULT_PATTERN] }
    val vaultLockTypeFlow: Flow<VaultLockType> = context.dataStore.data.map {
        val type = it[KEY_VAULT_LOCK_TYPE] ?: VaultLockType.PIN.name
        try { VaultLockType.valueOf(type) } catch (_: Exception) { VaultLockType.PIN }
    }

    val audioSpeedFlow: Flow<Float> = context.dataStore.data.map { it[KEY_AUDIO_SPEED] ?: 1.0f }
    val bassBoostFlow: Flow<Int> = context.dataStore.data.map { it[KEY_BASS_BOOST] ?: 0 }
    val virtualizerFlow: Flow<Boolean> = context.dataStore.data.map { it[KEY_VIRTUALIZER] ?: false }
    val eqPresetFlow: Flow<Int> = context.dataStore.data.map { it[KEY_EQ_PRESET] ?: 0 }

    suspend fun setTheme(theme: String) {
        context.dataStore.edit { it[KEY_THEME] = theme }
    }

    suspend fun setSongSort(sort: SortOption) {
        context.dataStore.edit { it[KEY_SONG_SORT] = sort.name }
    }

    suspend fun setVideoViewMode(mode: ViewMode) {
        context.dataStore.edit { it[KEY_VIDEO_VIEW_MODE] = mode.name }
    }

    suspend fun setWallpaperUri(uri: String?) {
        context.dataStore.edit {
            if (uri != null) it[KEY_WALLPAPER_URI] = uri else it.remove(KEY_WALLPAPER_URI)
        }
    }

    suspend fun setWallpaperPresetId(presetId: String) {
        context.dataStore.edit { it[KEY_WALLPAPER_PRESET_ID] = presetId }
    }

    suspend fun setWallpaperOpacity(opacity: Float) {
        context.dataStore.edit { it[KEY_WALLPAPER_OPACITY] = opacity }
    }

    suspend fun setVaultPin(hash: String?) {
        context.dataStore.edit {
            if (hash != null) it[KEY_VAULT_PIN] = hash else it.remove(KEY_VAULT_PIN)
        }
    }

    suspend fun setVaultPattern(patternHash: String?) {
        context.dataStore.edit {
            if (patternHash != null) it[KEY_VAULT_PATTERN] = patternHash else it.remove(KEY_VAULT_PATTERN)
        }
    }

    suspend fun setVaultLockType(lockType: VaultLockType) {
        context.dataStore.edit { it[KEY_VAULT_LOCK_TYPE] = lockType.name }
    }

    suspend fun setAudioSpeed(speed: Float) {
        context.dataStore.edit { it[KEY_AUDIO_SPEED] = speed }
    }

    suspend fun setBassBoost(level: Int) {
        context.dataStore.edit { it[KEY_BASS_BOOST] = level }
    }

    suspend fun setVirtualizer(enabled: Boolean) {
        context.dataStore.edit { it[KEY_VIRTUALIZER] = enabled }
    }

    suspend fun setEqPreset(presetIndex: Int) {
        context.dataStore.edit { it[KEY_EQ_PRESET] = presetIndex }
    }
}
