package com.lerzaplayer.theme

import androidx.compose.ui.graphics.Color

val CyanAccent = Color(0xFF00E5FF)
val BlueAccent = Color(0xFF00B0FF)
val GreenAccent = Color(0xFF00E676)
val OrangeAccent = Color(0xFFFF9100)
val RedAccent = Color(0xFFFF334B)

// AMOLED Theme Colors
val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF10141D)
val AmoledCard = Color(0xFF181F2B)
val AmoledTextPrimary = Color(0xFFFFFFFF)
val AmoledTextSecondary = Color(0xFF9E9E9E)

// Pure White Theme Colors
val WhiteBackground = Color(0xFFF7F9FC)
val WhiteSurface = Color(0xFFFFFFFF)
val WhiteCard = Color(0xFFEEF2F6)
val WhiteTextPrimary = Color(0xFF1A1D24)
val WhiteTextSecondary = Color(0xFF6B7280)

// Soft Rose
val RoseBackground = Color(0xFF140D10)
val RoseSurface = Color(0xFF24151B)
val RoseAccent = Color(0xFFFF4081)

// Mint Sage
val MintBackground = Color(0xFF0B1410)
val MintSurface = Color(0xFF12221A)
val MintAccent = Color(0xFF00E676)

// Pastel Sky
val SkyBackground = Color(0xFF0C141E)
val SkySurface = Color(0xFF121F2F)
val SkyAccent = Color(0xFF00B0FF)

// Soft Lavender
val LavenderBackground = Color(0xFF120E1C)
val LavenderSurface = Color(0xFF1D162D)
val LavenderAccent = Color(0xFFB388FF)

// Sunset Amber
val AmberBackground = Color(0xFF161109)
val AmberSurface = Color(0xFF261D12)
val AmberAccent = Color(0xFFFFAB00)

data class LerzaColorScheme(
    val background: Color,
    val surface: Color,
    val card: Color,
    val primary: Color,
    val onPrimary: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val isDark: Boolean
)

fun getThemeScheme(themeName: String): LerzaColorScheme {
    return when (themeName) {
        "AMOLED Black" -> LerzaColorScheme(
            background = AmoledBackground,
            surface = AmoledSurface,
            card = AmoledCard,
            primary = CyanAccent,
            onPrimary = Color.Black,
            textPrimary = AmoledTextPrimary,
            textSecondary = AmoledTextSecondary,
            isDark = true
        )
        "Soft Rose" -> LerzaColorScheme(
            background = RoseBackground,
            surface = RoseSurface,
            card = Color(0xFF331C26),
            primary = RoseAccent,
            onPrimary = Color.White,
            textPrimary = Color.White,
            textSecondary = Color(0xFFD6A2B6),
            isDark = true
        )
        "Mint Sage" -> LerzaColorScheme(
            background = MintBackground,
            surface = MintSurface,
            card = Color(0xFF172D23),
            primary = MintAccent,
            onPrimary = Color.Black,
            textPrimary = Color.White,
            textSecondary = Color(0xFFA5D6A7),
            isDark = true
        )
        "Pastel Sky" -> LerzaColorScheme(
            background = SkyBackground,
            surface = SkySurface,
            card = Color(0xFF17283C),
            primary = SkyAccent,
            onPrimary = Color.Black,
            textPrimary = Color.White,
            textSecondary = Color(0xFF90CAF9),
            isDark = true
        )
        "Soft Lavender" -> LerzaColorScheme(
            background = LavenderBackground,
            surface = LavenderSurface,
            card = Color(0xFF2B2042),
            primary = LavenderAccent,
            onPrimary = Color.Black,
            textPrimary = Color.White,
            textSecondary = Color(0xFFCE93D8),
            isDark = true
        )
        "Sunset Amber" -> LerzaColorScheme(
            background = AmberBackground,
            surface = AmberSurface,
            card = Color(0xFF362817),
            primary = AmberAccent,
            onPrimary = Color.Black,
            textPrimary = Color.White,
            textSecondary = Color(0xFFFFCC80),
            isDark = true
        )
        else -> LerzaColorScheme( // Pure White
            background = WhiteBackground,
            surface = WhiteSurface,
            card = WhiteCard,
            primary = BlueAccent,
            onPrimary = Color.White,
            textPrimary = WhiteTextPrimary,
            textSecondary = WhiteTextSecondary,
            isDark = false
        )
    }
}
