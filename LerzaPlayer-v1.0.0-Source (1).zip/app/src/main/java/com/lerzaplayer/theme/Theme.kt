package com.lerzaplayer.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*

val LocalLerzaColors = compositionLocalOf { getThemeScheme("Pure White") }

@Composable
fun LerzaPlayerTheme(
    themeName: String = "Pure White",
    content: @Composable () -> Unit
) {
    val scheme = remember(themeName) { getThemeScheme(themeName) }

    val materialColors = if (scheme.isDark) {
        darkColorScheme(
            primary = scheme.primary,
            background = scheme.background,
            surface = scheme.surface,
            onBackground = scheme.textPrimary,
            onSurface = scheme.textPrimary
        )
    } else {
        lightColorScheme(
            primary = scheme.primary,
            background = scheme.background,
            surface = scheme.surface,
            onBackground = scheme.textPrimary,
            onSurface = scheme.textPrimary
        )
    }

    CompositionLocalProvider(LocalLerzaColors provides scheme) {
        MaterialTheme(
            colorScheme = materialColors,
            content = content
        )
    }
}
