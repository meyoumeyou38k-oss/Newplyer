package com.lerzaplayer.ui.search

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import com.lerzaplayer.ui.common.SongItemRow

@Composable
fun SearchScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onBack: () -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onAddToQueue: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val activeColor = ThemeManager.currentThemeColor
    var query by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    BackHandler { onBack() }

    LaunchedEffect(Unit) {
        try { focusRequester.requestFocus() } catch (_: Exception) {}
    }

    var selectedFilterCategory by remember { mutableStateOf("All") }

    // اسکورنگ سسٹم: پریفکس اور گانوں کو اوّلین ترجیح
    fun computeSongMatchScore(q: String, song: SongItem): Int {
        if (q.isBlank()) return 1
        val cleanQ = q.trim().lowercase()
        val titleLower = song.title.lowercase().trim()
        val artistLower = song.artist.lowercase().trim()

        if (titleLower == cleanQ) return 100000
        if (titleLower.startsWith(cleanQ)) return 50000 - titleLower.length
        
        val words = titleLower.split(" ", "_", "-", ".", "(", ")").filter { it.isNotBlank() }
        for (w in words) {
            if (w == cleanQ) return 30000
            if (w.startsWith(cleanQ)) return 25000
        }

        val idx = titleLower.indexOf(cleanQ)
        if (idx >= 0) return 10000 - idx * 10

        if (artistLower.startsWith(cleanQ)) return 5000
        if (artistLower.contains(cleanQ)) return 2000

        var qi = 0
        for (ch in titleLower) {
            if (qi < cleanQ.length && ch == cleanQ[qi]) qi++
        }
        if (qi == cleanQ.length) return 800

        return 0
    }

    fun computeVideoMatchScore(q: String, video: VideoItem): Int {
        if (q.isBlank()) return 1
        val cleanQ = q.trim().lowercase()
        val titleLower = video.title.lowercase().trim()

        if (titleLower == cleanQ) return 100000
        if (titleLower.startsWith(cleanQ)) return 50000 - titleLower.length

        val words = titleLower.split(" ", "_", "-", ".", "(", ")").filter { it.isNotBlank() }
        for (w in words) {
            if (w.startsWith(cleanQ)) return 25000
        }

        val idx = titleLower.indexOf(cleanQ)
        if (idx >= 0) return 10000 - idx * 10

        return 0
    }

    val rankedSongs = remember(query, songs, selectedFilterCategory) {
        if (query.isBlank() && selectedFilterCategory == "All") {
            emptyList()
        } else {
            val q = query.trim()
            songs.mapNotNull { song ->
                val categoryPass = when (selectedFilterCategory) {
                    "Sad" -> listOf("sad", "dard", "gham", "judai", "dil", "slow", "bewafa").any { kw -> song.title.contains(kw, true) || song.artist.contains(kw, true) }
                    "Punjabi" -> listOf("sidhu", "moose", "praak", "ammy", "diljit", "punjabi", "jatt", "ishtar").any { kw -> song.title.contains(kw, true) || song.artist.contains(kw, true) }
                    "Remix" -> listOf("remix", "bass", "dj", "party", "dance", "beat").any { kw -> song.title.contains(kw, true) }
                    "Videos" -> false
                    else -> true
                }
                if (!categoryPass) null
                else {
                    val score = computeSongMatchScore(q, song)
                    if (score > 0) Pair(song, score) else null
                }
            }.sortedByDescending { it.second }
             .map { it.first }
        }
    }

    val matchedArtists = remember(query, songs) {
        if (query.isBlank()) emptyList()
        else {
            val q = query.trim().lowercase()
            songs.map { it.artist }
                .distinct()
                .filter { it.lowercase().startsWith(q) || it.lowercase().contains(q) }
                .take(6)
        }
    }

    val rankedVideos = remember(query, videos, selectedFilterCategory, rankedSongs) {
        if (query.isBlank()) emptyList()
        else if (selectedFilterCategory == "Songs" || selectedFilterCategory == "Artists") emptyList()
        else {
            val q = query.trim()
            videos.mapNotNull { video ->
                val score = computeVideoMatchScore(q, video)
                if (score > 0) Pair(video, score) else null
            }.sortedByDescending { it.second }
             .map { it.first }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        Surface(
            color = colors.surface,
            shadowElevation = 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = LerzaIcons.ArrowBack,
                            contentDescription = "Back",
                            tint = colors.textPrimary
                        )
                    }

                    TextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = {
                            Text(
                                text = "Search songs first by title or letter (e.g. H)...",
                                color = colors.textSecondary,
                                fontSize = 14.sp
                            )
                        },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            cursorColor = activeColor
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(focusRequester)
                    )

                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(
                                imageVector = LerzaIcons.Close,
                                contentDescription = "Clear",
                                tint = colors.textSecondary
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val filterChips = listOf("All", "Songs", "Artists", "Videos", "Sad", "Punjabi", "Remix")
                    filterChips.forEach { chip ->
                        val isSelected = selectedFilterCategory == chip
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) activeColor else colors.card)
                                .clickable { selectedFilterCategory = chip }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = chip,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) colors.onPrimary else colors.textSecondary
                            )
                        }
                    }
                }
            }
        }

        if (query.isBlank() && selectedFilterCategory == "All") {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable { onBack() },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.Search,
                        contentDescription = null,
                        tint = activeColor.copy(alpha = 0.5f),
                        modifier = Modifier.size(56.dp)
                    )
                    Text(
                        text = "Instant Search across ${songs.size} songs & ${videos.size} videos",
                        color = colors.textSecondary,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Type any letter (e.g. 'H') to instantly see all matching songs first",
                        color = colors.textSecondary.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 60.dp)
            ) {
                if (matchedArtists.isNotEmpty() && selectedFilterCategory != "Videos") {
                    item {
                        Text(
                            text = "ARTISTS (${matchedArtists.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeColor,
                            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 6.dp)
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 16.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            matchedArtists.forEach { artistName ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(colors.card)
                                        .clickable { query = artistName }
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(CircleShape)
                                                .background(activeColor),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = artistName.take(1).uppercase(),
                                                color = colors.onPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }
                                        Text(
                                            text = artistName,
                                            fontSize = 13.sp,
                                            color = colors.textPrimary,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. گانے ہمیشہ سب سے پہلے آئیں گے
                if (rankedSongs.isNotEmpty() && selectedFilterCategory != "Videos") {
                    item {
                        Text(
                            text = "SONGS (${rankedSongs.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeColor,
                            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 6.dp)
                        )
                    }
                    items(rankedSongs, key = { "s_${it.id}" }) { song ->
                        SongItemRow(
                            song = song,
                            isPlaying = isPlaying,
                            isCurrent = currentSong?.id == song.id,
                            isMultiSelectActive = false,
                            isSelected = false,
                            onSongClick = { onSongClick(song) },
                            onSongLongClick = {},
                            onToggleSelect = {},
                            onToggleFavorite = { onToggleFavoriteSong(song) },
                            onPlayNext = { onSongClick(song) },
                            onAddToQueue = { onAddToQueue(song) },
                            onAddToPlaylist = {},
                            onHideInVault = {},
                            onDelete = {}
                        )
                    }
                }

                // 3. ویڈیوز صرف گانوں کے بعد یا اگر کوئی گانا میچ نہ کرے
                if (rankedVideos.isNotEmpty()) {
                    item {
                        Text(
                            text = if (rankedSongs.isEmpty()) "VIDEOS (${rankedVideos.size})" else "MATCHING VIDEOS (${rankedVideos.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeColor,
                            modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 6.dp)
                        )
                    }
                    items(rankedVideos, key = { "v_${it.id}" }) { video ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onVideoClick(video) }
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(60.dp, 40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(colors.card),
                                contentAlignment = Alignment.Center
                            ) {
                                AsyncImage(
                                    model = video.contentUri,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = video.title,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = colors.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${video.folderName}   ${video.durationFormatted}",
                                    fontSize = 12.sp,
                                    color = colors.textSecondary
                                )
                            }
                        }
                    }
                }

                if (rankedSongs.isEmpty() && rankedVideos.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 60.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No matches found for \"$query\"",
                                color = colors.textSecondary,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}