@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@file:androidx.media3.common.util.UnstableApi
@file:Suppress("UnsafeOptInUsageError", "OPT_IN_USAGE_DEFAULT", "DEPRECATION")

package com.lerzaplayer.ui.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.os.Build
import android.net.Uri
import android.provider.Settings
import android.util.Rational
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.playback.PlaytimeTracker
import com.lerzaplayer.theme.LerzaIcons
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

enum class VideoGestureMode {
    VOLUME,
    BRIGHTNESS
}

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@androidx.media3.common.util.UnstableApi
@Composable
fun VideoPlayerScreen(
    video: VideoItem,
    onClose: () -> Unit,
    onPreviousVideo: () -> Unit = {},
    onNextVideo: () -> Unit = {},
    onPlayAsAudio: () -> Unit = {},
    onDeleteVideo: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager }
    val maxAudioVolume = remember(audioManager) {
        audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15
    }

    val exoPlayer = remember(video.id, video.contentUri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.contentUri))
            prepare()
            playWhenReady = true
        }
    }

    var isPlaying by remember { mutableStateOf(true) }
    var currentPos by remember { mutableStateOf(0L) }
    var totalDur by remember { mutableStateOf(video.duration) }
    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var isLandscape by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableStateOf(1.0f) }
    var resizeMode by remember { mutableStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }

    // Dialog & Menu visibility states
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showAudioTracks by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var isLooping by remember { mutableStateOf(false) }

    // Long press 10s button fast-forward state
    var isFastForwarding by remember { mutableStateOf(false) }

    // Gesture swipe HUD overlay state
    var activeGesture by remember { mutableStateOf<VideoGestureMode?>(null) }
    var gestureProgress by remember { mutableFloatStateOf(0f) } // 0..100
    var gestureHideJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

    val audioTrackOptions = exoPlayer.currentTracks.groups
        .filter { it.type == C.TRACK_TYPE_AUDIO }
        .flatMap { group ->
            (0 until group.length).map { index ->
                val format = group.getTrackFormat(index)
                AudioTrackOption(
                    group = group.mediaTrackGroup,
                    index = index,
                    label = format.label ?: format.language ?: "Audio ${index + 1}"
                )
            }
        }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.release()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    LaunchedEffect(video.id) {
        currentPos = 0L
        totalDur = video.duration
        isPlaying = true
        controlsVisible = true
    }

    // Auto-hide controls timer: Paused when 3-dots menu or any dialog is open!
    LaunchedEffect(controlsVisible, showMoreMenu, showSpeedDialog, showInfoDialog, showAudioTracks, showDeleteConfirm) {
        if (controlsVisible && !isLocked && !showMoreMenu && !showSpeedDialog && !showInfoDialog && !showAudioTracks && !showDeleteConfirm) {
            delay(4500)
            controlsVisible = false
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            if (exoPlayer.isPlaying) {
                currentPos = exoPlayer.currentPosition
                totalDur = exoPlayer.duration.coerceAtLeast(video.duration)
                PlaytimeTracker.addVideoTime(context, 400L)
            }
            delay(400)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            // 1. Gesture detection for Brightness (Right side) & Volume (Left side) swipe
            .pointerInput(isLocked) {
                if (!isLocked) {
                    var isRightSide = false
                    var totalDragY = 0f
                    var initialFraction = 0f
                    val screenHeight = size.height.toFloat()

                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            gestureHideJob?.cancel()
                            isRightSide = offset.x >= (size.width / 2f)
                            totalDragY = 0f

                            if (isRightSide) {
                                // Screen brightness setup
                                val curBrightness = activity?.window?.attributes?.screenBrightness ?: -1f
                                initialFraction = if (curBrightness < 0f) {
                                    try {
                                        Settings.System.getInt(
                                            context.contentResolver,
                                            Settings.System.SCREEN_BRIGHTNESS
                                        ) / 255f
                                    } catch (_: Exception) { 0.5f }
                                } else curBrightness
                                activeGesture = VideoGestureMode.BRIGHTNESS
                                gestureProgress = (initialFraction * 100f).coerceIn(0f, 100f)
                            } else {
                                // Audio volume setup
                                val curVol = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
                                initialFraction = curVol.toFloat() / maxAudioVolume.coerceAtLeast(1).toFloat()
                                activeGesture = VideoGestureMode.VOLUME
                                gestureProgress = (initialFraction * 100f).coerceIn(0f, 100f)
                            }
                        },
                        onVerticalDrag = { change, dragAmount ->
                            change.consume()
                            totalDragY -= dragAmount
                            val deltaFraction = totalDragY / (screenHeight * 0.70f)
                            val newFraction = (initialFraction + deltaFraction).coerceIn(0f, 1f)
                            gestureProgress = (newFraction * 100f).coerceIn(0f, 100f)

                            if (isRightSide) {
                                val lp = activity?.window?.attributes
                                if (lp != null) {
                                    lp.screenBrightness = newFraction.coerceIn(0.01f, 1.0f)
                                    activity.window.attributes = lp
                                }
                            } else {
                                val targetVol = (newFraction * maxAudioVolume).toInt().coerceIn(0, maxAudioVolume)
                                audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                            }
                        },
                        onDragEnd = {
                            gestureHideJob = scope.launch {
                                delay(1200)
                                activeGesture = null
                            }
                        },
                        onDragCancel = {
                            activeGesture = null
                        }
                    )
                }
            }
            // 2. Tap and Double Tap Gestures
            .pointerInput(isLocked) {
                detectTapGestures(
                    onTap = {
                        if (!isLocked) {
                            controlsVisible = !controlsVisible
                        } else {
                            controlsVisible = true
                        }
                    },
                    onDoubleTap = {
                        if (!isLocked) {
                            if (exoPlayer.isPlaying) {
                                exoPlayer.pause()
                                isPlaying = false
                            } else {
                                exoPlayer.play()
                                isPlaying = true
                            }
                        }
                    }
                )
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    this.resizeMode = resizeMode
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { playerView ->
                playerView.player = exoPlayer
                playerView.resizeMode = resizeMode
            },
            modifier = Modifier.fillMaxSize()
        )

        // Visual HUD Overlay for Swipe Gestures (Volume / Brightness)
        AnimatedVisibility(
            visible = activeGesture != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.Black.copy(alpha = 0.82f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.20f)),
                shadowElevation = 12.dp
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 26.dp, vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val isBrightness = activeGesture == VideoGestureMode.BRIGHTNESS
                    val icon = if (isBrightness) {
                        Icons.Default.BrightnessMedium
                    } else {
                        if (gestureProgress <= 0f) Icons.Default.VolumeMute else Icons.Default.VolumeUp
                    }
                    val label = if (isBrightness) "Brightness" else "Volume"
                    val accentColor = if (isBrightness) Color(0xFFFFD54F) else Color(0xFF00E5FF)

                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = accentColor,
                        modifier = Modifier.size(38.dp)
                    )

                    Text(
                        text = "$label: ${gestureProgress.toInt()}%",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    Box(
                        modifier = Modifier
                            .width(110.dp)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color.White.copy(alpha = 0.22f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(fraction = (gestureProgress / 100f).coerceIn(0f, 1f))
                                .background(accentColor)
                        )
                    }
                }
            }
        }

        // On-screen HUD for 2.5x Fast Forward (Triggered by holding the 10s Forward Button)
        AnimatedVisibility(
            visible = isFastForwarding,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 74.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = Color.Black.copy(alpha = 0.85f),
                border = BorderStroke(1.5.dp, Color(0xFF00E5FF)),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.FastForward,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "2.5x Fast Forward",
                        color = Color(0xFF00E5FF),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Controls Layer
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.52f))
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(16.dp)
            ) {
                // Top Bar with Sleek Glass Pill Buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        VideoGlassIconButton(
                            icon = LerzaIcons.ArrowBack,
                            contentDescription = "Back",
                            onClick = onClose
                        )
                        Text(
                            text = video.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        VideoGlassIconButton(
                            icon = if (isLocked) LerzaIcons.Lock else LerzaIcons.LockOpen,
                            contentDescription = "Lock",
                            tint = if (isLocked) Color(0xFF00E5FF) else Color.White,
                            onClick = { isLocked = !isLocked }
                        )

                        if (!isLocked) {
                            VideoGlassIconButton(
                                icon = LerzaIcons.Speed,
                                contentDescription = "Speed",
                                onClick = { showSpeedDialog = true }
                            )

                            Box {
                                VideoGlassIconButton(
                                    icon = LerzaIcons.MoreVert,
                                    contentDescription = "Video options",
                                    onClick = { showMoreMenu = true }
                                )

                                DropdownMenu(
                                    expanded = showMoreMenu,
                                    onDismissRequest = { showMoreMenu = false },
                                    modifier = Modifier.background(Color(0xFF161C24))
                                ) {
                                    VideoMenuItem(
                                        icon = LerzaIcons.Share,
                                        title = "Share",
                                        accentTint = Color(0xFF00B0FF),
                                        onClick = {
                                            showMoreMenu = false
                                            runCatching {
                                                val share = Intent(Intent.ACTION_SEND).apply {
                                                    type = "video/*"
                                                    putExtra(Intent.EXTRA_STREAM, video.contentUri)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(share, "Share video"))
                                            }
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.Videocam,
                                        title = "Floating window",
                                        accentTint = Color(0xFF00E5FF),
                                        onClick = {
                                            showMoreMenu = false
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                runCatching {
                                                    activity?.enterPictureInPictureMode(
                                                        PictureInPictureParams.Builder()
                                                            .setAspectRatio(Rational(16, 9))
                                                            .build()
                                                    )
                                                }
                                            }
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.Repeat,
                                        title = if (isLooping) "Play mode: Repeat one" else "Play mode: Normal",
                                        accentTint = Color(0xFF9C27B0),
                                        onClick = {
                                            isLooping = !isLooping
                                            exoPlayer.repeatMode = if (isLooping) {
                                                androidx.media3.common.Player.REPEAT_MODE_ONE
                                            } else {
                                                androidx.media3.common.Player.REPEAT_MODE_OFF
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.AspectRatio,
                                        title = "Scale adjust",
                                        accentTint = Color(0xFF00E676),
                                        onClick = {
                                            resizeMode = when (resizeMode) {
                                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.Headphones,
                                        title = "Audio track",
                                        accentTint = Color(0xFFFFB300),
                                        onClick = {
                                            showMoreMenu = false
                                            showAudioTracks = true
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.ScreenRotation,
                                        title = "Screen rotation",
                                        accentTint = Color(0xFF3D5AFE),
                                        onClick = {
                                            isLandscape = !isLandscape
                                            activity?.requestedOrientation = if (isLandscape) {
                                                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                            } else {
                                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.Info,
                                        title = "Video details",
                                        accentTint = Color(0xFF00ACC1),
                                        onClick = {
                                            showMoreMenu = false
                                            showInfoDialog = true
                                        }
                                    )
                                    HorizontalDivider(color = Color.White.copy(alpha = 0.12f), thickness = 0.8.dp)
                                    VideoMenuItem(
                                        icon = LerzaIcons.Delete,
                                        title = "Delete video",
                                        accentTint = Color(0xFFFF334B),
                                        textColor = Color(0xFFFF334B),
                                        onClick = {
                                            showMoreMenu = false
                                            showDeleteConfirm = true
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Center Media Controls with Redesigned Buttons & 10s Long-Press High-Speed Action
                if (!isLocked) {
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Previous Video Button
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.22f)),
                            modifier = Modifier.size(44.dp)
                        ) {
                            IconButton(onClick = onPreviousVideo, modifier = Modifier.fillMaxSize()) {
                                Icon(
                                    imageVector = LerzaIcons.SkipPrevious,
                                    contentDescription = "Previous video",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        // Rewind 10s Button
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.14f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                            modifier = Modifier.size(48.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    val target = (currentPos - 10000L).coerceAtLeast(0L)
                                    exoPlayer.seekTo(target)
                                },
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Icon(
                                    imageVector = LerzaIcons.FastRewind,
                                    contentDescription = "Rewind 10s",
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }

                        // Central Hero Play/Pause Button (Gradient Glow)
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF00E5FF), Color(0xFF00B0FF))
                                    )
                                )
                                .border(2.dp, Color.White.copy(alpha = 0.40f), CircleShape)
                                .clickable {
                                    if (exoPlayer.isPlaying) {
                                        exoPlayer.pause()
                                        isPlaying = false
                                    } else {
                                        exoPlayer.play()
                                        isPlaying = true
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) LerzaIcons.Pause else LerzaIcons.PlayArrow,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        // Forward 10s Button: Tap seeks 10s, Long-press triggers 2.5x High-Speed playback!
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isFastForwarding) Color(0xFF00E5FF).copy(alpha = 0.35f)
                                    else Color.White.copy(alpha = 0.14f)
                                )
                                .border(
                                    width = if (isFastForwarding) 1.8.dp else 1.dp,
                                    color = if (isFastForwarding) Color(0xFF00E5FF) else Color.White.copy(alpha = 0.25f),
                                    shape = CircleShape
                                )
                                .pointerInput(playbackSpeed) {
                                    detectTapGestures(
                                        onPress = {
                                            val originalSpeed = playbackSpeed
                                            var isLongPressed = false
                                            try {
                                                val released = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                                    tryAwaitRelease()
                                                }
                                                if (released == null) {
                                                    isLongPressed = true
                                                    isFastForwarding = true
                                                    exoPlayer.playbackParameters = androidx.media3.common.PlaybackParameters(2.5f)
                                                    tryAwaitRelease()
                                                }
                                            } finally {
                                                if (isLongPressed) {
                                                    isFastForwarding = false
                                                    exoPlayer.playbackParameters = androidx.media3.common.PlaybackParameters(originalSpeed)
                                                }
                                            }
                                        },
                                        onTap = {
                                            val target = (currentPos + 10000L).coerceAtMost(totalDur)
                                            exoPlayer.seekTo(target)
                                        }
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = LerzaIcons.FastForward,
                                contentDescription = "Forward 10s",
                                tint = if (isFastForwarding) Color(0xFF00E5FF) else Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        // Next Video Button
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.22f)),
                            modifier = Modifier.size(44.dp)
                        ) {
                            IconButton(onClick = onNextVideo, modifier = Modifier.fillMaxSize()) {
                                Icon(
                                    imageVector = LerzaIcons.SkipNext,
                                    contentDescription = "Next video",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }

                // Bottom Timeline, Duration, and Secondary Action Controls
                if (!isLocked) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                    ) {
                        val progressFraction = if (totalDur > 0) (currentPos.toFloat() / totalDur.toFloat()).coerceIn(0f, 1f) else 0f
                        Slider(
                            value = progressFraction,
                            onValueChange = { frac ->
                                val target = (frac * totalDur).toLong()
                                exoPlayer.seekTo(target)
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00E5FF),
                                activeTrackColor = Color(0xFF00E5FF),
                                inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                            )
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val curSec = currentPos / 1000
                            val totSec = totalDur / 1000
                            Text(
                                text = "%d:%02d".format(curSec / 60, curSec % 60),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (playbackSpeed != 1.0f) {
                                    Text(
                                        text = "${playbackSpeed}x",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "%d:%02d".format(totSec / 60, totSec % 60),
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontSize = 12.sp
                                )
                            }
                        }

                        // Bottom Action Buttons with Polished Styling
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            VideoGlassIconButton(
                                icon = LerzaIcons.Headphones,
                                contentDescription = "Play as audio",
                                onClick = onPlayAsAudio
                            )

                            VideoGlassIconButton(
                                icon = LerzaIcons.ScreenRotation,
                                contentDescription = "Rotate screen",
                                onClick = {
                                    isLandscape = !isLandscape
                                    activity?.requestedOrientation = if (isLandscape) {
                                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    } else {
                                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                    }
                                }
                            )

                            VideoGlassIconButton(
                                icon = LerzaIcons.Lock,
                                contentDescription = "Lock controls",
                                onClick = {
                                    isLocked = true
                                    controlsVisible = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Playback Speed Dialog
        if (showSpeedDialog) {
            AlertDialog(
                onDismissRequest = { showSpeedDialog = false },
                title = { Text("Playback Speed", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (playbackSpeed == spd) Color(0xFF00E5FF).copy(alpha = 0.22f) else Color.Transparent)
                                    .clickable {
                                        playbackSpeed = spd
                                        exoPlayer.playbackParameters = androidx.media3.common.PlaybackParameters(spd)
                                        showSpeedDialog = false
                                    }
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (spd == 1.0f) "1.0x (Normal)" else "${spd}x",
                                    color = if (playbackSpeed == spd) Color(0xFF00E5FF) else Color.White,
                                    fontWeight = if (playbackSpeed == spd) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSpeedDialog = false }) {
                        Text("Cancel", color = Color(0xFF00E5FF))
                    }
                },
                containerColor = Color(0xFF131A26)
            )
        }

        // Video Info Dialog
        if (showInfoDialog) {
            AlertDialog(
                onDismissRequest = { showInfoDialog = false },
                title = { Text("Video Details", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Title: ${video.title}", color = Color.White, fontSize = 13.sp)
                        Text("Duration: ${video.durationFormatted}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text("Resolution: ${video.resolution}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text("Folder: ${video.folderName}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text("Location: ${video.path}", color = Color.Gray, fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showInfoDialog = false }) {
                        Text("OK", color = Color(0xFF00E5FF))
                    }
                },
                containerColor = Color(0xFF131A26)
            )
        }

        // Audio Track Selection Dialog
        if (showAudioTracks) {
            AlertDialog(
                onDismissRequest = { showAudioTracks = false },
                title = { Text("Audio Track", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    if (audioTrackOptions.isEmpty()) {
                        Text("No alternate audio tracks are available for this video.", color = Color.White.copy(alpha = 0.8f))
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            audioTrackOptions.forEach { option ->
                                TextButton(
                                    onClick = {
                                        exoPlayer.trackSelectionParameters =
                                            exoPlayer.trackSelectionParameters.buildUpon()
                                                .setOverrideForType(TrackSelectionOverride(option.group, option.index))
                                                .build()
                                        showAudioTracks = false
                                    }
                                ) {
                                    Text(option.label, color = Color(0xFF00E5FF))
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showAudioTracks = false }) {
                        Text("Close", color = Color(0xFF00E5FF))
                    }
                },
                containerColor = Color(0xFF131A26)
            )
        }

        // Delete Confirm Dialog
        if (showDeleteConfirm) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirm = false },
                title = { Text("Delete this video?", color = Color.White, fontWeight = FontWeight.Bold) },
                text = { Text("This removes the video from device storage permanently.", color = Color.White.copy(alpha = 0.8f)) },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showDeleteConfirm = false
                            onDeleteVideo()
                            onClose()
                        }
                    ) { Text("Delete", color = Color(0xFFFF334B), fontWeight = FontWeight.Bold) }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel", color = Color.White) }
                },
                containerColor = Color(0xFF131A26)
            )
        }
    }
}

/**
 * Modern glassmorphic rounded action button for the video player toolbar
 */
@Composable
private fun VideoGlassIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String?,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Surface(
        shape = CircleShape,
        color = Color.Black.copy(alpha = 0.38f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.16f)),
        modifier = Modifier.size(38.dp)
    ) {
        IconButton(onClick = onClick, modifier = Modifier.fillMaxSize()) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = tint,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/**
 * Modern styled menu item with dedicated rounded icon container
 */
@Composable
private fun VideoMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    accentTint: Color = Color(0xFF00E5FF),
    textColor: Color = Color.White,
    onClick: () -> Unit
) {
    DropdownMenuItem(
        text = {
            Text(
                text = title,
                color = textColor,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Medium
            )
        },
        leadingIcon = {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentTint.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentTint,
                    modifier = Modifier.size(17.dp)
                )
            }
        },
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
    )
}

private data class AudioTrackOption(
    val group: TrackGroup,
    val index: Int,
    val label: String
)