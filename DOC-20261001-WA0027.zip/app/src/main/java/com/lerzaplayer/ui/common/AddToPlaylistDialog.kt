package com.lerzaplayer.ui.common

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.PlaylistEntity
import com.lerzaplayer.data.database.PlaylistItemEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 🌟 ایک یا ایک سے زیادہ گانوں کو پلے لسٹ میں شامل کرنے والا جامع ڈائیلاگ
 * - موجودہ محفوظ شدہ پلے لسٹس دکھاتا ہے
 * - "+ New Playlist" بٹن کے ذریعے نئی پلے لسٹ بنانے اور فوراً گانے ایڈ کرنے کی سہولت دیتا ہے
 */
@Composable
fun AddToPlaylistDialog(
    songs: List<SongItem>,
    onDismiss: () -> Unit
) {
    if (songs.isEmpty()) {
        onDismiss()
        return
    }

    val context = LocalContext.current
    val colors = LocalLerzaColors.current
    val scope = rememberCoroutineScope()
    val playlistDao = remember { AppDatabase.getDatabase(context).playlistDao() }
    val playlists by playlistDao.getAllPlaylists().collectAsState(initial = emptyList())

    var showCreateDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = colors.surface,
            tonalElevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // ہیڈر
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Add to playlist",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                        Text(
                            text = if (songs.size == 1) songs[0].title else "${songs.size} tracks selected",
                            fontSize = 12.sp,
                            color = colors.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = LerzaIcons.Close,
                            contentDescription = "Close",
                            tint = colors.textSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // "+ New Playlist" آپشن
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { showCreateDialog = true }
                        .background(colors.primary.copy(alpha = 0.12f))
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        color = colors.primary,
                        shape = CircleShape,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = LerzaIcons.Add,
                                contentDescription = "Create",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Column {
                        Text(
                            text = "New playlist",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.primary
                        )
                        Text(
                            text = "Create and add songs",
                            fontSize = 11.sp,
                            color = colors.primary.copy(alpha = 0.75f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(colors.textSecondary.copy(alpha = 0.12f))
                )

                Spacer(modifier = Modifier.height(8.dp))

                // پلے لسٹس کی فہرست
                if (playlists.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No custom playlists found.\nTap 'New playlist' above to create one.",
                            fontSize = 12.sp,
                            color = colors.textSecondary,
                            lineHeight = 18.sp
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 280.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(playlists, key = { it.id }) { playlist ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        scope.launch {
                                            withContext(Dispatchers.IO) {
                                                songs.forEachIndexed { index, song ->
                                                    playlistDao.insertPlaylistItem(
                                                        PlaylistItemEntity(
                                                            playlistId = playlist.id,
                                                            songId = song.id,
                                                            sortOrder = index
                                                        )
                                                    )
                                                }
                                            }
                                            val message = if (songs.size == 1) {
                                                "Added \"${songs[0].title}\" to ${playlist.name}"
                                            } else {
                                                "Added ${songs.size} tracks to ${playlist.name}"
                                            }
                                            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                                            onDismiss()
                                        }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    color = colors.card,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = LerzaIcons.PlaylistAdd,
                                            contentDescription = null,
                                            tint = colors.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = playlist.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = colors.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // نئی پلے لسٹ بنانے کا ڈائیلاگ
    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = {
                Text(
                    text = "New playlist",
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
            },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    label = { Text("Playlist name") },
                    placeholder = { Text("e.g. My Favorites") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.primary,
                        focusedLabelColor = colors.primary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = newPlaylistName.trim()
                        if (trimmed.isNotBlank()) {
                            scope.launch {
                                val playlistId = withContext(Dispatchers.IO) {
                                    val newId = playlistDao.insertPlaylist(PlaylistEntity(name = trimmed))
                                    songs.forEachIndexed { index, song ->
                                        playlistDao.insertPlaylistItem(
                                            PlaylistItemEntity(
                                                playlistId = newId,
                                                songId = song.id,
                                                sortOrder = index
                                            )
                                        )
                                    }
                                    newId
                                }
                                showCreateDialog = false
                                newPlaylistName = ""
                                val message = if (songs.size == 1) {
                                    "Created \"$trimmed\" and added song"
                                } else {
                                    "Created \"$trimmed\" and added ${songs.size} tracks"
                                }
                                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                                onDismiss()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.primary)
                ) {
                    Text("Create & Add", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel", color = colors.textSecondary)
                }
            },
            containerColor = colors.surface,
            shape = RoundedCornerShape(20.dp)
        )
    }
}