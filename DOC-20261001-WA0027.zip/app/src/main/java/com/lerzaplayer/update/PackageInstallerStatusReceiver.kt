package com.lerzaplayer.update

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.os.Process
import android.util.Log
import kotlin.system.exitProcess

/**
 * 🌟 PackageInstaller کی کال بیک کو ہینڈل کرنے والا ریسیور:
 * 1. اگر سسٹم کو صارف کی تصدیق درکار ہو (مثلاً پرانے اینڈرائیڈ پر) تو خودکار سسٹم انسٹال ڈائیلاگ دکھاتا ہے۔
 * 2. جب انسٹالیشن کامیابی سے مکمل ہو جائے (STATUS_SUCCESS):
 *    ایپ خودکار طور پر بند (exit/crash) ہو جاتی ہے جیسا کہ صارف نے ہدایت دی ہے۔
 *    دوبارہ ایپ کھولنے پر نیا اپڈیٹڈ ورژن کھلتا ہے۔
 */
class PackageInstallerStatusReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
        Log.d(TAG, "PackageInstaller status: $status, message: $message")

        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                Log.d(TAG, "User confirmation prompt required by Android system. Launching...")
                val confirmIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(Intent.EXTRA_INTENT)
                }

                confirmIntent?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(it)
                }
            }

            PackageInstaller.STATUS_SUCCESS -> {
                Log.d(TAG, "Update successfully installed! Terminating app process to complete update...")
                AppUpdateManager.onInstallCompleted()

                // ایپ کو فوری اور خودکار طور پر بند کرنا تاکہ نیا ورژن ایکٹو ہو جائے
                try {
                    Process.killProcess(Process.myPid())
                    exitProcess(0)
                } catch (e: Exception) {
                    Log.e(TAG, "Error terminating process: ${e.message}", e)
                    exitProcess(0)
                }
            }

            PackageInstaller.STATUS_FAILURE,
            PackageInstaller.STATUS_FAILURE_ABORTED,
            PackageInstaller.STATUS_FAILURE_BLOCKED,
            PackageInstaller.STATUS_FAILURE_CONFLICT,
            PackageInstaller.STATUS_FAILURE_INCOMPATIBLE,
            PackageInstaller.STATUS_FAILURE_INVALID,
            PackageInstaller.STATUS_FAILURE_STORAGE -> {
                Log.e(TAG, "Installation failed with status $status: $message")
                AppUpdateManager.onInstallFailed("Installation failed ($status): $message")
            }

            else -> {
                Log.d(TAG, "PackageInstaller other status: $status")
            }
        }
    }

    companion object {
        private const val TAG = "PackageInstallerReceiver"
        const val ACTION_INSTALL_STATUS = "com.lerzaplayer.update.INSTALL_STATUS"
    }
}