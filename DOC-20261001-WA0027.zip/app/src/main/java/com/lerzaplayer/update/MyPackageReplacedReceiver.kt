package com.lerzaplayer.update

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import java.io.File

/**
 * 🌟 اینڈرائیڈ آپریٹنگ سسٹم کی طرف سے بھیجا جانے والا ریسیور:
 * جب ایپ کا نیا ورژن کامیابی کے ساتھ انسٹال ہو جاتا ہے،
 * تو کیشے (Cache) میں موجود پرانی عارضی APK فائل ڈیلیٹ کر دی جاتی ہے تاکہ موبائل کی میموری صاف رہے۔
 */
class MyPackageReplacedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            Log.d("LerzaUpdate", "LerzaPlayer has been replaced/updated successfully. Cleaning update cache...")
            try {
                val updatesDir = File(context.cacheDir, "app_updates")
                if (updatesDir.exists()) {
                    updatesDir.deleteRecursively()
                }
            } catch (e: Exception) {
                Log.e("LerzaUpdate", "Failed to clean update cache: ${e.message}")
            }
        }
    }
}