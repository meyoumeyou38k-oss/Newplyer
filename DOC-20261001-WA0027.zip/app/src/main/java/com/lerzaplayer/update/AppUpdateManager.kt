package com.lerzaplayer.update

import android.app.Activity
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(
    val versionName: String,
    val versionCode: Int,
    val releaseTitle: String,
    val changelog: List<String>,
    val apkUrl: String,
    val apkSize: String,
    val isForceUpdate: Boolean,
    val minSdk: Int
)

sealed class UpdateDownloadState {
    object Idle : UpdateDownloadState()
    data class Downloading(val progressPercent: Int, val downloadedBytes: Long, val totalBytes: Long) : UpdateDownloadState()
    data class Installing(val message: String = "Installing update automatically...") : UpdateDownloadState()
    object InstalledSuccess : UpdateDownloadState()
    data class Error(val message: String) : UpdateDownloadState()
}

object AppUpdateManager {
    private const val TAG = "AppUpdateManager"

    // 🌟 لائیو Vercel ویب سائٹ کا درست لائیو اپڈیٹ لنک
    var UPDATE_API_URL = "https://lerzaplayer.vercel.app/update.json"

    private val _downloadState = MutableStateFlow<UpdateDownloadState>(UpdateDownloadState.Idle)
    val downloadState: StateFlow<UpdateDownloadState> = _downloadState.asStateFlow()

    private val _availableUpdate = MutableStateFlow<UpdateInfo?>(null)
    val availableUpdate: StateFlow<UpdateInfo?> = _availableUpdate.asStateFlow()

    /**
     * رشتہ دار (Relative) URL کو ویب سائٹ کے مکمل ڈاؤن لوڈ لنک میں تبدیل کرتا ہے
     */
    fun getResolvedDownloadUrl(rawUrl: String): String {
        val trimmed = rawUrl.trim()
        return when {
            trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            trimmed.startsWith("/") -> "https://lerzaplayer.vercel.app$trimmed"
            else -> "https://lerzaplayer.vercel.app/$trimmed"
        }
    }

    /**
     * چیک کرتا ہے کہ آیا ایپ کے پاس پیکج انسٹال کرنے کی پرمیشن ہے
     */
    fun hasInstallPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.packageManager.canRequestPackageInstalls()
        } else {
            true
        }
    }

    /**
     * پیکج انسٹال کرنے کی اجازت لینے کے لیے سسٹم سیٹنگز کھولتا ہے
     */
    fun requestInstallPermission(activity: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                    data = Uri.parse("package:${activity.packageName}")
                }
                activity.startActivity(intent)
            } catch (e: Exception) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                    activity.startActivity(intent)
                } catch (_: Exception) {}
            }
        }
    }

    /**
     * ویب سائٹ سے لائیو چیک کرتا ہے کہ آیا نیا ورژن آ گیا ہے
     */
    suspend fun checkForUpdates(context: Context, customUrl: String? = null): UpdateInfo? = withContext(Dispatchers.IO) {
        val targetUrl = customUrl ?: UPDATE_API_URL
        try {
            val url = URL(targetUrl)
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 10000
                readTimeout = 10000
                requestMethod = "GET"
                instanceFollowRedirects = true
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "LerzaPlayer-Android-App")
            }

            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val jsonString = connection.inputStream.bufferedReader().use { it.readText() }
                val rootJson = JSONObject(jsonString)
                val dataObj = if (rootJson.has("data")) rootJson.getJSONObject("data") else rootJson

                val latestVersionCode = dataObj.optInt("versionCode", 1)
                val currentVersionCode = try {
                    val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        pInfo.longVersionCode.toInt()
                    } else {
                        @Suppress("DEPRECATION")
                        pInfo.versionCode
                    }
                } catch (_: Exception) { 1 }

                // اگر ویب سائٹ پر موجود ورژن کوڈ موجودہ انسٹال شدہ کوڈ سے بڑا ہے
                if (latestVersionCode > currentVersionCode) {
                    val changelogList = mutableListOf<String>()
                    val changelogArray = dataObj.optJSONArray("changelog")
                    if (changelogArray != null) {
                        for (i in 0 until changelogArray.length()) {
                            changelogList.add(changelogArray.getString(i))
                        }
                    }

                    val rawApkUrl = dataObj.optString("apkUrl", "")
                    val finalApkUrl = getResolvedDownloadUrl(rawApkUrl)

                    val info = UpdateInfo(
                        versionName = dataObj.optString("versionName", "1.0.0"),
                        versionCode = latestVersionCode,
                        releaseTitle = dataObj.optString("releaseTitle", "New Update Available"),
                        changelog = changelogList,
                        apkUrl = finalApkUrl,
                        apkSize = dataObj.optString("apkSize", ""),
                        isForceUpdate = dataObj.optBoolean("isForceUpdate", false),
                        minSdk = dataObj.optInt("minSdk", 24)
                    )
                    _availableUpdate.value = info
                    return@withContext info
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        _availableUpdate.value = null
        null
    }

    /**
     * کروم براؤزر کے بغیر ایپ کے اندر ہی APK فائل کیشے میں ڈاؤن لوڈ کرتا ہے۔
     * 🌟 ڈاؤن لوڈ مکمل ہوتے ہی بغیر کسی بٹن کلک کے فوری خودکار انسٹال شروع کر دیتا ہے!
     */
    suspend fun startInAppDownload(
        context: Context,
        updateInfo: UpdateInfo,
        activity: Activity? = null
    ) = withContext(Dispatchers.IO) {
        val downloadUrl = getResolvedDownloadUrl(updateInfo.apkUrl)
        if (downloadUrl.isBlank()) {
            _downloadState.value = UpdateDownloadState.Error("Invalid APK download URL.")
            return@withContext
        }

        try {
            _downloadState.value = UpdateDownloadState.Downloading(0, 0, 0)
            var currentUrl = downloadUrl
            var connection: HttpURLConnection
            var redirectCount = 0
            val maxRedirects = 5

            // ری ڈائریکٹس کو محفوظ طریقے سے فالو کریں
            while (true) {
                val url = URL(currentUrl)
                connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 30000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "LerzaPlayer-Android-App")
                }
                val code = connection.responseCode
                if (code == HttpURLConnection.HTTP_MOVED_PERM || code == HttpURLConnection.HTTP_MOVED_TEMP || code == 307 || code == 308) {
                    val location = connection.getHeaderField("Location")
                    if (location != null && redirectCount < maxRedirects) {
                        currentUrl = location
                        redirectCount++
                        continue
                    }
                }
                break
            }

            val totalBytes = connection.contentLength.toLong()
            val updatesDir = File(context.cacheDir, "app_updates").apply { mkdirs() }
            val targetApk = File(updatesDir, "LerzaPlayer_v${updateInfo.versionName}.apk")
            if (targetApk.exists()) targetApk.delete()

            connection.inputStream.use { input ->
                FileOutputStream(targetApk).use { output ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    var totalRead = 0L
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                        totalRead += bytesRead
                        val progress = if (totalBytes > 0) ((totalRead * 100) / totalBytes).toInt() else -1
                        _downloadState.value = UpdateDownloadState.Downloading(progress, totalRead, totalBytes)
                    }
                }
            }

            // 🌟 ڈاؤن لوڈ مکمل! اب صارف کو کوئی بٹن کلک نہیں کرنا پڑے گا، سیدھا انسٹال ہوگا!
            _downloadState.value = UpdateDownloadState.Installing("Download complete. Installing update automatically...")

            // فوری خودکار انسٹالیشن شروع کریں
            installApkAutomatically(context, targetApk, activity)

        } catch (e: Exception) {
            e.printStackTrace()
            _downloadState.value = UpdateDownloadState.Error("Download failed: ${e.localizedMessage ?: "Network error"}")
        }
    }

    /**
     * خودکار انسٹالیشن:
     * 1. اینڈرائیڈ 12+ پر PackageInstaller کے ذریعے بغیر یوزر انٹرفیس روکے اپڈیٹ سیشن شروع کرتا ہے
     * 2. اگر سسٹم کو تصدیق درکار ہو تو سسٹم ڈائیلاگ خودکار ظاہر ہوگا
     * 3. بیک اپ فال بیک کے طور پر FileProvider انسٹالر بھی تیار ہے
     */
    fun installApkAutomatically(context: Context, apkFile: File, activity: Activity? = null) {
        if (!apkFile.exists()) {
            _downloadState.value = UpdateDownloadState.Error("Downloaded APK file not found.")
            return
        }

        // اگر نامعلوم سورسز سے انسٹالیشن کی اجازت نہ ہو
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
            activity?.let { requestInstallPermission(it) }
            _downloadState.value = UpdateDownloadState.Error("Install permission required. Please allow unknown sources in Settings and retry.")
            return
        }

        try {
            installViaPackageInstaller(context, apkFile)
        } catch (e: Exception) {
            Log.e(TAG, "PackageInstaller session error, falling back to standard intent: ${e.message}", e)
            fallbackInstallIntent(context, apkFile, activity)
        }
    }

    /**
     * اینڈرائیڈ PackageInstaller Session API کا استعمال کرتے ہوئے پس منظر میں انسٹالیشن
     */
    private fun installViaPackageInstaller(context: Context, apkFile: File) {
        val packageInstaller = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
            setAppPackageName(context.packageName)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // اینڈرائیڈ 12+ پر بغیر کسی بٹن کلک کے خودکار اپڈیٹ
                setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                setInstallReason(android.content.pm.PackageManager.INSTALL_REASON_USER)
            }
        }

        val sessionId = packageInstaller.createSession(params)
        val session = packageInstaller.openSession(sessionId)

        session.use { activeSession ->
            FileInputStream(apkFile).use { input ->
                activeSession.openWrite("LerzaUpdate_${System.currentTimeMillis()}", 0, apkFile.length()).use { output ->
                    input.copyTo(output)
                    activeSession.fsync(output)
                }
            }

            // کال بیک انٹینٹ جو PackageInstallerStatusReceiver کو بھیجا جائے گا
            val callbackIntent = Intent(context, PackageInstallerStatusReceiver::class.java).apply {
                action = PackageInstallerStatusReceiver.ACTION_INSTALL_STATUS
            }

            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                sessionId,
                callbackIntent,
                flags
            )

            // سیشن کمٹ کریں
            activeSession.commit(pendingIntent.intentSender)
        }
    }

    /**
     * روایتی فال بیک اگر سسٹم PackageInstaller سیشن بلاک کرے
     */
    fun fallbackInstallIntent(context: Context, apkFile: File, activity: Activity? = null) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val apkUri = FileProvider.getUriForFile(context, authority, apkFile)
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (activity != null) {
                activity.startActivity(installIntent)
            } else {
                context.startActivity(installIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Fallback install intent failed: ${e.message}", e)
            _downloadState.value = UpdateDownloadState.Error("Failed to trigger installer: ${e.localizedMessage}")
        }
    }

    fun onInstallCompleted() {
        _downloadState.value = UpdateDownloadState.InstalledSuccess
    }

    fun onInstallFailed(errorMessage: String) {
        _downloadState.value = UpdateDownloadState.Error(errorMessage)
    }

    fun dismissUpdate() {
        _availableUpdate.value = null
        _downloadState.value = UpdateDownloadState.Idle
    }
}