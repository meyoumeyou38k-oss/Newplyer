package com.lerzaplayer.ads

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import android.widget.Toast
import com.google.android.gms.ads.*
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AdManager {
    private const val TAG = "LerzaAdManager"
    private const val REMOTE_CONFIG_URL = "https://lerzaplayer.vercel.app/ads.json"
    private const val PREFS_NAME = "lerza_ad_config_prefs"
    private const val KEY_CONFIG_JSON = "cached_config_json"

    // Official Google Test Ad Unit IDs (guaranteed to always load on any phone)
    const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"
    const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"
    const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

    // Active Remote Values (loaded dynamically from lerzaplayer.vercel.app/ads.json)
    var isMasterAdsEnabled: Boolean = true
    var isAppOpenEnabled: Boolean = true
    var isSongsListAdEnabled: Boolean = true
    var isVideosListAdEnabled: Boolean = true
    var isSettingsClickAdEnabled: Boolean = true
    var isVaultRewardAdEnabled: Boolean = true

    var appOpenAdUnitId: String = "ca-app-pub-7375534389683057/3906515984"
    var nativeAdUnitId: String = "ca-app-pub-7375534389683057/8388686475"
    var interstitialAdUnitId: String = "ca-app-pub-7375534389683057/1823278127"
    var rewardedAdUnitId: String = "ca-app-pub-7375534389683057/7678240038"

    private var appOpenAd: AppOpenAd? = null
    private var isAppOpenLoading = false

    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false

    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    fun isNetworkAvailable(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val network = cm?.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            true
        }
    }

    fun initialize(context: Context) {
        loadCachedConfig(context)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Initialize AdMob MobileAds
                MobileAds.initialize(context) { status ->
                    Log.d(TAG, "AdMob MobileAds initialized")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error initializing MobileAds", e)
            }

            fetchRemoteConfig(context)
            withContext(Dispatchers.Main) {
                preloadAds(context)
            }
        }
    }

    fun fetchRemoteConfig(context: Context) {
        if (!isNetworkAvailable(context)) return

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val url = URL(REMOTE_CONFIG_URL)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.requestMethod = "GET"
                conn.setRequestProperty("Accept", "application/json")
                conn.setRequestProperty("User-Agent", "LerzaPlayer-Android")

                if (conn.responseCode == HttpURLConnection.HTTP_OK) {
                    val responseStr = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(responseStr)
                    applyConfig(json)

                    // Cache for offline/subsequent fast launches
                    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    prefs.edit().putString(KEY_CONFIG_JSON, responseStr).apply()
                    Log.d(TAG, "Remote ad config fetched & applied successfully: " + responseStr)
                }
                conn.disconnect()
            } catch (e: Exception) {
                Log.w(TAG, "Could not fetch remote config, using cached: " + e.message)
            }
        }
    }

    private fun loadCachedConfig(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val cached = prefs.getString(KEY_CONFIG_JSON, null) ?: return
        try {
            val json = JSONObject(cached)
            applyConfig(json)
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing cached config", e)
        }
    }

    private fun applyConfig(json: JSONObject) {
        try {
            isMasterAdsEnabled = json.optBoolean("master_ads_enabled", true)
            isAppOpenEnabled = json.optBoolean("app_open_ad_enabled", true)
            isSongsListAdEnabled = json.optBoolean("songs_list_ad_enabled", true)
            isVideosListAdEnabled = json.optBoolean("videos_list_ad_enabled", true)
            isSettingsClickAdEnabled = json.optBoolean("settings_click_ad_enabled", true)
            isVaultRewardAdEnabled = json.optBoolean("vault_reward_ad_enabled", true)

            appOpenAdUnitId = json.optString("app_open_ad_unit_id", appOpenAdUnitId)
            nativeAdUnitId = json.optString("songs_list_ad_unit_id", nativeAdUnitId)
            interstitialAdUnitId = json.optString("settings_click_ad_unit_id", interstitialAdUnitId)
            rewardedAdUnitId = json.optString("vault_reward_ad_unit_id", rewardedAdUnitId)
        } catch (e: Exception) {
            Log.e(TAG, "Error applying config", e)
        }
    }

    fun preloadAds(context: Context) {
        if (!isNetworkAvailable(context) || !isMasterAdsEnabled) return
        loadAppOpenAd(context)
        loadInterstitial(context)
        loadRewarded(context)
    }

    // --- 1. App Open Ad ---
    private fun loadAppOpenAd(context: Context, useFallback: Boolean = false) {
        if (isAppOpenLoading || appOpenAd != null || !isNetworkAvailable(context) || !isMasterAdsEnabled || !isAppOpenEnabled) return
        isAppOpenLoading = true

        val unitId = if (useFallback) TEST_APP_OPEN_ID else appOpenAdUnitId
        val request = AdRequest.Builder().build()
        AppOpenAd.load(context, unitId, request, object : AppOpenAd.AppOpenAdLoadCallback() {
            override fun onAdLoaded(ad: AppOpenAd) {
                appOpenAd = ad
                isAppOpenLoading = false
                Log.d(TAG, "AppOpenAd loaded with unit: " + unitId)
            }
            override fun onAdFailedToLoad(error: LoadAdError) {
                appOpenAd = null
                isAppOpenLoading = false
                Log.w(TAG, "AppOpenAd failed on " + unitId + ": " + error.message)
                if (!useFallback) {
                    loadAppOpenAd(context, useFallback = true)
                }
            }
        })
    }

    fun checkAndShowAppOpenAd(activity: Activity) {
        val prefs = activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val launchCount = prefs.getInt("launch_count", 0) + 1
        prefs.edit().putInt("launch_count", launchCount).apply()

        // Skip ad on the very first launch, show on 2nd and subsequent launches
        if (launchCount <= 1) {
            Log.d(TAG, "First app launch: skipping AppOpen ad.")
            return
        }
        if (!isNetworkAvailable(activity) || !isMasterAdsEnabled || !isAppOpenEnabled) return

        if (appOpenAd != null) {
            appOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    appOpenAd = null
                    loadAppOpenAd(activity)
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    appOpenAd = null
                }
            }
            appOpenAd?.show(activity)
        } else {
            // Load and show on-demand with automatic fallback
            val request = AdRequest.Builder().build()
            AppOpenAd.load(activity, appOpenAdUnitId, request, object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            appOpenAd = null
                        }
                    }
                    ad.show(activity)
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    AppOpenAd.load(activity, TEST_APP_OPEN_ID, request, object : AppOpenAd.AppOpenAdLoadCallback() {
                        override fun onAdLoaded(ad: AppOpenAd) {
                            ad.show(activity)
                        }
                        override fun onAdFailedToLoad(error: LoadAdError) {}
                    })
                }
            })
        }
    }

    // --- 2. Interstitial Ad (Settings click) ---
    private fun loadInterstitial(context: Context, useFallback: Boolean = false) {
        if (isInterstitialLoading || interstitialAd != null || !isNetworkAvailable(context) || !isMasterAdsEnabled || !isSettingsClickAdEnabled) return
        isInterstitialLoading = true

        val unitId = if (useFallback) TEST_INTERSTITIAL_ID else interstitialAdUnitId
        val request = AdRequest.Builder().build()
        InterstitialAd.load(context, unitId, request, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) {
                interstitialAd = ad
                isInterstitialLoading = false
                Log.d(TAG, "Interstitial loaded with unit: " + unitId)
            }
            override fun onAdFailedToLoad(error: LoadAdError) {
                interstitialAd = null
                isInterstitialLoading = false
                Log.w(TAG, "Interstitial failed on " + unitId + ": " + error.message)
                if (!useFallback) {
                    loadInterstitial(context, useFallback = true)
                }
            }
        })
    }

    fun showSettingsInterstitial(activity: Activity, onComplete: () -> Unit) {
        if (!isNetworkAvailable(activity) || !isMasterAdsEnabled || !isSettingsClickAdEnabled) {
            onComplete()
            return
        }

        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onComplete()
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onComplete()
                }
            }
            ad.show(activity)
        } else {
            onComplete()
            loadInterstitial(activity)
        }
    }

    // --- 3. Rewarded Video Ad (Vault Forgot Password) ---
    private fun loadRewarded(context: Context, useFallback: Boolean = false) {
        if (isRewardedLoading || rewardedAd != null || !isNetworkAvailable(context) || !isMasterAdsEnabled || !isVaultRewardAdEnabled) return
        isRewardedLoading = true

        val unitId = if (useFallback) TEST_REWARDED_ID else rewardedAdUnitId
        val request = AdRequest.Builder().build()
        RewardedAd.load(context, unitId, request, object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) {
                rewardedAd = ad
                isRewardedLoading = false
                Log.d(TAG, "Rewarded ad loaded with unit: " + unitId)
            }
            override fun onAdFailedToLoad(error: LoadAdError) {
                rewardedAd = null
                isRewardedLoading = false
                Log.w(TAG, "Rewarded ad failed on " + unitId + ": " + error.message)
                if (!useFallback) {
                    loadRewarded(context, useFallback = true)
                }
            }
        })
    }

    fun showVaultRewardAd(
        activity: Activity,
        onRewarded: () -> Unit,
        onFailedOrDismissed: (String) -> Unit
    ) {
        if (!isNetworkAvailable(activity)) {
            onFailedOrDismissed("No Internet Connection. Please connect to Wi-Fi or Mobile Data.")
            return
        }

        if (!isMasterAdsEnabled || !isVaultRewardAdEnabled) {
            onRewarded()
            return
        }

        val ad = rewardedAd
        if (ad != null) {
            var earned = false
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewarded(activity)
                    if (earned) {
                        onRewarded()
                    } else {
                        onFailedOrDismissed("Please watch the full ad to reset security.")
                    }
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    loadRewarded(activity)
                    // If ad display fails, unlock to avoid user lockout
                    onRewarded()
                }
            }
            ad.show(activity) { _ ->
                earned = true
            }
        } else {
            // Load on demand: first try publisher ID, if AdMob rejects (e.g. Publisher data not found), immediately fallback to Test ID!
            Toast.makeText(activity, "Loading video ad, please wait...", Toast.LENGTH_SHORT).show()
            val request = AdRequest.Builder().build()
            RewardedAd.load(activity, rewardedAdUnitId, request, object : RewardedAdLoadCallback() {
                override fun onAdLoaded(newAd: RewardedAd) {
                    rewardedAd = newAd
                    showVaultRewardAd(activity, onRewarded, onFailedOrDismissed)
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Live reward ad failed (" + error.message + "), trying fallback test ad...")
                    // Fallback to official Google test rewarded ad
                    RewardedAd.load(activity, TEST_REWARDED_ID, request, object : RewardedAdLoadCallback() {
                        override fun onAdLoaded(fallbackAd: RewardedAd) {
                            rewardedAd = fallbackAd
                            showVaultRewardAd(activity, onRewarded, onFailedOrDismissed)
                        }
                        override fun onAdFailedToLoad(err2: LoadAdError) {
                            // If even fallback fails, don't lock out the user: unlock reset
                            Toast.makeText(activity, "Ad temporarily unavailable. Proceeding to reset...", Toast.LENGTH_SHORT).show()
                            onRewarded()
                        }
                    })
                }
            })
        }
    }
}
