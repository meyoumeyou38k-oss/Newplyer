package com.lerzaplayer.theme

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb

data class LerzaColorPalette(
    val primary: Color,
    val primaryVariant: Color,
    val accent: Color,
    val onPrimary: Color,
    val secondary: Color = accent,
    val card: Color,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val divider: Color,
    val isDark: Boolean
)

object ThemeManager {
    private const val PREFS_NAME = "lerza_theme_prefs"
    private const val KEY_COLOR = "selected_theme_color"
    private const val KEY_NAME = "selected_theme_name"
    private const val KEY_MODE = "selected_theme_mode"

    var currentThemeColor by mutableStateOf(LarkPurple)
    var currentThemeName by mutableStateOf("Purple")
    var currentThemeMode by mutableStateOf("Light")

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedColor = prefs.getInt(KEY_COLOR, LarkPurple.toArgb())
        val savedName = prefs.getString(KEY_NAME, "Purple") ?: "Purple"
        val savedMode = prefs.getString(KEY_MODE, "Light") ?: "Light"
        currentThemeColor = Color(savedColor)
        currentThemeName = savedName
        currentThemeMode = savedMode
    }

    fun setTheme(context: Context, color: Color, name: String = "") {
        currentThemeColor = color
        currentThemeName = name.ifEmpty { "Custom" }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putInt(KEY_COLOR, color.toArgb())
            .putString(KEY_NAME, currentThemeName)
            .apply()
    }

    fun setMode(context: Context, mode: String) {
        currentThemeMode = mode
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_MODE, mode).apply()
    }
}

val LocalLerzaColors = staticCompositionLocalOf {
    getLerzaPalette(LarkPurple, isDark = false, isNone = false)
}

object LerzaTheme {
    val colors: LerzaColorPalette
        @Composable
        @ReadOnlyComposable
        get() = LocalLerzaColors.current
}

fun getColorByThemeName(themeName: String): Color {
    return when (themeName.lowercase()) {
        "emerald" -> LarkEmerald
        "indigo" -> LarkIndigo
        "coral" -> LarkCoral
        "none" -> LarkPurple
        "purple" -> LarkPurple
        "green" -> LarkGreen
        "blue" -> LerzaBlue
        "orange" -> LarkOrange
        "red" -> LarkRed
        "pink" -> LarkPink
        "cyan" -> LarkCyan
        "amber", "yellow" -> LarkAmber
        else -> LarkPurple
    }
}

fun getContrastTextColor(backgroundColor: Color): Color {
    return if (backgroundColor.luminance() > 0.45f) Color(0xFF101418) else Color.White
}

fun getLerzaPalette(themeColor: Color, isDark: Boolean, isNone: Boolean = false): LerzaColorPalette {
    val effectiveColor = if (isNone || themeColor == Color.Transparent) {
        if (isDark) Color(0xFF9C27B0) else Color(0xFF8E24AA)
    } else {
        themeColor
    }
    val contrastOnPrimary = getContrastTextColor(effectiveColor)

    return if (isDark) {
        val bg = if (isNone) Color(0xFF000000) else Color(
            red = (effectiveColor.red * 0.08f).coerceIn(0f, 0.08f),
            green = (effectiveColor.green * 0.10f).coerceIn(0f, 0.10f),
            blue = (effectiveColor.blue * 0.08f).coerceIn(0f, 0.08f),
            alpha = 1f
        )
        val surf = if (isNone) Color(0xFF121417) else Color(
            red = (effectiveColor.red * 0.14f).coerceIn(0.06f, 0.16f),
            green = (effectiveColor.green * 0.16f).coerceIn(0.07f, 0.18f),
            blue = (effectiveColor.blue * 0.14f).coerceIn(0.06f, 0.16f),
            alpha = 1f
        )
        val crd = if (isNone) Color(0xFF1A1D24) else Color(
            red = (effectiveColor.red * 0.20f).coerceIn(0.10f, 0.22f),
            green = (effectiveColor.green * 0.22f).coerceIn(0.11f, 0.25f),
            blue = (effectiveColor.blue * 0.20f).coerceIn(0.10f, 0.22f),
            alpha = 1f
        )

        LerzaColorPalette(
            primary = effectiveColor,
            primaryVariant = effectiveColor.copy(alpha = 0.85f),
            accent = effectiveColor,
            onPrimary = contrastOnPrimary,
            secondary = effectiveColor,
            card = crd,
            background = bg,
            surface = surf,
            surfaceVariant = surf.copy(alpha = 0.9f),
            textPrimary = Color(0xFFFFFFFF),
            textSecondary = Color(0xFFB0B3B8),
            divider = effectiveColor.copy(alpha = 0.15f),
            isDark = true
        )
    } else {
        val lightBg = if (isNone) Color(0xFFF7F9FA) else Color(
            red = (effectiveColor.red * 0.06f + 0.94f).coerceIn(0.92f, 1f),
            green = (effectiveColor.green * 0.08f + 0.92f).coerceIn(0.92f, 1f),
            blue = (effectiveColor.blue * 0.06f + 0.94f).coerceIn(0.92f, 1f),
            alpha = 1f
        )
        val lightSurf = Color(0xFFFFFFFF)
        val lightCard = if (isNone) Color(0xFFFFFFFF) else Color(
            red = (effectiveColor.red * 0.12f + 0.88f).coerceIn(0.85f, 1f),
            green = (effectiveColor.green * 0.14f + 0.86f).coerceIn(0.85f, 1f),
            blue = (effectiveColor.blue * 0.12f + 0.88f).coerceIn(0.85f, 1f),
            alpha = 1f
        )

        LerzaColorPalette(
            primary = effectiveColor,
            primaryVariant = effectiveColor.copy(alpha = 0.85f),
            accent = effectiveColor,
            onPrimary = contrastOnPrimary,
            secondary = effectiveColor,
            card = lightCard,
            background = lightBg,
            surface = lightSurf,
            surfaceVariant = Color(0xFFF0F2F5),
            textPrimary = Color(0xFF111417),
            textSecondary = Color(0xFF5A6065),
            divider = Color(0xFFE2E5E8),
            isDark = false
        )
    }
}

@Composable
fun LerzaPlayerTheme(
    themeName: String = ThemeManager.currentThemeName,
    themeColor: Color? = null,
    darkTheme: Boolean = when (ThemeManager.currentThemeMode) {
        "Light" -> false
        "Dark" -> true
        else -> isSystemInDarkTheme()
    },
    content: @Composable () -> Unit
) {
    val activeColor = themeColor ?: ThemeManager.currentThemeColor
    val isNone = ThemeManager.currentThemeName.equals("None", ignoreCase = true)
    val lerzaPalette = getLerzaPalette(activeColor, darkTheme, isNone)

    val materialColorScheme = if (darkTheme) {
        darkColorScheme(
            primary = lerzaPalette.primary,
            secondary = lerzaPalette.accent,
            tertiary = lerzaPalette.primaryVariant,
            background = lerzaPalette.background,
            surface = lerzaPalette.surface,
            surfaceVariant = lerzaPalette.surfaceVariant,
            onPrimary = lerzaPalette.onPrimary,
            onBackground = lerzaPalette.textPrimary,
            onSurface = lerzaPalette.textPrimary
        )
    } else {
        lightColorScheme(
            primary = lerzaPalette.primary,
            secondary = lerzaPalette.accent,
            tertiary = lerzaPalette.primaryVariant,
            background = lerzaPalette.background,
            surface = lerzaPalette.surface,
            surfaceVariant = lerzaPalette.surfaceVariant,
            onPrimary = lerzaPalette.onPrimary,
            onBackground = lerzaPalette.textPrimary,
            onSurface = lerzaPalette.textPrimary
        )
    }

    CompositionLocalProvider(
        LocalLerzaColors provides lerzaPalette
    ) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            content = content
        )
    }
}