package com.lerzaplayer.playback

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

object PlaytimeTracker {
    private const val PREF_NAME = "lerza_playtime_prefs"
    private const val KEY_TOTAL_MUSIC_MS = "total_music_ms"
    private const val KEY_TOTAL_VIDEO_MS = "total_video_ms"

    private var prefs: SharedPreferences? = null

    private val _musicPlaytimeMs = MutableStateFlow(0L)
    val musicPlaytimeMs: StateFlow<Long> = _musicPlaytimeMs.asStateFlow()

    private val _videoPlaytimeMs = MutableStateFlow(0L)
    val videoPlaytimeMs: StateFlow<Long> = _videoPlaytimeMs.asStateFlow()

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            _musicPlaytimeMs.value = prefs?.getLong(KEY_TOTAL_MUSIC_MS, 0L) ?: 0L
            _videoPlaytimeMs.value = prefs?.getLong(KEY_TOTAL_VIDEO_MS, 0L) ?: 0L
        }
    }

    private fun getPrefs(context: Context): SharedPreferences {
        if (prefs == null) init(context)
        return prefs!!
    }

    fun addMusicTime(context: Context, deltaMs: Long) {
        val p = getPrefs(context)
        val newTotal = (p.getLong(KEY_TOTAL_MUSIC_MS, 0L) + deltaMs)
        p.edit().putLong(KEY_TOTAL_MUSIC_MS, newTotal).apply()
        _musicPlaytimeMs.value = newTotal

        // Record Month and Today
        val monthKey = "month_" + SimpleDateFormat("yyyy_MM", Locale.ENGLISH).format(Date())
        val dayKey = "day_" + SimpleDateFormat("yyyy_MM_dd", Locale.ENGLISH).format(Date())
        p.edit()
            .putLong(monthKey, p.getLong(monthKey, 0L) + deltaMs)
            .putLong(dayKey, p.getLong(dayKey, 0L) + deltaMs)
            .apply()
    }

    fun addVideoTime(context: Context, deltaMs: Long) {
        val p = getPrefs(context)
        val newTotal = (p.getLong(KEY_TOTAL_VIDEO_MS, 0L) + deltaMs)
        p.edit().putLong(KEY_TOTAL_VIDEO_MS, newTotal).apply()
        _videoPlaytimeMs.value = newTotal

        val monthKey = "month_v_" + SimpleDateFormat("yyyy_MM", Locale.ENGLISH).format(Date())
        val dayKey = "day_v_" + SimpleDateFormat("yyyy_MM_dd", Locale.ENGLISH).format(Date())
        p.edit()
            .putLong(monthKey, p.getLong(monthKey, 0L) + deltaMs)
            .putLong(dayKey, p.getLong(dayKey, 0L) + deltaMs)
            .apply()
    }

    fun getMonthPlaytimeMs(context: Context): Long {
        val p = getPrefs(context)
        val monthKey = "month_" + SimpleDateFormat("yyyy_MM", Locale.ENGLISH).format(Date())
        return p.getLong(monthKey, 0L)
    }

    fun getTodayPlaytimeMs(context: Context): Long {
        val p = getPrefs(context)
        val dayKey = "day_" + SimpleDateFormat("yyyy_MM_dd", Locale.ENGLISH).format(Date())
        return p.getLong(dayKey, 0L)
    }

    fun getCurrentMonthName(): String {
        return SimpleDateFormat("MMMM", Locale.ENGLISH).format(Date())
    }

    /**
     * Lark Player Style Formatting:
     * Examples: "2h 7m", "45m", "17s", "0m"
     */
    fun formatLarkTime(ms: Long): String {
        val totalSec = ms / 1000
        val hours = totalSec / 3600
        val mins = (totalSec % 3600) / 60
        val secs = totalSec % 60

        return when {
            hours > 0 -> "${hours}h ${mins}m"
            mins > 0 -> "${mins}m"
            secs > 0 -> "${secs}s"
            else -> "0m"
        }
    }

    fun formatTotalBadge(context: Context): String {
        val totalMs = (prefs?.getLong(KEY_TOTAL_MUSIC_MS, 0L) ?: 0L) +
                      (prefs?.getLong(KEY_TOTAL_VIDEO_MS, 0L) ?: 0L)
        return formatLarkTime(totalMs)
    }
}