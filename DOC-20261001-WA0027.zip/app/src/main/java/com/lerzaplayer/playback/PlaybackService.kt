package com.lerzaplayer.playback

import android.content.Intent
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.lerzaplayer.data.repository.ThumbnailExtractor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var playerManager: PlayerManager

    override fun onCreate() {
        super.onCreate()
        playerManager = PlayerManager.getInstance(this)

        // ForwardingPlayer guarantees that Next & Previous commands remain available
        // to Android System Media Controls (Android 13/14/15) even when ExoPlayer
        // manages tracks individually.
        val forwardingPlayer = object : ForwardingPlayer(playerManager.exoPlayer) {
            override fun getAvailableCommands(): Player.Commands {
                return super.getAvailableCommands().buildUpon()
                    .add(Player.COMMAND_SEEK_TO_NEXT)
                    .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                    .build()
            }

            override fun isCommandAvailable(command: Int): Boolean {
                return command == Player.COMMAND_SEEK_TO_NEXT ||
                        command == Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM ||
                        command == Player.COMMAND_SEEK_TO_PREVIOUS ||
                        command == Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM ||
                        super.isCommandAvailable(command)
            }

            override fun seekToNext() {
                playerManager.playNextTrack()
            }

            override fun seekToNextMediaItem() {
                playerManager.playNextTrack()
            }

            override fun seekToPrevious() {
                playerManager.playPreviousTrack()
            }

            override fun seekToPreviousMediaItem() {
                playerManager.playPreviousTrack()
            }

            override fun hasNextMediaItem(): Boolean {
                return true
            }

            override fun hasPreviousMediaItem(): Boolean {
                return true
            }
        }

        val sessionCallback = object : MediaSession.Callback {
            override fun onConnect(
                session: MediaSession,
                controller: MediaSession.ControllerInfo
            ): MediaSession.ConnectionResult {
                val connectionResult = super.onConnect(session, controller)
                val availablePlayerCommands = connectionResult.availablePlayerCommands.buildUpon()
                    .add(Player.COMMAND_SEEK_TO_NEXT)
                    .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                    .build()

                return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                    .setAvailableSessionCommands(connectionResult.availableSessionCommands)
                    .setAvailablePlayerCommands(availablePlayerCommands)
                    .build()
            }
        }

        mediaSession = MediaSession.Builder(this, forwardingPlayer)
            .setCallback(sessionCallback)
            .build()

        serviceScope.launch { playerManager.currentSong.collect { updateNotification() } }
        serviceScope.launch { playerManager.isPlaying.collect { updateNotification() } }
        serviceScope.launch { playerManager.duration.collect { updateNotification() } }
    }

    private fun updateNotification() {
        val song = playerManager.currentSong.value
        val isPlaying = playerManager.isPlaying.value
        val position = playerManager.currentPosition.value
        val duration = playerManager.duration.value
        val session = mediaSession

        serviceScope.launch(Dispatchers.IO) {
            val art = if (song != null) {
                ThumbnailExtractor.getSongCover(this@PlaybackService, song.contentUri, song.id)
            } else {
                null
            }

            val notification = NotificationHelper.buildMediaNotification(
                context = this@PlaybackService,
                song = song,
                isPlaying = isPlaying,
                albumArt = art,
                currentPosition = position,
                duration = duration,
                mediaSession = session
            )

            withContext(Dispatchers.Main) {
                if (isPlaying || song != null) {
                    startForeground(NotificationHelper.NOTIFICATION_ID, notification)
                } else {
                    stopForeground(STOP_FOREGROUND_DETACH)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(
            NotificationHelper.NOTIFICATION_ID,
            NotificationHelper.buildMediaNotification(
                context = this,
                song = playerManager.currentSong.value,
                isPlaying = playerManager.isPlaying.value,
                albumArt = null,
                currentPosition = playerManager.currentPosition.value,
                duration = playerManager.duration.value,
                mediaSession = mediaSession
            )
        )

        when (intent?.action) {
            ACTION_PLAY -> playerManager.play()
            ACTION_PAUSE -> playerManager.pause()
            ACTION_NEXT -> playerManager.playNextTrack()
            ACTION_PREV -> playerManager.playPreviousTrack()
            ACTION_STOP -> {
                playerManager.pause()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }

        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        serviceScope.cancel()
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.lerzaplayer.ACTION_PLAY"
        const val ACTION_PAUSE = "com.lerzaplayer.ACTION_PAUSE"
        const val ACTION_NEXT = "com.lerzaplayer.ACTION_NEXT"
        const val ACTION_PREV = "com.lerzaplayer.ACTION_PREV"
        const val ACTION_STOP = "com.lerzaplayer.ACTION_STOP"
    }
}