package com.lerzaplayer.playback

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

class PlayerManager private constructor(private val context: Context) {

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context).build().apply {
        setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .setUsage(C.USAGE_MEDIA)
                .build(),
            true
        )
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _currentSong = MutableStateFlow<SongItem?>(null)
    val currentSong: StateFlow<SongItem?> = _currentSong.asStateFlow()

    fun updateCurrentSongFavorite(isFav: Boolean) {
        val cur = _currentSong.value ?: return
        if (cur.isFavorite != isFav) {
            _currentSong.value = cur.copy(isFavorite = isFav)
        }
    }

    private val _currentVideo = MutableStateFlow<VideoItem?>(null)
    val currentVideo: StateFlow<VideoItem?> = _currentVideo.asStateFlow()

    private val _queue = MutableStateFlow<List<SongItem>>(emptyList())
    val queue: StateFlow<List<SongItem>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_ALL)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _sleepTimerRemainingMinutes = MutableStateFlow(0)
    val sleepTimerRemainingMinutes: StateFlow<Int> = _sleepTimerRemainingMinutes.asStateFlow()

    // 10-Band Virtual Equalizer States (-10 to +10 dB)
    private val _equalizerEnabled = MutableStateFlow(true)
    val equalizerEnabled: StateFlow<Boolean> = _equalizerEnabled.asStateFlow()

    // Default Jazz curve matching Lark Player
    private val _virtual10Bands = MutableStateFlow(listOf(3, 3, 2, 0, -1, -1, 0, 2, 3, 4))
    val virtual10Bands: StateFlow<List<Int>> = _virtual10Bands.asStateFlow()

    private val _activePresetId = MutableStateFlow("jazz")
    val activePresetId: StateFlow<String> = _activePresetId.asStateFlow()

    private val _bassBoostStrength = MutableStateFlow(350)
    val bassBoostStrength: StateFlow<Int> = _bassBoostStrength.asStateFlow()

    private val _virtualizerStrength = MutableStateFlow(0)
    val virtualizerStrength: StateFlow<Int> = _virtualizerStrength.asStateFlow()

    private val _loudnessGain = MutableStateFlow(100)
    val loudnessGain: StateFlow<Int> = _loudnessGain.asStateFlow()

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var sleepTimerJob: Job? = null

    // Target virtual frequencies in Hz (10 bands)
    private val virtualCenterFreqsHz = listOf(31, 63, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                _isPlaying.value = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)
                    initAudioEffects()
                } else if (playbackState == Player.STATE_ENDED) {
                    playNextTrack()
                }
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (audioSessionId != C.AUDIO_SESSION_ID_UNSET && audioSessionId != 0) {
                    initAudioEffects()
                }
            }
        })

        scope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _currentPosition.value = exoPlayer.currentPosition
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)
                    PlaytimeTracker.addMusicTime(context, 400L)
                }
                delay(400)
            }
        }

        initAudioEffects()
    }

    @Synchronized
    private fun initAudioEffects() {
        try {
            val audioSessionId = exoPlayer.audioSessionId
            if (audioSessionId == C.AUDIO_SESSION_ID_UNSET || audioSessionId == 0) {
                return
            }
            releaseAudioEffects()

            equalizer = Equalizer(1000, audioSessionId).apply {
                enabled = _equalizerEnabled.value
            }

            bassBoost = BassBoost(1000, audioSessionId).apply {
                enabled = _equalizerEnabled.value
                setStrength(_bassBoostStrength.value.toShort())
            }

            virtualizer = Virtualizer(1000, audioSessionId).apply {
                enabled = _equalizerEnabled.value
                setStrength(_virtualizerStrength.value.toShort())
            }

            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                enabled = true
            }

            applyLoudnessBoost(_loudnessGain.value)
            applyVirtualBandsToHardware()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun applyVirtualBandsToHardware() {
        val eq = equalizer ?: return
        try {
            eq.enabled = _equalizerEnabled.value
            val range = eq.bandLevelRange
            val minMb = range[0].toInt()
            val maxMb = range[1].toInt()
            val bandCount = eq.numberOfBands.toInt()
            val current10 = _virtual10Bands.value

            for (hwBand in 0 until bandCount) {
                val hwFreqHz = eq.getCenterFreq(hwBand.toShort()) / 1000
                var closestIndex = 0
                var minDiff = Int.MAX_VALUE
                for (vIndex in virtualCenterFreqsHz.indices) {
                    val diff = abs(virtualCenterFreqsHz[vIndex] - hwFreqHz)
                    if (diff < minDiff) {
                        minDiff = diff
                        closestIndex = vIndex
                    }
                }
                val dbVal = current10.getOrElse(closestIndex) { 0 }
                val targetMb = (dbVal * 100).coerceIn(minMb, maxMb)
                eq.setBandLevel(hwBand.toShort(), targetMb.toShort())
            }

            bassBoost?.apply {
                enabled = _equalizerEnabled.value
                setStrength(_bassBoostStrength.value.toShort())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setEqualizerEnabled(enabled: Boolean) {
        _equalizerEnabled.value = enabled
        try {
            if (equalizer == null) initAudioEffects()
            equalizer?.enabled = enabled
            bassBoost?.enabled = enabled
            virtualizer?.enabled = enabled
            applyVirtualBandsToHardware()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setVirtual10Band(bandIndex: Int, levelDb: Int) {
        val clamped = levelDb.coerceIn(-10, 10)
        val current = _virtual10Bands.value.toMutableList()
        if (bandIndex in current.indices) {
            current[bandIndex] = clamped
            _virtual10Bands.value = current
            _activePresetId.value = "custom"

            val lowBoost = ((current[0] + current[1] + current[2]) / 3f).coerceAtLeast(0f)
            val newBassStrength = (lowBoost * 100).toInt().coerceIn(0, 1000)
            _bassBoostStrength.value = newBassStrength

            applyVirtualBandsToHardware()
        }
    }

    fun applyLarkPreset(preset: com.lerzaplayer.ui.player.LarkPreset) {
        _activePresetId.value = preset.id
        _virtual10Bands.value = preset.bands
        _bassBoostStrength.value = preset.bassStrength
        applyVirtualBandsToHardware()
    }

    fun setBassBoostStrength(strength: Short) {
        val safe = strength.toInt().coerceIn(0, 1000)
        _bassBoostStrength.value = safe
        try {
            if (bassBoost == null) initAudioEffects()
            bassBoost?.apply {
                enabled = _equalizerEnabled.value
                setStrength(safe.toShort())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setVirtualizerStrength(strength: Short) {
        val safe = strength.toInt().coerceIn(0, 1000)
        _virtualizerStrength.value = safe
        try {
            if (virtualizer == null) initAudioEffects()
            virtualizer?.apply {
                enabled = _equalizerEnabled.value
                setStrength(safe.toShort())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun applyLoudnessBoost(percentage: Int) {
        try {
            if (percentage > 100) {
                val mB = (percentage - 100) * 35
                loudnessEnhancer?.apply {
                    enabled = true
                    setTargetGain(mB)
                }
            } else {
                loudnessEnhancer?.apply {
                    setTargetGain(0)
                    enabled = false
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setLoudnessGain(percentage: Int) {
        val safePercentage = percentage.coerceIn(1, 300)
        _loudnessGain.value = safePercentage
        try {
            val maxSystemVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (safePercentage <= 100) {
                val targetSystemVolume = (safePercentage * maxSystemVolume) / 100
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetSystemVolume, 0)
                applyLoudnessBoost(safePercentage)
            } else {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxSystemVolume, 0)
                if (loudnessEnhancer == null) initAudioEffects()
                applyLoudnessBoost(safePercentage)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun syncVolumeFromSystem() {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (max > 0 && _loudnessGain.value <= 100) {
            _loudnessGain.value = ((current.toFloat() / max.toFloat()) * 100).toInt().coerceIn(0, 100)
        }
    }

    fun playSongList(songs: List<SongItem>, startIndex: Int) {
        if (songs.isEmpty() || startIndex !in songs.indices) return
        _queue.value = songs
        _currentIndex.value = startIndex
        val song = songs[startIndex]
        _currentSong.value = song
        _currentVideo.value = null

        exoPlayer.setMediaItem(mediaItemFor(song))
        exoPlayer.prepare()
        exoPlayer.play()
        initAudioEffects()
        ContextCompat.startForegroundService(context, Intent(context, PlaybackService::class.java))
    }

    fun playSong(song: SongItem) = playSongList(listOf(song), 0)

    fun playNext(song: SongItem) {
        val songs = _queue.value
        if (songs.isEmpty()) {
            playSong(song)
            return
        }
        val insertionIndex = (_currentIndex.value + 1).coerceIn(0, songs.size)
        _queue.value = songs.toMutableList().apply { add(insertionIndex, song) }
    }

    private fun mediaItemFor(song: SongItem): MediaItem = MediaItem.Builder()
        .setUri(song.contentUri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(song.album)
                .setArtworkUri(song.albumArtUri)
                .build()
        )
        .build()

    fun addToQueue(song: SongItem) { _queue.value = _queue.value + song }

    fun removeFromQueue(index: Int) {
        val currentList = _queue.value.toMutableList()
        if (index in currentList.indices) {
            currentList.removeAt(index)
            _queue.value = currentList
            
            if (index == _currentIndex.value) {
                if (currentList.isNotEmpty()) {
                    val nextIndex = index.coerceAtMost(currentList.size - 1)
                    _currentIndex.value = nextIndex
                    val nextSong = currentList[nextIndex]
                    _currentSong.value = nextSong
                    exoPlayer.setMediaItem(mediaItemFor(nextSong))
                    exoPlayer.prepare()
                    exoPlayer.play()
                } else {
                    clearQueue()
                }
            } else if (index < _currentIndex.value) {
                _currentIndex.value = _currentIndex.value - 1
            }
        }
    }

    fun clearQueue() {
        _queue.value = emptyList()
        _currentSong.value = null
        exoPlayer.stop()
    }

    fun playPause() { if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play() }
    fun play() { exoPlayer.play() }
    fun pause() { exoPlayer.pause() }

    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs)
        _currentPosition.value = positionMs
    }

    fun playNextTrack() {
        val songs = _queue.value
        if (songs.isEmpty()) return
        if (_repeatMode.value == Player.REPEAT_MODE_ONE) {
            seekTo(0)
            play()
            return
        }
        val nextIndex = if (_isShuffle.value) songs.indices.random() else (_currentIndex.value + 1) % songs.size
        if (nextIndex == 0 && _repeatMode.value == Player.REPEAT_MODE_OFF) {
            exoPlayer.pause()
            seekTo(0)
            return
        }
        _currentIndex.value = nextIndex
        val song = songs[nextIndex]
        _currentSong.value = song
        _currentVideo.value = null
        exoPlayer.setMediaItem(mediaItemFor(song))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun playPreviousTrack() {
        val songs = _queue.value
        if (songs.isEmpty()) return
        if (exoPlayer.currentPosition > 3000L) {
            seekTo(0)
            return
        }
        val previousIndex = if (_currentIndex.value > 0) _currentIndex.value - 1 else songs.size - 1
        _currentIndex.value = previousIndex
        val song = songs[previousIndex]
        _currentSong.value = song
        _currentVideo.value = null
        exoPlayer.setMediaItem(mediaItemFor(song))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun toggleShuffle() { _isShuffle.value = !_isShuffle.value }

    fun cycleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
            else -> Player.REPEAT_MODE_ALL
        }
        exoPlayer.repeatMode = _repeatMode.value
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        exoPlayer.playbackParameters = PlaybackParameters(speed)
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _sleepTimerRemainingMinutes.value = minutes.coerceAtLeast(0)
        if (minutes <= 0) return
        sleepTimerJob = scope.launch {
            var remaining = minutes
            while (remaining > 0) {
                delay(60_000)
                remaining--
                _sleepTimerRemainingMinutes.value = remaining
            }
            pause()
        }
    }

    private fun releaseAudioEffects() {
        try {
            equalizer?.release()
            bassBoost?.release()
            virtualizer?.release()
            loudnessEnhancer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            equalizer = null
            bassBoost = null
            virtualizer = null
            loudnessEnhancer = null
        }
    }

    fun release() {
        sleepTimerJob?.cancel()
        scope.cancel()
        releaseAudioEffects()
        exoPlayer.release()
    }

    companion object {
        @Volatile
        private var INSTANCE: PlayerManager? = null

        fun getInstance(context: Context): PlayerManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PlayerManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}