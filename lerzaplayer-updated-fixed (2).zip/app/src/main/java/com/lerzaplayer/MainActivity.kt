package com.lerzaplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.app.PendingIntent
import android.app.RemoteAction
import android.os.Environment
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.FavoriteEntity
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.repository.DeletionResult
import com.lerzaplayer.data.repository.MediaRepository
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaPlayerTheme
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import com.lerzaplayer.data.language.AppLanguage
import com.lerzaplayer.data.language.LanguageManager
import com.lerzaplayer.data.language.LocalAppStrings
import com.lerzaplayer.ui.home.HomeScreen
import com.lerzaplayer.ui.player.FullPlayerScreen
import com.lerzaplayer.ui.player.VideoPlayerScreen
import com.lerzaplayer.ui.search.SearchScreen
import com.lerzaplayer.ui.settings.SettingsScreen
import com.lerzaplayer.ui.settings.ThemeScreen
import com.lerzaplayer.ui.vault.VaultScreen
import com.lerzaplayer.ui.update.UpdateDialog
import com.lerzaplayer.update.AppUpdateManager
import com.lerzaplayer.ads.AdManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

enum class AppDestination {
    HOME,
    SETTINGS,
    VAULT,
    SEARCH,
    THEME
}

@Composable
fun InstallPermissionDialog(
    onGrant: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.SystemUpdate,
                    contentDescription = null,
                    tint = Color(0xFFC084FC)
                )
                Text(
                    text = "Enable One-Tap Updates",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Text(
                text = "LerzaPlayer can update seamlessly with one tap. Please grant \"Install unknown apps\" permission so new updates can install automatically without extra clicks.",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 14.sp,
                lineHeight = 20.sp
            )
        },
        confirmButton = {
            Button(
                onClick = onGrant,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9333EA))
            ) {
                Text("Allow in Settings", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Later", color = Color.White.copy(alpha = 0.7f))
            }
        },
        containerColor = Color(0xFF1E1B2E),
        shape = RoundedCornerShape(20.dp)
    )
}

class MainActivity : ComponentActivity() {
    private lateinit var mediaRepository: MediaRepository
    private lateinit var playerManager: PlayerManager
    private var isVolumePopupVisible by mutableStateOf(false)
    private var currentVolumePercent by mutableIntStateOf(100)
    private var volumeDismissJob: Job? = null
    private var pendingDeleteEntity: RecentlyDeletedEntity? = null
    private var activePlayingVideo by mutableStateOf<VideoItem?>(null)
    private var pendingMediaKey by mutableStateOf<String?>(null)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (::mediaRepository.isInitialized) mediaRepository.refreshMedia()
        LerzaApp.instance.startMediaDownloadMonitoring()
    }

    private val scopedStorageDeleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            pendingDeleteEntity?.let { entity ->
                lifecycleScope.launch {
                    mediaRepository.confirmPendingDeletion(entity)
                    Toast.makeText(this@MainActivity, "Moved to Recently Deleted (30 days)", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            pendingDeleteEntity?.let { entity ->
                lifecycleScope.launch {
                    mediaRepository.cancelPendingDeletion(entity)
                }
            }
        }
        pendingDeleteEntity = null
    }

    // 🌟 ایپ انسٹال کرنے والی پرمیشن لانچر (Request Install Packages Launcher)
    private val installPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        // Returned from install unknown app sources setting
    }

    
    private fun buildMainPipParams(isPlaying: Boolean): android.app.PictureInPictureParams? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return null
        return runCatching {
            val actions = ArrayList<android.app.RemoteAction>()

            val prevIntent = Intent("com.lerzaplayer.PIP_PREV").apply { setPackage(packageName) }
            val prevPending = android.app.PendingIntent.getBroadcast(
                this, 101, prevIntent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val prevIcon = android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_previous)
            actions.add(android.app.RemoteAction(prevIcon, "Previous", "Previous", prevPending))

            val playPauseIntent = Intent("com.lerzaplayer.PIP_PLAY_PAUSE").apply { setPackage(packageName) }
            val playPausePending = android.app.PendingIntent.getBroadcast(
                this, 102, playPauseIntent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val playPauseIcon = android.graphics.drawable.Icon.createWithResource(
                this,
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            actions.add(android.app.RemoteAction(playPauseIcon, if (isPlaying) "Pause" else "Play", if (isPlaying) "Pause" else "Play", playPausePending))

            val nextIntent = Intent("com.lerzaplayer.PIP_NEXT").apply { setPackage(packageName) }
            val nextPending = android.app.PendingIntent.getBroadcast(
                this, 103, nextIntent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val nextIcon = android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_next)
            actions.add(android.app.RemoteAction(nextIcon, "Next", "Next", nextPending))

            android.app.PictureInPictureParams.Builder()
                .setAspectRatio(android.util.Rational(16, 9))
                .setActions(actions)
                .build()
        }.getOrNull()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (activePlayingVideo != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = buildMainPipParams(true)
                if (params != null) {
                    enterPictureInPictureMode(params)
                } else {
                    enterPictureInPictureMode(
                        android.app.PictureInPictureParams.Builder()
                            .setAspectRatio(android.util.Rational(16, 9))
                            .build()
                    )
                }
            } catch (_: Exception) {}
        }
    }

    
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleMediaIntent(intent)
    }

    private fun handleMediaIntent(intent: Intent?) {
        val key = intent?.getStringExtra("play_media_key") ?: return
        pendingMediaKey = key
        if (::mediaRepository.isInitialized) {
            mediaRepository.refreshMedia()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ThemeManager.init(this)

        val app = application as LerzaApp
        val prefManager = app.preferenceManager

        // Sync Language preference
        lifecycleScope.launch {
            prefManager.appLanguageFlow.collect { langCode ->
                LanguageManager.setLanguage(AppLanguage.fromCode(langCode))
            }
        }

        mediaRepository = MediaRepository(this)
        playerManager = app.playerManager
        playerManager.syncVolumeFromSystem()
        currentVolumePercent = playerManager.loudnessGain.value

                // تمام مطلوبہ پرمیشنز طلب کریں
        requestRequiredPermissions()
        handleMediaIntent(intent)

        // 🌟 اگر کوئی پرمیشن مس ہو جائے تو 1 منٹ بعد دوبارہ درخواست کریں
        lifecycleScope.launch {
            delay(60_000)
            val isAudioDenied = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED
            } else {
                checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            }
            if (isAudioDenied) {
                requestRequiredPermissions()
        handleMediaIntent(intent)
            }
        }

        // 🌟 ایپ سٹارٹ ہوتے ہی بیک گراؤنڈ میں ویب سائٹ سے لائیو اپڈیٹ چیک کریں
        lifecycleScope.launch {
            try {
                AppUpdateManager.checkForUpdates(this@MainActivity)
            } catch (_: Exception) {}
        }

        setContent {
            val prefManager = app.preferenceManager

            // 🌟 چیک کریں کہ آیا پہلی بار کا پرمیشن پرامپٹ دکھایا گیا ہے یا نہیں
            val installPermissionPrompted by prefManager.installPermissionPromptedFlow.collectAsState(initial = true)
            var showInstallPermissionDialog by remember { mutableStateOf(false) }

            LaunchedEffect(installPermissionPrompted) {
                if (!installPermissionPrompted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if (!packageManager.canRequestPackageInstalls()) {
                        delay(1200) // 1.2 سیکنڈ بعد تاکہ ہوم سکرین سیٹ ہو جائے
                        showInstallPermissionDialog = true
                    }
                }
            }

            val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
            val scope = rememberCoroutineScope()
            val songs by mediaRepository.getSongsFlow(songSort).collectAsState(initial = emptyList())
            val videos by mediaRepository.getVideosFlow(SortOption.DATE_ADDED_DESC).collectAsState(initial = emptyList())
            val recentlyDeleted by mediaRepository.getRecentlyDeletedFlow().collectAsState(initial = emptyList())
            val activeLoudnessGain by playerManager.loudnessGain.collectAsState()

            LaunchedEffect(activeLoudnessGain) {
                currentVolumePercent = activeLoudnessGain
            }

            var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
            var isFullPlayerVisible by remember { mutableStateOf(false) }
            // activePlayingVideo managed at Activity level
            var songToDeleteConfirm by remember { mutableStateOf<SongItem?>(null) }
            var videoToDeleteConfirm by remember { mutableStateOf<VideoItem?>(null) }

            BackHandler(enabled = activePlayingVideo != null) {
                activePlayingVideo = null
            }
            BackHandler(enabled = activePlayingVideo == null && isFullPlayerVisible) {
                isFullPlayerVisible = false
            }
            BackHandler(enabled = activePlayingVideo == null && !isFullPlayerVisible && currentDestination != AppDestination.HOME) {
                currentDestination = if (currentDestination == AppDestination.THEME) AppDestination.SETTINGS else AppDestination.HOME
            }

            val currentLang by LanguageManager.currentLanguage.collectAsState()
            val appStrings = remember(currentLang) { LanguageManager.getStringsFor(currentLang) }

            // Handle incoming notification click to auto-play new audio/video
            LaunchedEffect(pendingMediaKey, songs, videos) {
                val key = pendingMediaKey ?: return@LaunchedEffect
                val isVideo = key.startsWith("video:")
                val targetId = key.substringAfter(":").toLongOrNull() ?: return@LaunchedEffect
                if (isVideo) {
                    val targetVideo = videos.firstOrNull { it.id == targetId }
                    if (targetVideo != null) {
                        activePlayingVideo = targetVideo
                        pendingMediaKey = null
                    }
                } else {
                    val targetSong = songs.firstOrNull { it.id == targetId }
                    if (targetSong != null) {
                        val index = songs.indexOfFirst { it.id == targetSong.id }.let { if (it >= 0) it else 0 }
                        playerManager.playSongList(songs, index)
                        isFullPlayerVisible = true
                        pendingMediaKey = null
                    }
                }
            }

            CompositionLocalProvider(LocalAppStrings provides appStrings) {
                LerzaPlayerTheme(themeColor = ThemeManager.currentThemeColor) {
                val themeColors = LocalLerzaColors.current
                SideEffect {
                    window.statusBarColor = themeColors.surface.toArgb()
                    window.navigationBarColor = themeColors.background.toArgb()
                    WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !themeColors.isDark
                    WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !themeColors.isDark
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    when (currentDestination) {
                        AppDestination.HOME -> {
                            HomeScreen(
                                songs = songs,
                                videos = videos,
                                playerManager = playerManager,
                                prefManager = prefManager,
                                onSearchClick = { currentDestination = AppDestination.SEARCH },
                                onSettingsClick = { AdManager.showSettingsInterstitial(this@MainActivity) { currentDestination = AppDestination.SETTINGS } },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                onExpandFullPlayer = { isFullPlayerVisible = true },
                                onPlayVideo = { video ->
                                    playerManager.pause()
                                    activePlayingVideo = video
                                },
                                onToggleFavoriteSong = { song ->
                                    val newFav = !song.isFavorite
                                    playerManager.updateFavoriteStatus(song.id, newFav)
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (!newFav) {
                                            favDao.removeFavorite(song.id, "AUDIO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                        }
                                    }
                                },
                                onToggleFavoriteVideo = { video ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (video.isFavorite) {
                                            favDao.removeFavorite(video.id, "VIDEO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(video.id, "VIDEO"))
                                        }
                                    }
                                },
                                onHideSongInVault = { song ->
                                    scope.launch {
                                        app.vaultManager.hideSong(song)
                                        mediaRepository.refreshMedia()
                                    }
                                },
                                onHideVideoInVault = { video ->
                                    scope.launch {
                                        app.vaultManager.hideVideo(video)
                                        mediaRepository.refreshMedia()
                                    }
                                },
                                onDeleteSong = { song ->
                                    songToDeleteConfirm = song
                                },
                                onDeleteVideo = { video ->
                                    videoToDeleteConfirm = video
                                },
                                onScanDevice = {
                                    mediaRepository.refreshMedia()
                                }
                            )
                        }
                        AppDestination.SETTINGS -> {
                            SettingsScreen(
                                prefManager = prefManager,
                                onBack = { currentDestination = AppDestination.HOME },
                                onOpenEqualizer = { isFullPlayerVisible = true },
                                onScanMedia = { mediaRepository.refreshMedia() },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                recentlyDeleted = recentlyDeleted,
                                onPlayRecentlyDeleted = { item ->
                                    val backupFile = File(item.backupPath)
                                    if (backupFile.exists()) {
                                        val playableUri = Uri.fromFile(backupFile)
                                        playerManager.playSong(
                                            SongItem(
                                                id = item.id,
                                                title = item.originalName,
                                                artist = "Recently Deleted (30 Days)",
                                                album = "Trash",
                                                duration = item.duration,
                                                contentUri = playableUri,
                                                size = item.size,
                                                path = backupFile.absolutePath,
                                                mimeType = if (item.mediaType == "AUDIO") "audio/*" else "video/*"
                                            )
                                        )
                                        isFullPlayerVisible = true
                                    } else {
                                        Toast.makeText(this@MainActivity, "File expired or removed", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onRestoreRecentlyDeleted = { item ->
                                    scope.launch {
                                        mediaRepository.restoreRecentlyDeleted(item)
                                        Toast.makeText(this@MainActivity, "Restored back to phone storage!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onPermanentlyDeleteRecentlyDeleted = { item ->
                                    scope.launch {
                                        mediaRepository.permanentlyDeleteRecentlyDeleted(item)
                                        Toast.makeText(this@MainActivity, "Permanently deleted", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }
                        AppDestination.THEME -> {
                            ThemeScreen(
                                prefManager = prefManager,
                                onBack = { currentDestination = AppDestination.SETTINGS }
                            )
                        }
                        AppDestination.VAULT -> {
                            VaultScreen(
                                vaultManager = app.vaultManager,
                                onBack = {
                                    playerManager.clearQueue()
                                    isFullPlayerVisible = false
                                    currentDestination = AppDestination.HOME
                                },
                                onPlayMedia = { entity ->
                                    scope.launch {
                                        val playableFile = app.vaultManager.createPlaybackCopy(entity)
                                        if (playableFile != null && playableFile.exists() && playableFile.length() > 0L) {
                                            val playableUri = Uri.fromFile(playableFile)
                                            val playableId = kotlin.math.abs(entity.originalPath.hashCode()).toLong()
                                            if (entity.mediaType == "AUDIO") {
                                                playerManager.playSong(
                                                    SongItem(
                                                        id = playableId,
                                                        title = entity.originalName,
                                                        artist = "Private Vault",
                                                        album = "Private Vault",
                                                        duration = entity.duration,
                                                        contentUri = playableUri,
                                                        size = playableFile.length(),
                                                        path = playableFile.absolutePath,
                                                        mimeType = "audio/*"
                                                    )
                                                )
                                                isFullPlayerVisible = true
                                            } else {
                                                activePlayingVideo = VideoItem(
                                                    id = playableId,
                                                    title = entity.originalName,
                                                    duration = entity.duration,
                                                    contentUri = playableUri,
                                                    size = playableFile.length(),
                                                    path = playableFile.absolutePath,
                                                    folderName = "Private Vault"
                                                )
                                            }
                                        } else {
                                            Toast.makeText(this@MainActivity, "Preparing file for playback failed", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            )
                        }
                        AppDestination.SEARCH -> {
                            val currentSong by playerManager.currentSong.collectAsState()
                            val isPlaying by playerManager.isPlaying.collectAsState()
                            SearchScreen(
                                songs = songs,
                                videos = videos,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                onSongClick = { song ->
                                    val index = songs.indexOfFirst { it.id == song.id }
                                    if (index != -1) {
                                        playerManager.playSongList(songs, index)
                                    } else {
                                        playerManager.playSong(song)
                                    }
                                    isFullPlayerVisible = true
                                },
                                onVideoClick = { video ->
                                    playerManager.pause()
                                    activePlayingVideo = video
                                },
                                onBack = { currentDestination = AppDestination.HOME },
                                onToggleFavoriteSong = { song ->
                                    val newFav = !song.isFavorite
                                    playerManager.updateFavoriteStatus(song.id, newFav)
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (!newFav) {
                                            favDao.removeFavorite(song.id, "AUDIO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                        }
                                    }
                                },
                                onAddToQueue = { song -> playerManager.addToQueue(song) }
                            )
                        }
                    }

                    // Delete Song Confirmation Dialog
                    songToDeleteConfirm?.let { song ->
                        AlertDialog(
                            onDismissRequest = { songToDeleteConfirm = null },
                            title = { Text("Delete song?", fontWeight = FontWeight.Bold) },
                            text = {
                                Text("\"${song.title}\" will be removed from your device and moved to Recently Deleted in Settings for 30 days.")
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        val targetSong = song
                                        songToDeleteConfirm = null
                                        if (playerManager.currentSong.value?.id == targetSong.id) {
                                            playerManager.pause()
                                            playerManager.clearQueue()
                                        }
                                        scope.launch {
                                            when (val result = mediaRepository.deleteMedia(targetSong)) {
                                                is DeletionResult.Success -> {
                                                    Toast.makeText(this@MainActivity, "Deleted & moved to 30-day Trash", Toast.LENGTH_SHORT).show()
                                                }
                                                is DeletionResult.RequiresConsent -> {
                                                    pendingDeleteEntity = result.pendingItem
                                                    scopedStorageDeleteLauncher.launch(
                                                        IntentSenderRequest.Builder(result.intentSender).build()
                                                    )
                                                }
                                                is DeletionResult.Failure -> {
                                                    Toast.makeText(this@MainActivity, result.error, Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF334B))
                                ) {
                                    Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { songToDeleteConfirm = null }) {
                                    Text("Cancel")
                                }
                            }
                        )
                    }

                    // Delete Video Confirmation Dialog
                    videoToDeleteConfirm?.let { video ->
                        AlertDialog(
                            onDismissRequest = { videoToDeleteConfirm = null },
                            title = { Text("Delete video?", fontWeight = FontWeight.Bold) },
                            text = {
                                Text("\"${video.title}\" will be deleted from your device and moved to Recently Deleted for 30 days.")
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        val targetVideo = video
                                        videoToDeleteConfirm = null
                                        scope.launch {
                                            when (val result = mediaRepository.deleteMedia(targetVideo)) {
                                                is DeletionResult.Success -> {
                                                    Toast.makeText(this@MainActivity, "Deleted & moved to 30-day Trash", Toast.LENGTH_SHORT).show()
                                                }
                                                is DeletionResult.RequiresConsent -> {
                                                    pendingDeleteEntity = result.pendingItem
                                                    scopedStorageDeleteLauncher.launch(
                                                        IntentSenderRequest.Builder(result.intentSender).build()
                                                    )
                                                }
                                                is DeletionResult.Failure -> {
                                                    Toast.makeText(this@MainActivity, result.error, Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF334B))
                                ) {
                                    Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { videoToDeleteConfirm = null }) {
                                    Text("Cancel")
                                }
                            }
                        )
                    }

                    // Full Player Overlay
                    AnimatedVisibility(
                        visible = isFullPlayerVisible,
                        enter = slideInVertically(
                            initialOffsetY = { it },
                            animationSpec = androidx.compose.animation.core.tween(
                                durationMillis = 280,
                                easing = androidx.compose.animation.core.FastOutSlowInEasing
                            )
                        ),
                        exit = androidx.compose.animation.ExitTransition.None
                    ) {
                        FullPlayerScreen(
                            playerManager = playerManager,
                            onCollapse = { isFullPlayerVisible = false },
                            onFavoriteToggle = { song ->
                                val newFav = !song.isFavorite
                                playerManager.updateFavoriteStatus(song.id, newFav)
                                scope.launch {
                                    val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                    if (!newFav) {
                                        favDao.removeFavorite(song.id, "AUDIO")
                                    } else {
                                        favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                    }
                                }
                            }
                        )
                    }

                    // Video Player Overlay
                    activePlayingVideo?.let { vid ->
                        VideoPlayerScreen(
                            video = vid,
                            isInPipMode = isInPipModeState.value,
                            onClose = { activePlayingVideo = null },
                            onPreviousVideo = {
                                val currentVidId = activePlayingVideo?.id ?: vid.id
                                val index = videos.indexOfFirst { it.id == currentVidId }
                                if (videos.isNotEmpty()) {
                                    val prevIndex = if (index > 0) index - 1 else videos.lastIndex
                                    activePlayingVideo = videos[prevIndex]
                                }
                            },
                            onNextVideo = {
                                val currentVidId = activePlayingVideo?.id ?: vid.id
                                val index = videos.indexOfFirst { it.id == currentVidId }
                                if (videos.isNotEmpty()) {
                                    val nextIndex = if (index >= 0 && index < videos.lastIndex) index + 1 else 0
                                    activePlayingVideo = videos[nextIndex]
                                }
                            },
                            onPlayAsAudio = {
                                val currentVidId = activePlayingVideo?.id ?: vid.id
                                val videoAudioQueue = videos.map { v ->
                                    SongItem(
                                        id = v.id,
                                        title = v.title,
                                        artist = if (v.folderName.isNotEmpty()) v.folderName else "Video Audio",
                                        album = if (v.folderName.isNotEmpty()) v.folderName else "Videos",
                                        duration = v.duration,
                                        contentUri = v.contentUri,
                                        albumArtUri = null,
                                        size = v.size,
                                        path = v.path,
                                        mimeType = "video/*"
                                    )
                                }
                                val currentIndex = videos.indexOfFirst { it.id == currentVidId }.coerceAtLeast(0)
                                activePlayingVideo = null
                                isFullPlayerVisible = true
                                playerManager.playSongList(videoAudioQueue, currentIndex)
                            },
                            onDeleteVideo = {
                                videoToDeleteConfirm = vid
                            }
                        )
                    }

                    // Global Volume Popup
                    AnimatedVisibility(
                        visible = isVolumePopupVisible,
                        enter = fadeIn() + slideInVertically(initialOffsetY = { -50 }),
                        exit = fadeOut() + slideOutVertically(targetOffsetY = { -50 }),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 48.dp)
                    ) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.85f)),
                            modifier = Modifier
                                .padding(horizontal = 24.dp)
                                .fillMaxWidth(0.85f)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Volume Boost: $currentVolumePercent%",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Slider(
                                    value = currentVolumePercent.toFloat(),
                                    onValueChange = { newValue ->
                                        currentVolumePercent = newValue.toInt()
                                        playerManager.setLoudnessGain(currentVolumePercent)
                                        triggerVolumePopup()
                                    },
                                    valueRange = 1f..300f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = themeColors.primary,
                                        activeTrackColor = themeColors.primary
                                    )
                                )
                            }
                        }
                    }

                    // 🌟 IN-APP OTA UPDATE DIALOG POPUP (Without Chrome!)
                    val activeUpdate by AppUpdateManager.availableUpdate.collectAsState()
                    activeUpdate?.let { updateInfo ->
                        UpdateDialog(
                            updateInfo = updateInfo,
                            onDismiss = { AppUpdateManager.dismissUpdate() }
                        )
                    }

                    // 🌟 FIRST LAUNCH PACKAGE INSTALLER PERMISSION PROMPT
                    if (showInstallPermissionDialog) {
                        InstallPermissionDialog(
                            onGrant = {
                                showInstallPermissionDialog = false
                                lifecycleScope.launch { prefManager.setInstallPermissionPrompted(true) }
                                AppUpdateManager.requestInstallPermission(this@MainActivity)
                            },
                            onDismiss = {
                                showInstallPermissionDialog = false
                                lifecycleScope.launch { prefManager.setInstallPermissionPrompted(true) }
                            }
                        )
                }
            }
        }
    }
}

    }

    override fun onResume() {
        super.onResume()
        if (::playerManager.isInitialized) {
            playerManager.syncVolumeFromSystem()
            currentVolumePercent = playerManager.loudnessGain.value
        }
    }

    private fun triggerVolumePopup() {
        isVolumePopupVisible = true
        volumeDismissJob?.cancel()
        volumeDismissJob = lifecycleScope.launch {
            delay(1500)
            isVolumePopupVisible = false
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                playerManager.syncVolumeFromSystem()
                val targetVol = (playerManager.loudnessGain.value + 10).coerceAtMost(300)
                currentVolumePercent = targetVol
                playerManager.setLoudnessGain(targetVol)
                triggerVolumePopup()
                return true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                playerManager.syncVolumeFromSystem()
                val targetVol = (playerManager.loudnessGain.value - 10).coerceAtLeast(1)
                currentVolumePercent = targetVol
                playerManager.setLoudnessGain(targetVol)
                triggerVolumePopup()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private val isInPipModeState = mutableStateOf(false)

    @Deprecated("Deprecated in Java")
    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipModeState.value = isInPictureInPictureMode
    }

    private fun requestRequiredPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        startActivity(intent)
                    } catch (_: Exception) {}
                }
            }
        }

        // 🌟 نوٹ: نامعلوم سورسز سے انسٹالیشن کی پرمیشن اب ایک خوبصورت Compose ڈائیلاگ
        // (InstallPermissionDialog) کے ذریعے مانگی جاتی ہے تاکہ میڈیا پرمیشنز کے ساتھ ٹکراؤ نہ ہو
}
}
