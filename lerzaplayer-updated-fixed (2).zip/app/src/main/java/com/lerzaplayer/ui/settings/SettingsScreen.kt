package com.lerzaplayer.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.data.language.AppLanguage
import com.lerzaplayer.data.language.LanguageManager
import com.lerzaplayer.playback.PlaytimeTracker
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import com.lerzaplayer.ui.player.EqualizerSheet
import com.lerzaplayer.update.AppUpdateManager
import kotlinx.coroutines.launch
import java.io.File

data class AboutFeatureItem(
    val icon: ImageVector,
    val title: String,
    val description: String,
    val tag: String
)

val LERZA_FEATURES = listOf(
    AboutFeatureItem(
        Icons.Default.GraphicEq,
        "10-Band Pro Equalizer & Bass",
        "Fine-tune 10 discrete frequency bands (31Hz - 16kHz) with dedicated Bass Booster, Vocal Enhancer, and custom presets.",
        "Audio"
    ),
    AboutFeatureItem(
        Icons.Default.VolumeUp,
        "300% Volume Boost (5X Gain)",
        "Ultra-high hardware amplification up to 300% with real-time loudness processing and zero clipping distortion.",
        "Boost"
    ),
    AboutFeatureItem(
        Icons.Default.PictureInPicture,
        "Floating Window (PiP) Player",
        "Multi-task smoothly with floating video window featuring responsive Previous, Play/Pause, and Next buttons.",
        "PiP"
    ),
    AboutFeatureItem(
        Icons.Default.Headphones,
        "Seamless Video-to-Audio Mode",
        "Switch any video to background audio playback with continuous auto-advance across your entire video queue.",
        "Playback"
    ),
    AboutFeatureItem(
        Icons.Default.VisibilityOff,
        "Secure Private Vault",
        "Hide and encrypt your personal audio and video files inside an encrypted vault locked with PIN code or biometric pattern.",
        "Privacy"
    ),
    AboutFeatureItem(
        Icons.Default.Tune,
        "Sound Quality & 3D Spatial Virtualizer",
        "24-Bit/192kHz Hi-Res studio master output, 3D Spatial surround virtualizer, gapless playback, and auto-pause on headphone disconnect.",
        "Engine"
    ),
    AboutFeatureItem(
        Icons.Default.Language,
        "Multi-Language System",
        "Native support for English, Urdu (اردو), and Hindi (हिन्दी) for an intuitive local experience.",
        "Languages"
    ),
    AboutFeatureItem(
        Icons.Default.Alarm,
        "Live Playtime & Sleep Timer",
        "Real-time live music and video listening analytics with smart bedtime auto-stop timer.",
        "Analytics"
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    onOpenEqualizer: () -> Unit = {},
    onScanMedia: () -> Unit = {},
    onOpenVault: () -> Unit = {},
    recentlyDeleted: List<RecentlyDeletedEntity> = emptyList(),
    onPlayRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onRestoreRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onPermanentlyDeleteRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current
    val activeColor = ThemeManager.currentThemeColor

    val sleepMinutes by (context.applicationContext as? com.lerzaplayer.LerzaApp)?.playerManager?.sleepTimerRemainingMinutes?.collectAsState() ?: remember { mutableIntStateOf(0) }
    val playerManager = (context.applicationContext as? com.lerzaplayer.LerzaApp)?.playerManager ?: remember { PlayerManager.getInstance(context) }

    LaunchedEffect(Unit) {
        PlaytimeTracker.init(context)
    }
    val musicPlaytimeMs by PlaytimeTracker.musicPlaytimeMs.collectAsState()
    val videoPlaytimeMs by PlaytimeTracker.videoPlaytimeMs.collectAsState()
    val livePlaytime = remember(musicPlaytimeMs, videoPlaytimeMs) {
        PlaytimeTracker.formatLarkTime(musicPlaytimeMs + videoPlaytimeMs)
    }

    val currentLangCode by prefManager.appLanguageFlow.collectAsState(initial = "en")
    val activeLang = remember(currentLangCode) { AppLanguage.fromCode(currentLangCode) }
    val appStrings = remember(activeLang) { LanguageManager.getStringsFor(activeLang) }

    var currentSubScreen by remember { mutableStateOf<String?>(null) }
    var showSleepTimerSheet by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }

    BackHandler(enabled = currentSubScreen != null || showEqualizerSheet) {
        if (showEqualizerSheet) {
            showEqualizerSheet = false
        } else {
            currentSubScreen = null
        }
    }

    // Direct 10-Band Equalizer Sheet
    if (showEqualizerSheet) {
        EqualizerSheet(
            playerManager = playerManager,
            onDismiss = { showEqualizerSheet = false }
        )
    }

    if (currentSubScreen == "playtime") {
        PlaytimeScreen(
            onBack = { currentSubScreen = null }
        )
        return
    }

    if (currentSubScreen == "theme") {
        ThemeScreen(
            prefManager = prefManager,
            onBack = { currentSubScreen = null }
        )
        return
    }

        // Replacement Option for Scan Media: Sound Quality & Audio Effects
    if (currentSubScreen == "audio_effects") {
        val hiResAudio by prefManager.hiResAudioFlow.collectAsState(initial = true)
        val spatialSurround by prefManager.spatialSurroundFlow.collectAsState(initial = true)
        val gaplessPlayback by prefManager.gaplessPlaybackFlow.collectAsState(initial = true)
        val autoPauseHeadphones by prefManager.autoPauseHeadphonesFlow.collectAsState(initial = true)
        val crossfadeSeconds by prefManager.crossfadeSecondsFlow.collectAsState(initial = 3.0f)
        val vocalBoostLevel by prefManager.vocalBoostFlow.collectAsState(initial = 0)

        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = appStrings.soundQualityTitle,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { pad ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = colors.card,
                        border = BorderStroke(1.dp, activeColor.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(activeColor.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Tune, contentDescription = null, tint = activeColor, modifier = Modifier.size(22.dp))
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(appStrings.hiResTitle, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
                                    Text(appStrings.hiResDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                                }
                                Switch(
                                    checked = hiResAudio,
                                    onCheckedChange = {
                                        scope.launch {
                                            prefManager.setHiResAudio(it)
                                            playerManager.setHiResAudio(it)
                                        }
                                    },
                                    colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                                )
                            }
                        }
                    }
                }

                item {
                    SettingsGroupCard {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(appStrings.spatialSurroundTitle, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
                                Text(appStrings.spatialSurroundDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                            }
                            Switch(
                                checked = spatialSurround,
                                onCheckedChange = {
                                    scope.launch {
                                        prefManager.setSpatialSurround(it)
                                        playerManager.setSpatialSurround(it)
                                    }
                                },
                                colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                            )
                        }
                        SettingsDivider()
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(appStrings.gaplessTitle, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
                                Text(appStrings.gaplessDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                            }
                            Switch(
                                checked = gaplessPlayback,
                                onCheckedChange = {
                                    scope.launch {
                                        prefManager.setGaplessPlayback(it)
                                        playerManager.setGaplessPlayback(it)
                                    }
                                },
                                colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                            )
                        }
                        SettingsDivider()
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(appStrings.autoPauseTitle, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
                                Text(appStrings.autoPauseDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                            }
                            Switch(
                                checked = autoPauseHeadphones,
                                onCheckedChange = {
                                    scope.launch {
                                        prefManager.setAutoPauseHeadphones(it)
                                        playerManager.setAutoPauseHeadphones(it)
                                    }
                                },
                                colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                            )
                        }
                    }
                }

                // Vocal Booster Card
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = colors.card,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(appStrings.vocalBoosterTitle, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
                                Text("${(vocalBoostLevel / 10)}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = activeColor)
                            }
                            Text(appStrings.vocalBoosterDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                            Slider(
                                value = vocalBoostLevel.toFloat(),
                                onValueChange = {
                                    val safe = it.toInt()
                                    scope.launch {
                                        prefManager.setVocalBoost(safe)
                                        playerManager.setVocalBoost(safe)
                                    }
                                },
                                valueRange = 0f..1000f,
                                colors = SliderDefaults.colors(thumbColor = activeColor, activeTrackColor = activeColor)
                            )
                        }
                    }
                }

                // Crossfade Card
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = colors.card,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(appStrings.crossfadeTitle, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
                                Text("${crossfadeSeconds.toInt()}s", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = activeColor)
                            }
                            Text(appStrings.crossfadeDesc, fontSize = 11.5.sp, color = colors.textSecondary)
                            Slider(
                                value = crossfadeSeconds,
                                onValueChange = {
                                    scope.launch {
                                        prefManager.setCrossfadeSeconds(it)
                                        playerManager.setCrossfadeSeconds(it)
                                    }
                                },
                                valueRange = 0f..10f,
                                steps = 9,
                                colors = SliderDefaults.colors(thumbColor = activeColor, activeTrackColor = activeColor)
                            )
                        }
                    }
                }
            }
        }
        return
    }

    // Language Selection Subscreen (English, Urdu, Hindi)
    if (currentSubScreen == "language") {
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "App Language • زبان • भाषा",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { pad ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = colors.card,
                        border = BorderStroke(1.dp, activeColor.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "Select App Language",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Choose between English, Urdu, or Hindi for the app interface",
                                fontSize = 12.sp,
                                color = colors.textSecondary
                            )
                        }
                    }
                }

                item {
                    SettingsGroupCard {
                        AppLanguage.entries.forEachIndexed { index, lang ->
                            val isSelected = activeLang == lang
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        scope.launch {
                                            prefManager.setAppLanguage(lang.code)
                                            LanguageManager.setLanguage(lang)
                                            Toast.makeText(context, "${lang.displayName} selected", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                    .padding(horizontal = 16.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = lang.nativeName,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) activeColor else colors.textPrimary
                                    )
                                    Text(
                                        text = lang.displayName,
                                        fontSize = 12.sp,
                                        color = colors.textSecondary
                                    )
                                }
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(activeColor),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                            if (index < AppLanguage.entries.size - 1) {
                                SettingsDivider()
                            }
                        }
                    }
                }
            }
        }
        return
    }

    // Backup & Restore Screen (Coming Soon, Wait for Update)
    if (currentSubScreen == "backup_restore") {
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Backup & Restore",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = colors.card,
                    border = BorderStroke(1.dp, activeColor.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(activeColor.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = null,
                                tint = activeColor,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Text(
                            text = "Coming Soon",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = colors.textPrimary
                        )

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = activeColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "ویٹ فار اپ ڈیٹ • Wait for Update",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = activeColor,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }

                        Text(
                            text = "Cloud backup and restore is currently in progress. Please wait for the upcoming app update to synchronize your songs, playlists, and settings.",
                            fontSize = 13.sp,
                            color = colors.textSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 19.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = { currentSubScreen = null },
                            colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(46.dp)
                        ) {
                            Text("OK / Back", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
        return
    }

    // Gorgeous About Screen: Version 1.0.5, Features Frames, Developer Faraz Munawar at bottom
    if (currentSubScreen == "about") {
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = appStrings.aboutTitle,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header with App Branding and Version 1.0.0
                item {
                    Surface(
                        shape = RoundedCornerShape(26.dp),
                        color = colors.card,
                        border = BorderStroke(1.5.dp, activeColor.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(modifier = Modifier.fillMaxWidth()) {
                            Box(
                                modifier = Modifier
                                    .size(160.dp)
                                    .align(Alignment.TopEnd)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(activeColor.copy(alpha = 0.25f), Color.Transparent)
                                        )
                                    )
                            )

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(76.dp)
                                        .clip(RoundedCornerShape(22.dp))
                                        .background(
                                            Brush.linearGradient(
                                                listOf(activeColor, activeColor.copy(alpha = 0.7f))
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MusicNote,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(42.dp)
                                    )
                                }

                                Text(
                                    text = "LerzaPlayer Pro",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = colors.textPrimary
                                )

                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = activeColor.copy(alpha = 0.16f),
                                    border = BorderStroke(1.dp, activeColor.copy(alpha = 0.4f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(activeColor)
                                        )
                                        Text(
                                            text = "Version 1.0.5 (2026 Official Edition)",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = activeColor
                                        )
                                    }
                                }

                                Text(
                                    text = "Next-Generation Lossless Music & Video Player Engineered for Audiophiles",
                                    fontSize = 12.5.sp,
                                    color = colors.textSecondary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }

                // Features Header
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PREMIUM FEATURES",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = colors.textSecondary,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${LERZA_FEATURES.size} Built-in Tools",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeColor
                        )
                    }
                }

                // Beautiful Frames for Each Feature
                items(LERZA_FEATURES.size) { index ->
                    val feature = LERZA_FEATURES[index]
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = colors.card,
                        border = BorderStroke(0.9.dp, colors.divider.copy(alpha = 0.8f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(activeColor.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = feature.icon,
                                    contentDescription = null,
                                    tint = activeColor,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = feature.title,
                                        fontSize = 14.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.textPrimary
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = activeColor.copy(alpha = 0.12f)
                                    ) {
                                        Text(
                                            text = feature.tag,
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = activeColor,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = feature.description,
                                    fontSize = 11.5.sp,
                                    color = colors.textSecondary,
                                    lineHeight = 16.5.sp
                                )
                            }
                        }
                    }
                }

                                // DEVELOPER & ABOUT FOOTER - ELEGANT AND MINIMALIST
                item {
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = colors.card,
                        border = BorderStroke(1.dp, activeColor.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Crafted with passion by Faraz",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "ڈیزائن اور ڈیولپمنٹ بذریعہ فراز",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = activeColor
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "© 2026 Lerza Player Pro • All Rights Reserved",
                                fontSize = 11.sp,
                                color = colors.textSecondary.copy(alpha = 0.8f)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }
        return
    }

    if (currentSubScreen == "recently_deleted") {
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Recently deleted (${recentlyDeleted.size})",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { pad ->
            if (recentlyDeleted.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(pad),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Trash is empty. Deleted items remain here for 30 days.", color = colors.textSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(pad)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(recentlyDeleted.size) { idx ->
                        val item = recentlyDeleted[idx]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(colors.card)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { onPlayRecentlyDeleted(item) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(activeColor.copy(alpha = 0.2f))
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = activeColor)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.originalName, color = colors.textPrimary, fontSize = 13.sp, maxLines = 1)
                                Text("Auto-deletes in 30 days", color = colors.accent, fontSize = 10.sp)
                            }
                            Button(
                                onClick = { onRestoreRecentlyDeleted(item) },
                                colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Restore", fontSize = 11.sp, color = colors.onPrimary)
                            }
                            IconButton(onClick = { onPermanentlyDeleteRecentlyDeleted(item) }) {
                                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color(0xFFFF5252))
                            }
                        }
                    }
                }
            }
        }
        return
    }

    if (currentSubScreen == "notification") {
        var newMediaNotif by remember { mutableStateOf(true) }
        var pushNotif by remember { mutableStateOf(true) }
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Notification settings",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { pad ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                SettingsGroupCard {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("New Songs Added Notification", fontSize = 15.sp, color = colors.textPrimary)
                            Text("Alert when new media is detected on storage", fontSize = 12.sp, color = colors.textSecondary)
                        }
                        Switch(
                            checked = newMediaNotif,
                            onCheckedChange = { newMediaNotif = it },
                            colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                        )
                    }
                    SettingsDivider()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Media Player Timeline Notification", fontSize = 15.sp, color = colors.textPrimary)
                            Text("Interactive seekbar, Prev, Play, Next buttons in shade", fontSize = 12.sp, color = colors.textSecondary)
                        }
                        Switch(
                            checked = pushNotif,
                            onCheckedChange = { pushNotif = it },
                            colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                        )
                    }
                }
            }
        }
        return
    }

    // Main Settings Screen
    Scaffold(
        topBar = {
            Surface(
                color = colors.surface,
                modifier = Modifier.fillMaxWidth().statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Settings",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Group 1: Playtime & Backup & Restore
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.PlayCircleOutline,
                        title = appStrings.playtimeTitle,
                        badge = livePlaytime,
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "playtime"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.CloudSync,
                        title = appStrings.backupRestoreTitle,
                        badge = "Coming Soon",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "backup_restore"
                        }
                    )
                }
            }

            // Group 2: Theme & Sleep Timer & Equalizer (Opens 10-Band EQ Sheet directly)
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.Palette,
                        title = appStrings.themeTitle,
                        badge = ThemeManager.currentThemeName,
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "theme"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Alarm,
                        title = appStrings.sleepTimerTitle,
                        badge = if (sleepMinutes > 0) "$sleepMinutes min" else "Off",
                        accentColor = activeColor,
                        onClick = {
                            showSleepTimerSheet = true
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.GraphicEq,
                        title = appStrings.equalizerTitle,
                        badge = "10-Band EQ",
                        accentColor = activeColor,
                        onClick = {
                            showEqualizerSheet = true
                        }
                    )
                }
            }

            // Group 3: Hidden Files & Recently Deleted & Sound Quality (Replaced Scan Media Library)
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.VisibilityOff,
                        title = appStrings.vaultTitle,
                        badge = "Protected",
                        accentColor = activeColor,
                        onClick = onOpenVault
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.DeleteOutline,
                        title = appStrings.recentlyDeletedTitle,
                        badge = "${recentlyDeleted.size} files",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "recently_deleted"
                        }
                    )
                    SettingsDivider()
                    // NEW EXTRA TAB replacing "Scan Media Library"
                    LarkSettingsRow(
                        icon = Icons.Default.Tune,
                        title = appStrings.soundQualityTitle,
                        badge = "Hi-Res HD",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "audio_effects"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.NotificationsNone,
                        title = appStrings.notificationsTitle,
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "notification"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Language,
                        title = appStrings.languageTitle,
                        badge = activeLang.nativeName,
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "language"
                        }
                    )
                }
            }

            // Group 4: About & In-App OTA Update Check
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.SystemUpdate,
                        title = appStrings.checkForUpdatesTitle,
                        badge = "Check now",
                        accentColor = activeColor,
                        onClick = {
                            scope.launch {
                                Toast.makeText(context, "Checking server for updates...", Toast.LENGTH_SHORT).show()
                                val update = AppUpdateManager.checkForUpdates(context)
                                if (update == null) {
                                    Toast.makeText(context, "You are using the latest version!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Info,
                        title = appStrings.aboutTitle,
                        badge = "v1.0.5 • 2026",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "about"
                        }
                    )
                }
            }
        }
    }

    if (showSleepTimerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSleepTimerSheet = false },
            containerColor = colors.surface,
            contentColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 30.dp)
            ) {
                Text(
                    text = "Sleep timer",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(18.dp))
                SleepTimerOptionRow(
                    title = "Turn off",
                    isSelected = sleepMinutes == 0,
                    accentColor = activeColor,
                    onClick = {
                        playerManager.setSleepTimer(0)
                        showSleepTimerSheet = false
                    }
                )
                listOf(10, 20, 30, 60).forEach { mins ->
                    SleepTimerOptionRow(
                        title = "$mins minutes later",
                        isSelected = sleepMinutes == mins,
                        accentColor = activeColor,
                        onClick = {
                            playerManager.setSleepTimer(mins)
                            showSleepTimerSheet = false
                            Toast.makeText(context, "Playback will pause in $mins minutes", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsGroupCard(content: @Composable ColumnScope.() -> Unit) {
    val colors = LocalLerzaColors.current
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = colors.card,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            content()
        }
    }
}

@Composable
private fun LarkSettingsRow(
    icon: ImageVector,
    title: String,
    badge: String? = null,
    accentColor: Color,
    onClick: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            fontSize = 15.sp,
            color = colors.textPrimary,
            modifier = Modifier.weight(1f)
        )
        if (badge != null) {
            Text(
                text = badge,
                fontSize = 13.sp,
                color = colors.textSecondary
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = colors.textSecondary.copy(alpha = 0.5f),
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun SettingsDivider() {
    val colors = LocalLerzaColors.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(0.6.dp)
            .background(colors.divider)
    )
}

@Composable
private fun SleepTimerOptionRow(
    title: String,
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            fontSize = 15.sp,
            color = if (isSelected) accentColor else colors.textPrimary
        )
        if (isSelected) {
            Icon(Icons.Default.Check, contentDescription = null, tint = accentColor)
        }
    }
}