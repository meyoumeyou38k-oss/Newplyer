package com.lerzaplayer.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import com.lerzaplayer.update.AppUpdateManager
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onScanMedia: () -> Unit,
    onOpenVault: () -> Unit = {},
    recentlyDeleted: List<RecentlyDeletedEntity> = emptyList(),
    onPlayRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onRestoreRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onPermanentlyDeleteRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current
    val activeColor = ThemeManager.currentThemeColor
    val sleepMinutes by (context.applicationContext as? com.lerzaplayer.LerzaApp)?.playerManager?.sleepTimerRemainingMinutes?.collectAsState() ?: remember { mutableIntStateOf(0) }
    val playerManager = (context.applicationContext as? com.lerzaplayer.LerzaApp)?.playerManager
    var currentSubScreen by remember { mutableStateOf<String?>(null) }
    var showSleepTimerSheet by remember { mutableStateOf(false) }

    BackHandler(enabled = currentSubScreen != null) {
        currentSubScreen = null
    }

    if (currentSubScreen == "playtime") {
        PlaytimeScreen(
            onBack = { currentSubScreen = null }
        )
        return
    }

    if (currentSubScreen == "theme") {
        ThemeScreen(
            prefManager = prefManager,
            onBack = { currentSubScreen = null }
        )
        return
    }

    Scaffold(
        topBar = {
            Surface(
                color = colors.surface,
                modifier = Modifier.fillMaxWidth().statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Settings",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Group 1: Playtime & Backup
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.PlayCircleOutline,
                        title = "Playtime",
                        badge = "2h 7m",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "playtime"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.CloudSync,
                        title = "Backup & restore",
                        badge = "Log in",
                        accentColor = activeColor,
                        onClick = {
                            Toast.makeText(context, "Local backup active", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }

            // Group 2: Theme & Sleep Timer & Equalizer
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.Palette,
                        title = "Theme & Colors",
                        badge = ThemeManager.currentThemeName,
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "theme"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Alarm,
                        title = "Sleep timer",
                        badge = if (sleepMinutes > 0) "$sleepMinutes min" else "Off",
                        accentColor = activeColor,
                        onClick = {
                            showSleepTimerSheet = true
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.GraphicEq,
                        title = "Audio Equalizer & Bass",
                        badge = "10-Band EQ",
                        accentColor = activeColor,
                        onClick = onOpenEqualizer
                    )
                }
            }

            // Group 3: Hidden Files & Recently Deleted
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.VisibilityOff,
                        title = "Hidden files (Vault)",
                        badge = "Protected",
                        accentColor = activeColor,
                        onClick = onOpenVault
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.DeleteOutline,
                        title = "Recently deleted",
                        badge = "${recentlyDeleted.size} files",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "recently_deleted"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Refresh,
                        title = "Scan Media Library",
                        badge = "Rescan",
                        accentColor = activeColor,
                        onClick = onScanMedia
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.NotificationsNone,
                        title = "Notification settings",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "notification"
                        }
                    )
                }
            }

            // Group 4: About & In-App OTA Update Check
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.SystemUpdate,
                        title = "Check for Updates",
                        badge = "Check now",
                        accentColor = activeColor,
                        onClick = {
                            scope.launch {
                                Toast.makeText(context, "Checking server for updates...", Toast.LENGTH_SHORT).show()
                                val update = AppUpdateManager.checkForUpdates(context)
                                if (update == null) {
                                    Toast.makeText(context, "You are using the latest version!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Info,
                        title = "App Version",
                        badge = "Lerza Pro 2.4",
                        accentColor = activeColor,
                        onClick = {}
                    )
                }
            }
        }
    }

    if (showSleepTimerSheet && playerManager != null) {
        ModalBottomSheet(
            onDismissRequest = { showSleepTimerSheet = false },
            containerColor = colors.surface,
            contentColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 30.dp)
            ) {
                Text(
                    text = "Sleep timer",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(18.dp))
                SleepTimerOptionRow(
                    title = "Turn off",
                    isSelected = sleepMinutes == 0,
                    accentColor = activeColor,
                    onClick = {
                        playerManager.setSleepTimer(0)
                        showSleepTimerSheet = false
                    }
                )
                listOf(10, 20, 30, 60).forEach { mins ->
                    SleepTimerOptionRow(
                        title = "$mins minutes later",
                        isSelected = sleepMinutes == mins,
                        accentColor = activeColor,
                        onClick = {
                            playerManager.setSleepTimer(mins)
                            showSleepTimerSheet = false
                            Toast.makeText(context, "Playback will pause in $mins minutes", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    if (currentSubScreen == "notification") {
        var newMediaNotif by remember { mutableStateOf(true) }
        var pushNotif by remember { mutableStateOf(true) }
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Notification settings",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { pad ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(22.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("New media notification", fontSize = 16.sp, color = colors.textPrimary)
                    Switch(
                        checked = newMediaNotif,
                        onCheckedChange = { newMediaNotif = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Push notification", fontSize = 16.sp, color = colors.textPrimary)
                        Text("Recommend music I might like", fontSize = 12.sp, color = colors.textSecondary)
                    }
                    Switch(
                        checked = pushNotif,
                        onCheckedChange = { pushNotif = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = activeColor)
                    )
                }
            }
        }
    }

    if (currentSubScreen == "recently_deleted") {
        Scaffold(
            topBar = {
                Surface(
                    color = colors.surface,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Recently deleted (${recentlyDeleted.size})",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                }
            },
            containerColor = colors.background
        ) { pad ->
            if (recentlyDeleted.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(pad),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Trash is empty. Deleted items remain here for 30 days.", color = colors.textSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(pad)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(recentlyDeleted.size) { idx ->
                        val item = recentlyDeleted[idx]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(colors.card)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { onPlayRecentlyDeleted(item) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(activeColor.copy(alpha = 0.2f))
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = activeColor)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.originalName, color = colors.textPrimary, fontSize = 13.sp, maxLines = 1)
                                Text("Auto-deletes in 30 days", color = colors.accent, fontSize = 10.sp)
                            }
                            Button(
                                onClick = { onRestoreRecentlyDeleted(item) },
                                colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Restore", fontSize = 11.sp, color = colors.onPrimary)
                            }
                            IconButton(onClick = { onPermanentlyDeleteRecentlyDeleted(item) }) {
                                Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color(0xFFFF5252))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsGroupCard(content: @Composable ColumnScope.() -> Unit) {
    val colors = LocalLerzaColors.current
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = colors.card,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            content()
        }
    }
}

@Composable
private fun LarkSettingsRow(
    icon: ImageVector,
    title: String,
    badge: String? = null,
    accentColor: Color,
    onClick: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            fontSize = 15.sp,
            color = colors.textPrimary,
            modifier = Modifier.weight(1f)
        )
        if (badge != null) {
            Text(
                text = badge,
                fontSize = 13.sp,
                color = colors.textSecondary
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = colors.textSecondary.copy(alpha = 0.5f),
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun SettingsDivider() {
    val colors = LocalLerzaColors.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(0.6.dp)
            .background(colors.divider)
    )
}

@Composable
private fun SleepTimerOptionRow(
    title: String,
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            fontSize = 15.sp,
            color = if (isSelected) accentColor else colors.textPrimary
        )
        if (isSelected) {
            Icon(Icons.Default.Check, contentDescription = null, tint = accentColor)
        }
    }
}