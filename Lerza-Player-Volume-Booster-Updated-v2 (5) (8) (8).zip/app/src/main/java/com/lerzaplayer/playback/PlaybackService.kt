package com.lerzaplayer.playback

import android.content.Intent
import android.os.Bundle
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.lerzaplayer.data.repository.ThumbnailExtractor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var playerManager: PlayerManager

    override fun onCreate() {
        super.onCreate()
        playerManager = PlayerManager.getInstance(this)

        val nextSessionCommand = SessionCommand(CUSTOM_COMMAND_NEXT, Bundle.EMPTY)
        mediaSession = MediaSession.Builder(this, playerManager.exoPlayer)
            .setCallback(object : MediaSession.Callback {
                override fun onConnect(
                    session: MediaSession,
                    controller: MediaSession.ControllerInfo
                ): MediaSession.ConnectionResult {
                    val availableSessionCommands =
                        MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon()
                            .add(nextSessionCommand)
                            .build()
                    return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                        .setAvailableSessionCommands(availableSessionCommands)
                        .build()
                }

                override fun onCustomCommand(
                    session: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    customCommand: SessionCommand,
                    args: Bundle
                ): ListenableFuture<SessionResult> {
                    if (customCommand.customAction == CUSTOM_COMMAND_NEXT) {
                        playerManager.playNextTrack()
                    }
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
            })
            .build()

        mediaSession?.setCustomLayout(
            listOf(
                CommandButton.Builder()
                    .setIcon(CommandButton.ICON_NEXT)
                    .setDisplayName("Next")
                    .setSessionCommand(nextSessionCommand)
                    .build()
            )
        )
        serviceScope.launch { playerManager.currentSong.collect { updateNotification() } }
        serviceScope.launch { playerManager.isPlaying.collect { updateNotification() } }
        serviceScope.launch { playerManager.duration.collect { updateNotification() } }
    }

    private fun updateNotification() {
        val song = playerManager.currentSong.value
        val isPlaying = playerManager.isPlaying.value
        val position = playerManager.currentPosition.value
        val duration = playerManager.duration.value
        val session = mediaSession

        serviceScope.launch(Dispatchers.IO) {
            val art = if (song != null) {
                ThumbnailExtractor.getSongCover(this@PlaybackService, song.contentUri, song.id)
            } else {
                null
            }
            val notification = NotificationHelper.buildMediaNotification(
                context = this@PlaybackService,
                song = song,
                isPlaying = isPlaying,
                albumArt = art,
                currentPosition = position,
                duration = duration,
                mediaSession = session
            )
            withContext(Dispatchers.Main) {
                if (isPlaying || song != null) {
                    startForeground(NotificationHelper.NOTIFICATION_ID, notification)
                } else {
                    stopForeground(STOP_FOREGROUND_DETACH)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(
            NotificationHelper.NOTIFICATION_ID,
            NotificationHelper.buildMediaNotification(
                context = this,
                song = playerManager.currentSong.value,
                isPlaying = playerManager.isPlaying.value,
                albumArt = null,
                currentPosition = playerManager.currentPosition.value,
                duration = playerManager.duration.value,
                mediaSession = mediaSession
            )
        )
        when (intent?.action) {
            ACTION_PLAY -> playerManager.play()
            ACTION_PAUSE -> playerManager.pause()
            ACTION_NEXT -> playerManager.playNextTrack()
            ACTION_PREV -> playerManager.playPreviousTrack()
            ACTION_STOP -> {
                playerManager.pause()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        serviceScope.cancel()
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.lerzaplayer.ACTION_PLAY"
        const val ACTION_PAUSE = "com.lerzaplayer.ACTION_PAUSE"
        const val ACTION_NEXT = "com.lerzaplayer.ACTION_NEXT"
        const val ACTION_PREV = "com.lerzaplayer.ACTION_PREV"
        const val ACTION_STOP = "com.lerzaplayer.ACTION_STOP"
        private const val CUSTOM_COMMAND_NEXT = "com.lerzaplayer.MEDIA_SESSION_NEXT"
    }
}
