package com.lerzaplayer.ui.home

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lerzaplayer.data.model.*
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.AutoHidingHeader
import com.lerzaplayer.ui.common.MultiSelectActionBar
import com.lerzaplayer.ui.common.TabsRow
import com.lerzaplayer.ui.common.WallpaperBackground
import com.lerzaplayer.ui.player.MiniPlayer
import com.lerzaplayer.ui.songs.SongListScreen
import com.lerzaplayer.ui.videos.VideoListScreen
import com.lerzaplayer.ui.playlists.PlaylistsScreen
import com.lerzaplayer.ui.folders.FoldersScreen
import com.lerzaplayer.ui.albums.AlbumsScreen
import com.lerzaplayer.ui.artists.ArtistsScreen
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    playerManager: PlayerManager,
    onNavigateToSearch: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToVault: () -> Unit,
    onNavigateToTheme: () -> Unit,
    onOpenFullPlayer: () -> Unit,
    onOpenVideoPlayer: (VideoItem) -> Unit,
    onScanDevice: () -> Unit,
    onDeleteSongRequested: (SongItem) -> Unit,
    onDeleteVideoRequested: (VideoItem) -> Unit,
    onBulkDeleteRequested: (List<SongItem>) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val coroutineScope = rememberCoroutineScope()
    val pagerState = rememberPagerState(initialPage = 1, pageCount = { 6 })

    // UI Preferences
    val context = LocalContext.current
    val prefManager = remember { PreferenceManager(context) }
    val densityScale by prefManager.densityScale.collectAsState(initial = 1.15f)
    val wallpaperUri by prefManager.wallpaperUri.collectAsState(initial = null)
    val wallpaperDim by prefManager.wallpaperDim.collectAsState(initial = 0.50f)
    val wallpaperBlur by prefManager.wallpaperBlur.collectAsState(initial = 0f)

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()
    val currentSort by playerManager.currentSort.collectAsState()
    val viewMode by playerManager.videoViewMode.collectAsState()

    var isHeaderVisible by remember { mutableStateOf(true) }
    var selectedSongIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    val isMultiSelectMode = selectedSongIds.isNotEmpty()

    BackHandler(enabled = isMultiSelectMode) {
        selectedSongIds = emptySet()
    }

    val nestedScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -12f && isHeaderVisible) {
                    isHeaderVisible = false
                } else if (available.y > 12f && !isHeaderVisible) {
                    isHeaderVisible = true
                }
                return Offset.Zero
            }
        }
    }

    WallpaperBackground(
        wallpaperUri = wallpaperUri,
        dimAmount = wallpaperDim,
        blurRadius = wallpaperBlur
    ) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .nestedScroll(nestedScrollConnection)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                AutoHidingHeader(
                    visible = isHeaderVisible,
                    onSearchClick = onNavigateToSearch,
                    onSettingsClick = onNavigateToSettings
                )

                TabsRow(
                    selectedTab = pagerState.currentPage,
                    onTabSelected = { tabIndex ->
                        coroutineScope.launch {
                            pagerState.animateScrollToPage(tabIndex)
                        }
                    }
                )

                // 🌟 Accidental Swipe Protection:
                // userScrollEnabled is set to false to prevent diagonal list fling from accidentally swiping tabs!
                // Tabs switch reliably with top bar tabs or explicit navigation.
                HorizontalPager(
                    state = pagerState,
                    userScrollEnabled = false,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) { page ->
                    when (page) {
                        0 -> VideoListScreen(
                            videos = videos,
                            viewMode = viewMode,
                            onVideoClick = onOpenVideoPlayer,
                            onViewModeToggle = { playerManager.toggleVideoViewMode() },
                            onScanDevice = onScanDevice,
                            onToggleFavorite = { playerManager.toggleVideoFavorite(it) },
                            onHideInVault = { onNavigateToVault() },
                            onDelete = onDeleteVideoRequested
                        )
                        1 -> SongListScreen(
                            songs = songs,
                            currentSong = currentSong,
                            isPlaying = isPlaying,
                            currentSort = currentSort,
                            selectedSongIds = selectedSongIds,
                            isMultiSelectMode = isMultiSelectMode,
                            densityScale = densityScale,
                            onSongClick = { song, index ->
                                playerManager.playPlaylist(songs, index)
                            },
                            onToggleSelect = { songId ->
                                selectedSongIds = if (selectedSongIds.contains(songId)) {
                                    selectedSongIds - songId
                                } else {
                                    selectedSongIds + songId
                                }
                            },
                            onStartMultiSelect = { songId ->
                                selectedSongIds = setOf(songId)
                            },
                            onSortChanged = { playerManager.setSortOption(it) },
                            onToggleFavorite = { playerManager.toggleSongFavorite(it) },
                            onPlayNext = { playerManager.playNext(it) },
                            onAddToQueue = { playerManager.addToQueue(it) },
                            onAddToPlaylist = { /* Playlist Picker */ },
                            onHideInVault = { onNavigateToVault() },
                            onDelete = onDeleteSongRequested
                        )
                        2 -> PlaylistsScreen(
                            allSongs = songs,
                            playerManager = playerManager,
                            onOpenSong = { song -> playerManager.playSong(song) },
                            onOpenEqualizer = onOpenFullPlayer
                        )
                        3 -> FoldersScreen(
                            songs = songs,
                            playerManager = playerManager,
                            onOpenSong = { song -> playerManager.playSong(song) }
                        )
                        4 -> AlbumsScreen(
                            songs = songs,
                            playerManager = playerManager,
                            onOpenSong = { song -> playerManager.playSong(song) }
                        )
                        5 -> ArtistsScreen(
                            songs = songs,
                            playerManager = playerManager,
                            onOpenSong = { song -> playerManager.playSong(song) }
                        )
                    }
                }
            }

            // Bottom Mini Player
            if (currentSong != null && !isMultiSelectMode) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                ) {
                    MiniPlayer(
                        currentSong = currentSong,
                        isPlaying = isPlaying,
                        onExpand = onOpenFullPlayer,
                        onPlayPause = { playerManager.togglePlayPause() },
                        onNext = { playerManager.skipNext() },
                        onOpenQueue = onOpenFullPlayer
                    )
                }
            }

            // Multi-Select Action Bar
            AnimatedVisibility(
                visible = isMultiSelectMode,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                MultiSelectActionBar(
                    selectedCount = selectedSongIds.size,
                    onSelectAll = {
                        selectedSongIds = songs.map { it.id }.toSet()
                    },
                    onDeselectAll = {
                        selectedSongIds = emptySet()
                    },
                    onPlaySelection = {
                        val selectedSongs = songs.filter { selectedSongIds.contains(it.id) }
                        if (selectedSongs.isNotEmpty()) {
                            playerManager.playPlaylist(selectedSongs, 0)
                            selectedSongIds = emptySet()
                        }
                    },
                    onDeleteSelection = {
                        val selectedSongs = songs.filter { selectedSongIds.contains(it.id) }
                        onBulkDeleteRequested(selectedSongs)
                    }
                )
            }
        }
    }
}
