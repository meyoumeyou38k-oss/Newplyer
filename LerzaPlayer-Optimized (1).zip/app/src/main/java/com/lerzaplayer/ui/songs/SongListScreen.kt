package com.lerzaplayer.ui.songs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow

@Composable
fun SongListScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    currentSort: SortOption,
    selectedSongIds: Set<Long>,
    isMultiSelectMode: Boolean,
    densityScale: Float = 1.15f,
    onSongClick: (SongItem, Int) -> Unit,
    onToggleSelect: (Long) -> Unit,
    onStartMultiSelect: (Long) -> Unit,
    onSortChanged: (SortOption) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onPlayNext: (SongItem) -> Unit,
    onAddToQueue: (SongItem) -> Unit,
    onAddToPlaylist: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var sortMenuExpanded by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${songs.size} Songs",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = colors.textSecondary
            )

            Box {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { sortMenuExpanded = true }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.Sort,
                        contentDescription = "Sort",
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = currentSort.displayName,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textPrimary
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                DropdownMenu(
                    expanded = sortMenuExpanded,
                    onDismissRequest = { sortMenuExpanded = false },
                    modifier = Modifier.background(colors.surface)
                ) {
                    SortOption.values().forEach { option ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = option.displayName,
                                    color = if (option == currentSort) colors.primary else colors.textPrimary,
                                    fontWeight = if (option == currentSort) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            onClick = {
                                sortMenuExpanded = false
                                onSortChanged(option)
                            }
                        )
                    }
                }
            }
        }

        // 🚀 120Hz Hardware Accelerated LazyColumn with Pool Re-use and Stable Keys
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(bottom = if (isMultiSelectMode) 80.dp else 56.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(
                items = songs,
                key = { it.id },
                contentType = { "song_item" }
            ) { song ->
                val isSelected = selectedSongIds.contains(song.id)
                val isCurrent = currentSong?.id == song.id

                SongItemRow(
                    song = song,
                    isPlaying = isPlaying,
                    isCurrent = isCurrent,
                    isMultiSelectActive = isMultiSelectMode,
                    isSelected = isSelected,
                    densityScale = densityScale,
                    onSongClick = {
                        val index = songs.indexOfFirst { it.id == song.id }
                        onSongClick(song, index)
                    },
                    onSongLongClick = {
                        onStartMultiSelect(song.id)
                    },
                    onToggleSelect = {
                        onToggleSelect(song.id)
                    },
                    onToggleFavorite = {
                        onToggleFavorite(song)
                    },
                    onPlayNext = {
                        onPlayNext(song)
                    },
                    onAddToQueue = {
                        onAddToQueue(song)
                    },
                    onAddToPlaylist = {
                        onAddToPlaylist(song)
                    },
                    onHideInVault = {
                        onHideInVault(song)
                    },
                    onDelete = {
                        onDelete(song)
                    }
                )
            }
        }
    }
}
