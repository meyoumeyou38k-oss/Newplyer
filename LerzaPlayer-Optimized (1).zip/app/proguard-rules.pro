# Add project specific ProGuard rules here.
-keep class com.lerzaplayer.data.database.** { *; }
-keep class com.lerzaplayer.playback.** { *; }
-dontwarn androidx.media3.**

# 🚀 LerzaPlayer Hardware GPU & R8 Optimization Rules
-repackageclasses 'com.lerzaplayer.opt'
-allowaccessmodification
-overloadaggressively
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Jetpack Compose Performance Optimizations
-keep,allowobfuscation,allowshrinking class androidx.compose.runtime.** { *; }
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
}

# Coroutines and Media3
-keep class kotlinx.coroutines.** { *; }
-keep class androidx.media3.** { *; }
-dontwarn sun.misc.Unsafe
