package com.lerzaplayer.playback

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class EqualizerSnapshot(
    val bandCentersHz: List<Int> = emptyList(),
    val minimumBandLevel: Short = 0,
    val maximumBandLevel: Short = 0,
    val presetNames: List<String> = emptyList(),
    val bandLevels: List<Short> = emptyList(),
    val selectedPreset: Int? = null,
    val activeSoundProfile: String? = null,
    val supported: Boolean = false
)

class PlayerManager private constructor(private val context: Context) {

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context).build()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _currentSong = MutableStateFlow<SongItem?>(null)
    val currentSong: StateFlow<SongItem?> = _currentSong.asStateFlow()

    private val _currentVideo = MutableStateFlow<VideoItem?>(null)
    val currentVideo: StateFlow<VideoItem?> = _currentVideo.asStateFlow()

    private val _queue = MutableStateFlow<List<SongItem>>(emptyList())
    val queue: StateFlow<List<SongItem>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_ALL)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _sleepTimerRemainingMinutes = MutableStateFlow(0)
    val sleepTimerRemainingMinutes: StateFlow<Int> = _sleepTimerRemainingMinutes.asStateFlow()

    private val _equalizerEnabled = MutableStateFlow(true)
    val equalizerEnabled: StateFlow<Boolean> = _equalizerEnabled.asStateFlow()

    private val _bassBoostStrength = MutableStateFlow(0)
    val bassBoostStrength: StateFlow<Int> = _bassBoostStrength.asStateFlow()

    private val _virtualizerStrength = MutableStateFlow(0)
    val virtualizerStrength: StateFlow<Int> = _virtualizerStrength.asStateFlow()

    // 300% Boost Level (1 to 300)
    private val _loudnessGain = MutableStateFlow(100)
    val loudnessGain: StateFlow<Int> = _loudnessGain.asStateFlow()

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var sleepTimerJob: Job? = null

    private val _equalizerSnapshot = MutableStateFlow(EqualizerSnapshot())
    val equalizerSnapshot: StateFlow<EqualizerSnapshot> = _equalizerSnapshot.asStateFlow()
    private var selectedEqualizerPreset: Int? = null
    private var selectedSoundProfile: String? = null

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                _isPlaying.value = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)
                    initAudioEffects()
                } else if (playbackState == Player.STATE_ENDED) {
                    playNextTrack()
                }
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                initAudioEffects()
            }
        })

        scope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _currentPosition.value = exoPlayer.currentPosition
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)
                }
                delay(400)
            }
        }

        initAudioEffects()
    }

    private fun initAudioEffects() {
        try {
            val audioSessionId = exoPlayer.audioSessionId
            if (audioSessionId == 0) return
            releaseAudioEffects()
            equalizer = Equalizer(0, audioSessionId).apply {
                enabled = _equalizerEnabled.value
            }
            bassBoost = BassBoost(0, audioSessionId).apply {
                enabled = _equalizerEnabled.value
                setStrength(_bassBoostStrength.value.toShort())
            }
            virtualizer = Virtualizer(0, audioSessionId).apply {
                enabled = _equalizerEnabled.value
                setStrength(_virtualizerStrength.value.toShort())
            }
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                enabled = _loudnessGain.value > 100
                val boostValue = if (_loudnessGain.value > 100) (_loudnessGain.value - 100) * 15 else 0
                setTargetGain(boostValue)
            }
            publishEqualizerSnapshot()
        } catch (e: Exception) {
            e.printStackTrace()
            _equalizerSnapshot.value = EqualizerSnapshot()
        }
    }

    private fun releaseAudioEffects() {
        try {
            equalizer?.release()
            bassBoost?.release()
            virtualizer?.release()
            loudnessEnhancer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            equalizer = null
            bassBoost = null
            virtualizer = null
            loudnessEnhancer = null
        }
    }

    private fun publishEqualizerSnapshot() {
        try {
            val eq = equalizer ?: run {
                _equalizerSnapshot.value = EqualizerSnapshot()
                return
            }
            val range = eq.bandLevelRange
            val bandCount = eq.numberOfBands.toInt()
            val presetCount = eq.numberOfPresets.toInt()
            _equalizerSnapshot.value = EqualizerSnapshot(
                bandCentersHz = (0 until bandCount).map { band ->
                    eq.getCenterFreq(band.toShort()).coerceAtLeast(0) / 1000
                },
                minimumBandLevel = range[0],
                maximumBandLevel = range[1],
                presetNames = (0 until presetCount).map { preset -> eq.getPresetName(preset.toShort()) },
                bandLevels = (0 until bandCount).map { band -> eq.getBandLevel(band.toShort()) },
                selectedPreset = selectedEqualizerPreset,
                activeSoundProfile = selectedSoundProfile,
                supported = bandCount > 0
            )
        } catch (e: Exception) {
            e.printStackTrace()
            _equalizerSnapshot.value = EqualizerSnapshot()
        }
    }

    /** Controls System Volume (1% to 100%) and Loudness Enhancer Boost (101% to 300%) */
    fun setLoudnessGain(percentage: Int) {
        val safePercentage = percentage.coerceIn(1, 300)
        _loudnessGain.value = safePercentage
        try {
            val maxSystemVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

            if (safePercentage <= 100) {
                // 1% سے 100%: سسٹم والیم کو سیٹ کریں
                val targetSystemVolume = (safePercentage * maxSystemVolume) / 100
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetSystemVolume, 0)

                // 100% سے نیچے والیم بوسٹ کو 0 کر دیں
                loudnessEnhancer?.apply {
                    setTargetGain(0)
                    enabled = false
                }
            } else {
                // 100% سے اوپر: سسٹم والیم کو میکسی مم پر رکھیں
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxSystemVolume, 0)

                // 101% سے 300%: اضافی بوسٹ اپلائی کریں
                if (loudnessEnhancer == null) initAudioEffects()
                val mB = (safePercentage - 100) * 15
                loudnessEnhancer?.apply {
                    enabled = true
                    setTargetGain(mB)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun playSongList(songs: List<SongItem>, startIndex: Int) {
        if (songs.isEmpty() || startIndex !in songs.indices) return
        _queue.value = songs
        _currentIndex.value = startIndex
        val song = songs[startIndex]
        _currentSong.value = song
        _currentVideo.value = null

        exoPlayer.setMediaItem(mediaItemFor(song))
        exoPlayer.prepare()
        exoPlayer.play()
        initAudioEffects()
        ContextCompat.startForegroundService(context, Intent(context, PlaybackService::class.java))
    }

    fun setPlaylist(songs: List<SongItem>, startIndex: Int) {
        playSongList(songs, startIndex)
    }

    fun playSong(song: SongItem) {
        playSongList(listOf(song), 0)
    }

    /** Inserts a song immediately after the current track without interrupting playback. */
    fun playNext(song: SongItem) {
        val songs = _queue.value
        if (songs.isEmpty()) {
            playSong(song)
            return
        }
        val insertionIndex = (_currentIndex.value + 1).coerceIn(0, songs.size)
        _queue.value = songs.toMutableList().apply { add(insertionIndex, song) }
    }

    private fun mediaItemFor(song: SongItem): MediaItem = MediaItem.Builder()
        .setUri(song.contentUri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(song.album)
                .setArtworkUri(song.albumArtUri)
                .build()
        )
        .build()

    fun addToQueue(song: SongItem) {
        _queue.value = _queue.value + song
    }

    fun removeFromQueue(index: Int) {
        if (index in _queue.value.indices) {
            val currentList = _queue.value.toMutableList()
            currentList.removeAt(index)
            _queue.value = currentList
            if (index < _currentIndex.value) {
                _currentIndex.value = (_currentIndex.value - 1).coerceAtLeast(0)
            }
        }
    }

    fun clearQueue() {
        _queue.value = emptyList()
        _currentSong.value = null
        exoPlayer.stop()
    }

    fun playPause() {
        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
    }

    fun play() {
        exoPlayer.play()
    }

    fun pause() {
        exoPlayer.pause()
    }

    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs)
        _currentPosition.value = positionMs
    }

    fun playNextTrack() {
        val songs = _queue.value
        if (songs.isEmpty()) return

        if (_repeatMode.value == Player.REPEAT_MODE_ONE) {
            seekTo(0)
            play()
            return
        }

        val nextIndex = if (_isShuffle.value) songs.indices.random() else (_currentIndex.value + 1) % songs.size
        if (nextIndex == 0 && _repeatMode.value == Player.REPEAT_MODE_OFF) {
            exoPlayer.pause()
            seekTo(0)
            return
        }

        _currentIndex.value = nextIndex
        val song = songs[nextIndex]
        _currentSong.value = song
        _currentVideo.value = null
        exoPlayer.setMediaItem(mediaItemFor(song))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun playPreviousTrack() {
        val songs = _queue.value
        if (songs.isEmpty()) return
        if (exoPlayer.currentPosition > 3000L) {
            seekTo(0)
            return
        }

        val previousIndex = if (_currentIndex.value > 0) _currentIndex.value - 1 else songs.size - 1
        _currentIndex.value = previousIndex
        val song = songs[previousIndex]
        _currentSong.value = song
        _currentVideo.value = null
        exoPlayer.setMediaItem(mediaItemFor(song))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun toggleShuffle() {
        _isShuffle.value = !_isShuffle.value
    }

    fun cycleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
            else -> Player.REPEAT_MODE_ALL
        }
        exoPlayer.repeatMode = _repeatMode.value
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        exoPlayer.playbackParameters = PlaybackParameters(speed)
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _sleepTimerRemainingMinutes.value = minutes.coerceAtLeast(0)
        if (minutes <= 0) return

        sleepTimerJob = scope.launch {
            var remaining = minutes
            while (remaining > 0) {
                delay(60_000)
                remaining--
                _sleepTimerRemainingMinutes.value = remaining
            }
            pause()
        }
    }

    fun adjustVolumeUp() {
        audioManager.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            AudioManager.ADJUST_RAISE,
            AudioManager.FLAG_SHOW_UI
        )
    }

    fun adjustVolumeDown() {
        audioManager.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
    }

    fun getCurrentVolume(): Int {
        return audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
    }

    fun getMaxVolume(): Int {
        return audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    }

    fun setVolume(volume: Int) {
        val max = getMaxVolume()
        val targetVolume = volume.coerceIn(0, max)
        audioManager.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            targetVolume,
            AudioManager.FLAG_SHOW_UI
        )
    }

    fun setEqualizerEnabled(enabled: Boolean) {
        _equalizerEnabled.value = enabled
        try {
            if (equalizer == null) initAudioEffects()
            equalizer?.enabled = enabled
            bassBoost?.enabled = enabled
            virtualizer?.enabled = enabled
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setEqualizerPreset(presetIndex: Short) {
        try {
            val eq = equalizer ?: return
            if (presetIndex < 0 || presetIndex >= eq.numberOfPresets) return
            eq.usePreset(presetIndex)
            selectedEqualizerPreset = presetIndex.toInt()
            selectedSoundProfile = null
            publishEqualizerSnapshot()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setEqualizerBand(band: Short, level: Short) {
        try {
            if (equalizer == null) initAudioEffects()
            val eq = equalizer ?: return
            if (band.toInt() in 0 until eq.numberOfBands.toInt()) {
                val range = eq.bandLevelRange
                eq.setBandLevel(band, level.coerceIn(range[0], range[1]))
                selectedEqualizerPreset = null
                selectedSoundProfile = null
                publishEqualizerSnapshot()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /** Applies a five-point tone curve to the device's actual equalizer bands. */
    fun applySoundProfile(name: String, curve: List<Float>, bassStrength: Int) {
        if (curve.size != 5) return
        try {
            if (equalizer == null) initAudioEffects()
            val eq = equalizer ?: return
            val range = eq.bandLevelRange
            val minLevel = range[0].toInt()
            val maxLevel = range[1].toInt()
            val centerLevel = (minLevel + maxLevel) / 2f
            val maxDeviation = (maxLevel - minLevel) / 2f
            val bandCount = eq.numberOfBands.toInt()
            for (band in 0 until bandCount) {
                val position = if (bandCount <= 1) 0f else band.toFloat() * 4f / (bandCount - 1)
                val left = position.toInt().coerceIn(0, 4)
                val right = (left + 1).coerceAtMost(4)
                val fraction = position - left
                val normalized = (curve[left] + (curve[right] - curve[left]) * fraction).coerceIn(-1f, 1f)
                val level = (centerLevel + normalized * maxDeviation).toInt()
                    .coerceIn(minLevel, maxLevel).toShort()
                eq.setBandLevel(band.toShort(), level)
            }
            selectedEqualizerPreset = null
            selectedSoundProfile = name
            setBassBoostStrength(bassStrength.toShort())
            publishEqualizerSnapshot()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun resetEqualizer() {
        try {
            if (equalizer == null) initAudioEffects()
            equalizer?.let { eq ->
                val range = eq.bandLevelRange
                val neutral = 0.toShort().coerceIn(range[0], range[1])
                for (band in 0 until eq.numberOfBands.toInt()) {
                    eq.setBandLevel(band.toShort(), neutral)
                }
            }
            selectedEqualizerPreset = null
            selectedSoundProfile = null
            setBassBoostStrength(0)
            setVirtualizerStrength(0)
            publishEqualizerSnapshot()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setBassBoostStrength(strength: Short) {
        val safeStrength = strength.toInt().coerceIn(0, 1000)
        _bassBoostStrength.value = safeStrength
        try {
            if (bassBoost == null) initAudioEffects()
            bassBoost?.apply {
                enabled = _equalizerEnabled.value
                setStrength(safeStrength.toShort())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setVirtualizerStrength(strength: Short) {
        val safeStrength = strength.toInt().coerceIn(0, 1000)
        _virtualizerStrength.value = safeStrength
        try {
            if (virtualizer == null) initAudioEffects()
            virtualizer?.apply {
                enabled = _equalizerEnabled.value
                setStrength(safeStrength.toShort())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun release() {
        sleepTimerJob?.cancel()
        scope.cancel()
        releaseAudioEffects()
        exoPlayer.release()
    }

    companion object {
        @Volatile
        private var INSTANCE: PlayerManager? = null

        fun getInstance(context: Context): PlayerManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PlayerManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
