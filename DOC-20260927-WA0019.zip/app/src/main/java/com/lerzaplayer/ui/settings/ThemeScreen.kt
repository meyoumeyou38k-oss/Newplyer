package com.lerzaplayer.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.buildLarkTheme
import kotlinx.coroutines.launch

data class LarkColorCircle(
    val id: String,
    val title: String,
    val circleColor: Color
)

val THEME_CIRCLES = listOf(
    LarkColorCircle("AMOLED Black", "Default Dark", Color(0xFF12161A)),
    LarkColorCircle("Blue", "Sky Blue", Color(0xFF2979FF)),
    LarkColorCircle("Green", "Mint Green", Color(0xFF00E676)),
    LarkColorCircle("Purple", "Purple", Color(0xFFE040FB)),      // اسکرین شاٹ 1، 2، 3 والا پرپل
    LarkColorCircle("Orange", "Sunset Orange", Color(0xFFFF6D00)),
    LarkColorCircle("Red", "Soft Rose", Color(0xFFFF1744))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current

    val currentThemeName by prefManager.themeFlow.collectAsState(initial = "Purple")
    val wallpaperUri by prefManager.wallpaperUriFlow.collectAsState(initial = null)
    val wallpaperOpacity by prefManager.wallpaperOpacityFlow.collectAsState(initial = 0.75f)

    var modeSelection by remember { mutableStateOf("Dark") }

    val activePalette = remember(currentThemeName) {
        buildLarkTheme(currentThemeName)
    }

    // گیلری سے وال پیپر تصویر کا لانچر
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            scope.launch {
                prefManager.setWallpaperUri(uri.toString())
            }
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(onClick = onBack) {
                        Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                    }
                    Text(
                        text = "Theme",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = colors.primary,
                    contentColor = Color.White
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Menu, contentDescription = null, modifier = Modifier.size(14.dp))
                        Text("Medium", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // 1. اوپر اصلی فون پریویو کارڈ (Lark Player Live Preview Screen - Screenshot 2)
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.86f)
                    .weight(1f)
                    .clip(RoundedCornerShape(28.dp))
                    .border(2.dp, colors.primary.copy(alpha = 0.35f), RoundedCornerShape(28.dp))
                    .background(colors.background)
            ) {
                // اگر وال پیپر لگا ہو تو پریویو میں بھی نظر آئے
                if (!wallpaperUri.isNullOrBlank()) {
                    AsyncImage(
                        model = wallpaperUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = wallpaperOpacity))
                    )
                }

                // پریویو اسکرین کا اندرونی حصہ
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Lark Player",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Search, contentDescription = null, tint = colors.textSecondary, modifier = Modifier.size(16.dp))
                            Icon(Icons.Default.Tune, contentDescription = null, tint = colors.textSecondary, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = colors.primary,
                            contentColor = Color.White
                        ) {
                            Text("Songs", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = colors.surface,
                            contentColor = colors.textSecondary
                        ) {
                            Text("Videos", fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = colors.surface,
                            contentColor = colors.textSecondary
                        ) {
                            Text("Playlists", fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    listOf(
                        "Crazy In Love With Your Smile" to "Don Juan",
                        "Heart Skips A Beat" to "Hariel",
                        "Beach Memories" to "Nattan",
                        "Can't Stop This Feeling" to "Henrique & Juliano",
                        "Blue Eyes That Saw My Soul" to "Mc Poze"
                    ).forEach { (title, artist) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(colors.primary.copy(alpha = 0.35f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = colors.primary, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = title,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = colors.textPrimary,
                                    maxLines = 1
                                )
                                Text(text = artist, fontSize = 9.sp, color = colors.textSecondary, maxLines = 1)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Dark / Light / System موڈ سلیکٹر (Screenshot 2)
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = colors.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("Dark" to Icons.Default.DarkMode, "Light" to Icons.Default.LightMode, "System" to Icons.Default.SettingsBrightness).forEach { (mode, icon) ->
                        val isSelected = modeSelection == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(24.dp))
                                .background(if (isSelected) colors.primary else Color.Transparent)
                                .clickable {
                                    modeSelection = mode
                                    if (mode == "Light") {
                                        scope.launch { prefManager.setTheme("Pure White") }
                                    } else {
                                        scope.launch { prefManager.setTheme("Purple") }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isSelected) Color.White else colors.textSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = mode,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else colors.textSecondary
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // وال پیپر اوپیسٹی سلائیڈر
            if (!wallpaperUri.isNullOrBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Opacity: ${(wallpaperOpacity * 100).toInt()}%",
                        color = colors.textSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.width(76.dp)
                    )
                    Slider(
                        value = wallpaperOpacity,
                        onValueChange = { scope.launch { prefManager.setWallpaperOpacity(it) } },
                        valueRange = 0.2f..0.95f,
                        colors = SliderDefaults.colors(
                            thumbColor = colors.primary,
                            activeTrackColor = colors.primary
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { scope.launch { prefManager.setWallpaperUri(null) } }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Remove Wallpaper", tint = Color(0xFFFF5252))
                    }
                }
            }

            // 3. نیچے رنگین سرکلز اور گیلری کا بٹن (Screenshot 2 & 3)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp)
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // گیلری سے فوٹو چننے کا بٹن
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(colors.surface)
                        .border(1.5.dp, colors.primary.copy(alpha = 0.4f), CircleShape)
                        .clickable { photoPickerLauncher.launch(arrayOf("image/*")) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = "Pick Wallpaper",
                        tint = colors.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // تمام رنگین تھیم سرکلز (پرپل، نیلا، سبز، اورنج، ریڈ، بلیک)
                THEME_CIRCLES.forEach { circleItem ->
                    val isSel = currentThemeName.contains(circleItem.id, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(circleItem.circleColor)
                            .border(
                                width = 2.dp,
                                color = if (isSel) Color.White else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable {
                                scope.launch { prefManager.setTheme(circleItem.id) }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSel) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}