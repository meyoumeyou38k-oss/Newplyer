package com.lerzaplayer.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

data class LerzaColorPalette(
    val primary: Color,
    val background: Color,
    val surface: Color,
    val card: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val divider: Color,
    val accent: Color,
    val isDark: Boolean = true
)

val LocalLerzaColors = staticCompositionLocalOf {
    LerzaColorPalette(
        primary = Color(0xFF2979FF),
        background = Color(0xFF0C0E11),
        surface = Color(0xFF14181D),
        card = Color(0xFF1C2229),
        textPrimary = Color(0xFFFFFFFF),
        textSecondary = Color(0xFF9E9E9E),
        divider = Color(0x1FFFFFFF),
        accent = Color(0xFF2979FF),
        isDark = true
    )
}

/**
 * Lark Player کی طرح متحرک اور گہرا تھیم تیار کرنے کا الگورتھم
 */
fun buildLarkTheme(themeName: String, isDark: Boolean = true): LerzaColorPalette {
    return when (themeName) {
        // پرپل / میجنٹا تھیم (جیسا کہ اسکرین شاٹ 1، 2، 3 میں ہے)
        "Purple", "Royal Purple", "Neon Pink" -> LerzaColorPalette(
            primary = Color(0xFFE040FB),
            background = Color(0xFF1D1121), // گہرا جامنی بیک گراؤنڈ
            surface = Color(0xFF2B1831),    // جامنی کارڈ سرفیس
            card = Color(0xFF381F40),       // کارڈز اور آئٹمز
            textPrimary = Color(0xFFFFFFFF),
            textSecondary = Color(0xFFD1B2D8),
            divider = Color(0x28E040FB),
            accent = Color(0xFFFF4081),
            isDark = true
        )

        // نیلا تھیم (Sky Blue)
        "Blue", "Sky Blue" -> LerzaColorPalette(
            primary = Color(0xFF2979FF),
            background = Color(0xFF0B1321), // گہرا اوشین بلیو بیک گراؤنڈ
            surface = Color(0xFF121F33),
            card = Color(0xFF182A45),
            textPrimary = Color(0xFFFFFFFF),
            textSecondary = Color(0xFF90CAF9),
            divider = Color(0x282979FF),
            accent = Color(0xFF00E5FF),
            isDark = true
        )

        // سبز تھیم (Mint Green)
        "Green", "Mint Green" -> LerzaColorPalette(
            primary = Color(0xFF00E676),
            background = Color(0xFF0B1D14), // گہرا فارسٹ گرین بیک گراؤنڈ
            surface = Color(0xFF122C1F),
            card = Color(0xFF1A3B2B),
            textPrimary = Color(0xFFFFFFFF),
            textSecondary = Color(0xFFA7F3D0),
            divider = Color(0x2800E676),
            accent = Color(0xFF69F0AE),
            isDark = true
        )

        // اورنج تھیم (Sunset Orange)
        "Orange", "Sunset Orange" -> LerzaColorPalette(
            primary = Color(0xFFFF6D00),
            background = Color(0xFF21130B), // گہرا وارم اورنج بیک گراؤنڈ
            surface = Color(0xFF331D12),
            card = Color(0xFF452718),
            textPrimary = Color(0xFFFFFFFF),
            textSecondary = Color(0xFFFFCCBC),
            divider = Color(0x28FF6D00),
            accent = Color(0xFFFFAB40),
            isDark = true
        )

        // لال / روز تھیم (Soft Rose / Red)
        "Red", "Soft Rose" -> LerzaColorPalette(
            primary = Color(0xFFFF1744),
            background = Color(0xFF210B10), // گہرا مہرونش ریڈ بیک گراؤنڈ
            surface = Color(0xFF33121A),
            card = Color(0xFF451923),
            textPrimary = Color(0xFFFFFFFF),
            textSecondary = Color(0xFFFFCDD2),
            divider = Color(0x28FF1744),
            accent = Color(0xFFFF5252),
            isDark = true
        )

        // پیور لائٹ تھیم
        "Pure White" -> LerzaColorPalette(
            primary = Color(0xFF2979FF),
            background = Color(0xFFF7F9FC),
            surface = Color(0xFFFFFFFF),
            card = Color(0xFFEDF2F7),
            textPrimary = Color(0xFF1A202C),
            textSecondary = Color(0xFF718096),
            divider = Color(0x1A000000),
            accent = Color(0xFF2979FF),
            isDark = false
        )

        // ڈیفالٹ امورلڈ بلیک
        else -> LerzaColorPalette(
            primary = Color(0xFF00E5FF),
            background = Color(0xFF0C0E11),
            surface = Color(0xFF14181D),
            card = Color(0xFF1C2229),
            textPrimary = Color(0xFFFFFFFF),
            textSecondary = Color(0xFF9E9E9E),
            divider = Color(0x1FFFFFFF),
            accent = Color(0xFF00E5FF),
            isDark = true
        )
    }
}

@Composable
fun LerzaPlayerTheme(
    themeName: String = "AMOLED Black",
    content: @Composable () -> Unit
) {
    val targetColors = buildLarkTheme(themeName)

    // تھیم بدلتے وقت نرم اور ہموار اینیمیشن
    val animatedBg = animateColorAsState(targetColors.background, tween(400), label = "bg")
    val animatedSurface = animateColorAsState(targetColors.surface, tween(400), label = "surface")
    val animatedCard = animateColorAsState(targetColors.card, tween(400), label = "card")
    val animatedPrimary = animateColorAsState(targetColors.primary, tween(400), label = "primary")

    val currentPalette = targetColors.copy(
        background = animatedBg.value,
        surface = animatedSurface.value,
        card = animatedCard.value,
        primary = animatedPrimary.value
    )

    val colorScheme = if (targetColors.isDark) {
        darkColorScheme(
            primary = currentPalette.primary,
            background = currentPalette.background,
            surface = currentPalette.surface,
            onPrimary = Color.White,
            onBackground = currentPalette.textPrimary,
            onSurface = currentPalette.textPrimary
        )
    } else {
        lightColorScheme(
            primary = currentPalette.primary,
            background = currentPalette.background,
            surface = currentPalette.surface,
            onPrimary = Color.White,
            onBackground = currentPalette.textPrimary,
            onSurface = currentPalette.textPrimary
        )
    }

    CompositionLocalProvider(LocalLerzaColors provides currentPalette) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}