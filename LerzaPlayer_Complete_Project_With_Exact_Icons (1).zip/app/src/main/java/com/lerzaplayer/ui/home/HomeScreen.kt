package com.lerzaplayer.ui.home

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.lerzaplayer.R
import com.lerzaplayer.data.model.*
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.AutoHidingHeader
import com.lerzaplayer.ui.common.MultiSelectActionBar
import com.lerzaplayer.ui.common.TabsRow
import com.lerzaplayer.ui.common.WallpaperBackground
import com.lerzaplayer.ui.player.MiniPlayer
import com.lerzaplayer.ui.songs.SongListScreen
import com.lerzaplayer.ui.videos.VideoListScreen
import com.lerzaplayer.ui.playlists.PlaylistsScreen
import com.lerzaplayer.ui.folders.FoldersScreen
import com.lerzaplayer.ui.albums.AlbumsScreen
import com.lerzaplayer.ui.artists.ArtistsScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Ultra Smooth Hardware Accelerated Home Screen
 * - Pull-To-Refresh physics offloaded directly to GPU RenderThread via graphicsLayer
 * - Official Lerza DJ Penguin Transparent Logo in Header
 * - Zero frame drop tab transitions
 */
@Composable
fun HomeScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    playerManager: PlayerManager,
    prefManager: PreferenceManager,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onOpenVault: () -> Unit,
    onExpandFullPlayer: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onToggleFavoriteVideo: (VideoItem) -> Unit,
    onHideSongInVault: (SongItem) -> Unit,
    onHideVideoInVault: (VideoItem) -> Unit,
    onDeleteSong: (SongItem) -> Unit,
    onDeleteVideo: (VideoItem) -> Unit,
    onScanDevice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()
    val wallpaperUri by prefManager.wallpaperUriFlow.collectAsState(initial = null)
    val wallpaperOpacity by prefManager.wallpaperOpacityFlow.collectAsState(initial = 0.75f)
    val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
    val videoViewMode by prefManager.videoViewModeFlow.collectAsState(initial = ViewMode.GRID)
    val songDensity by prefManager.songItemDensityFlow.collectAsState(initial = 1.15f)

    val pagerState = rememberPagerState(initialPage = 1, pageCount = { 6 })
    var headerVisible by remember { mutableStateOf(true) }

    // Lark Player Pull-To-Refresh State (Hardware RenderThread Driven)
    var isReloading by remember { mutableStateOf(false) }
    var pullOffsetY by remember { mutableFloatStateOf(0f) }

    fun triggerReload() {
        if (!isReloading) {
            isReloading = true
            onScanDevice()
            scope.launch {
                delay(950)
                isReloading = false
                pullOffsetY = 0f
            }
        }
    }

    val nestedScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -12f) {
                    headerVisible = false
                } else if (available.y > 12f) {
                    headerVisible = true
                }
                return Offset.Zero
            }

            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource
            ): Offset {
                if (available.y > 0 && source == NestedScrollSource.Drag) {
                    pullOffsetY = (pullOffsetY + available.y * 0.45f).coerceAtMost(190f)
                    if (pullOffsetY > 115f && !isReloading) {
                        triggerReload()
                    }
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }
        }
    }

    var isMultiSelectMode by remember { mutableStateOf(false) }
    val selectedSongIds = remember { mutableStateListOf<Long>() }

    BackHandler(enabled = isMultiSelectMode) {
        isMultiSelectMode = false
        selectedSongIds.clear()
    }

    BackHandler(enabled = !isMultiSelectMode && pagerState.currentPage != 1) {
        scope.launch { pagerState.animateScrollToPage(1) }
    }

    fun toggleSongSelection(id: Long) {
        if (selectedSongIds.contains(id)) {
            selectedSongIds.remove(id)
            if (selectedSongIds.isEmpty()) isMultiSelectMode = false
        } else {
            selectedSongIds.add(id)
        }
    }

    WallpaperBackground(
        wallpaperUri = wallpaperUri,
        opacity = wallpaperOpacity
    ) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .nestedScroll(nestedScrollConnection)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                AutoHidingHeader(
                    visible = headerVisible,
                    onSearchClick = onSearchClick,
                    onSettingsClick = onSettingsClick
                )

                TabsRow(
                    selectedTab = pagerState.currentPage,
                    onTabSelected = { index ->
                        scope.launch { pagerState.animateScrollToPage(index) }
                    }
                )

                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.weight(1f)
                ) { page ->
                    when (page) {
                        0 -> {
                            VideoListScreen(
                                videos = videos,
                                viewMode = videoViewMode,
                                onVideoClick = onPlayVideo,
                                onViewModeToggle = {
                                    scope.launch {
                                        val nextMode = if (videoViewMode == ViewMode.GRID) ViewMode.LIST else ViewMode.GRID
                                        prefManager.setVideoViewMode(nextMode)
                                    }
                                },
                                onScanDevice = ::triggerReload,
                                onToggleFavorite = onToggleFavoriteVideo,
                                onHideInVault = onHideVideoInVault,
                                onDelete = onDeleteVideo
                            )
                        }
                        1 -> {
                            SongListScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                currentSort = songSort,
                                selectedSongIds = selectedSongIds.toSet(),
                                isMultiSelectMode = isMultiSelectMode,
                                densityScale = songDensity,
                                onSongClick = { song, _ ->
                                    val index = songs.indexOfFirst { it.id == song.id }
                                    if (index >= 0) {
                                        playerManager.playSong(song, songs, index)
                                    }
                                },
                                onToggleSelect = ::toggleSongSelection,
                                onStartMultiSelect = { id ->
                                    isMultiSelectMode = true
                                    selectedSongIds.add(id)
                                },
                                onSortChanged = { newSort ->
                                    scope.launch { prefManager.setSongSort(newSort) }
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onPlayNext = { song -> playerManager.playNext(song) },
                                onAddToQueue = { song -> playerManager.addToQueue(song) },
                                onAddToPlaylist = { /* Playlist bottom sheet */ },
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                        2 -> {
                            PlaylistsScreen(
                                onOpenVault = onOpenVault,
                                onScanDevice = ::triggerReload
                            )
                        }
                        3 -> {
                            FoldersScreen(
                                songs = songs,
                                onPlaySong = { song ->
                                    playerManager.playSong(song, listOf(song), 0)
                                },
                                onScanDevice = ::triggerReload
                            )
                        }
                        4 -> {
                            AlbumsScreen(
                                songs = songs,
                                onPlayAlbum = { albumSongs ->
                                    if (albumSongs.isNotEmpty()) {
                                        playerManager.playSong(albumSongs.first(), albumSongs, 0)
                                    }
                                },
                                onScanDevice = ::triggerReload
                            )
                        }
                        5 -> {
                            ArtistsScreen(
                                songs = songs,
                                onPlayArtist = { artistSongs ->
                                    if (artistSongs.isNotEmpty()) {
                                        playerManager.playSong(artistSongs.first(), artistSongs, 0)
                                    }
                                },
                                onScanDevice = ::triggerReload
                            )
                        }
                    }
                }
            }

            // GPU Accelerated Pull-to-Refresh Floating Badge
            if (pullOffsetY > 8f || isReloading) {
                val infiniteTransition = rememberInfiniteTransition(label = "reloadRotation")
                val spinAngle by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 360f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(800, easing = LinearEasing),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "spin"
                )

                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .graphicsLayer {
                            // Pure RenderThread hardware matrix translation
                            translationY = pullOffsetY.coerceIn(10f, 150f)
                            cameraDistance = 12f
                        }
                        .padding(top = 8.dp)
                        .shadow(10.dp, CircleShape)
                        .clip(CircleShape)
                        .background(Color.White)
                        .size(44.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reloading",
                        tint = colors.primary,
                        modifier = Modifier
                            .size(24.dp)
                            .graphicsLayer {
                                rotationZ = if (isReloading) spinAngle else (pullOffsetY * 2.5f)
                            }
                    )
                }
            }

            // Seamless Floating Mini Player
            AnimatedVisibility(
                visible = currentSong != null && !isMultiSelectMode,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut(),
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                currentSong?.let { song ->
                    MiniPlayer(
                        song = song,
                        isPlaying = isPlaying,
                        onPlayPause = {
                            if (isPlaying) playerManager.pause() else playerManager.resume()
                        },
                        onSkipNext = { playerManager.skipNext() },
                        onClick = onExpandFullPlayer,
                        modifier = Modifier.padding(horizontal = 0.dp, vertical = 0.dp)
                    )
                }
            }

            // Multi-Select Action Bar
            MultiSelectActionBar(
                visible = isMultiSelectMode,
                selectedCount = selectedSongIds.size,
                totalCount = songs.size,
                onSelectAll = {
                    selectedSongIds.clear()
                    selectedSongIds.addAll(songs.map { it.id })
                },
                onDeselectAll = {
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onPlaySelected = {
                    val selected = songs.filter { selectedSongIds.contains(it.id) }
                    if (selected.isNotEmpty()) {
                        playerManager.playSong(selected.first(), selected, 0)
                        isMultiSelectMode = false
                    }
                },
                onDeleteSelected = {
                    val toDelete = songs.filter { selectedSongIds.contains(it.id) }
                    toDelete.forEach(onDeleteSong)
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}
