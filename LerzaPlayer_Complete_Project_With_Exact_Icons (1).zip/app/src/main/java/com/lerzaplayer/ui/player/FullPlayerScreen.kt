package com.lerzaplayer.ui.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.R
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SongLyrics
import com.lerzaplayer.lyrics.LyricsManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.DynamicArtPalette
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.PaletteExtractor
import kotlin.math.roundToInt

/**
 * Ultra Fluid GPU Accelerated Full Player Screen
 * - Pure RenderThread vinyl disc rotation via graphicsLayer
 * - Official Lerza DJ Penguin Transparent Mascot in Vinyl Core
 * - Dynamic color transitions and hardware accelerated audio ring rendering
 */
@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun FullPlayerScreen(
    playerManager: PlayerManager,
    onCollapse: () -> Unit,
    onFavoriteToggle: (SongItem) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()
    val currentPosition by playerManager.currentPosition.collectAsState()
    val duration by playerManager.duration.collectAsState()
    val queue by playerManager.queue.collectAsState()
    val currentIndex by playerManager.currentIndex.collectAsState()
    val isShuffle by playerManager.isShuffle.collectAsState()
    val repeatMode by playerManager.repeatMode.collectAsState()

    var showOptionsSheet by remember { mutableStateOf(false) }
    var showEqSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showLyricsDialog by remember { mutableStateOf(false) }
    var lyricsState by remember { mutableStateOf<SongLyrics?>(null) }
    var isLoadingLyrics by remember { mutableStateOf(false) }

    LaunchedEffect(currentSong?.id) {
        val song = currentSong
        if (song != null) {
            isLoadingLyrics = true
            lyricsState = LyricsManager.getLyricsForSong(context, song)
            isLoadingLyrics = false
        } else {
            lyricsState = null
        }
    }

    // Dynamic light color palette generated from track seed
    val dynamicPalette = remember(currentSong?.id) {
        PaletteExtractor.extractPalette(null, currentSong?.id ?: 0L)
    }

    // Soft smooth animated transition across songs
    val animatedBgColor by animateColorAsState(
        targetValue = dynamicPalette.softLightBackground,
        animationSpec = tween(500, easing = FastOutSlowInEasing),
        label = "BgColor"
    )

    val textColor = remember(animatedBgColor) {
        val luminance = (0.299 * animatedBgColor.red + 0.587 * animatedBgColor.green + 0.114 * animatedBgColor.blue)
        if (luminance > 0.55) Color(0xFF1E202A) else Color.White
    }

    val subTextColor = remember(textColor) {
        textColor.copy(alpha = 0.72f)
    }

    var offsetY by remember { mutableFloatStateOf(0f) }
    val draggableState = rememberDraggableState { delta ->
        if (delta > 0 || offsetY > 0) {
            offsetY = (offsetY + delta).coerceAtLeast(0f)
            if (offsetY > 320f) {
                onCollapse()
            }
        }
    }

    val progress = remember(currentPosition, duration) {
        if (duration > 0) (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f) else 0f
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .offset { IntOffset(0, offsetY.roundToInt()) }
            .draggable(
                state = draggableState,
                orientation = Orientation.Vertical,
                onDragStopped = {
                    if (offsetY > 180f) {
                        onCollapse()
                    } else {
                        offsetY = 0f
                    }
                }
            )
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        animatedBgColor,
                        animatedBgColor.copy(alpha = 0.95f),
                        colors.background
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onCollapse) {
                    Icon(
                        imageVector = LerzaIcons.KeyboardArrowDown,
                        contentDescription = "Collapse",
                        tint = textColor,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "PLAYING FROM LIBRARY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = subTextColor
                    )
                    Text(
                        text = currentSong?.album ?: "Lerza Pro",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = textColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(onClick = { showOptionsSheet = true }) {
                    Icon(
                        imageVector = LerzaIcons.MoreVert,
                        contentDescription = "Menu",
                        tint = textColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Artwork Area (with rotating vinyl if no thumbnail)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                val hasThumbnail = currentSong?.albumArtUri != null
                if (hasThumbnail) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .aspectRatio(1f)
                            .shadow(24.dp, RoundedCornerShape(28.dp))
                            .clip(RoundedCornerShape(28.dp))
                            .background(colors.card)
                    ) {
                        AsyncImage(
                            model = currentSong?.albumArtUri,
                            contentDescription = currentSong?.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                } else {
                    // GPU Accelerated Rotating Colorful Vinyl Disc with Lerza Mascot Logo
                    AudioVinylVisualizer(
                        isPlaying = isPlaying,
                        primaryColor = dynamicPalette.accentColor,
                        secondaryColor = dynamicPalette.glowColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Title, Artist and Favorite
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentSong?.title ?: "Select a Track",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = textColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currentSong?.artist ?: "Unknown Artist",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = subTextColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                currentSong?.let { song ->
                    IconButton(onClick = { onFavoriteToggle(song) }) {
                        Icon(
                            imageVector = if (song.isFavorite) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (song.isFavorite) Color(0xFFFF334B) else textColor,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Slider & Progress
            Column(modifier = Modifier.fillMaxWidth()) {
                Slider(
                    value = progress,
                    onValueChange = { newProgress ->
                        val targetMs = (newProgress * duration).toLong()
                        playerManager.seekTo(targetMs)
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = dynamicPalette.accentColor,
                        activeTrackColor = dynamicPalette.accentColor,
                        inactiveTrackColor = textColor.copy(alpha = 0.22f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatTime(currentPosition),
                        fontSize = 11.sp,
                        color = subTextColor,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = formatTime(duration),
                        fontSize = 11.sp,
                        color = subTextColor,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Playback Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { playerManager.toggleShuffle() }) {
                    Icon(
                        imageVector = LerzaIcons.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (isShuffle) dynamicPalette.accentColor else subTextColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(
                    onClick = { playerManager.skipPrevious() },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SkipPrevious,
                        contentDescription = "Previous",
                        tint = textColor,
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Play / Pause FAB
                Box(
                    modifier = Modifier
                        .size(70.dp)
                        .shadow(14.dp, CircleShape)
                        .clip(CircleShape)
                        .background(dynamicPalette.accentColor)
                        .clickable {
                            if (isPlaying) playerManager.pause() else playerManager.resume()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) LerzaIcons.Pause else LerzaIcons.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(
                    onClick = { playerManager.skipNext() },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SkipNext,
                        contentDescription = "Next",
                        tint = textColor,
                        modifier = Modifier.size(36.dp)
                    )
                }

                IconButton(onClick = { playerManager.cycleRepeatMode() }) {
                    Icon(
                        imageVector = when (repeatMode) {
                            1 -> LerzaIcons.RepeatOne
                            2 -> LerzaIcons.Repeat
                            else -> LerzaIcons.Repeat
                        },
                        contentDescription = "Repeat",
                        tint = if (repeatMode > 0) dynamicPalette.accentColor else subTextColor,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bottom Actions (Lyrics & Equalizer)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { showLyricsDialog = true },
                    colors = ButtonDefaults.textButtonColors(contentColor = textColor)
                ) {
                    Icon(LerzaIcons.Lyrics, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Lyrics", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }

                TextButton(
                    onClick = { showEqSheet = true },
                    colors = ButtonDefaults.textButtonColors(contentColor = textColor)
                ) {
                    Icon(LerzaIcons.Equalizer, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Equalizer", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }

                TextButton(
                    onClick = { showQueueSheet = true },
                    colors = ButtonDefaults.textButtonColors(contentColor = textColor)
                ) {
                    Icon(LerzaIcons.QueueMusic, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Queue (${queue.size})", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/**
 * GPU Hardware Accelerated Rotating Vinyl Disc & Audio Visualizer
 * Features the official Lerza DJ Penguin Transparent Mascot Logo
 */
@Composable
fun AudioVinylVisualizer(
    isPlaying: Boolean,
    primaryColor: Color,
    secondaryColor: Color
) {
    val infiniteTransition = rememberInfiniteTransition(label = "vinyl")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth(0.85f)
            .aspectRatio(1f),
        contentAlignment = Alignment.Center
    ) {
        // Neon Pulsing Sonic Rings (GPU Canvas Draw)
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = if (isPlaying) pulseScale else 1f
                    scaleY = if (isPlaying) pulseScale else 1f
                }
        ) {
            val centerOffset = center
            val maxR = size.minDimension / 2f

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(primaryColor.copy(alpha = 0.35f), Color.Transparent),
                    center = centerOffset,
                    radius = maxR
                ),
                radius = maxR
            )

            drawCircle(
                color = secondaryColor.copy(alpha = 0.50f),
                radius = maxR * 0.92f,
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
            )

            drawCircle(
                color = primaryColor.copy(alpha = 0.35f),
                radius = maxR * 0.78f,
                style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        // Vinyl Disc Surface (Pure RenderThread Rotation via graphicsLayer)
        Box(
            modifier = Modifier
                .fillMaxSize(0.90f)
                .shadow(24.dp, CircleShape)
                .clip(CircleShape)
                .background(
                    Brush.sweepGradient(
                        colors = listOf(
                            Color(0xFF14151E),
                            Color(0xFF282A3A),
                            Color(0xFF14151E),
                            Color(0xFF33364D),
                            Color(0xFF14151E)
                        )
                    )
                )
                .graphicsLayer {
                    rotationZ = if (isPlaying) rotation else 0f
                },
            contentAlignment = Alignment.Center
        ) {
            // Concentric vinyl grooves
            Canvas(modifier = Modifier.fillMaxSize()) {
                val centerOffset = center
                val maxR = size.minDimension / 2f
                for (r in listOf(0.40f, 0.50f, 0.60f, 0.70f, 0.80f, 0.88f)) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.08f),
                        radius = maxR * r,
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
            }

            // Center Label: Official DJ Penguin Transparent Mascot Logo
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF221144),
                                Color(0xFF0F061F)
                            )
                        )
                    )
                    .border(2.5.dp, primaryColor, CircleShape)
                    .padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_lerza_logo_transparent),
                    contentDescription = "Lerza DJ Mascot",
                    tint = Color.Unspecified,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

private fun formatTime(millis: Long): String {
    val totalSeconds = (millis / 1000).toInt()
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}
