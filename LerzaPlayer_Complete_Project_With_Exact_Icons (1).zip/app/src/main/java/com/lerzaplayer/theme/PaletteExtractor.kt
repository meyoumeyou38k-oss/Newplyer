package com.lerzaplayer.theme

import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import androidx.palette.graphics.Palette

data class DynamicArtPalette(
    val dominantColor: Color,
    val accentColor: Color,
    val glowColor: Color,
    val softLightBackground: Color
)

/**
 * High-Performance Palette Extractor with In-Memory LRU Cache
 * Prevents redundant palette re-computations and drops 0 frames during song switching.
 */
object PaletteExtractor {

    // 16 Luxury Soft Pastels for Dynamic Aura
    private val SOFT_LIGHT_PRESETS = listOf(
        Pair(Color(0xFFE8EAF6), Color(0xFF3F51B5)), // Soft Indigo
        Pair(Color(0xFFF3E5F5), Color(0xFF9C27B0)), // Soft Purple
        Pair(Color(0xFFE1F5FE), Color(0xFF03A9F4)), // Soft Cyan
        Pair(Color(0xFFE0F2F1), Color(0xFF009688)), // Soft Teal
        Pair(Color(0xFFF1F8E9), Color(0xFF8BC34A)), // Soft Light Green
        Pair(Color(0xFFFFF8E1), Color(0xFFFFB300)), // Soft Amber
        Pair(Color(0xFFFBE9E7), Color(0xFFFF5722)), // Soft Deep Orange
        Pair(Color(0xFFFCE4EC), Color(0xFFE91E63)), // Soft Pink
        Pair(Color(0xFFEDE7F6), Color(0xFF673AB7)), // Soft Deep Purple
        Pair(Color(0xFFE3F2FD), Color(0xFF2196F3)), // Soft Blue
        Pair(Color(0xFFE8F5E9), Color(0xFF4CAF50)), // Soft Green
        Pair(Color(0xFFFFFDE7), Color(0xFFFBC02D)), // Soft Yellow
        Pair(Color(0xFFEFEBE9), Color(0xFF795548)), // Soft Brown
        Pair(Color(0xFFECEFF1), Color(0xFF607D8B)), // Soft Blue Grey
        Pair(Color(0xFFF9FBE7), Color(0xFFCDDC39)), // Soft Lime
        Pair(Color(0xFFFAFAFA), Color(0xFF424242))  // Soft Platinum
    )

    private val cache = androidx.collection.LruCache<Long, DynamicArtPalette>(64)

    fun extractPalette(bitmap: Bitmap?, seedId: Long): DynamicArtPalette {
        cache.get(seedId)?.let { return it }

        val palette = if (bitmap != null) {
            val p = Palette.from(bitmap).generate()
            val dom = p.getDominantColor(0xFF1E88E5.toInt())
            val accent = p.getVibrantColor(p.getLightVibrantColor(dom))
            val domColor = Color(dom)
            val accentColor = Color(accent)
            
            // Soft tinted light background
            val softBg = Color(
                red = (domColor.red * 0.25f + 0.75f).coerceIn(0f, 1f),
                green = (domColor.green * 0.25f + 0.75f).coerceIn(0f, 1f),
                blue = (domColor.blue * 0.25f + 0.75f).coerceIn(0f, 1f),
                alpha = 1f
            )

            DynamicArtPalette(
                dominantColor = domColor,
                accentColor = accentColor,
                glowColor = accentColor.copy(alpha = 0.6f),
                softLightBackground = softBg
            )
        } else {
            // Pick deterministic luxury preset by track ID
            val index = (Math.abs(seedId) % SOFT_LIGHT_PRESETS.size).toInt()
            val (softBg, accent) = SOFT_LIGHT_PRESETS[index]
            DynamicArtPalette(
                dominantColor = accent,
                accentColor = accent,
                glowColor = accent.copy(alpha = 0.5f),
                softLightBackground = softBg
            )
        }

        cache.put(seedId, palette)
        return palette
    }
}
