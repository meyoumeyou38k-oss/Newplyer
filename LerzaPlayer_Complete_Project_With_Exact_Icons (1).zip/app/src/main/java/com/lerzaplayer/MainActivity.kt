package com.lerzaplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.FavoriteEntity
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.repository.DeletionResult
import com.lerzaplayer.data.repository.MediaRepository
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaPlayerTheme
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import com.lerzaplayer.ui.home.HomeScreen
import com.lerzaplayer.ui.player.FullPlayerScreen
import com.lerzaplayer.ui.player.VideoPlayerScreen
import com.lerzaplayer.ui.search.SearchScreen
import com.lerzaplayer.ui.settings.SettingsScreen
import com.lerzaplayer.ui.settings.ThemeScreen
import com.lerzaplayer.ui.vault.VaultScreen
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

enum class AppDestination {
    HOME,
    SETTINGS,
    VAULT,
    SEARCH,
    THEME
}

/**
 * Hardware & GPU Accelerated Main Activity
 * Fully harnesses phone GPU rendering pipeline with zero frame drops
 */
class MainActivity : ComponentActivity() {
    private lateinit var mediaRepository: MediaRepository
    private lateinit var playerManager: PlayerManager

    private var isVolumePopupVisible by mutableStateOf(false)
    private var currentVolumePercent by mutableIntStateOf(100)
    private var volumeDismissJob: Job? = null
    private var pendingDeleteEntity: RecentlyDeletedEntity? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (::mediaRepository.isInitialized) mediaRepository.refreshMedia()
    }

    private val scopedStorageDeleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            pendingDeleteEntity?.let { entity ->
                lifecycleScope.launch {
                    mediaRepository.confirmPendingDeletion(entity)
                    Toast.makeText(this@MainActivity, "Moved to Recently Deleted (30 days)", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            pendingDeleteEntity?.let { entity ->
                lifecycleScope.launch {
                    mediaRepository.cancelPendingDeletion(entity)
                }
            }
        }
        pendingDeleteEntity = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Explicit Hardware Acceleration on Window & GPU RenderSurface
        window.setFlags(
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        )

        enableEdgeToEdge()
        ThemeManager.init(this)

        val app = application as LerzaApp
        mediaRepository = MediaRepository(this)
        playerManager = app.playerManager
        playerManager.syncVolumeFromSystem()
        currentVolumePercent = playerManager.loudnessGain.value

        requestRequiredPermissions()

        setContent {
            val prefManager = app.preferenceManager
            val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
            val scope = rememberCoroutineScope()

            val songs by mediaRepository.getSongsFlow(songSort).collectAsState(initial = emptyList())
            val videos by mediaRepository.getVideosFlow(SortOption.DATE_ADDED_DESC).collectAsState(initial = emptyList())
            val recentlyDeleted by mediaRepository.getRecentlyDeletedFlow().collectAsState(initial = emptyList())
            val activeLoudnessGain by playerManager.loudnessGain.collectAsState()

            LaunchedEffect(activeLoudnessGain) {
                currentVolumePercent = activeLoudnessGain
            }

            var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
            var isFullPlayerVisible by remember { mutableStateOf(false) }
            var activePlayingVideo by remember { mutableStateOf<VideoItem?>(null) }
            var songToDeleteConfirm by remember { mutableStateOf<SongItem?>(null) }
            var videoToDeleteConfirm by remember { mutableStateOf<VideoItem?>(null) }

            BackHandler(enabled = activePlayingVideo != null) {
                activePlayingVideo = null
            }

            BackHandler(enabled = activePlayingVideo == null && isFullPlayerVisible) {
                isFullPlayerVisible = false
            }

            BackHandler(enabled = activePlayingVideo == null && !isFullPlayerVisible && currentDestination != AppDestination.HOME) {
                currentDestination = if (currentDestination == AppDestination.THEME) AppDestination.SETTINGS else AppDestination.HOME
            }

            LerzaPlayerTheme(themeColor = ThemeManager.currentThemeColor) {
                val themeColors = LocalLerzaColors.current

                SideEffect {
                    window.statusBarColor = themeColors.surface.toArgb()
                    window.navigationBarColor = themeColors.background.toArgb()
                    WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !themeColors.isDark
                    WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !themeColors.isDark
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    when (currentDestination) {
                        AppDestination.HOME -> {
                            HomeScreen(
                                songs = songs,
                                videos = videos,
                                playerManager = playerManager,
                                prefManager = prefManager,
                                onSearchClick = { currentDestination = AppDestination.SEARCH },
                                onSettingsClick = { currentDestination = AppDestination.SETTINGS },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                onExpandFullPlayer = { isFullPlayerVisible = true },
                                onPlayVideo = { video ->
                                    playerManager.pause()
                                    activePlayingVideo = video
                                },
                                onToggleFavoriteSong = { song ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (song.isFavorite) {
                                            favDao.removeFavorite(song.id, "AUDIO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                        }
                                    }
                                },
                                onToggleFavoriteVideo = { video ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (video.isFavorite) {
                                            favDao.removeFavorite(video.id, "VIDEO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(video.id, "VIDEO"))
                                        }
                                    }
                                },
                                onHideSongInVault = { song ->
                                    scope.launch {
                                        app.vaultManager.hideSong(song)
                                        mediaRepository.refreshMedia()
                                    }
                                },
                                onHideVideoInVault = { video ->
                                    scope.launch {
                                        app.vaultManager.hideVideo(video)
                                        mediaRepository.refreshMedia()
                                    }
                                },
                                onDeleteSong = { song ->
                                    songToDeleteConfirm = song
                                },
                                onDeleteVideo = { video ->
                                    videoToDeleteConfirm = video
                                },
                                onScanDevice = {
                                    mediaRepository.refreshMedia()
                                }
                            )
                        }
                        AppDestination.SETTINGS -> {
                            SettingsScreen(
                                prefManager = prefManager,
                                onBack = { currentDestination = AppDestination.HOME },
                                onOpenEqualizer = { isFullPlayerVisible = true },
                                onScanMedia = { mediaRepository.refreshMedia() },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                recentlyDeleted = recentlyDeleted,
                                onPlayRecentlyDeleted = { item ->
                                    val backupFile = File(item.backupPath)
                                    if (backupFile.exists()) {
                                        val playableUri = Uri.fromFile(backupFile)
                                        playerManager.playSong(
                                            SongItem(
                                                id = item.id,
                                                title = item.originalName,
                                                artist = "Recently Deleted (30 Days)",
                                                album = "Trash",
                                                duration = item.duration,
                                                contentUri = playableUri,
                                                size = item.size,
                                                path = backupFile.absolutePath,
                                                mimeType = if (item.mediaType == "AUDIO") "audio/*" else "video/*"
                                            )
                                        )
                                        isFullPlayerVisible = true
                                    } else {
                                        Toast.makeText(this@MainActivity, "File expired or removed", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onRestoreRecentlyDeleted = { item ->
                                    scope.launch {
                                        mediaRepository.restoreRecentlyDeleted(item)
                                        Toast.makeText(this@MainActivity, "Restored back to phone storage!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onPermanentlyDeleteRecentlyDeleted = { item ->
                                    scope.launch {
                                        mediaRepository.permanentlyDeleteRecentlyDeleted(item)
                                        Toast.makeText(this@MainActivity, "Permanently deleted", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                        }
                        AppDestination.VAULT -> {
                            VaultScreen(
                                vaultManager = app.vaultManager,
                                onBack = { currentDestination = AppDestination.HOME },
                                onPlaySong = { song ->
                                    playerManager.playSong(song, listOf(song), 0)
                                    isFullPlayerVisible = true
                                },
                                onPlayVideo = { video ->
                                    playerManager.pause()
                                    activePlayingVideo = video
                                },
                                onRestoreSong = { mediaRepository.refreshMedia() },
                                onRestoreVideo = { mediaRepository.refreshMedia() }
                            )
                        }
                        AppDestination.SEARCH -> {
                            SearchScreen(
                                songs = songs,
                                videos = videos,
                                currentSong = playerManager.currentSong.collectAsState().value,
                                isPlaying = playerManager.isPlaying.collectAsState().value,
                                onSongClick = { song ->
                                    playerManager.playSong(song, songs, songs.indexOfFirst { it.id == song.id })
                                    isFullPlayerVisible = true
                                },
                                onVideoClick = { video ->
                                    playerManager.pause()
                                    activePlayingVideo = video
                                },
                                onBack = { currentDestination = AppDestination.HOME },
                                onToggleFavoriteSong = { song ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (song.isFavorite) {
                                            favDao.removeFavorite(song.id, "AUDIO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                        }
                                    }
                                },
                                onAddToQueue = { song -> playerManager.addToQueue(song) }
                            )
                        }
                        AppDestination.THEME -> {
                            ThemeScreen(
                                prefManager = prefManager,
                                onBack = { currentDestination = AppDestination.SETTINGS }
                            )
                        }
                    }

                    // Full Screen Player Animated Overlay
                    AnimatedVisibility(
                        visible = isFullPlayerVisible,
                        enter = slideInVertically(
                            initialOffsetY = { it },
                            animationSpec = tween(320, easing = FastOutSlowInEasing)
                        ) + fadeIn(animationSpec = tween(250)),
                        exit = slideOutVertically(
                            targetOffsetY = { it },
                            animationSpec = tween(280, easing = FastOutSlowInEasing)
                        ) + fadeOut(animationSpec = tween(200))
                    ) {
                        FullPlayerScreen(
                            playerManager = playerManager,
                            onCollapse = { isFullPlayerVisible = false },
                            onFavoriteToggle = { song ->
                                scope.launch {
                                    val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                    if (song.isFavorite) {
                                        favDao.removeFavorite(song.id, "AUDIO")
                                    } else {
                                        favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                    }
                                }
                            }
                        )
                    }

                    // Video Player Overlay
                    activePlayingVideo?.let { video ->
                        VideoPlayerScreen(
                            video = video,
                            onClose = { activePlayingVideo = null }
                        )
                    }

                    // Volume Popup Indicator
                    AnimatedVisibility(
                        visible = isVolumePopupVisible,
                        enter = fadeIn() + scaleIn(initialScale = 0.85f),
                        exit = fadeOut() + scaleOut(targetScale = 0.85f),
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(bottom = 60.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = Color(0xDD181822),
                            shadowElevation = 8.dp,
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = if (currentVolumePercent > 100) "VOLUME BOOST" else "VOLUME",
                                    color = if (currentVolumePercent > 100) Color(0xFFFF5252) else Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "$currentVolumePercent%",
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                if (::playerManager.isInitialized) {
                    val newVol = (currentVolumePercent + 5).coerceAtMost(200)
                    playerManager.setLoudnessGain(newVol)
                    currentVolumePercent = newVol
                    showVolumeIndicator()
                    return true
                }
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                if (::playerManager.isInitialized) {
                    val newVol = (currentVolumePercent - 5).coerceAtLeast(0)
                    playerManager.setLoudnessGain(newVol)
                    currentVolumePercent = newVol
                    showVolumeIndicator()
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun showVolumeIndicator() {
        isVolumePopupVisible = true
        volumeDismissJob?.cancel()
        volumeDismissJob = lifecycleScope.launch {
            delay(1200)
            isVolumePopupVisible = false
        }
    }

    private fun requestRequiredPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }
}
