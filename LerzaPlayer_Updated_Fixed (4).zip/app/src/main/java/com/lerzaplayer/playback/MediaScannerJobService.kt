package com.lerzaplayer.playback

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Android JobService that triggers in the background when the app is completely closed.
 * Listens to MediaStore ContentUri triggers for newly saved videos and audio.
 */
class MediaScannerJobService : JobService() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onStartJob(params: JobParameters?): Boolean {
        serviceScope.launch {
            try {
                val monitor = MediaDownloadMonitor(applicationContext)
                monitor.scanNow()
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                // Re-arm trigger for next new video additions
                schedule(applicationContext)
                jobFinished(params, false)
            }
        }
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        serviceScope.cancel()
        return true
    }

    companion object {
        const val JOB_ID = 8801

        fun schedule(context: Context) {
            try {
                val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as? JobScheduler ?: return
                val component = ComponentName(context, MediaScannerJobService::class.java)

                val builder = JobInfo.Builder(JOB_ID, component)
                    .setPersisted(true)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    builder.addTriggerContentUri(
                        JobInfo.TriggerContentUri(
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                            JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS
                        )
                    )
                    builder.addTriggerContentUri(
                        JobInfo.TriggerContentUri(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                            JobInfo.TriggerContentUri.FLAG_NOTIFY_FOR_DESCENDANTS
                        )
                    )
                    builder.setTriggerContentUpdateDelay(800)
                    builder.setTriggerContentMaxDelay(3000)
                } else {
                    builder.setPeriodic(15 * 60 * 1000)
                }

                scheduler.schedule(builder.build())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
