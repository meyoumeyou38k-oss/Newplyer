package com.lerzaplayer.playback

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Re-registers MediaScannerJobService when phone boots or app updates.
 */
class MediaBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON") {
            MediaScannerJobService.schedule(context)
        }
    }
}
