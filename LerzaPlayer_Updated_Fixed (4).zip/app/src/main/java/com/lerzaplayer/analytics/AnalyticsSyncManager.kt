package com.lerzaplayer.analytics

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.provider.Settings
import com.lerzaplayer.data.language.LanguageManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

object AnalyticsSyncManager {

    private const val TURSO_URL = "https://faraz-farazmunawar.aws-ap-south-1.turso.io/v2/pipeline"
    private const val TURSO_TOKEN = "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhIjoicnciLCJpYXQiOjE3OTEwMzQ5MzYsImlkIjoiMDFhMGZjZjMtYTAwMS03OWMzLThlNmQtOTZlODY5YzUxN2RjIiwia2lkIjoiTzl5UXVSOHV6Tjc3ZHhxaUtkTVZ5WGNTYnhlNW9PWjFXWm41Z09vaFVxOCIsInJpZCI6ImNkODAzNjcwLWYxZTUtNDc2MC1iZjE5LTQ4MWY4NmZiZjAzYSJ9.DCnIUR3T8njv1OdDzx0Jas07nYTjPupnWJdiHCkNdzyxCeD0ScSWRoY9TKbbvZvx9QgnxCbYI1kbAzGtGe52Cg"

    private const val PREFS_NAME = "lerza_analytics_prefs"
    private const val KEY_PERM_ID = "perm_device_id"
    private const val KEY_LAST_SYNC_MS = "last_sync_timestamp"

    private var syncJob: Job? = null
    private var isInitialized = false

    @SuppressLint("HardwareIds")
    fun getPermanentDeviceId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val cached = prefs.getString(KEY_PERM_ID, null)
        if (!cached.isNullOrBlank()) return cached

        var deviceId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (_: Exception) {
            null
        }

        // اگر Android ID میسر نہ ہو یا ایمولیٹر ڈیفالٹ ہو تو رینڈم مستقل UUID بنائیں
        if (deviceId.isNullOrBlank() || deviceId == "9774d56d682e549c") {
            deviceId = UUID.randomUUID().toString().replace("-", "").take(16)
        }

        val finalId = "dev_$deviceId"
        prefs.edit().putString(KEY_PERM_ID, finalId).apply()
        return finalId
    }

    fun init(context: Context) {
        if (isInitialized) return
        isInitialized = true

        val appContext = context.applicationContext
        // فوری سنک جب ایپ کھلے
        syncNow(appContext)

        // ہر 20 منٹ بعد بیک گراؤنڈ سنک جب تک ایپ ایکٹو رہے
        syncJob = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                delay(20 * 60 * 1000L) // 20 منٹ
                performSync(appContext)
            }
        }
    }

    fun syncNow(context: Context) {
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            performSync(appContext)
        }
    }

    private fun performSync(context: Context) {
        try {
            val deviceId = getPermanentDeviceId(context)

            // ماڈل اور برانڈ (مثلاً Samsung Galaxy A52)
            val manufacturer = Build.MANUFACTURER?.replaceFirstChar { it.uppercase() } ?: "Android"
            val rawModel = Build.MODEL ?: "Device"
            val deviceModel = if (rawModel.startsWith(manufacturer, ignoreCase = true)) {
                rawModel
            } else {
                "$manufacturer $rawModel"
            }

            val androidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"

            val appVersion = try {
                context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "1.0.5"
            } catch (_: Exception) {
                "1.0.5"
            }

            val appLang = try {
                LanguageManager.currentLanguage.value.code
            } catch (_: Exception) {
                "ur"
            }

            // پلے ٹائم میموری سے حاصل کریں
            val playtimePrefs = context.getSharedPreferences("lerza_playtime_prefs", Context.MODE_PRIVATE)
            val musicMs = playtimePrefs.getLong("total_music_ms", 0L)
            val videoMs = playtimePrefs.getLong("total_video_ms", 0L)

            val audioMinutes = (musicMs / 60000L).toInt()
            val videoMinutes = (videoMs / 60000L).toInt()
            val totalMinutes = audioMinutes + videoMinutes

            val firstInstallTime = try {
                context.packageManager.getPackageInfo(context.packageName, 0).firstInstallTime
            } catch (_: Exception) {
                System.currentTimeMillis()
            }

            val nowMs = System.currentTimeMillis()

            // محفوظ Turso SQL UPSERT اسٹیٹمنٹ
            val upsertSql = """
                INSERT INTO devices (
                    device_id, device_model, device_manufacturer, android_version,
                    app_version, app_language, audio_playtime_minutes, video_playtime_minutes,
                    total_playtime_minutes, session_count, first_install_time, last_active_time, updated_at
                ) VALUES (
                    '$deviceId', '${escapeSql(deviceModel)}', '${escapeSql(manufacturer)}', '$androidVersion',
                    '$appVersion', '$appLang', $audioMinutes, $videoMinutes,
                    $totalMinutes, 1, $firstInstallTime, $nowMs, CURRENT_TIMESTAMP
                ) ON CONFLICT(device_id) DO UPDATE SET
                    device_model = excluded.device_model,
                    android_version = excluded.android_version,
                    app_version = excluded.app_version,
                    app_language = excluded.app_language,
                    audio_playtime_minutes = excluded.audio_playtime_minutes,
                    video_playtime_minutes = excluded.video_playtime_minutes,
                    total_playtime_minutes = excluded.total_playtime_minutes,
                    session_count = session_count + 1,
                    last_active_time = excluded.last_active_time,
                    updated_at = CURRENT_TIMESTAMP;
            """.trimIndent()

            // HTTP POST ریکویسٹ Turso پائپ لائن پر
            val url = URL(TURSO_URL)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8000
                readTimeout = 8000
                doOutput = true
                setRequestProperty("Authorization", "Bearer $TURSO_TOKEN")
                setRequestProperty("Content-Type", "application/json")
            }

            val requestBody = JSONObject().apply {
                val reqArray = JSONArray().apply {
                    put(JSONObject().apply {
                        put("type", "execute")
                        put("stmt", JSONObject().apply {
                            put("sql", upsertSql)
                        })
                    })
                }
                put("requests", reqArray)
            }

            OutputStreamWriter(conn.outputStream).use { writer ->
                writer.write(requestBody.toString())
                writer.flush()
            }

            val responseCode = conn.responseCode
            conn.disconnect()

            if (responseCode == HttpURLConnection.HTTP_OK) {
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putLong(KEY_LAST_SYNC_MS, nowMs)
                    .apply()
            }
        } catch (_: Exception) {
            // اگر نیٹ ورک آف لائن ہو یا کوئی تعطل آئے تو خاموشی سے نظر انداز کر دیا جائے
        }
    }

    private fun escapeSql(str: String): String {
        return str.replace("'", "''")
    }
}
