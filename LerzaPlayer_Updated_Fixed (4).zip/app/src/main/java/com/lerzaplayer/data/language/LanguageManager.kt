package com.lerzaplayer.data.language

import android.content.Context
import androidx.compose.runtime.compositionLocalOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    URDU("ur", "Urdu", "اردو"),
    HINDI("hi", "Hindi", "हिन्दी");

    companion object {
        fun fromCode(code: String): AppLanguage {
            return entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: ENGLISH
        }
    }
}

data class AppStrings(
    // Bottom Tabs
    val tabVideos: String,
    val tabSongs: String,
    val tabPlaylists: String,
    val tabFolders: String,
    val tabAlbums: String,
    val tabArtists: String,

    // Header & Search
    val searchPlaceholder: String,
    val settingsTitle: String,
    val back: String,
    val save: String,
    val cancel: String,
    val delete: String,
    val done: String,
    val selectAll: String,
    val deselectAll: String,

    // Settings Main
    val playtimeTitle: String,
    val backupRestoreTitle: String,
    val themeTitle: String,
    val sleepTimerTitle: String,
    val equalizerTitle: String,
    val vaultTitle: String,
    val recentlyDeletedTitle: String,
    val soundQualityTitle: String,
    val notificationsTitle: String,
    val languageTitle: String,
    val checkForUpdatesTitle: String,
    val aboutTitle: String, // Just "About" without LerzaPlayer

    // Sound Quality & Effects
    val hiResTitle: String,
    val hiResDesc: String,
    val spatialSurroundTitle: String,
    val spatialSurroundDesc: String,
    val gaplessTitle: String,
    val gaplessDesc: String,
    val autoPauseTitle: String,
    val autoPauseDesc: String,
    val crossfadeTitle: String,
    val crossfadeDesc: String,
    val vocalBoosterTitle: String,
    val vocalBoosterDesc: String,

    // Player & Controls
    val volumeBooster: String,
    val volumeBoost5x: String,
    val playAsAudio: () -> String,
    val floatingPip: String,
    val previous: String,
    val next: String,
    val play: String,
    val pause: String,
    val lyricsTitle: String,
    val lyricsUnavailable: String,
    val playbackSpeed: String,
    val shuffleAll: String,

    // Song Actions & Dialogs
    val addToPlaylist: String,
    val setRingtone: String,
    val trackInfo: String,
    val renameSong: String,
    val deleteFromLibrary: String,
    val emptyMusic: String,
    val emptyVideos: String,
    val emptyFavorites: String,
    val emptyPlaylists: String,
    val emptyVault: String,

    // Notifications & Download Monitor
    val newAudioDetected: String,
    val newVideoDetected: String,
    val tapToPlay: String,
    val tapToWatch: String
)

val EnglishStrings = AppStrings(
    tabVideos = "Videos",
    tabSongs = "Songs",
    tabPlaylists = "Playlists",
    tabFolders = "Folders",
    tabAlbums = "Albums",
    tabArtists = "Artists",
    searchPlaceholder = "Search songs, videos, artists...",
    settingsTitle = "Settings",
    back = "Back",
    save = "Save",
    cancel = "Cancel",
    delete = "Delete",
    done = "Done",
    selectAll = "Select All",
    deselectAll = "Deselect All",
    playtimeTitle = "Playtime",
    backupRestoreTitle = "Backup & restore",
    themeTitle = "Theme & style",
    sleepTimerTitle = "Sleep timer",
    equalizerTitle = "Audio Equalizer & Bass",
    vaultTitle = "Hidden files (Vault)",
    recentlyDeletedTitle = "Recently deleted",
    soundQualityTitle = "Sound Quality & Audio Effects",
    notificationsTitle = "Notification settings",
    languageTitle = "Language",
    checkForUpdatesTitle = "Check for Updates",
    aboutTitle = "About",
    hiResTitle = "High-Res Audio Output",
    hiResDesc = "24-bit / 192kHz Studio Master Output",
    spatialSurroundTitle = "3D Spatial Surround Virtualizer",
    spatialSurroundDesc = "Expands soundstage for headphones and earphones",
    gaplessTitle = "Gapless Playback",
    gaplessDesc = "Continuous flow without silence between tracks",
    autoPauseTitle = "Headphone Safety Auto-Pause",
    autoPauseDesc = "Automatically pause when unplugging headphones",
    crossfadeTitle = "Song Crossfade Transition",
    crossfadeDesc = "Fade out ending song while fading in next track",
    vocalBoosterTitle = "Vocal Clarity Booster",
    vocalBoosterDesc = "Enhance speech and vocal clarity in music and videos",
    volumeBooster = "Volume Booster",
    volumeBoost5x = "5X Audio Boost (Up to 300%)",
    playAsAudio = { "Play as Audio" },
    floatingPip = "Floating window (PiP)",
    previous = "Previous",
    next = "Next",
    play = "Play",
    pause = "Pause",
    lyricsTitle = "Lyrics",
    lyricsUnavailable = "Lyrics not available",
    playbackSpeed = "Playback Speed",
    shuffleAll = "Shuffle All",
    addToPlaylist = "Add to Playlist",
    setRingtone = "Set as Phone Ringtone",
    trackInfo = "Track Information",
    renameSong = "Rename Song Title",
    deleteFromLibrary = "Delete from library",
    emptyMusic = "No music found",
    emptyVideos = "No videos found",
    emptyFavorites = "No favorites yet",
    emptyPlaylists = "Create your first playlist",
    emptyVault = "Your Vault is empty",
    newAudioDetected = "New Song Downloaded",
    newVideoDetected = "New Video Downloaded",
    tapToPlay = "Tap to play now",
    tapToWatch = "Tap to watch now"
)

val UrduStrings = AppStrings(
    tabVideos = "ویڈیوز",
    tabSongs = "گانے",
    tabPlaylists = "پلے لسٹس",
    tabFolders = "فولڈرز",
    tabAlbums = "البمز",
    tabArtists = "فنکار",
    searchPlaceholder = "گانے، ویڈیوز، فنکار تلاش کریں...",
    settingsTitle = "ترتیبات",
    back = "واپس",
    save = "محفوظ کریں",
    cancel = "منسوخ کریں",
    delete = "حذف کریں",
    done = "مکمل",
    selectAll = "سب منتخب کریں",
    deselectAll = "انتخاب ختم کریں",
    playtimeTitle = "پلے ٹائم",
    backupRestoreTitle = "بیک اپ اور بحالی",
    themeTitle = "تھیم اور انداز",
    sleepTimerTitle = "سلیپ ٹائمر",
    equalizerTitle = "آڈیو ایکویلائزر اور باس",
    vaultTitle = "چھپی ہوئی فائلیں (والٹ)",
    recentlyDeletedTitle = "حال ہی میں حذف شدہ",
    soundQualityTitle = "صوتی معیار اور آڈیو اثرات",
    notificationsTitle = "نوٹیفکیشن کی ترتیبات",
    languageTitle = "زبان (Language)",
    checkForUpdatesTitle = "اپ ڈیٹس چیک کریں",
    aboutTitle = "کے بارے میں",
    hiResTitle = "ہائی ریزولوشن آڈیو آؤٹ پٹ",
    hiResDesc = "24-بٹ / 192 کلو ہرٹز اسٹوڈیو ماسٹر آؤٹ پٹ",
    spatialSurroundTitle = "تھری ڈی اسپیشل سراؤنڈ ورچوئلائزر",
    spatialSurroundDesc = "ہیڈ فونز اور ایئرفونز کے لیے ساؤنڈ اسٹیج کو وسیع کرتا ہے",
    gaplessTitle = "گیپ لیس پلے بیک",
    gaplessDesc = "ٹریکس کے درمیان خاموشی کے بغیر تسلسل",
    autoPauseTitle = "ہیڈ فون الگ ہونے پر خودکار توقف",
    autoPauseDesc = "ہیڈ فون اتارنے پر خودکار پلے بند ہو جائے گا",
    crossfadeTitle = "سونگ کراس فیڈ ٹرانزیشن",
    crossfadeDesc = "اگلے گانے کو مدہم کرتے ہوئے ملانا",
    vocalBoosterTitle = "ووکل کلیرٹی بوسٹر",
    vocalBoosterDesc = "گانے اور ویڈیو میں آواز کو صاف اور واضح بنائیں",
    volumeBooster = "والیوم بوسٹر",
    volumeBoost5x = "5 گنا زبردست بوسٹ (300% تک)",
    playAsAudio = { "بطور آڈیو چلائیں" },
    floatingPip = "فلوٹنگ ونڈو (PiP)",
    previous = "پچھلا",
    next = "اگلا",
    play = "چلائیں",
    pause = "روکیں",
    lyricsTitle = "شاعری / بول",
    lyricsUnavailable = "شاعری دستیاب نہیں ہے",
    playbackSpeed = "پلے بیک رفتار",
    shuffleAll = "سب شفل کریں",
    addToPlaylist = "پلے لسٹ میں شامل کریں",
    setRingtone = "فون رنگ ٹون مقرر کریں",
    trackInfo = "ٹریک کی تفصیلات",
    renameSong = "گانے کا نام تبدیل کریں",
    deleteFromLibrary = "لائبریری سے حذف کریں",
    emptyMusic = "کوئی گانا نہیں ملا",
    emptyVideos = "کوئی ویڈیو نہیں ملی",
    emptyFavorites = "ابھی تک کوئی پسندیدہ نہیں",
    emptyPlaylists = "اپنی پہلی پلے لسٹ بنائیں",
    emptyVault = "آپ کا والٹ خالی ہے",
    newAudioDetected = "نیا گانا ڈاؤن لوڈ ہوا",
    newVideoDetected = "نئی ویڈیو ڈاؤن لوڈ ہوئی",
    tapToPlay = "سننے کے لیے ٹیپ کریں",
    tapToWatch = "دیکھنے کے لیے ٹیپ کریں"
)

val HindiStrings = AppStrings(
    tabVideos = "वीडियो",
    tabSongs = "गाने",
    tabPlaylists = "प्लेलिस्ट",
    tabFolders = "फ़ोल्डर",
    tabAlbums = "एल्बम",
    tabArtists = "कलाकार",
    searchPlaceholder = "गाने, वीडियो, कलाकार खोजें...",
    settingsTitle = "सेटिंग्स",
    back = "वापस",
    save = "सहेजें",
    cancel = "रद्द करें",
    delete = "हटाएं",
    done = "पूर्ण",
    selectAll = "सभी चुनें",
    deselectAll = "चयन रद्द करें",
    playtimeTitle = "प्ले टाइम",
    backupRestoreTitle = "बैकअप और रीस्टोर",
    themeTitle = "थीम और स्टाइल",
    sleepTimerTitle = "स्लीप टाइमर",
    equalizerTitle = "ऑडियो इक्वलाइज़र और बास",
    vaultTitle = "छिपी हुई फ़ाइलें (वॉल्ट)",
    recentlyDeletedTitle = "हाल ही में हटाए गए",
    soundQualityTitle = "ध्वनि गुणवत्ता और ऑडियो प्रभाव",
    notificationsTitle = "सूचना सेटिंग्स",
    languageTitle = "भाषा (Language)",
    checkForUpdatesTitle = "अपडेट की जाँच करें",
    aboutTitle = "के बारे में",
    hiResTitle = "हाई-रेस ऑडियो आउटपुट",
    hiResDesc = "24-बिट / 192kHz स्टूडियो मास्टर आउटपुट",
    spatialSurroundTitle = "3D स्थानिक सराउंड वर्चुअलाइज़र",
    spatialSurroundDesc = "हेडफ़ोन और इयरफ़ोन के लिए साउंडस्टेज का विस्तार करता है",
    gaplessTitle = "गैपलेस प्लेबैक",
    gaplessDesc = "ट्रैक्स के बीच बिना रुकावट निरंतर प्रवाह",
    autoPauseTitle = "हेडफ़ोन सुरक्षा ऑटो-पॉज़",
    autoPauseDesc = "हेडफ़ोन अनप्लग करने पर स्वचालित रूप से रोकें",
    crossfadeTitle = "सॉन्ग क्रॉसफ़ेड ट्रांज़िशन",
    crossfadeDesc = "अगले ट्रैक में सहज फेड ट्रांज़िशन",
    vocalBoosterTitle = "वोकल क्लैरिटी बूस्टर",
    vocalBoosterDesc = "संगीत और वीडियो में आवाज़ को स्पष्ट और साफ़ बनाएं",
    volumeBooster = "वॉल्यूम बूस्टर",
    volumeBoost5x = "5 गुना शक्तिशाली बूस्ट (300% तक)",
    playAsAudio = { "ऑडियो के रूप में चलाएं" },
    floatingPip = "फ्लोटिंग विंडो (PiP)",
    previous = "पिछला",
    next = "अगला",
    play = "चलाएं",
    pause = "रोकें",
    lyricsTitle = "गीत के बोल",
    lyricsUnavailable = "बोल उपलब्ध नहीं हैं",
    playbackSpeed = "प्लेबैक गति",
    shuffleAll = "सभी शफ़ल करें",
    addToPlaylist = "प्लेलिस्ट में जोड़ें",
    setRingtone = "फ़ोन रिंगटोन सेट करें",
    trackInfo = "ट्रैक जानकारी",
    renameSong = "गाने का नाम बदलें",
    deleteFromLibrary = "लाइब्रेरी से हटाएं",
    emptyMusic = "कोई संगीत नहीं मिला",
    emptyVideos = "कोई वीडियो नहीं मिला",
    emptyFavorites = "अभी तक कोई पसंदीदा नहीं",
    emptyPlaylists = "अपनी पहली प्लेलिस्ट बनाएं",
    emptyVault = "आपका वॉल्ट खाली है",
    newAudioDetected = "नया गाना डाउनलोड हुआ",
    newVideoDetected = "नया वीडियो डाउनलोड हुआ",
    tapToPlay = "सुनने के लिए टैप करें",
    tapToWatch = "देखने के लिए टैप करें"
)

object LanguageManager {
    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    val strings: AppStrings
        get() = when (_currentLanguage.value) {
            AppLanguage.ENGLISH -> EnglishStrings
            AppLanguage.URDU -> UrduStrings
            AppLanguage.HINDI -> HindiStrings
        }

    fun setLanguage(lang: AppLanguage, context: Context? = null) {
        _currentLanguage.value = lang
        if (context != null) {
            runCatching {
                val locale = Locale(lang.code)
                Locale.setDefault(locale)
                val config = context.resources.configuration
                config.setLocale(locale)
                @Suppress("DEPRECATION")
                context.resources.updateConfiguration(config, context.resources.displayMetrics)
            }
        }
    }

    fun getStringsFor(lang: AppLanguage): AppStrings {
        return when (lang) {
            AppLanguage.ENGLISH -> EnglishStrings
            AppLanguage.URDU -> UrduStrings
            AppLanguage.HINDI -> HindiStrings
        }
    }
}

val LocalAppStrings = compositionLocalOf { EnglishStrings }
