package com.lerzaplayer.ui.onboarding

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.lerzaplayer.R
import com.lerzaplayer.data.language.AppLanguage
import com.lerzaplayer.data.language.LanguageManager
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.*
import kotlinx.coroutines.launch
import java.security.MessageDigest

@Composable
fun OnboardingScreen(
    prefManager: PreferenceManager,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val activeColor = ThemeManager.currentThemeColor
    val colors = LocalLerzaColors.current

    var currentStep by remember { mutableIntStateOf(1) }
    val totalSteps = 8

    // زبان کی لوکلائزیشن
    val currentLang by LanguageManager.currentLanguage.collectAsState()

    // تھیم اور وال پیپر کی اسٹیٹ
    var selectedThemeMode by remember { mutableStateOf(ThemeManager.currentThemeMode) }
    var selectedWallpaperUri by remember { mutableStateOf<Uri?>(null) }
    var wallpaperOpacity by remember { mutableFloatStateOf(0.75f) }

    // صارف کا نام
    var userNameInput by remember { mutableStateOf("") }

    // والٹ پاس ورڈ
    var walletPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var passwordError by remember { mutableStateOf("") }

    // پرمیشنز اسٹیٹ
    var isNotificationAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }

    var isAudioAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    var isVideoAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    var isPhotosAllowed by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
            } else {
                ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
            }
        )
    }

    // Launchers
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isNotificationAllowed = granted
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isAudioAllowed = granted
    }

    val videoPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isVideoAllowed = granted
    }

    val photosPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        isPhotosAllowed = granted
    }

    val wallpaperPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedWallpaperUri = uri
            scope.launch {
                prefManager.setWallpaperUri(uri.toString())
            }
        }
    }

    BackHandler(enabled = currentStep > 1) {
        currentStep -= 1
    }

    // SHA-256 Hasher
    fun hashPin(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(pin.toByteArray())
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        // بیک گراؤنڈ وال پیپر لائیو پریویو
        if (selectedWallpaperUri != null) {
            AsyncImage(
                model = selectedWallpaperUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(alpha = wallpaperOpacity)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // ٹاپ ہیڈر اور پروگریس بار
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = activeColor,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Text(
                            text = "Lerza Player",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = colors.textPrimary
                        )
                    }

                    Surface(
                        color = activeColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "$currentStep / $totalSteps",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeColor,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                // پروگریس ڈاٹس
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (i in 1..totalSteps) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    if (i <= currentStep) activeColor else colors.card
                                )
                        )
                    }
                }
            }

            // مین کنٹینٹ ویو
            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                when (currentStep) {
                    // PAGE 1: WELCOME
                    1 -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.verticalScroll(rememberScrollState())
                        ) {
                            Surface(
                                shape = RoundedCornerShape(28.dp),
                                shadowElevation = 10.dp,
                                color = activeColor,
                                modifier = Modifier.size(96.dp)
                            ) {
                                AsyncImage(
                                    model = R.drawable.app_icon,
                                    contentDescription = "Lerza Player Logo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Text(
                                text = "Welcome to Lerza Player",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = colors.textPrimary,
                                textAlign = TextAlign.Center
                            )

                            Text(
                                text = "Let's personalize your player experience.",
                                fontSize = 14.sp,
                                color = colors.textSecondary,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Features
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                FeatureItemRow(
                                    icon = Icons.Default.MusicNote,
                                    title = "Hi-Res Offline Music & 4K Video Playback",
                                    activeColor = activeColor,
                                    colors = colors
                                )
                                FeatureItemRow(
                                    icon = Icons.Default.PlayArrow,
                                    title = "Seamless In-App YouTube Search & Streaming",
                                    activeColor = Color(0xFFFF0000),
                                    colors = colors
                                )
                                FeatureItemRow(
                                    icon = Icons.Default.Lock,
                                    title = "Secure Private Vault with Custom Wallpapers",
                                    activeColor = activeColor,
                                    colors = colors
                                )
                            }
                        }
                    }

                    // PAGE 2: LANGUAGE SELECTION
                    2 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "Select Language / زبان منتخب کریں",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary
                                )
                                Text(
                                    text = "Choose your preferred language",
                                    fontSize = 12.sp,
                                    color = colors.textSecondary
                                )
                            }

                            listOf(
                                AppLanguage.ENGLISH to "English",
                                AppLanguage.URDU to "اردو (Urdu)",
                                AppLanguage.HINDI to "हिन्दी (Hindi)"
                            ).forEach { (lang, display) ->
                                val isSelected = currentLang == lang
                                Surface(
                                    color = if (isSelected) activeColor.copy(alpha = 0.12f) else colors.card,
                                    shape = RoundedCornerShape(16.dp),
                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, activeColor) else null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            LanguageManager.setLanguage(lang, context)
                                            scope.launch { prefManager.setAppLanguage(lang.code) }
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(16.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            RadioButton(
                                                selected = isSelected,
                                                onClick = {
                                                    LanguageManager.setLanguage(lang, context)
                                                    scope.launch { prefManager.setAppLanguage(lang.code) }
                                                },
                                                colors = RadioButtonDefaults.colors(selectedColor = activeColor)
                                            )
                                            Text(
                                                text = display,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = colors.textPrimary
                                            )
                                        }
                                        Text(
                                            text = lang.nativeName,
                                            fontSize = 13.sp,
                                            color = colors.textSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // PAGE 3: THEME & APPEARANCE
                    3 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = "Theme & Appearance",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )

                            // Light / Dark
                            Text("Theme Mode", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = colors.textSecondary)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                listOf("Light", "Dark").forEach { mode ->
                                    val isSelected = selectedThemeMode == mode
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (isSelected) activeColor else colors.card,
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                selectedThemeMode = mode
                                                ThemeManager.setMode(context, mode)
                                                scope.launch {
                                                    prefManager.setTheme(if (mode == "Dark") PreferenceManager.THEME_AMOLED else PreferenceManager.THEME_WHITE)
                                                }
                                            }
                                    ) {
                                        Box(
                                            modifier = Modifier.padding(vertical = 12.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = mode,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) Color.White else colors.textPrimary
                                            )
                                        }
                                    }
                                }
                            }

                            // Theme Accent Colors
                            Text("Accent Colors", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = colors.textSecondary)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                listOf(
                                    LarkPurple to "Purple",
                                    LarkIndigo to "Indigo",
                                    LarkCoral to "Coral",
                                    LarkGreen to "Green",
                                    LarkEmerald to "Emerald"
                                ).forEach { (col, name) ->
                                    val isSelected = activeColor == col
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(CircleShape)
                                            .background(col)
                                            .border(
                                                width = if (isSelected) 3.dp else 0.dp,
                                                color = Color.White,
                                                shape = CircleShape
                                            )
                                            .clickable {
                                                ThemeManager.setTheme(context, col, name)
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // Wallpaper Picker & Opacity
                            Text("Custom Wallpaper", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = colors.textSecondary)
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = colors.card,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { wallpaperPickerLauncher.launch("image/*") }
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = activeColor)
                                        Text(
                                            text = if (selectedWallpaperUri != null) "Change Gallery Wallpaper" else "Choose from Gallery",
                                            fontSize = 14.sp,
                                            color = colors.textPrimary
                                        )
                                    }
                                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = colors.textSecondary)
                                }
                            }

                            if (selectedWallpaperUri != null) {
                                Text(
                                    text = "Wallpaper Opacity: ${(wallpaperOpacity * 100).toInt()}%",
                                    fontSize = 12.sp,
                                    color = colors.textSecondary
                                )
                                Slider(
                                    value = wallpaperOpacity,
                                    onValueChange = {
                                        wallpaperOpacity = it
                                        scope.launch { prefManager.setWallpaperOpacity(it) }
                                    },
                                    valueRange = 0.2f..0.9f,
                                    colors = SliderDefaults.colors(thumbColor = activeColor, activeTrackColor = activeColor)
                                )
                            }
                        }
                    }

                    // PAGE 4: USER NAME
                    4 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = "What should we call you?",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Personalize your Lerza Player experience with your name.",
                                fontSize = 13.sp,
                                color = colors.textSecondary
                            )

                            OutlinedTextField(
                                value = userNameInput,
                                onValueChange = {
                                    userNameInput = it
                                    scope.launch { prefManager.setUserName(it) }
                                },
                                placeholder = { Text("Your name (e.g. Bilal, Ayesha)", color = colors.textSecondary) },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = activeColor,
                                    unfocusedBorderColor = colors.card,
                                    focusedTextColor = colors.textPrimary,
                                    unfocusedTextColor = colors.textPrimary
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Text(
                                text = "ℹ️ This will be displayed on your player profile and greeting.",
                                fontSize = 12.sp,
                                color = colors.textSecondary.copy(alpha = 0.8f)
                            )
                        }
                    }

                    // PAGE 5: WALLET PASSWORD
                    5 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = "Create your Wallet Password",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Protect your private tracks, secret videos, and tokens.",
                                fontSize = 13.sp,
                                color = colors.textSecondary
                            )

                            OutlinedTextField(
                                value = walletPassword,
                                onValueChange = { walletPassword = it },
                                label = { Text("Wallet Passcode") },
                                singleLine = true,
                                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = activeColor),
                                trailingIcon = {
                                    IconButton(onClick = { showPassword = !showPassword }) {
                                        Icon(
                                            imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = null
                                        )
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = confirmPassword,
                                onValueChange = { confirmPassword = it },
                                label = { Text("Confirm Passcode") },
                                singleLine = true,
                                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = activeColor),
                                modifier = Modifier.fillMaxWidth()
                            )

                            if (passwordError.isNotBlank()) {
                                Text(
                                    text = passwordError,
                                    color = Color(0xFFFF334B),
                                    fontSize = 12.sp
                                )
                            }

                            Text(
                                text = "🔒 Your passcode encrypts your hidden vault files locally.",
                                fontSize = 12.sp,
                                color = colors.textSecondary
                            )
                        }
                    }

                    // PAGE 6: NOTIFICATIONS
                    6 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = "Notifications Setup",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Enable background media notification controls",
                                fontSize = 13.sp,
                                color = colors.textSecondary
                            )

                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = colors.card,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Notifications, contentDescription = null, tint = activeColor)
                                        Text(
                                            text = "Playback Drawer Controls",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = colors.textPrimary
                                        )
                                    }
                                    Text(
                                        text = "Allows controlling play/pause, next and previous song directly from lock screen and notification bar.",
                                        fontSize = 12.sp,
                                        color = colors.textSecondary
                                    )

                                    Button(
                                        onClick = {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                            } else {
                                                isNotificationAllowed = true
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isNotificationAllowed) Color(0xFF10B981) else activeColor
                                        ),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = if (isNotificationAllowed) "✓ Notifications Enabled" else "Allow Notifications",
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // PAGE 7: APP PERMISSIONS
                    7 -> {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = "Required App Permissions",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Grant permissions to scan audio and video files on your device.",
                                fontSize = 12.sp,
                                color = colors.textSecondary
                            )

                            // Audio
                            PermissionCard(
                                title = "Music & Audio Access",
                                desc = "Required to play MP3, AAC, FLAC songs from device",
                                isGranted = isAudioAllowed,
                                onAllow = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        audioPermissionLauncher.launch(Manifest.permission.READ_MEDIA_AUDIO)
                                    } else {
                                        audioPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                    }
                                },
                                activeColor = activeColor,
                                colors = colors
                            )

                            // Video
                            PermissionCard(
                                title = "Video & Media Access",
                                desc = "Required to play 4K, HD videos and movie clips",
                                isGranted = isVideoAllowed,
                                onAllow = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        videoPermissionLauncher.launch(Manifest.permission.READ_MEDIA_VIDEO)
                                    } else {
                                        videoPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                    }
                                },
                                activeColor = activeColor,
                                colors = colors
                            )

                            // Photos
                            PermissionCard(
                                title = "Photos & Storage Access",
                                desc = "Required for custom wallpapers and album art",
                                isGranted = isPhotosAllowed,
                                onAllow = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        photosPermissionLauncher.launch(Manifest.permission.READ_MEDIA_IMAGES)
                                    } else {
                                        photosPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                                    }
                                },
                                activeColor = activeColor,
                                colors = colors
                            )
                        }
                    }

                    // PAGE 8: FINAL SETUP / COMPLETION
                    8 -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.verticalScroll(rememberScrollState())
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = activeColor,
                                modifier = Modifier.size(72.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }

                            Text(
                                text = "You're all set!",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = colors.textPrimary,
                                textAlign = TextAlign.Center
                            )

                            Text(
                                text = "Your Lerza Player experience is ready.",
                                fontSize = 14.sp,
                                color = colors.textSecondary,
                                textAlign = TextAlign.Center
                            )

                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = colors.card,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    SummaryItem("Language", currentLang.displayName)
                                    SummaryItem("Theme", ThemeManager.currentThemeName)
                                    SummaryItem("Wallpaper", if (selectedWallpaperUri != null) "Configured" else "Default")
                                    SummaryItem("Wallet", if (walletPassword.isNotBlank()) "Secured" else "Skipped")
                                    SummaryItem("Permissions", "Granted")
                                }
                            }
                        }
                    }
                }
            }

            // باٹم نیویگیشن بٹنز
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (currentStep > 1) {
                    OutlinedButton(
                        onClick = { currentStep -= 1 },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.height(52.dp)
                    ) {
                        Text("Back", color = colors.textPrimary, fontWeight = FontWeight.SemiBold)
                    }
                }

                if (currentStep == 5) {
                    TextButton(
                        onClick = { currentStep = 6 },
                        modifier = Modifier.height(52.dp)
                    ) {
                        Text("Skip for now", color = colors.textSecondary)
                    }
                }

                Button(
                    onClick = {
                        if (currentStep == 5) {
                            if (walletPassword.isNotBlank()) {
                                if (walletPassword.length < 4) {
                                    passwordError = "Password must be at least 4 digits"
                                    return@Button
                                }
                                if (walletPassword != confirmPassword) {
                                    passwordError = "Passwords do not match"
                                    return@Button
                                }
                                passwordError = ""
                                scope.launch {
                                    prefManager.setVaultPin(hashPin(walletPassword))
                                    prefManager.setVaultLockType(VaultLockType.PIN)
                                }
                            }
                            currentStep = 6
                        } else if (currentStep < totalSteps) {
                            currentStep += 1
                        } else {
                            // تمام ترتیبات مکمل
                            scope.launch {
                                prefManager.setOnboardingCompleted(true)
                                onComplete()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Text(
                        text = if (currentStep == totalSteps) "Done" else "Next",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun FeatureItemRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    activeColor: Color,
    colors: LerzaColorPalette
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = colors.card,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = activeColor.copy(alpha = 0.15f),
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = null, tint = activeColor, modifier = Modifier.size(20.dp))
                }
            }
            Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary)
        }
    }
}

@Composable
private fun PermissionCard(
    title: String,
    desc: String,
    isGranted: Boolean,
    onAllow: () -> Unit,
    activeColor: Color,
    colors: LerzaColorPalette
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = colors.card,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                Text(text = desc, fontSize = 11.sp, color = colors.textSecondary)
            }

            Button(
                onClick = onAllow,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isGranted) Color(0xFF10B981) else activeColor
                ),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (isGranted) "✓ Allowed" else "Allow",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun SummaryItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = Color(0xFF10B981),
                modifier = Modifier.size(16.dp)
            )
            Text(text = label, fontSize = 13.sp, color = Color.Gray)
        }
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}
