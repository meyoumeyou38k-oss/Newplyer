@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@file:androidx.media3.common.util.UnstableApi
@file:Suppress("UnsafeOptInUsageError", "OPT_IN_USAGE_DEFAULT", "DEPRECATION")

package com.lerzaplayer.ui.player

import android.app.Activity
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.provider.Settings
import android.util.Rational
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.playback.PlaytimeTracker
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.ThemeManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

enum class VideoGestureMode {
    VOLUME,
    BRIGHTNESS
}

enum class DoubleTapSide {
    LEFT,
    RIGHT
}

private const val ACTION_PIP_PREV = "com.lerzaplayer.PIP_PREV"
private const val ACTION_PIP_PLAY_PAUSE = "com.lerzaplayer.PIP_PLAY_PAUSE"
private const val ACTION_PIP_NEXT = "com.lerzaplayer.PIP_NEXT"

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@androidx.media3.common.util.UnstableApi
@Composable
fun VideoPlayerScreen(
    video: VideoItem,
    isInPipMode: Boolean = false,
    onClose: () -> Unit,
    onPreviousVideo: () -> Unit = {},
    onNextVideo: () -> Unit = {},
    onPlayAsAudio: () -> Unit = {},
    onDeleteVideo: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val currentOnNext by rememberUpdatedState(onNextVideo)
    val currentOnPrev by rememberUpdatedState(onPreviousVideo)
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val activeThemeColor = remember(ThemeManager.currentThemeColor) { ThemeManager.currentThemeColor }

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager }
    val maxAudioVolume = remember(audioManager) {
        audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15
    }

    var audioSessionId by remember { mutableIntStateOf(0) }
    var loudnessEnhancer by remember { mutableStateOf<LoudnessEnhancer?>(null) }
    var volumePercent by remember { mutableIntStateOf(100) }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = true
        }
    }

    var isPlaying by remember { mutableStateOf(true) }
    var currentPos by remember { mutableLongStateOf(0L) }
    var totalDur by remember { mutableLongStateOf(if (video.duration > 0) video.duration else 1L) }
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPos by remember { mutableFloatStateOf(0f) }

    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var showUnlockButton by remember { mutableStateOf(false) }
    var unlockButtonHideJob by remember { mutableStateOf<Job?>(null) }

    var isLandscape by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }

    var showSpeedDialog by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showAudioTracks by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var isLooping by remember { mutableStateOf(false) }

    var is6xFastForwarding by remember { mutableStateOf(false) }

    var zoomScale by remember { mutableFloatStateOf(1f) }
    var zoomOffsetX by remember { mutableFloatStateOf(0f) }
    var zoomOffsetY by remember { mutableFloatStateOf(0f) }

    var activeGesture by remember { mutableStateOf<VideoGestureMode?>(null) }
    var gestureProgress by remember { mutableFloatStateOf(0f) }
    var gestureHideJob by remember { mutableStateOf<Job?>(null) }

    var doubleTapSide by remember { mutableStateOf<DoubleTapSide?>(null) }
    var accumulatedSeekSeconds by remember { mutableIntStateOf(0) }
    var doubleTapResetJob by remember { mutableStateOf<Job?>(null) }
    var lastTapTime by remember { mutableLongStateOf(0L) }

    BackHandler(enabled = isLandscape && !isInPipMode) {
        isLandscape = false
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }

    fun buildPipParams(): PictureInPictureParams? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || activity == null) return null
        return runCatching {
            val actions = ArrayList<RemoteAction>()

            val prevIntent = Intent(ACTION_PIP_PREV).apply { setPackage(activity.packageName) }
            val prevPending = PendingIntent.getBroadcast(activity, 101, prevIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val prevIcon = android.graphics.drawable.Icon.createWithResource(activity, android.R.drawable.ic_media_previous)
            actions.add(RemoteAction(prevIcon, "Previous", "Previous", prevPending))

            val playPauseIntent = Intent(ACTION_PIP_PLAY_PAUSE).apply { setPackage(activity.packageName) }
            val playPausePending = PendingIntent.getBroadcast(activity, 102, playPauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val playPauseIcon = android.graphics.drawable.Icon.createWithResource(activity, if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
            actions.add(RemoteAction(playPauseIcon, if (isPlaying) "Pause" else "Play", if (isPlaying) "Pause" else "Play", playPausePending))

            val nextIntent = Intent(ACTION_PIP_NEXT).apply { setPackage(activity.packageName) }
            val nextPending = PendingIntent.getBroadcast(activity, 103, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val nextIcon = android.graphics.drawable.Icon.createWithResource(activity, android.R.drawable.ic_media_next)
            actions.add(RemoteAction(nextIcon, "Next", "Next", nextPending))

            PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .setActions(actions)
                .build()
        }.getOrNull()
    }

    fun updatePipActions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null) {
            buildPipParams()?.let { params ->
                runCatching { activity.setPictureInPictureParams(params) }
            }
        }
    }

    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    ACTION_PIP_PREV -> currentOnPrev()
                    ACTION_PIP_PLAY_PAUSE -> {
                        if (exoPlayer.isPlaying) {
                            exoPlayer.pause()
                            isPlaying = false
                        } else {
                            exoPlayer.play()
                            isPlaying = true
                        }
                        updatePipActions()
                    }
                    ACTION_PIP_NEXT -> currentOnNext()
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(ACTION_PIP_PREV)
            addAction(ACTION_PIP_PLAY_PAUSE)
            addAction(ACTION_PIP_NEXT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        onDispose {
            runCatching { context.unregisterReceiver(receiver) }
        }
    }

    LaunchedEffect(Unit) {
        val curVol = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: (maxAudioVolume / 2)
        volumePercent = ((curVol.toFloat() / maxAudioVolume.coerceAtLeast(1).toFloat()) * 100f).toInt().coerceIn(0, 100)
    }

    fun applyVolumeAndBoost(targetPercent: Int) {
        val clampedPercent = targetPercent.coerceIn(0, 300)
        volumePercent = clampedPercent
        if (clampedPercent <= 100) {
            val streamVol = Math.round((clampedPercent / 100f) * maxAudioVolume).coerceIn(0, maxAudioVolume)
            audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, streamVol, 0)
            exoPlayer.volume = 1.0f
            try {
                loudnessEnhancer?.apply {
                    setTargetGain(0)
                    enabled = false
                }
            } catch (_: Exception) {}
        } else {
            audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, maxAudioVolume, 0)
            exoPlayer.volume = 1.0f
            try {
                if (loudnessEnhancer == null && audioSessionId != 0 && audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
                    loudnessEnhancer = LoudnessEnhancer(audioSessionId)
                }
                val boostGainMb = ((clampedPercent - 100) * 25).coerceIn(0, 5000)
                loudnessEnhancer?.apply {
                    enabled = true
                    setTargetGain(boostGainMb)
                }
            } catch (_: Exception) {}
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    val d = exoPlayer.duration
                    if (d > 0) {
                        totalDur = d
                    }
                    updatePipActions()
                } else if (playbackState == Player.STATE_ENDED) {
                    if (!isLooping) {
                        currentOnNext()
                    }
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                updatePipActions()
            }

            override fun onAudioSessionIdChanged(newAudioSessionId: Int) {
                audioSessionId = newAudioSessionId
                if (newAudioSessionId != C.AUDIO_SESSION_ID_UNSET && newAudioSessionId != 0) {
                    try {
                        loudnessEnhancer?.release()
                        loudnessEnhancer = LoudnessEnhancer(newAudioSessionId).apply {
                            if (volumePercent > 100) {
                                enabled = true
                                val boostGainMb = ((volumePercent - 100) * 35).coerceIn(0, 8000)
                                setTargetGain(boostGainMb)
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            try {
                loudnessEnhancer?.release()
                loudnessEnhancer = null
            } catch (_: Exception) {}
            exoPlayer.release()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    LaunchedEffect(video.id, video.contentUri) {
        currentPos = 0L
        scrubPos = 0f
        isScrubbing = false
        totalDur = if (video.duration > 0) video.duration else 1L
        isPlaying = true
        controlsVisible = true
        is6xFastForwarding = false
        zoomScale = 1f
        zoomOffsetX = 0f
        zoomOffsetY = 0f

        exoPlayer.setMediaItem(MediaItem.fromUri(video.contentUri))
        exoPlayer.prepare()
        exoPlayer.play()
        exoPlayer.playbackParameters = PlaybackParameters(playbackSpeed)
    }

    LaunchedEffect(controlsVisible, showMoreMenu, showSpeedDialog, showInfoDialog, showAudioTracks, showDeleteConfirm, isLocked, isInPipMode) {
        if (controlsVisible && !isLocked && !isInPipMode && !showMoreMenu && !showSpeedDialog && !showInfoDialog && !showAudioTracks && !showDeleteConfirm) {
            delay(4200)
            controlsVisible = false
        }
    }

    LaunchedEffect(exoPlayer) {
        while (isActive) {
            if (exoPlayer.isPlaying && !isScrubbing) {
                currentPos = exoPlayer.currentPosition
                val d = exoPlayer.duration
                if (d > 0) {
                    totalDur = d
                }
                PlaytimeTracker.addVideoTime(context, 350L)
            }
            delay(350)
        }
    }

    val audioTrackOptions = remember(exoPlayer.currentTracks) {
        exoPlayer.currentTracks.groups
            .filter { it.type == C.TRACK_TYPE_AUDIO }
            .flatMap { group ->
                (0 until group.length).map { index ->
                    val format = group.getTrackFormat(index)
                    AudioTrackOption(
                        group = group.mediaTrackGroup,
                        index = index,
                        label = format.label ?: format.language ?: "Audio ${index + 1}"
                    )
                }
            }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isLocked, isInPipMode, playbackSpeed, totalDur) {
                if (isInPipMode) return@pointerInput

                val screenWidth = size.width.toFloat()
                val screenHeight = size.height.toFloat()
                val touchSlopPx = with(density) { 14.dp.toPx() }

                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startX = down.position.x
                    val isLeft25 = startX <= (screenWidth * 0.35f)
                    val isRight25 = startX >= (screenWidth * 0.65f)

                    var isDraggingVertical = false
                    var initialDragValue = 0f

                    if (isLocked) {
                        showUnlockButton = true
                        unlockButtonHideJob?.cancel()
                        unlockButtonHideJob = scope.launch {
                            delay(3500)
                            showUnlockButton = false
                        }
                        return@awaitEachGesture
                    }

                    var longPressTriggered = false
                    val longPressJob = scope.launch {
                        delay(380)
                        if (!isDraggingVertical && !isLocked && !isInPipMode) {
                            longPressTriggered = true
                            is6xFastForwarding = true
                            exoPlayer.playbackParameters = PlaybackParameters(6.0f)
                        }
                    }

                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break

                        if (change.pressed) {
                            val currentTouchPos = change.position
                            val deltaX = currentTouchPos.x - startX
                            val deltaY = currentTouchPos.y - down.position.y
                            val distance = abs(deltaY)

                            if (!isDraggingVertical && (isLeft25 || isRight25) && distance > touchSlopPx && abs(deltaY) > abs(deltaX)) {
                                isDraggingVertical = true
                                longPressJob.cancel()
                                if (longPressTriggered) {
                                    is6xFastForwarding = false
                                    exoPlayer.playbackParameters = PlaybackParameters(playbackSpeed)
                                    longPressTriggered = false
                                }

                                gestureHideJob?.cancel()
                                if (isRight25) {
                                    activeGesture = VideoGestureMode.VOLUME
                                    initialDragValue = volumePercent.toFloat()
                                    gestureProgress = initialDragValue
                                } else {
                                    activeGesture = VideoGestureMode.BRIGHTNESS
                                    val curBrightness = activity?.window?.attributes?.screenBrightness ?: -1f
                                    val brVal = if (curBrightness < 0f) {
                                        try {
                                            Settings.System.getInt(
                                                context.contentResolver,
                                                Settings.System.SCREEN_BRIGHTNESS
                                            ) / 255f
                                        } catch (_: Exception) { 0.5f }
                                    } else curBrightness
                                    initialDragValue = (brVal * 100f).coerceIn(0f, 100f)
                                    gestureProgress = initialDragValue
                                }
                            }

                            if (isDraggingVertical) {
                                change.consume()
                                val totalDeltaY = down.position.y - currentTouchPos.y
                                val dragFraction = totalDeltaY / (screenHeight * 0.5f)

                                if (activeGesture == VideoGestureMode.VOLUME) {
                                    val newVol = (initialDragValue + dragFraction * 300f).coerceIn(0f, 300f)
                                    gestureProgress = newVol
                                    applyVolumeAndBoost(newVol.toInt())
                                } else if (activeGesture == VideoGestureMode.BRIGHTNESS) {
                                    val newBr = (initialDragValue + dragFraction * 100f).coerceIn(0f, 100f)
                                    gestureProgress = newBr
                                    val lp = activity?.window?.attributes
                                    if (lp != null) {
                                        lp.screenBrightness = (newBr / 100f).coerceIn(0.01f, 1.0f)
                                        activity.window.attributes = lp
                                    }
                                }
                            }
                        } else {
                            change.consume()
                            break
                        }
                    }

                    longPressJob.cancel()
                    if (is6xFastForwarding) {
                        is6xFastForwarding = false
                        exoPlayer.playbackParameters = PlaybackParameters(playbackSpeed)
                    }

                    if (isDraggingVertical) {
                        gestureHideJob = scope.launch {
                            delay(1200)
                            activeGesture = null
                        }
                    } else if (!longPressTriggered) {
                        val currentTime = System.currentTimeMillis()
                        val timeDiff = currentTime - lastTapTime
                        lastTapTime = currentTime

                        if (timeDiff < 300) {
                            if (isRight25) {
                                val step = 10
                                accumulatedSeekSeconds = if (accumulatedSeekSeconds >= 0) accumulatedSeekSeconds + step else step
                                doubleTapSide = DoubleTapSide.RIGHT
                                val newTarget = (exoPlayer.currentPosition + (accumulatedSeekSeconds * 1000L)).coerceIn(0L, totalDur)
                                exoPlayer.seekTo(newTarget)
                                currentPos = newTarget

                                doubleTapResetJob?.cancel()
                                doubleTapResetJob = scope.launch {
                                    delay(800)
                                    doubleTapSide = null
                                    accumulatedSeekSeconds = 0
                                }
                            } else if (isLeft25) {
                                val step = -10
                                accumulatedSeekSeconds = if (accumulatedSeekSeconds <= 0) accumulatedSeekSeconds + step else step
                                doubleTapSide = DoubleTapSide.LEFT
                                val newTarget = (exoPlayer.currentPosition + (accumulatedSeekSeconds * 1000L)).coerceIn(0L, totalDur)
                                exoPlayer.seekTo(newTarget)
                                currentPos = newTarget

                                doubleTapResetJob?.cancel()
                                doubleTapResetJob = scope.launch {
                                    delay(800)
                                    doubleTapSide = null
                                    accumulatedSeekSeconds = 0
                                }
                            } else {
                                controlsVisible = !controlsVisible
                            }
                        } else {
                            controlsVisible = !controlsVisible
                        }
                    }
                }
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    this.resizeMode = resizeMode
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { playerView ->
                playerView.player = exoPlayer
                playerView.resizeMode = resizeMode
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = if (isInPipMode) 1f else zoomScale,
                    scaleY = if (isInPipMode) 1f else zoomScale,
                    translationX = if (isInPipMode) 0f else zoomOffsetX,
                    translationY = if (isInPipMode) 0f else zoomOffsetY
                )
                .pointerInput(isLocked, isInPipMode) {
                    if (!isLocked && !isInPipMode) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val newScale = (zoomScale * zoom).coerceIn(1f, 5.0f)
                            zoomScale = newScale
                            if (newScale > 1f) {
                                val maxPanX = (size.width * (newScale - 1f)) / 2f
                                val maxPanY = (size.height * (newScale - 1f)) / 2f
                                zoomOffsetX = (zoomOffsetX + pan.x * newScale).coerceIn(-maxPanX, maxPanX)
                                zoomOffsetY = (zoomOffsetY + pan.y * newScale).coerceIn(-maxPanY, maxPanY)
                            } else {
                                zoomOffsetX = 0f
                                zoomOffsetY = 0f
                            }
                        }
                    }
                }
        )

        if (!isInPipMode) {
            AnimatedVisibility(
                visible = isLocked && showUnlockButton,
                enter = fadeIn(tween(150)) + scaleIn(tween(150)),
                exit = fadeOut(tween(250)) + scaleOut(tween(250)),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .statusBarsPadding()
                    .padding(start = 24.dp, top = 20.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.Black.copy(alpha = 0.82f),
                    border = BorderStroke(1.5.dp, activeThemeColor),
                    shadowElevation = 12.dp,
                    modifier = Modifier.clickable {
                        isLocked = false
                        controlsVisible = true
                        showUnlockButton = false
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = LerzaIcons.Lock,
                            contentDescription = "Unlock",
                            tint = activeThemeColor,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Tap to unlock",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = activeGesture == VideoGestureMode.BRIGHTNESS,
                enter = fadeIn(tween(150)),
                exit = fadeOut(tween(250)),
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 24.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.BrightnessMedium,
                        contentDescription = "Brightness",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "${gestureProgress.toInt()}%",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Box(
                        modifier = Modifier
                            .width(32.dp)
                            .height(160.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.28f)),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        val fillFrac = (gestureProgress / 100f).coerceIn(0f, 1f)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(fillFrac)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White)
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = activeGesture == VideoGestureMode.VOLUME,
                enter = fadeIn(tween(150)),
                exit = fadeOut(tween(250)),
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 24.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isBoosted = gestureProgress > 100f
                    Icon(
                        imageVector = if (gestureProgress <= 0f) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = "Volume",
                        tint = if (isBoosted) activeThemeColor else Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "${gestureProgress.toInt()}%",
                        color = if (isBoosted) activeThemeColor else Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Box(
                        modifier = Modifier
                            .width(32.dp)
                            .height(160.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.28f)),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        val fillFrac = if (gestureProgress <= 100f) {
                            (gestureProgress / 100f) * 0.50f
                        } else {
                            0.50f + ((gestureProgress - 100f) / 200f) * 0.50f
                        }.coerceIn(0f, 1f)

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(fillFrac)
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isBoosted) activeThemeColor else Color.White)
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = is6xFastForwarding,
                enter = fadeIn(tween(120)),
                exit = fadeOut(tween(200)),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 68.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.85f),
                    border = BorderStroke(1.5.dp, activeThemeColor),
                    shadowElevation = 10.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = LerzaIcons.FastForward,
                            contentDescription = null,
                            tint = activeThemeColor,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "6X Speed",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = doubleTapSide == DoubleTapSide.RIGHT,
                enter = fadeIn(tween(100)),
                exit = fadeOut(tween(200)),
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 40.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.72f),
                    border = BorderStroke(1.2.dp, activeThemeColor.copy(alpha = 0.8f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = LerzaIcons.FastForward,
                            contentDescription = "Forward",
                            tint = activeThemeColor,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "+${accumulatedSeekSeconds}s",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = doubleTapSide == DoubleTapSide.LEFT,
                enter = fadeIn(tween(100)),
                exit = fadeOut(tween(200)),
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 40.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.72f),
                    border = BorderStroke(1.2.dp, activeThemeColor.copy(alpha = 0.8f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = LerzaIcons.FastRewind,
                            contentDescription = "Rewind",
                            tint = activeThemeColor,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "${accumulatedSeekSeconds}s",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = controlsVisible && !isLocked,
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(200)),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.50f))
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f, fill = false)
                        ) {
                            VideoGlassIconButton(
                                icon = LerzaIcons.ArrowBack,
                                contentDescription = "Back",
                                onClick = {
                                    if (isLandscape) {
                                        isLandscape = false
                                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                    } else {
                                        onClose()
                                    }
                                }
                            )
                            Text(
                                text = video.title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box {
                                VideoGlassIconButton(
                                    icon = LerzaIcons.MoreVert,
                                    contentDescription = "Options",
                                    onClick = { showMoreMenu = true }
                                )

                                DropdownMenu(
                                    expanded = showMoreMenu,
                                    onDismissRequest = { showMoreMenu = false },
                                    modifier = Modifier
                                        .background(Color(0xFF0F131A))
                                        .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(14.dp))
                                ) {
                                    VideoMenuItem(
                                        icon = LerzaIcons.Share,
                                        title = "Share",
                                        accentTint = Color(0xFF38BDF8),
                                        onClick = {
                                            showMoreMenu = false
                                            runCatching {
                                                val share = Intent(Intent.ACTION_SEND).apply {
                                                    type = "video/*"
                                                    putExtra(Intent.EXTRA_STREAM, video.contentUri)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(share, "Share video"))
                                            }
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.Videocam,
                                        title = "Floating window (PiP)",
                                        accentTint = Color(0xFF2DD4BF),
                                        onClick = {
                                            showMoreMenu = false
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null) {
                                                controlsVisible = false
                                                buildPipParams()?.let { params ->
                                                    activity.enterPictureInPictureMode(params)
                                                } ?: run {
                                                    val fallbackParams = PictureInPictureParams.Builder()
                                                        .setAspectRatio(Rational(16, 9))
                                                        .build()
                                                    activity.enterPictureInPictureMode(fallbackParams)
                                                }
                                            }
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.Repeat,
                                        title = if (isLooping) "Repeat: One" else "Repeat: Off",
                                        accentTint = Color(0xFFA78BFA),
                                        onClick = {
                                            isLooping = !isLooping
                                            exoPlayer.repeatMode = if (isLooping) {
                                                Player.REPEAT_MODE_ONE
                                            } else {
                                                Player.REPEAT_MODE_OFF
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.AspectRatio,
                                        title = "Scale adjust",
                                        accentTint = Color(0xFF34D399),
                                        onClick = {
                                            resizeMode = when (resizeMode) {
                                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.ScreenRotation,
                                        title = if (isLandscape) "Switch to Portrait" else "Switch to Landscape",
                                        accentTint = Color(0xFF60A5FA),
                                        onClick = {
                                            isLandscape = !isLandscape
                                            activity?.requestedOrientation = if (isLandscape) {
                                                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                            } else {
                                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    VideoMenuItem(
                                        icon = LerzaIcons.Info,
                                        title = "Video details",
                                        accentTint = Color(0xFFFBBF24),
                                        onClick = {
                                            showMoreMenu = false
                                            showInfoDialog = true
                                        }
                                    )
                                    HorizontalDivider(color = Color.White.copy(alpha = 0.12f), thickness = 0.8.dp)
                                    VideoMenuItem(
                                        icon = LerzaIcons.Delete,
                                        title = "Delete video",
                                        accentTint = Color(0xFFFF4D4D),
                                        textColor = Color(0xFFFF4D4D),
                                        onClick = {
                                            showMoreMenu = false
                                            showDeleteConfirm = true
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onPlayAsAudio, modifier = Modifier.size(44.dp)) {
                                Icon(
                                    imageVector = LerzaIcons.Headphones,
                                    contentDescription = "Play as audio",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { showSpeedDialog = true }
                                    .padding(horizontal = 6.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = LerzaIcons.Speed,
                                    contentDescription = "Playback speed",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    text = "${playbackSpeed}x",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            IconButton(
                                onClick = {
                                    isLocked = true
                                    controlsVisible = false
                                    showUnlockButton = true
                                    unlockButtonHideJob?.cancel()
                                    unlockButtonHideJob = scope.launch {
                                        delay(3500)
                                        showUnlockButton = false
                                    }
                                },
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = LerzaIcons.Lock,
                                    contentDescription = "Lock controls",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            IconButton(
                                onClick = {
                                    isLandscape = !isLandscape
                                    activity?.requestedOrientation = if (isLandscape) {
                                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    } else {
                                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                    }
                                },
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = LerzaIcons.ScreenRotation,
                                    contentDescription = "Rotate screen",
                                    tint = if (isLandscape) activeThemeColor else Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            IconButton(
                                onClick = {
                                    resizeMode = when (resizeMode) {
                                        AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                        AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    }
                                },
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = LerzaIcons.AspectRatio,
                                    contentDescription = "Scale adjust",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val curSec = if (isScrubbing) (scrubPos * totalDur).toLong() / 1000L else currentPos / 1000L
                            val totSec = totalDur / 1000L

                            Text(
                                text = "%d:%02d".format(curSec / 60, curSec % 60),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(42.dp),
                                textAlign = TextAlign.Start
                            )

                            val progressFraction = if (totalDur > 0) {
                                if (isScrubbing) scrubPos else (currentPos.toFloat() / totalDur.toFloat()).coerceIn(0f, 1f)
                            } else 0f

                            Slider(
                                value = progressFraction,
                                onValueChange = { frac ->
                                    isScrubbing = true
                                    scrubPos = frac
                                },
                                onValueChangeFinished = {
                                    val target = (scrubPos * totalDur).toLong().coerceIn(0L, totalDur)
                                    exoPlayer.seekTo(target)
                                    currentPos = target
                                    isScrubbing = false
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = activeThemeColor,
                                    activeTrackColor = activeThemeColor,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(28.dp)
                            )

                            Text(
                                text = "%d:%02d".format(totSec / 60, totSec % 60),
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(42.dp),
                                textAlign = TextAlign.End
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.Black.copy(alpha = 0.40f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
                                modifier = Modifier.size(52.dp)
                            ) {
                                IconButton(onClick = onPreviousVideo, modifier = Modifier.fillMaxSize()) {
                                    Icon(
                                        imageVector = LerzaIcons.SkipPrevious,
                                        contentDescription = "Previous video",
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(28.dp))

                            Surface(
                                shape = CircleShape,
                                color = Color.Black.copy(alpha = 0.48f),
                                border = BorderStroke(1.2.dp, Color.White.copy(alpha = 0.28f)),
                                modifier = Modifier.size(68.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        if (exoPlayer.isPlaying) {
                                            exoPlayer.pause()
                                            isPlaying = false
                                        } else {
                                            exoPlayer.play()
                                            isPlaying = true
                                        }
                                        updatePipActions()
                                    },
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) LerzaIcons.Pause else LerzaIcons.PlayArrow,
                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                        tint = Color.White,
                                        modifier = Modifier.size(34.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(28.dp))

                            Surface(
                                shape = CircleShape,
                                color = Color.Black.copy(alpha = 0.40f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
                                modifier = Modifier.size(52.dp)
                            ) {
                                IconButton(onClick = onNextVideo, modifier = Modifier.fillMaxSize()) {
                                    Icon(
                                        imageVector = LerzaIcons.SkipNext,
                                        contentDescription = "Next video",
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (showSpeedDialog) {
                AlertDialog(
                    onDismissRequest = { showSpeedDialog = false },
                    title = { Text("Playback Speed", color = Color.White, fontWeight = FontWeight.Bold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (playbackSpeed == spd) activeThemeColor.copy(alpha = 0.25f) else Color.Transparent)
                                        .clickable {
                                            playbackSpeed = spd
                                            exoPlayer.playbackParameters = PlaybackParameters(spd)
                                            showSpeedDialog = false
                                        }
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (spd == 1.0f) "1.0x (Normal)" else "${spd}x",
                                        color = if (playbackSpeed == spd) activeThemeColor else Color.White,
                                        fontWeight = if (playbackSpeed == spd) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showSpeedDialog = false }) {
                            Text("Cancel", color = activeThemeColor)
                        }
                    },
                    containerColor = Color(0xFF131922)
                )
            }

            if (showInfoDialog) {
                AlertDialog(
                    onDismissRequest = { showInfoDialog = false },
                    title = { Text("Video Details", color = Color.White, fontWeight = FontWeight.Bold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Title: ${video.title}", color = Color.White, fontSize = 13.sp)
                            Text("Duration: ${video.durationFormatted}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                            Text("Resolution: ${video.resolution}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                            Text("Folder: ${video.folderName}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                            Text("Location: ${video.path}", color = Color.Gray, fontSize = 11.sp)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showInfoDialog = false }) {
                            Text("OK", color = activeThemeColor)
                        }
                    },
                    containerColor = Color(0xFF131922)
                )
            }

            if (showAudioTracks) {
                AlertDialog(
                    onDismissRequest = { showAudioTracks = false },
                    title = { Text("Audio Track", color = Color.White, fontWeight = FontWeight.Bold) },
                    text = {
                        if (audioTrackOptions.isEmpty()) {
                            Text("No alternate audio tracks are available for this video.", color = Color.White.copy(alpha = 0.8f))
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                audioTrackOptions.forEach { option ->
                                    TextButton(
                                        onClick = {
                                            exoPlayer.trackSelectionParameters =
                                                exoPlayer.trackSelectionParameters.buildUpon()
                                                    .setOverrideForType(TrackSelectionOverride(option.group, option.index))
                                                    .build()
                                            showAudioTracks = false
                                        }
                                    ) {
                                        Text(option.label, color = activeThemeColor)
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showAudioTracks = false }) {
                            Text("Close", color = activeThemeColor)
                        }
                    },
                    containerColor = Color(0xFF131922)
                )
            }

            if (showDeleteConfirm) {
                AlertDialog(
                    onDismissRequest = { showDeleteConfirm = false },
                    title = { Text("Delete this video?", color = Color.White, fontWeight = FontWeight.Bold) },
                    text = { Text("This removes the video from device storage permanently.", color = Color.White.copy(alpha = 0.8f)) },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                showDeleteConfirm = false
                                onDeleteVideo()
                                onClose()
                            }
                        ) { Text("Delete", color = Color(0xFFFF334B), fontWeight = FontWeight.Bold) }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel", color = Color.White) }
                    },
                    containerColor = Color(0xFF131922)
                )
            }
        }
    }
}

@Composable
private fun VideoGlassIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String?,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Surface(
        shape = CircleShape,
        color = Color.Black.copy(alpha = 0.40f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
        modifier = Modifier.size(40.dp)
    ) {
        IconButton(onClick = onClick, modifier = Modifier.fillMaxSize()) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = tint,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun VideoMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    accentTint: Color = Color(0xFF00E5FF),
    textColor: Color = Color.White,
    onClick: () -> Unit
) {
    DropdownMenuItem(
        text = {
            Text(
                text = title,
                color = textColor,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.SemiBold
            )
        },
        leadingIcon = {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentTint.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentTint,
                    modifier = Modifier.size(17.dp)
                )
            }
        },
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
    )
}

private data class AudioTrackOption(
    val group: TrackGroup,
    val index: Int,
    val label: String
)
