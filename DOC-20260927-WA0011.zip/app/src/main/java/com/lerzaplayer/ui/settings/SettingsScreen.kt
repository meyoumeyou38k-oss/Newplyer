package com.lerzaplayer.ui.settings

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onScanMedia: () -> Unit,
    onOpenVault: () -> Unit = {},
    recentlyDeleted: List<RecentlyDeletedEntity> = emptyList(),
    onPlayRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onRestoreRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onPermanentlyDeleteRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentTheme by prefManager.themeFlow.collectAsState(initial = "Pure White")
    val wallpaperUri by prefManager.wallpaperUriFlow.collectAsState(initial = null)
    val wallpaperOpacity by prefManager.wallpaperOpacityFlow.collectAsState(initial = 0.75f)

    val wallpaperPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            scope.launch {
                prefManager.setWallpaperUri(uri.toString())
            }
        }
    }

    Scaffold(
        topBar = {
            Surface(
                color = colors.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(
                                imageVector = LerzaIcons.ArrowBack,
                                contentDescription = "Back",
                                tint = colors.textPrimary
                            )
                        }
                        Column {
                            Text(
                                text = "Lerza Player Settings",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Media Import, Themes, Trash & Performance",
                                fontSize = 11.sp,
                                color = colors.textSecondary
                            )
                        }
                    }
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = LerzaIcons.Close,
                            contentDescription = "Close",
                            tint = colors.textSecondary
                        )
                    }
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item {
                SettingsHeroCard()
            }

            // RECENTLY DELETED SECTION (WITH PLAY & RESTORE)
            item {
                SettingsCard(
                    title = "RECENTLY DELETED (30 DAYS TRASH)",
                    icon = LerzaIcons.Delete
                ) {
                    Text(
                        text = if (recentlyDeleted.isEmpty()) {
                            "Deleted songs and videos stay safe here for 30 days. You can play to verify, restore them anytime, or let them auto-delete after 30 days."
                        } else {
                            "${recentlyDeleted.size} item(s) are stored safely for 30 days. Tap play to check before restoring."
                        },
                        fontSize = 13.sp,
                        color = colors.textSecondary
                    )

                    if (recentlyDeleted.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        recentlyDeleted.forEach { item ->
                            val daysLeft = remember(item.deletedAt) {
                                val passed = System.currentTimeMillis() - item.deletedAt
                                val remaining = (30L * 24 * 60 * 60 * 1000 - passed) / (24 * 60 * 60 * 1000)
                                remaining.coerceAtLeast(1)
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(colors.card)
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Play Button to preview the deleted song
                                IconButton(
                                    onClick = { onPlayRecentlyDeleted(item) },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF1E60F2).copy(alpha = 0.15f))
                                ) {
                                    Icon(
                                        imageVector = LerzaIcons.PlayArrow,
                                        contentDescription = "Play to check",
                                        tint = Color(0xFF1E60F2),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.originalName,
                                        color = colors.textPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1
                                    )
                                    Text(
                                        text = "${item.mediaType} • Auto-deletes in $daysLeft day(s)",
                                        fontSize = 11.sp,
                                        color = Color(0xFFFFB020)
                                    )
                                }

                                // Restore Button
                                Button(
                                    onClick = { onRestoreRecentlyDeleted(item) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(LerzaIcons.Restore, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Restore", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                // Delete forever Button
                                IconButton(
                                    onClick = { onPermanentlyDeleteRecentlyDeleted(item) },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        LerzaIcons.Delete,
                                        contentDescription = "Delete forever",
                                        tint = Color(0xFFFF334B),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                SettingsCard(
                    title = "SCAN & IMPORT MEDIA",
                    icon = LerzaIcons.Folder
                ) {
                    Text(
                        text = "Scan storage to index newly downloaded songs, albums, and video files.",
                        fontSize = 13.sp,
                        color = colors.textSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onScanMedia,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60F2)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(LerzaIcons.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Import & Rescan Media")
                    }
                }
            }

            item {
                SettingsCard(
                    title = "BACKGROUND PLAYBACK & PERFORMANCE",
                    icon = LerzaIcons.Tune
                ) {
                    Text(
                        text = "Prevent Android OS from pausing music when the screen turns off or while using other applications.",
                        fontSize = 13.sp,
                        color = colors.textSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = {
                            try {
                                val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(LerzaIcons.CheckCircle, contentDescription = null, tint = Color(0xFF00C853), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Request Battery Exemption")
                    }
                }
            }

            item {
                SettingsCard(
                    title = "APP THEME COLORS",
                    icon = LerzaIcons.Palette
                ) {
                    val themeList = listOf(
                        "AMOLED Black" to Color(0xFF000000),
                        "Pure White" to Color(0xFFFFFFFF),
                        "Soft Rose" to Color(0xFFFF4081),
                        "Mint Sage" to Color(0xFF00E676),
                        "Pastel Sky" to Color(0xFF00B0FF),
                        "Soft Lavender" to Color(0xFFB388FF),
                        "Sunset Amber" to Color(0xFFFFAB00)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        themeList.forEach { (themeName, colorSample) ->
                            val isSelected = currentTheme == themeName
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) Color(0xFF1E60F2).copy(alpha = 0.12f) else colors.card)
                                    .clickable {
                                        scope.launch { prefManager.setTheme(themeName) }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(22.dp)
                                            .clip(CircleShape)
                                            .background(colorSample)
                                            .border(1.dp, Color.Gray.copy(alpha = 0.5f), CircleShape)
                                    )
                                    Text(
                                        text = themeName,
                                        fontSize = 14.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = colors.textPrimary
                                    )
                                }
                                if (isSelected) {
                                    Icon(
                                        imageVector = LerzaIcons.Check,
                                        contentDescription = "Selected",
                                        tint = Color(0xFF1E60F2),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                SettingsCard(
                    title = "AUDIO ENHANCEMENT & EQUALIZER",
                    icon = LerzaIcons.Tune
                ) {
                    Text(
                        text = "10-Band Equalizer, Bass Boost & Lark Player Audio Presets.",
                        fontSize = 13.sp,
                        color = colors.textSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onOpenEqualizer,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B0FF)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(LerzaIcons.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open Audio Equalizer")
                    }
                }
            }

            item {
                SettingsCard(
                    title = "PRIVATE MEDIA VAULT",
                    icon = LerzaIcons.Lock
                ) {
                    Text(
                        text = "Keep private audio and video in a device-protected vault with a PIN or pattern.",
                        fontSize = 13.sp,
                        color = colors.textSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onOpenVault,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60F2)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(LerzaIcons.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open Private Vault")
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = LocalLerzaColors.current
    Surface(
        color = colors.surface,
        shape = RoundedCornerShape(22.dp),
        shadowElevation = if (colors.isDark) 0.dp else 4.dp,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (colors.isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFDBE5F3)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(19.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFF1E60F2),
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    color = Color(0xFF1E60F2)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingsHeroCard() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF0E2D62), Color(0xFF1D63D8), Color(0xFF00A8C7))
                )
            )
            .padding(22.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(LerzaIcons.Tune, contentDescription = null, tint = Color.White)
            }
            Text(
                text = "YOUR PLAYER, YOUR RULES",
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.2.sp,
                color = Color.White.copy(alpha = 0.82f)
            )
        }
        Spacer(modifier = Modifier.height(18.dp))
        Text(
            text = "Make Lerza yours.",
            fontSize = 25.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Tune your library, sound, 30-day trash recovery, and private media.",
            fontSize = 13.sp,
            lineHeight = 19.sp,
            color = Color.White.copy(alpha = 0.82f)
        )
    }
}