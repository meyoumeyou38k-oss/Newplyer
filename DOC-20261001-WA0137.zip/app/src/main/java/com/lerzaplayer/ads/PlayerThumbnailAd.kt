package com.lerzaplayer.ads

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView

@Composable
fun PlayerThumbnailAd(
    modifier: Modifier = Modifier,
    onAdLoaded: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    if (!AdManager.isNetworkAvailable(context) || !AdManager.isMasterAdsEnabled) {
        onAdLoaded(false)
        return
    }

    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }
    var isReady by remember { mutableStateOf(false) }

    DisposableEffect(AdManager.nativeAdUnitId) {
        fun loadAd(unitId: String, isFallback: Boolean = false) {
            val adLoader = AdLoader.Builder(context, unitId)
                .forNativeAd { ad ->
                    nativeAd = ad
                    isReady = true
                    onAdLoaded(true)
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        if (!isFallback) {
                            loadAd(AdManager.TEST_NATIVE_ID, isFallback = true)
                        } else {
                            isReady = false
                            onAdLoaded(false)
                        }
                    }
                })
                .withNativeAdOptions(
                    NativeAdOptions.Builder()
                        .setMediaAspectRatio(NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_SQUARE)
                        .build()
                )
                .build()

            adLoader.loadAd(AdRequest.Builder().build())
        }

        loadAd(AdManager.nativeAdUnitId)

        onDispose {
            nativeAd?.destroy()
        }
    }

    val ad = nativeAd
    if (!isReady || ad == null || !AdManager.isMasterAdsEnabled) {
        return
    }

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { ctx ->
            createPlayerAdView(ctx, ad)
        },
        update = { view ->
            populatePlayerAd(view, ad)
        }
    )
}

private fun createPlayerAdView(context: Context, ad: NativeAd): NativeAdView {
    val adView = NativeAdView(context)
    val rootLayout = FrameLayout(context).apply {
        layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
    }

    val mediaView = MediaView(context).apply {
        layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
    }
    rootLayout.addView(mediaView)

    val badge = TextView(context).apply {
        text = "AD"
        textSize = 9f
        setTextColor(AndroidColor.BLACK)
        setBackgroundColor(AndroidColor.parseColor("#F59E0B"))
        setPadding(10, 4, 10, 4)
        typeface = Typeface.DEFAULT_BOLD
        layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            topMargin = 10
            leftMargin = 10
        }
    }
    rootLayout.addView(badge)

    val bottomOverlay = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundColor(AndroidColor.parseColor("#DD111827"))
        setPadding(10, 6, 10, 6)
        layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.BOTTOM
        }
    }

    val headlineView = TextView(context).apply {
        textSize = 11f
        setTextColor(AndroidColor.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
    }

    val ctaButton = Button(context).apply {
        textSize = 10f
        setTextColor(AndroidColor.BLACK)
        setBackgroundColor(AndroidColor.parseColor("#38BDF8"))
        typeface = Typeface.DEFAULT_BOLD
        setPadding(14, 0, 14, 0)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            66
        )
    }

    bottomOverlay.addView(headlineView)
    bottomOverlay.addView(ctaButton)
    rootLayout.addView(bottomOverlay)

    adView.addView(rootLayout)
    adView.mediaView = mediaView
    adView.headlineView = headlineView
    adView.callToActionView = ctaButton

    populatePlayerAd(adView, ad)
    return adView
}

private fun populatePlayerAd(adView: NativeAdView, ad: NativeAd) {
    (adView.headlineView as? TextView)?.text = ad.headline ?: "Sponsored"
    (adView.callToActionView as? Button)?.text = ad.callToAction ?: "WATCH"
    adView.mediaView?.let { mv ->
        mv.mediaContent = ad.mediaContent
    }
    adView.setNativeAd(ad)
}
