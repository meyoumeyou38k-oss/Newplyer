package com.lerzaplayer.ads

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.lerzaplayer.theme.LocalLerzaColors

@Composable
fun NativeAdFeedItem(
    modifier: Modifier = Modifier,
    isForVideo: Boolean = false
) {
    val context = LocalContext.current
    val colors = LocalLerzaColors.current

    val isSectionEnabled = if (isForVideo) AdManager.isVideosListAdEnabled else AdManager.isSongsListAdEnabled
    if (!AdManager.isNetworkAvailable(context) || !AdManager.isMasterAdsEnabled || !isSectionEnabled) {
        return
    }

    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }
    var isFailed by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        fun loadWithFallback(unitId: String, isFallback: Boolean = false) {
            val adLoader = AdLoader.Builder(context, unitId)
                .forNativeAd { ad ->
                    nativeAd = ad
                    isFailed = false
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(error: LoadAdError) {
                        if (!isFallback) {
                            // Automatically fallback to Google Test Native Ad if publisher data is not yet approved
                            loadWithFallback(AdManager.TEST_NATIVE_ID, isFallback = true)
                        } else {
                            isFailed = true
                        }
                    }
                })
                .build()
            adLoader.loadAd(AdRequest.Builder().build())
        }

        loadWithFallback(AdManager.nativeAdUnitId)

        onDispose {
            nativeAd?.destroy()
        }
    }

    val currentAd = nativeAd
    if (currentAd == null || isFailed) {
        return
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(colors.card)
            .border(1.dp, colors.card.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        AndroidView(
            modifier = Modifier.fillMaxWidth(),
            factory = { ctx ->
                createNativeAdView(ctx, currentAd)
            },
            update = { view ->
                populateNativeAd(view, currentAd)
            }
        )
    }
}

private fun createNativeAdView(context: Context, ad: NativeAd): NativeAdView {
    val adView = NativeAdView(context)
    val layout = android.widget.LinearLayout(context).apply {
        orientation = android.widget.LinearLayout.VERTICAL
        layoutParams = android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    val topRow = android.widget.LinearLayout(context).apply {
        orientation = android.widget.LinearLayout.HORIZONTAL
        gravity = android.view.Gravity.CENTER_VERTICAL
        layoutParams = android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    val iconView = ImageView(context).apply {
        layoutParams = android.widget.LinearLayout.LayoutParams(110, 110).apply {
            marginEnd = 24
        }
    }

    val textCol = android.widget.LinearLayout(context).apply {
        orientation = android.widget.LinearLayout.VERTICAL
        layoutParams = android.widget.LinearLayout.LayoutParams(
            0,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
            1.0f
        )
    }

    val badgeAndTitleRow = android.widget.LinearLayout(context).apply {
        orientation = android.widget.LinearLayout.HORIZONTAL
        gravity = android.view.Gravity.CENTER_VERTICAL
    }

    val badge = TextView(context).apply {
        text = "AD"
        textSize = 9f
        setTextColor(android.graphics.Color.BLACK)
        setBackgroundColor(android.graphics.Color.parseColor("#F59E0B"))
        setPadding(8, 2, 8, 2)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    val headlineView = TextView(context).apply {
        textSize = 13f
        setTextColor(android.graphics.Color.WHITE)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
        setPadding(12, 0, 0, 0)
    }

    val bodyView = TextView(context).apply {
        textSize = 11f
        setTextColor(android.graphics.Color.parseColor("#94A3B8"))
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
        setPadding(0, 4, 0, 0)
    }

    val ctaButton = Button(context).apply {
        textSize = 11f
        setTextColor(android.graphics.Color.BLACK)
        setBackgroundColor(android.graphics.Color.parseColor("#38BDF8"))
        setPadding(20, 0, 20, 0)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    badgeAndTitleRow.addView(badge)
    badgeAndTitleRow.addView(headlineView)
    textCol.addView(badgeAndTitleRow)
    textCol.addView(bodyView)

    topRow.addView(iconView)
    topRow.addView(textCol)
    topRow.addView(ctaButton)

    layout.addView(topRow)

    adView.addView(layout)

    adView.headlineView = headlineView
    adView.bodyView = bodyView
    adView.callToActionView = ctaButton
    adView.iconView = iconView

    populateNativeAd(adView, ad)
    return adView
}

private fun populateNativeAd(adView: NativeAdView, ad: NativeAd) {
    (adView.headlineView as? TextView)?.text = ad.headline
    (adView.bodyView as? TextView)?.text = ad.body ?: ad.advertiser ?: "Sponsored"
    (adView.callToActionView as? Button)?.text = ad.callToAction ?: "OPEN"
    if (ad.icon != null && adView.iconView != null) {
        (adView.iconView as ImageView).setImageDrawable(ad.icon?.drawable)
        adView.iconView?.visibility = View.VISIBLE
    } else {
        adView.iconView?.visibility = View.GONE
    }
    adView.setNativeAd(ad)
}
