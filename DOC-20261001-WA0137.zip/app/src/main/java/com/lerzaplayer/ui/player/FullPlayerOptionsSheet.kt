package com.lerzaplayer.ui.player

import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.DynamicArtPalette
import com.lerzaplayer.theme.LerzaIcons
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FullPlayerOptionsSheet(
    song: SongItem,
    playerManager: PlayerManager,
    dynamicPalette: DynamicArtPalette,
    onDismiss: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onHideInVault: () -> Unit,
    onDeleteSong: () -> Unit
) {
    val context = LocalContext.current
    val accent = dynamicPalette.accentColor
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val playbackSpeed by playerManager.playbackSpeed.collectAsState()
    val sleepMinutes by playerManager.sleepTimerRemainingMinutes.collectAsState()

    var showSpeedDialog by remember { mutableStateOf(false) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showRingtoneCutterDialog by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF131718),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = {
            Surface(
                modifier = Modifier
                    .padding(top = 10.dp, bottom = 6.dp)
                    .size(width = 38.dp, height = 4.dp),
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.25f)
            ) {}
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            // 1. Song Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.08f)),
                    contentAlignment = Alignment.Center
                ) {
                    if (song.albumArtUri != null) {
                        AsyncImage(
                            model = song.albumArtUri,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.DarkGray),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = LerzaIcons.MusicNote,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = song.artist,
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.65f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = { showRenameDialog = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit Tags",
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 2. Add to playlist
            LarkMenuRow(
                icon = Icons.Default.PlaylistAdd,
                title = "Add to playlist",
                onClick = {
                    onDismiss()
                    onAddToPlaylist()
                }
            )

            // 3. Share
            LarkMenuRow(
                icon = Icons.Default.Reply,
                title = "Share",
                onClick = {
                    onDismiss()
                    shareAudioFile(context, song)
                }
            )

            Spacer(modifier = Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(0.6.dp).background(Color.White.copy(alpha = 0.1f)))
            Spacer(modifier = Modifier.height(6.dp))

            // 4. Speed
            LarkMenuRow(
                icon = Icons.Default.Speed,
                title = "Speed",
                subText = "${"%.2f".format(playbackSpeed).trimEnd('0').trimEnd('.')}x",
                onClick = { showSpeedDialog = true }
            )

            // 5. Make as a ringtone
            LarkMenuRow(
                icon = Icons.Default.NotificationsNone,
                title = "Make as a ringtone (رنگ ٹون بنائیں)",
                onClick = {
                    showRingtoneCutterDialog = true
                }
            )

            // 6. Sleep timer
            LarkMenuRow(
                icon = Icons.Default.Alarm,
                title = "Sleep timer",
                subText = if (sleepMinutes > 0) "$sleepMinutes min" else null,
                onClick = { showSleepTimerDialog = true }
            )

            Spacer(modifier = Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(0.6.dp).background(Color.White.copy(alpha = 0.1f)))
            Spacer(modifier = Modifier.height(6.dp))

            // 7. Hide (Vault)
            LarkMenuRow(
                icon = Icons.Default.VisibilityOff,
                title = "Hide",
                onClick = {
                    onDismiss()
                    onHideInVault()
                }
            )

            // 8. Delete
            LarkMenuRow(
                icon = Icons.Default.DeleteOutline,
                title = "Delete",
                onClick = {
                    onDismiss()
                    onDeleteSong()
                }
            )
        }
    }

    // اسپیڈ کا ڈائیلاگ
    if (showSpeedDialog) {
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            title = { Text("Playback speed", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                        val isSel = playbackSpeed == spd
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) accent.copy(alpha = 0.2f) else Color.Transparent)
                                .clickable {
                                    playerManager.setPlaybackSpeed(spd)
                                    showSpeedDialog = false
                                }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${spd}x",
                                color = if (isSel) accent else Color.White,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSpeedDialog = false }) { Text("Cancel", color = accent) }
            },
            containerColor = Color(0xFF1E2628)
        )
    }

    // نیند کے ٹائمر کا ڈائیلاگ
    if (showSleepTimerDialog) {
        AlertDialog(
            onDismissRequest = { showSleepTimerDialog = false },
            title = { Text("Sleep timer", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15, 30, 45, 60, 90).forEach { mins ->
                        val isSel = sleepMinutes == mins
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) accent.copy(alpha = 0.2f) else Color.Transparent)
                                .clickable {
                                    playerManager.setSleepTimer(mins)
                                    showSleepTimerDialog = false
                                    Toast.makeText(context, "Music will stop in $mins minutes", Toast.LENGTH_SHORT).show()
                                }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "$mins minutes",
                                color = if (isSel) accent else Color.White,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                    if (sleepMinutes > 0) {
                        TextButton(
                            onClick = {
                                playerManager.setSleepTimer(0)
                                showSleepTimerDialog = false
                                Toast.makeText(context, "Sleep timer turned off", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Text("Turn off timer", color = Color(0xFFFF4D4D))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSleepTimerDialog = false }) { Text("Close", color = accent) }
            },
            containerColor = Color(0xFF1E2628)
        )
    }

    // ایڈٹ / رینیم ڈائیلاگ
    if (showRenameDialog) {
        var newTitle by remember { mutableStateOf(song.title) }
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Edit track title", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newTitle,
                    onValueChange = { newTitle = it },
                    label = { Text("Song title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newTitle.isNotBlank()) {
                            playerManager.updateSongTitle(song.id, newTitle)
                            Toast.makeText(context, "Track title updated: " + newTitle, Toast.LENGTH_SHORT).show()
                        }
                        showRenameDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Text("Save", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                }
            },
            containerColor = Color(0xFF1E2628)
        )
    }
}

@Composable
private fun LarkMenuRow(
    icon: ImageVector,
    title: String,
    subText: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = Color.White.copy(alpha = 0.9f),
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = title,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White.copy(alpha = 0.92f),
            modifier = Modifier.weight(1f)
        )
        if (subText != null) {
            Text(
                text = subText,
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.5f),
                fontWeight = FontWeight.Normal
            )
            Spacer(modifier = Modifier.width(4.dp))
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.3f),
            modifier = Modifier.size(20.dp)
        )
    }
}

private fun shareAudioFile(context: Context, song: SongItem) {
    try {
        val file = File(song.path)
        val uri = if (file.exists()) {
            androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } else {
            song.contentUri
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share \"${song.title}\""))
    } catch (e: Exception) {
        Toast.makeText(context, "Cannot share file: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun setAsRingtone(context: Context, song: SongItem) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        if (!Settings.System.canWrite(context)) {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            context.startActivity(intent)
            Toast.makeText(context, "Please allow 'Modify system settings' to set ringtone", Toast.LENGTH_LONG).show()
            return
        }
    }
    try {
        RingtoneManager.setActualDefaultRingtoneUri(
            context,
            RingtoneManager.TYPE_RINGTONE,
            song.contentUri
        )
        Toast.makeText(context, "Set \"${song.title}\" as ringtone!", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Failed to set ringtone: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}