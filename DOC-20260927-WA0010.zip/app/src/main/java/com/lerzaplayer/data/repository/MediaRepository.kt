package com.lerzaplayer.data.repository

import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

sealed class DeletionResult {
    object Success : DeletionResult()
    data class RequiresConsent(val intentSender: IntentSender, val pendingItem: RecentlyDeletedEntity) : DeletionResult()
    data class Failure(val error: String) : DeletionResult()
}

class MediaRepository(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val favoriteDao = db.favoriteDao()
    private val vaultDao = db.vaultDao()
    private val recentlyDeletedDao = db.recentlyDeletedDao()
    private val refreshSignal = MutableStateFlow(0L)

    fun refreshMedia() {
        refreshSignal.value = System.currentTimeMillis()
    }

    fun getRecentlyDeletedFlow(): Flow<List<RecentlyDeletedEntity>> {
        val expiry = System.currentTimeMillis() - RECENT_DELETE_WINDOW_MS
        return recentlyDeletedDao.getRecent(expiry)
            .onStart { recentlyDeletedDao.deleteExpired(expiry) }
            .flowOn(Dispatchers.IO)
    }

    fun getSongsFlow(sortOption: SortOption): Flow<List<SongItem>> {
        return combine(
            favoriteDao.getAllFavorites(),
            vaultDao.getAllVaultMedia(),
            refreshSignal
        ) { favorites, vaultMedia, _ ->
            val favSet = favorites.filter { it.mediaType == "AUDIO" }.map { it.mediaId }.toSet()
            val hiddenPaths = vaultMedia.map { it.originalPath }.toSet()
            querySongs(sortOption, favSet, hiddenPaths)
        }.flowOn(Dispatchers.IO)
    }

    fun getVideosFlow(sortOption: SortOption): Flow<List<VideoItem>> {
        return combine(
            favoriteDao.getAllFavorites(),
            vaultDao.getAllVaultMedia(),
            refreshSignal
        ) { favorites, vaultMedia, _ ->
            val favSet = favorites.filter { it.mediaType == "VIDEO" }.map { it.mediaId }.toSet()
            val hiddenPaths = vaultMedia.map { it.originalPath }.toSet()
            queryVideos(sortOption, favSet, hiddenPaths)
        }.flowOn(Dispatchers.IO)
    }

    suspend fun querySongs(
        sortOption: SortOption,
        favSet: Set<Long> = emptySet(),
        hiddenPaths: Set<String> = emptySet()
    ): List<SongItem> = withContext(Dispatchers.IO) {
        val songList = mutableListOf<SongItem>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.ALBUM_ID
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 10000"
        val sortOrder = when (sortOption) {
            SortOption.TITLE_ASC -> "${MediaStore.Audio.Media.TITLE} ASC"
            SortOption.ARTIST_ASC -> "${MediaStore.Audio.Media.ARTIST} ASC"
            SortOption.DURATION_DESC -> "${MediaStore.Audio.Media.DURATION} DESC"
            SortOption.SIZE_DESC -> "${MediaStore.Audio.Media.SIZE} DESC"
            SortOption.DATE_ADDED_DESC -> "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        }
        try {
            context.contentResolver.query(collection, projection, selection, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val artBaseUri = Uri.parse("content://media/external/audio/albumart")
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val path = cursor.getString(dataCol) ?: ""
                    if (hiddenPaths.contains(path)) continue
                    val title = cursor.getString(titleCol) ?: "Unknown Title"
                    val artist = cursor.getString(artistCol) ?: "Unknown Artist"
                    val album = cursor.getString(albumCol) ?: "Unknown Album"
                    val duration = cursor.getLong(durationCol)
                    val size = cursor.getLong(sizeCol)
                    val dateAdded = cursor.getLong(dateCol)
                    val mime = cursor.getString(mimeCol) ?: "audio/mpeg"
                    val albumId = cursor.getLong(albumIdCol)
                    val contentUri = ContentUris.withAppendedId(collection, id)
                    val albumArtUri = ContentUris.withAppendedId(artBaseUri, albumId)
                    songList.add(
                        SongItem(
                            id = id,
                            title = title,
                            artist = if (artist == "<unknown>") "Device Storage" else artist,
                            album = album,
                            duration = duration,
                            contentUri = contentUri,
                            albumArtUri = albumArtUri,
                            size = size,
                            dateAdded = dateAdded,
                            path = path,
                            mimeType = mime,
                            isFavorite = favSet.contains(id),
                            hasLyrics = true
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        songList
    }

    suspend fun queryVideos(
        sortOption: SortOption,
        favSet: Set<Long> = emptySet(),
        hiddenPaths: Set<String> = emptySet()
    ): List<VideoItem> = withContext(Dispatchers.IO) {
        val videoList = mutableListOf<VideoItem>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DATA
        )
        val sortOrder = when (sortOption) {
            SortOption.TITLE_ASC -> "${MediaStore.Video.Media.TITLE} ASC"
            SortOption.DURATION_DESC -> "${MediaStore.Video.Media.DURATION} DESC"
            SortOption.SIZE_DESC -> "${MediaStore.Video.Media.SIZE} DESC"
            else -> "${MediaStore.Video.Media.DATE_ADDED} DESC"
        }
        try {
            context.contentResolver.query(collection, projection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val path = cursor.getString(dataCol) ?: ""
                    if (hiddenPaths.contains(path)) continue
                    val title = cursor.getString(titleCol) ?: "Video $id"
                    val duration = cursor.getLong(durationCol)
                    val size = cursor.getLong(sizeCol)
                    val dateAdded = cursor.getLong(dateCol)
                    val folderName = try {
                        File(path).parentFile?.name ?: "Videos"
                    } catch (_: Exception) {
                        "Videos"
                    }
                    val contentUri = ContentUris.withAppendedId(collection, id)
                    videoList.add(
                        VideoItem(
                            id = id,
                            title = title,
                            duration = duration,
                            contentUri = contentUri,
                            size = size,
                            dateAdded = dateAdded,
                            path = path,
                            folderName = folderName,
                            isFavorite = favSet.contains(id)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        videoList
    }

    /**
     * گانے یا ویڈیو کو فون سے ڈیلیٹ کر کے 30 دن کے لیے بیک اپ میں محفوظ کرتا ہے
     */
    suspend fun deleteMediaToTrash(
        uri: Uri,
        originalPath: String,
        name: String,
        mediaType: String,
        duration: Long,
        size: Long
    ): DeletionResult = withContext(Dispatchers.IO) {
        val trashDir = File(context.filesDir, "recently_deleted").apply { mkdirs() }
        val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
        val backupFile = File(trashDir, "${System.currentTimeMillis()}_${safeName.ifBlank { "media" }}")

        try {
            // مرحلہ 1: فائل کو پہلے اندرونی سیف بیک اپ میں کاپی کریں
            val sourceFile = originalPath.takeIf { it.isNotBlank() }?.let(::File)
            if (sourceFile?.isFile == true && sourceFile.exists()) {
                sourceFile.copyTo(backupFile, overwrite = true)
            } else {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(backupFile).use { output -> input.copyTo(output) }
                } ?: return@withContext DeletionResult.Failure("Cannot read media file")
            }

            if (!backupFile.exists() || backupFile.length() == 0L) {
                return@withContext DeletionResult.Failure("Failed to create backup")
            }

            val pendingEntity = RecentlyDeletedEntity(
                originalPath = originalPath,
                backupPath = backupFile.absolutePath,
                originalName = name,
                mediaType = mediaType,
                duration = duration,
                size = if (size > 0L) size else backupFile.length()
            )

            // مرحلہ 2: فون اسٹوریج اور میڈیا اسٹور سے ڈیلیٹ کرنے کی کوشش کریں
            var deletedDirectly = false

            // ڈائریکٹ فائل ڈیلیشن (Android 9/10 یا روٹ ڈائریکٹریز)
            try {
                if (sourceFile?.exists() == true) {
                    deletedDirectly = sourceFile.delete()
                }
            } catch (_: Exception) {}

            // MediaStore Resolver سے ڈیلیٹ کریں
            try {
                val rows = context.contentResolver.delete(uri, null, null)
                if (rows > 0) deletedDirectly = true
            } catch (e: RecoverableSecurityException) {
                // اینڈرائیڈ 10 پر سسٹم کنفرمیشن ڈائیلاگ
                return@withContext DeletionResult.RequiresConsent(e.userAction.actionIntent.intentSender, pendingEntity)
            } catch (e: SecurityException) {
                // اینڈرائیڈ 11+ پر Scoped Storage ڈیلیٹ ریکویسٹ
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val deleteRequest = MediaStore.createDeleteRequest(context.contentResolver, listOf(uri))
                    return@withContext DeletionResult.RequiresConsent(deleteRequest.intentSender, pendingEntity)
                }
            }

            if (deletedDirectly || !File(originalPath).exists()) {
                confirmPendingDeletion(pendingEntity)
                DeletionResult.Success
            } else {
                // اگر اینڈرائیڈ 11+ ہے اور سیکیورٹی ایکسیپشن نہیں آئی تو سیدھا ڈیلیٹ ریکویسٹ بھیجیں
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        val deleteRequest = MediaStore.createDeleteRequest(context.contentResolver, listOf(uri))
                        DeletionResult.RequiresConsent(deleteRequest.intentSender, pendingEntity)
                    } catch (e: Exception) {
                        backupFile.delete()
                        DeletionResult.Failure("Delete permission denied: ${e.message}")
                    }
                } else {
                    backupFile.delete()
                    DeletionResult.Failure("Unable to delete file from device")
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            backupFile.delete()
            DeletionResult.Failure(e.localizedMessage ?: "Unknown error")
        }
    }

    suspend fun deleteMedia(song: SongItem): DeletionResult {
        return deleteMediaToTrash(song.contentUri, song.path, song.title, "AUDIO", song.duration, song.size)
    }

    suspend fun deleteMedia(video: VideoItem): DeletionResult {
        return deleteMediaToTrash(video.contentUri, video.path, video.title, "VIDEO", video.duration, video.size)
    }

    suspend fun confirmPendingDeletion(entity: RecentlyDeletedEntity) = withContext(Dispatchers.IO) {
        recentlyDeletedDao.insert(entity)
        recentlyDeletedDao.deleteExpired(System.currentTimeMillis() - RECENT_DELETE_WINDOW_MS)
        MediaScannerConnection.scanFile(context, arrayOf(entity.originalPath), null, null)
        refreshMedia()
    }

    suspend fun cancelPendingDeletion(entity: RecentlyDeletedEntity) = withContext(Dispatchers.IO) {
        try {
            File(entity.backupPath).delete()
        } catch (_: Exception) {}
    }

    suspend fun restoreRecentlyDeleted(item: RecentlyDeletedEntity) = withContext(Dispatchers.IO) {
        try {
            val backup = File(item.backupPath)
            if (!backup.exists()) return@withContext
            val destination = File(item.originalPath)
            destination.parentFile?.mkdirs()
            backup.copyTo(destination, overwrite = true)
            MediaScannerConnection.scanFile(
                context,
                arrayOf(destination.absolutePath),
                null,
                null
            )
            backup.delete()
            recentlyDeletedDao.delete(item)
            refreshMedia()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun permanentlyDeleteRecentlyDeleted(item: RecentlyDeletedEntity) = withContext(Dispatchers.IO) {
        runCatching { File(item.backupPath).delete() }
        recentlyDeletedDao.delete(item)
    }

    companion object {
        private const val RECENT_DELETE_WINDOW_MS = 30L * 24 * 60 * 60 * 1000
    }
}