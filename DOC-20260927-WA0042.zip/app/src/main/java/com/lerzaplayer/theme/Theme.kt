package com.lerzaplayer.theme

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb

// ہر اسکرین، وال پیپر، بیک گراؤنڈ اور بٹن کے لیے گہرا تھیم پیلیٹ
data class LerzaColorPalette(
    val primary: Color,             // چمکدار رنگ (بٹنز، سلائیڈرز، پلے آئیکونز کے لیے)
    val primaryVariant: Color,      // گہرا رنگ
    val accent: Color,              // ہائی لائٹ رنگ
    val onPrimary: Color,           // بٹن کے اوپر کا ٹیکسٹ
    val secondary: Color = accent,
    val card: Color,                // گانوں اور آئٹمز کے کارڈ کا رنگ (تھیم سے رنگین)
    val background: Color,          // پوری ایپ کا بیک گراؤنڈ (ہوم، سیٹنگز، والٹ وغیرہ)
    val surface: Color,             // ہیڈر، ٹاپ بار اور مینیو کا رنگ
    val surfaceVariant: Color,      // باکسز اور سرکلز کا رنگ
    val textPrimary: Color,         // صاف اور واضح سفید ٹیکسٹ
    val textSecondary: Color,       // ہلکا نرم ٹیکسٹ
    val divider: Color,             // لکیر کا رنگ
    val isDark: Boolean
)

object ThemeManager {
    private const val PREFS_NAME = "lerza_theme_prefs"
    private const val KEY_COLOR = "selected_theme_color"
    private const val KEY_NAME = "selected_theme_name"

    // ڈیفالٹ میں لائیو اسٹیٹ
    var currentThemeColor by mutableStateOf(LarkGreen)
    var currentThemeName by mutableStateOf("Green")

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedColor = prefs.getInt(KEY_COLOR, LarkGreen.toArgb())
        val savedName = prefs.getString(KEY_NAME, "Green") ?: "Green"
        currentThemeColor = Color(savedColor)
        currentThemeName = savedName
    }

    fun setTheme(context: Context, color: Color, name: String = "") {
        currentThemeColor = color
        currentThemeName = name.ifEmpty { "Custom" }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putInt(KEY_COLOR, color.toArgb())
            .putString(KEY_NAME, currentThemeName)
            .apply()
    }
}

val LocalLerzaColors = staticCompositionLocalOf {
    getLerzaPalette(LarkGreen, true)
}

object LerzaTheme {
    val colors: LerzaColorPalette
        @Composable
        @ReadOnlyComposable
        get() = LocalLerzaColors.current
}

fun getColorByThemeName(themeName: String): Color {
    return when (themeName.lowercase()) {
        "green", "default" -> LarkGreen
        "blue" -> LerzaBlue
        "purple" -> LarkPurple
        "orange" -> LarkOrange
        "red" -> LarkRed
        "pink" -> LarkPink
        "cyan" -> LarkCyan
        "amber", "yellow" -> LarkAmber
        else -> LarkGreen
    }
}

fun getContrastTextColor(backgroundColor: Color): Color {
    return if (backgroundColor.luminance() > 0.45f) Color(0xFF101418) else Color.White
}

// -------------------------------------------------------------------------------------
// ڈیپ تھیمنگ: جو رنگ یوزر منتخب کرے گا، پورا بیک گراؤنڈ اور سرفیس اسی رنگ کے گہرے شیڈ میں ڈھل جائے گا!
// -------------------------------------------------------------------------------------
fun getLerzaPalette(themeColor: Color, isDark: Boolean = true): LerzaColorPalette {
    val contrastOnPrimary = getContrastTextColor(themeColor)

    // گہرا بیک گراؤنڈ جو منتخب رنگ (جیسے Green) کے ساتھ جڑ جائے
    val deepThemeBg = Color(
        red = (themeColor.red * 0.12f).coerceIn(0.04f, 0.14f),
        green = (themeColor.green * 0.14f).coerceIn(0.05f, 0.16f),
        blue = (themeColor.blue * 0.12f).coerceIn(0.04f, 0.15f),
        alpha = 1f
    )

    // سرفیس اور کارڈز جو ہلکے سے رنگین ہوں
    val deepSurface = Color(
        red = (themeColor.red * 0.18f).coerceIn(0.08f, 0.22f),
        green = (themeColor.green * 0.20f).coerceIn(0.09f, 0.24f),
        blue = (themeColor.blue * 0.18f).coerceIn(0.08f, 0.22f),
        alpha = 1f
    )

    val deepCard = Color(
        red = (themeColor.red * 0.24f).coerceIn(0.12f, 0.28f),
        green = (themeColor.green * 0.26f).coerceIn(0.13f, 0.30f),
        blue = (themeColor.blue * 0.24f).coerceIn(0.12f, 0.28f),
        alpha = 1f
    )

    return LerzaColorPalette(
        primary = themeColor,
        primaryVariant = themeColor.copy(alpha = 0.85f),
        accent = themeColor,
        onPrimary = contrastOnPrimary,
        secondary = themeColor,
        card = deepCard,
        background = deepThemeBg,
        surface = deepSurface,
        surfaceVariant = deepSurface.copy(alpha = 0.9f),
        textPrimary = Color.White,
        textSecondary = Color.White.copy(alpha = 0.70f),
        divider = themeColor.copy(alpha = 0.15f),
        isDark = true
    )
}

fun buildLarkTheme(
    themeColor: Color = ThemeManager.currentThemeColor,
    isDark: Boolean = true
): LerzaColorPalette {
    return getLerzaPalette(themeColor, isDark)
}

fun buildLarkTheme(
    themeName: String,
    isDark: Boolean = true
): LerzaColorPalette {
    return getLerzaPalette(getColorByThemeName(themeName), isDark)
}

@Composable
fun LerzaPlayerTheme(
    themeName: String = ThemeManager.currentThemeName,
    themeColor: Color? = null,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val activeColor = themeColor ?: ThemeManager.currentThemeColor
    val lerzaPalette = getLerzaPalette(activeColor, darkTheme)

    val materialColorScheme = darkColorScheme(
        primary = lerzaPalette.primary,
        secondary = lerzaPalette.accent,
        tertiary = lerzaPalette.primaryVariant,
        background = lerzaPalette.background,
        surface = lerzaPalette.surface,
        surfaceVariant = lerzaPalette.surfaceVariant,
        onPrimary = lerzaPalette.onPrimary,
        onBackground = lerzaPalette.textPrimary,
        onSurface = lerzaPalette.textPrimary
    )

    CompositionLocalProvider(
        LocalLerzaColors provides lerzaPalette
    ) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            content = content
        )
    }
}