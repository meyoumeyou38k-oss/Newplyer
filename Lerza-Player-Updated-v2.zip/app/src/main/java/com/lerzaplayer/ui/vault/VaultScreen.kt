package com.lerzaplayer.ui.vault

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.vault.VaultManager
import kotlinx.coroutines.launch

@Composable
fun VaultScreen(
    vaultManager: VaultManager,
    onBack: () -> Unit,
    onPlayMedia: (VaultMediaEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val scope = rememberCoroutineScope()
    val isUnlocked by vaultManager.isUnlocked.collectAsState()
    val vaultMedia by vaultManager.vaultMediaFlow.collectAsState(initial = emptyList())
    val savedLockType by vaultManager.lockTypeFlow.collectAsState(initial = VaultLockType.PIN)
    var lockType by remember { mutableStateOf(VaultLockType.PIN) }
    var enteredPin by remember { mutableStateOf("") }
    var patternNodes by remember { mutableStateOf<List<Int>>(emptyList()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var failedAttempts by remember { mutableStateOf(0) }
    var selectedFilter by remember { mutableStateOf("ALL") }
    var showResetDialog by remember { mutableStateOf(false) }
    var showChangeLockDialog by remember { mutableStateOf(false) }

    LaunchedEffect(savedLockType) {
        lockType = savedLockType
    }

    val filteredMedia = remember(vaultMedia, selectedFilter) {
        when (selectedFilter) {
            "AUDIO" -> vaultMedia.filter { it.mediaType == "AUDIO" }
            "VIDEO" -> vaultMedia.filter { it.mediaType == "VIDEO" }
            else -> vaultMedia
        }
    }

    val audioCount = remember(vaultMedia) { vaultMedia.count { it.mediaType == "AUDIO" } }
    val videoCount = remember(vaultMedia) { vaultMedia.count { it.mediaType == "VIDEO" } }

    Scaffold(
        topBar = {
            Surface(
                color = colors.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Text(
                            text = "Private Vault",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }

                    if (isUnlocked) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(onClick = { showChangeLockDialog = true }) {
                                Icon(LerzaIcons.Settings, contentDescription = "Change Lock", tint = colors.textSecondary)
                            }
                            IconButton(onClick = { vaultManager.lockVault() }) {
                                Icon(LerzaIcons.Lock, contentDescription = "Lock", tint = Color(0xFFFF334B))
                            }
                        }
                    }
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (!isUnlocked) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E60F2).copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = LerzaIcons.Lock,
                            contentDescription = null,
                            tint = Color(0xFF1E60F2),
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (lockType == VaultLockType.PIN) "Enter Vault PIN" else "Draw Pattern Lock",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Text(
                        text = "New vault files use authenticated encryption protected by Android Keystore.",
                        fontSize = 12.sp,
                        color = colors.textSecondary
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    if (lockType == VaultLockType.PIN) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(bottom = 28.dp)
                        ) {
                            repeat(4) { idx ->
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (idx < enteredPin.length) Color(0xFF1E60F2) else colors.card
                                        )
                                        .border(1.dp, Color(0xFF1E60F2), CircleShape)
                                )
                            }
                        }

                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val rows = listOf(
                                listOf("1", "2", "3"),
                                listOf("4", "5", "6"),
                                listOf("7", "8", "9"),
                                listOf("PAT", "0", "DEL")
                            )
                            rows.forEach { row ->
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                                ) {
                                    row.forEach { key ->
                                        Box(
                                            modifier = Modifier
                                                .size(64.dp)
                                                .clip(CircleShape)
                                                .background(colors.card)
                                                .clickable {
                                                    when (key) {
                                                        "DEL" -> if (enteredPin.isNotEmpty()) enteredPin = enteredPin.dropLast(1)
                                                        "PAT" -> {
                                                            lockType = VaultLockType.PATTERN
                                                            scope.launch { vaultManager.setLockMode(VaultLockType.PATTERN) }
                                                            enteredPin = ""
                                                            errorMessage = null
                                                        }
                                                        else -> {
                                                            if (enteredPin.length < 4) {
                                                                enteredPin += key
                                                                if (enteredPin.length == 4) {
                                                                    scope.launch {
                                                                        val success = vaultManager.verifyPin(enteredPin)
                                                                        if (success) {
                                                                            failedAttempts = 0
                                                                        } else {
                                                                            errorMessage = "Incorrect PIN"
                                                                            failedAttempts += 1
                                                                            enteredPin = ""
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (key == "DEL") {
                                                Icon(LerzaIcons.Backspace, contentDescription = "Delete", tint = colors.textPrimary)
                                            } else if (key == "PAT") {
                                                Icon(LerzaIcons.Pattern, contentDescription = "Pattern Mode", tint = colors.textPrimary)
                                            } else {
                                                Text(
                                                    text = key,
                                                    fontSize = 22.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = colors.textPrimary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = if (patternNodes.isEmpty()) "Tap at least 4 dots to form pattern" else "Selected: ${patternNodes.size} dots",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF1E60F2)
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
                                for (r in 0..2) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                                        for (c in 0..2) {
                                            val nodeIndex = r * 3 + c + 1
                                            val isSelected = patternNodes.contains(nodeIndex)
                                            Box(
                                                modifier = Modifier
                                                    .size(56.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isSelected) Color(0xFF1E60F2) else colors.card)
                                                    .border(
                                                        2.dp,
                                                        if (isSelected) Color(0xFF00E5FF) else colors.textSecondary.copy(alpha = 0.25f),
                                                        CircleShape
                                                    )
                                                    .clickable {
                                                        if (!isSelected) {
                                                            patternNodes = patternNodes + nodeIndex
                                                        }
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(14.dp)
                                                        .clip(CircleShape)
                                                        .background(if (isSelected) Color.White else colors.textSecondary)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Button(
                                onClick = {
                                    scope.launch {
                                        val success = vaultManager.verifyPattern(patternNodes)
                                        if (success) {
                                            failedAttempts = 0
                                            errorMessage = null
                                        } else {
                                            errorMessage = "Incorrect Pattern"
                                            failedAttempts += 1
                                            patternNodes = emptyList()
                                        }
                                    }
                                },
                                enabled = patternNodes.size >= 4,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60F2)),
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Text("Unlock vault", color = Color.White)
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                modifier = Modifier.padding(top = 10.dp)
                            ) {
                                TextButton(onClick = { patternNodes = emptyList(); errorMessage = null }) {
                                    Text("Clear Pattern", color = Color(0xFFFF334B), fontSize = 13.sp)
                                }
                                TextButton(onClick = {
                                    lockType = VaultLockType.PIN
                                    errorMessage = null
                                    patternNodes = emptyList()
                                    scope.launch { vaultManager.setLockMode(VaultLockType.PIN) }
                                }) {
                                    Text("Switch to PIN Mode", color = Color(0xFF1E60F2), fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage ?: "",
                            color = Color(0xFFFF334B),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 14.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (failedAttempts >= 6) {
                        TextButton(onClick = { showResetDialog = true }) {
                            Text("Forgot password? Set a new lock", color = Color(0xFF1E60F2), fontSize = 12.sp)
                        }
                    }
                }
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = selectedFilter == "ALL",
                            onClick = { selectedFilter = "ALL" },
                            label = { Text("All (${vaultMedia.size})") }
                        )
                        FilterChip(
                            selected = selectedFilter == "AUDIO",
                            onClick = { selectedFilter = "AUDIO" },
                            label = { Text("Audio ($audioCount)") }
                        )
                        FilterChip(
                            selected = selectedFilter == "VIDEO",
                            onClick = { selectedFilter = "VIDEO" },
                            label = { Text("Video ($videoCount)") }
                        )
                    }

                    if (filteredMedia.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${filteredMedia.size} private items",
                                fontSize = 12.sp,
                                color = colors.textSecondary
                            )
                            TextButton(
                                onClick = {
                                    scope.launch { vaultManager.restoreAllMedia(filteredMedia) }
                                }
                            ) {
                                Icon(
                                    imageVector = LerzaIcons.Restore,
                                    contentDescription = null,
                                    tint = Color(0xFF00C853),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Restore All", color = Color(0xFF00C853), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Divider(color = colors.card, thickness = 0.5.dp)

                    if (filteredMedia.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .background(colors.card),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = LerzaIcons.Lock,
                                        contentDescription = null,
                                        tint = colors.textSecondary,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = if (vaultMedia.isEmpty()) "Private Vault is Empty" else "No matching files",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Use the 3-dots menu on songs or videos to securely hide them inside the vault.",
                                    fontSize = 12.sp,
                                    color = colors.textSecondary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filteredMedia) { item ->
                                VaultMediaRow(
                                    media = item,
                                    onPlay = { onPlayMedia(item) },
                                    onRestore = {
                                        scope.launch { vaultManager.restoreMedia(item) }
                                    },
                                    onDeletePermanently = {
                                        scope.launch { vaultManager.deletePermanently(item) }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset Vault Lock", color = colors.textPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "After six failed unlock attempts, you can create a new PIN. This changes only the vault lock; hidden media stays in the vault.",
                    color = colors.textSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            vaultManager.resetVaultLock()
                            enteredPin = ""
                            patternNodes = emptyList()
                            failedAttempts = 0
                            errorMessage = null
                            showResetDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF334B))
                ) {
                    Text("Reset Lock", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel", color = colors.textSecondary)
                }
            },
            containerColor = colors.surface
        )
    }

    if (showChangeLockDialog) {
        var newPin by remember { mutableStateOf("") }
        var newPattern by remember { mutableStateOf<List<Int>>(emptyList()) }
        var dialogMode by remember { mutableStateOf(VaultLockType.PIN) }

        AlertDialog(
            onDismissRequest = { showChangeLockDialog = false },
            title = { Text("Update Security Lock", color = colors.textPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Choose your preferred lock type:",
                        fontSize = 13.sp,
                        color = colors.textSecondary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = dialogMode == VaultLockType.PIN,
                            onClick = { dialogMode = VaultLockType.PIN },
                            label = { Text("4-Digit PIN") }
                        )
                        FilterChip(
                            selected = dialogMode == VaultLockType.PATTERN,
                            onClick = { dialogMode = VaultLockType.PATTERN },
                            label = { Text("Pattern") }
                        )
                    }

                    if (dialogMode == VaultLockType.PIN) {
                        OutlinedTextField(
                            value = newPin,
                            onValueChange = { if (it.length <= 4 && it.all { ch -> ch.isDigit() }) newPin = it },
                            label = { Text("Enter New 4-Digit PIN") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Choose a pattern using at least 4 dots (${newPattern.size} selected).",
                                fontSize = 12.sp,
                                color = Color(0xFF1E60F2)
                            )
                            for (row in 0..2) {
                                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                    for (column in 0..2) {
                                        val node = row * 3 + column + 1
                                        val selected = node in newPattern
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(if (selected) Color(0xFF1E60F2) else colors.card)
                                                .border(1.dp, Color(0xFF1E60F2), CircleShape)
                                                .clickable {
                                                    if (selected) newPattern = newPattern - node
                                                    else newPattern = newPattern + node
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Box(
                                                Modifier
                                                    .size(10.dp)
                                                    .clip(CircleShape)
                                                    .background(if (selected) Color.White else colors.textSecondary)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            if (dialogMode == VaultLockType.PIN && newPin.length == 4) {
                                vaultManager.updatePin(newPin)
                                showChangeLockDialog = false
                            } else if (dialogMode == VaultLockType.PATTERN && newPattern.size >= 4) {
                                vaultManager.updatePattern(newPattern)
                                showChangeLockDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60F2))
                ) {
                    Text("Save", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showChangeLockDialog = false }) {
                    Text("Cancel", color = colors.textSecondary)
                }
            },
            containerColor = colors.surface
        )
    }
}

@Composable
fun VaultMediaRow(
    media: VaultMediaEntity,
    onPlay: () -> Unit,
    onRestore: () -> Unit,
    onDeletePermanently: () -> Unit
) {
    val colors = LocalLerzaColors.current
    var showDeleteConfirm by remember { mutableStateOf(false) }
    val sizeMb = remember(media.size) {
        val mb = media.size / (1024.0 * 1024.0)
        if (mb >= 0.1) "%.1f MB".format(mb) else "${media.size / 1024} KB"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(colors.card)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF1E60F2).copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (media.mediaType == "AUDIO") LerzaIcons.Audiotrack else LerzaIcons.Videocam,
                    contentDescription = null,
                    tint = Color(0xFF1E60F2),
                    modifier = Modifier.size(22.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = media.originalName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Private ${media.mediaType} • $sizeMb",
                    fontSize = 11.sp,
                    color = colors.textSecondary
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(onClick = onPlay) {
                Icon(
                    imageVector = LerzaIcons.PlayArrow,
                    contentDescription = "Play from Vault",
                    tint = Color(0xFF1E60F2)
                )
            }
            IconButton(onClick = onRestore) {
                Icon(
                    imageVector = LerzaIcons.Restore,
                    contentDescription = "Restore to Library",
                    tint = Color(0xFF00C853)
                )
            }
            IconButton(onClick = { showDeleteConfirm = true }) {
                Icon(
                    imageVector = LerzaIcons.Delete,
                    contentDescription = "Delete Permanently",
                    tint = Color(0xFFFF334B)
                )
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Permanently?", color = colors.textPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "This encrypted file will be permanently removed from vault storage.",
                    color = colors.textSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeletePermanently()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF334B))
                ) {
                    Text("Delete", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", color = colors.textSecondary)
                }
            },
            containerColor = colors.surface
        )
    }
}
