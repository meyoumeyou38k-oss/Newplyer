package com.lerzaplayer.ui.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.playback.PlayerManager
import kotlin.math.roundToInt

private val EqCyan = Color(0xFF45E6FF)
private val EqPurple = Color(0xFFB67CFF)
private val EqPink = Color(0xFFFF64B4)
private val EqGreen = Color(0xFF67F5C1)
private val EqPanel = Color(0xFF111827)

private data class SoundProfile(
    val name: String,
    val curve: List<Float>,
    val bass: Int
)

private val soundProfiles = listOf(
    SoundProfile("Bass Boost", listOf(0.92f, 0.55f, 0.05f, -0.12f, -0.08f), 850),
    SoundProfile("Electronics", listOf(0.40f, 0.12f, -0.18f, 0.43f, 0.62f), 300),
    SoundProfile("Jazz", listOf(0.18f, 0.08f, -0.05f, 0.18f, 0.28f), 180),
    SoundProfile("Pop", listOf(-0.08f, 0.24f, 0.38f, 0.20f, -0.06f), 220)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerSheet(
    playerManager: PlayerManager,
    onDismiss: () -> Unit
) {
    val snapshot by playerManager.equalizerSnapshot.collectAsState()
    val enabled by playerManager.equalizerEnabled.collectAsState()
    val bassStrength by playerManager.bassBoostStrength.collectAsState()
    val virtualizerStrength by playerManager.virtualizerStrength.collectAsState()
    val bandIndexes = fiveBandIndexes(snapshot.bandLevels.size)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = EqPanel,
        contentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF172B48), Color(0xFF30204C), Color(0xFF142D38))
                        )
                    )
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(color = EqCyan.copy(alpha = 0.16f), shape = CircleShape) {
                    Icon(
                        imageVector = Icons.Filled.GraphicEq,
                        contentDescription = null,
                        tint = EqCyan,
                        modifier = Modifier.padding(11.dp).size(27.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Lerza Audio Lab", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (snapshot.supported) "Live device audio equalizer" else "Start music to enable audio effects",
                        color = EqCyan.copy(alpha = 0.86f),
                        fontSize = 12.sp
                    )
                }
                Switch(checked = enabled, onCheckedChange = playerManager::setEqualizerEnabled)
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF192235))
                    .padding(16.dp)
            ) {
                Text(
                    "SOUND PROFILES",
                    color = EqCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.4.sp
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    soundProfiles.forEach { profile ->
                        FilterChip(
                            selected = snapshot.activeSoundProfile == profile.name,
                            enabled = enabled && snapshot.supported,
                            onClick = {
                                playerManager.applySoundProfile(profile.name, profile.curve, profile.bass)
                            },
                            label = { Text(profile.name) }
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xFF192235))
                    .padding(horizontal = 10.dp, vertical = 15.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("FIVE-BAND EQ", color = EqPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                        Text("Drag each fader to shape your sound", color = Color.LightGray, fontSize = 11.sp)
                    }
                    Text("LIVE", color = EqGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))

                if (!snapshot.supported || snapshot.bandLevels.isEmpty()) {
                    Text(
                        "The device equalizer is unavailable. Start a song first; the five controls then connect to the device's audio bands.",
                        color = Color.LightGray,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        bandIndexes.forEachIndexed { displayIndex, actualIndex ->
                            val level = snapshot.bandLevels.getOrElse(actualIndex) { 0 }.toInt()
                            val centerHz = snapshot.bandCentersHz.getOrElse(actualIndex) { 0 }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    formatFrequency(centerHz),
                                    color = Color.White.copy(alpha = 0.83f),
                                    fontSize = 9.sp,
                                    maxLines = 1
                                )
                                VerticalBandControl(
                                    value = level,
                                    minimum = snapshot.minimumBandLevel.toInt(),
                                    maximum = snapshot.maximumBandLevel.toInt(),
                                    accent = listOf(EqCyan, EqPurple, EqPink, EqGreen, Color(0xFFFFC857))[displayIndex],
                                    enabled = enabled,
                                    onValueChange = { newLevel ->
                                        playerManager.setEqualizerBand(actualIndex.toShort(), newLevel.toShort())
                                    }
                                )
                                Text(
                                    "%+.1f".format(level / 100f),
                                    color = EqPurple,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            StrengthControl(
                title = "Bass impact",
                subtitle = "Adds low-frequency punch",
                value = bassStrength,
                accent = EqPink,
                icon = { Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = EqPink) },
                enabled = enabled && snapshot.supported,
                onValueChange = { playerManager.setBassBoostStrength(it.toShort()) }
            )
            StrengthControl(
                title = "Stereo space",
                subtitle = "Widens the soundstage",
                value = virtualizerStrength,
                accent = EqGreen,
                icon = { Icon(Icons.Filled.Headphones, contentDescription = null, tint = EqGreen) },
                enabled = enabled && snapshot.supported,
                onValueChange = { playerManager.setVirtualizerStrength(it.toShort()) }
            )

            TextButton(
                onClick = playerManager::resetEqualizer,
                modifier = Modifier.align(Alignment.End)
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = null, tint = EqCyan)
                Spacer(Modifier.width(6.dp))
                Text("Reset sound", color = EqCyan)
            }
        }
    }
}

@Composable
private fun VerticalBandControl(
    value: Int,
    minimum: Int,
    maximum: Int,
    accent: Color,
    enabled: Boolean,
    onValueChange: (Int) -> Unit
) {
    val safeMaximum = if (maximum > minimum) maximum else minimum + 1
    val currentOnValueChange by rememberUpdatedState(onValueChange)
    val fraction = ((value - minimum).toFloat() / (safeMaximum - minimum)).coerceIn(0f, 1f)

    Box(
        modifier = Modifier
            .width(48.dp)
            .height(154.dp)
            .then(
                if (enabled) {
                    Modifier
                        .pointerInput(minimum, safeMaximum) {
                            fun updateFromY(y: Float) {
                                val top = 12f
                                val trackHeight = (size.height - 24f).coerceAtLeast(1f)
                                val amount = (1f - ((y - top) / trackHeight)).coerceIn(0f, 1f)
                                currentOnValueChange((minimum + amount * (safeMaximum - minimum)).roundToInt())
                            }
                            detectTapGestures { updateFromY(it.y) }
                        }
                        .pointerInput(minimum, safeMaximum) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                val top = 12f
                                val trackHeight = (size.height - 24f).coerceAtLeast(1f)
                                val amount = (1f - ((change.position.y - top) / trackHeight)).coerceIn(0f, 1f)
                                currentOnValueChange((minimum + amount * (safeMaximum - minimum)).roundToInt())
                            }
                        }
                } else Modifier
            )
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(154.dp)) {
            val centerX = size.width / 2f
            val top = 12f
            val bottom = size.height - 12f
            val trackHeight = (bottom - top).coerceAtLeast(1f)
            val thumbY = bottom - fraction * trackHeight
            val zeroFraction = ((0f - minimum) / (safeMaximum - minimum)).coerceIn(0f, 1f)
            val zeroY = bottom - zeroFraction * trackHeight

            drawLine(
                color = Color.White.copy(alpha = 0.16f),
                start = Offset(centerX, top),
                end = Offset(centerX, bottom),
                strokeWidth = 5.dp.toPx()
            )
            drawLine(
                brush = Brush.verticalGradient(listOf(EqCyan, accent, EqPink), startY = top, endY = bottom),
                start = Offset(centerX, minOf(zeroY, thumbY)),
                end = Offset(centerX, maxOf(zeroY, thumbY)),
                strokeWidth = 5.dp.toPx()
            )
            drawLine(
                color = Color.White.copy(alpha = 0.45f),
                start = Offset(centerX - 12.dp.toPx(), zeroY),
                end = Offset(centerX + 12.dp.toPx(), zeroY),
                strokeWidth = 1.dp.toPx()
            )
            drawCircle(color = accent.copy(alpha = 0.23f), radius = 12.dp.toPx(), center = Offset(centerX, thumbY))
            drawCircle(color = accent, radius = 7.dp.toPx(), center = Offset(centerX, thumbY))
            drawCircle(color = Color.White, radius = 3.dp.toPx(), center = Offset(centerX, thumbY))
        }
    }
}

@Composable
private fun StrengthControl(
    title: String,
    subtitle: String,
    value: Int,
    accent: Color,
    icon: @Composable () -> Unit,
    enabled: Boolean,
    onValueChange: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF192235))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(color = accent.copy(alpha = 0.14f), shape = CircleShape, modifier = Modifier.size(38.dp)) {
                Box(contentAlignment = Alignment.Center) { icon() }
            }
            Column(modifier = Modifier.weight(1f).padding(start = 10.dp)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(subtitle, color = Color.LightGray.copy(alpha = 0.75f), fontSize = 11.sp)
            }
            Text("${value / 10}%", color = accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Slider(
            value = value.toFloat().coerceIn(0f, 1000f),
            onValueChange = { onValueChange(it.toInt()) },
            valueRange = 0f..1000f,
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = Color.White.copy(alpha = 0.12f)
            )
        )
    }
}

private fun fiveBandIndexes(bandCount: Int): List<Int> {
    if (bandCount <= 0) return emptyList()
    if (bandCount == 1) return List(5) { 0 }
    return (0..4).map { displayIndex ->
        (displayIndex * (bandCount - 1) / 4f).roundToInt().coerceIn(0, bandCount - 1)
    }
}

private fun formatFrequency(hz: Int): String = when {
    hz >= 1000 -> "${"%.1f".format(hz / 1000f).trimEnd('0').trimEnd('.')}k"
    else -> "${hz}Hz"
}
