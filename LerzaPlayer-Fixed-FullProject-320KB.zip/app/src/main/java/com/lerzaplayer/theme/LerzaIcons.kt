package com.lerzaplayer.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object LerzaIcons {

    val Play: ImageVector = ImageVector.Builder(
        name = "Play",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(8f, 5f)
            verticalLineTo(19f)
            lineTo(19f, 12f)
            close()
        }
    }.build()

    val Pause: ImageVector = ImageVector.Builder(
        name = "Pause",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 19f)
            horizontalLineTo(10f)
            verticalLineTo(5f)
            horizontalLineTo(6f)
            verticalLineTo(19f)
            close()
            moveTo(14f, 5f)
            verticalLineTo(19f)
            horizontalLineTo(18f)
            verticalLineTo(5f)
            horizontalLineTo(14f)
            close()
        }
    }.build()

    val SkipNext: ImageVector = ImageVector.Builder(
        name = "SkipNext",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 18f)
            lineTo(14.5f, 12f)
            lineTo(6f, 6f)
            verticalLineTo(18f)
            close()
            moveTo(16f, 6f)
            verticalLineTo(18f)
            horizontalLineTo(18f)
            verticalLineTo(6f)
            horizontalLineTo(16f)
            close()
        }
    }.build()

    val SkipPrevious: ImageVector = ImageVector.Builder(
        name = "SkipPrevious",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 6f)
            horizontalLineTo(8f)
            verticalLineTo(18f)
            horizontalLineTo(6f)
            close()
            moveTo(9.5f, 12f)
            lineTo(18f, 18f)
            verticalLineTo(6f)
            lineTo(9.5f, 12f)
            close()
        }
    }.build()

    val Shuffle: ImageVector = ImageVector.Builder(
        name = "Shuffle",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(10.59f, 9.17f)
            lineTo(5.41f, 4f)
            lineTo(4f, 5.41f)
            lineTo(9.17f, 10.59f)
            lineTo(10.59f, 9.17f)
            close()
            moveTo(14.5f, 4f)
            lineTo(16.54f, 6.04f)
            lineTo(4f, 18.59f)
            lineTo(5.41f, 20f)
            lineTo(17.96f, 7.46f)
            lineTo(20f, 9.5f)
            verticalLineTo(4f)
            horizontalLineTo(14.5f)
            close()
            moveTo(14.83f, 13.41f)
            lineTo(13.42f, 14.83f)
            lineTo(16.55f, 17.95f)
            lineTo(14.5f, 20f)
            horizontalLineTo(20f)
            verticalLineTo(14.5f)
            lineTo(17.96f, 16.54f)
            lineTo(14.83f, 13.41f)
            close()
        }
    }.build()

    val Repeat: ImageVector = ImageVector.Builder(
        name = "Repeat",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(7f, 7f)
            horizontalLineTo(17f)
            verticalLineTo(10f)
            lineTo(21f, 6f)
            lineTo(17f, 2f)
            verticalLineTo(5f)
            horizontalLineTo(5f)
            verticalLineTo(11f)
            horizontalLineTo(7f)
            verticalLineTo(7f)
            close()
            moveTo(17f, 17f)
            horizontalLineTo(7f)
            verticalLineTo(14f)
            lineTo(3f, 18f)
            lineTo(7f, 22f)
            verticalLineTo(19f)
            horizontalLineTo(19f)
            verticalLineTo(13f)
            horizontalLineTo(17f)
            verticalLineTo(17f)
            close()
        }
    }.build()

    val RepeatOne: ImageVector = ImageVector.Builder(
        name = "RepeatOne",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(7f, 7f)
            horizontalLineTo(17f)
            verticalLineTo(10f)
            lineTo(21f, 6f)
            lineTo(17f, 2f)
            verticalLineTo(5f)
            horizontalLineTo(5f)
            verticalLineTo(11f)
            horizontalLineTo(7f)
            verticalLineTo(7f)
            close()
            moveTo(17f, 17f)
            horizontalLineTo(7f)
            verticalLineTo(14f)
            lineTo(3f, 18f)
            lineTo(7f, 22f)
            verticalLineTo(19f)
            horizontalLineTo(19f)
            verticalLineTo(13f)
            horizontalLineTo(17f)
            verticalLineTo(17f)
            close()
            moveTo(13f, 15f)
            verticalLineTo(9f)
            horizontalLineTo(12f)
            lineTo(10f, 10f)
            verticalLineTo(11f)
            lineTo(11.5f, 10.25f)
            verticalLineTo(15f)
            horizontalLineTo(13f)
            close()
        }
    }.build()

    val QueueMusic: ImageVector = ImageVector.Builder(
        name = "QueueMusic",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(15f, 6f)
            horizontalLineTo(3f)
            verticalLineTo(8f)
            horizontalLineTo(15f)
            verticalLineTo(6f)
            close()
            moveTo(15f, 10f)
            horizontalLineTo(3f)
            verticalLineTo(12f)
            horizontalLineTo(15f)
            verticalLineTo(10f)
            close()
            moveTo(3f, 16f)
            horizontalLineTo(11f)
            verticalLineTo(14f)
            horizontalLineTo(3f)
            verticalLineTo(16f)
            close()
            moveTo(17f, 6f)
            verticalLineTo(14.18f)
            curveTo(16.69f, 14.07f, 16.35f, 14f, 16f, 14f)
            curveTo(14.34f, 14f, 13f, 15.34f, 13f, 17f)
            curveTo(13f, 18.66f, 14.34f, 20f, 16f, 20f)
            curveTo(17.66f, 20f, 19f, 18.66f, 19f, 17f)
            verticalLineTo(8f)
            horizontalLineTo(22f)
            verticalLineTo(6f)
            horizontalLineTo(17f)
            close()
        }
    }.build()

    val Tune: ImageVector = ImageVector.Builder(
        name = "Tune",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(3f, 17f)
            verticalLineTo(19f)
            horizontalLineTo(9f)
            verticalLineTo(17f)
            horizontalLineTo(3f)
            close()
            moveTo(3f, 5f)
            verticalLineTo(7f)
            horizontalLineTo(13f)
            verticalLineTo(5f)
            horizontalLineTo(3f)
            close()
            moveTo(13f, 21f)
            verticalLineTo(19f)
            horizontalLineTo(21f)
            verticalLineTo(17f)
            horizontalLineTo(13f)
            verticalLineTo(15f)
            horizontalLineTo(11f)
            verticalLineTo(21f)
            horizontalLineTo(13f)
            close()
            moveTo(7f, 9f)
            verticalLineTo(11f)
            horizontalLineTo(3f)
            verticalLineTo(13f)
            horizontalLineTo(7f)
            verticalLineTo(15f)
            horizontalLineTo(9f)
            verticalLineTo(9f)
            horizontalLineTo(7f)
            close()
            moveTo(21f, 13f)
            verticalLineTo(11f)
            horizontalLineTo(11f)
            verticalLineTo(13f)
            horizontalLineTo(21f)
            close()
            moveTo(15f, 9f)
            horizontalLineTo(17f)
            verticalLineTo(7f)
            horizontalLineTo(21f)
            verticalLineTo(5f)
            horizontalLineTo(17f)
            verticalLineTo(3f)
            horizontalLineTo(15f)
            verticalLineTo(9f)
            close()
        }
    }.build()

    val MusicNote: ImageVector = ImageVector.Builder(
        name = "MusicNote",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f)
            verticalLineTo(13.55f)
            curveTo(11.41f, 13.21f, 10.73f, 13f, 10f, 13f)
            curveTo(7.79f, 13f, 6f, 14.79f, 6f, 17f)
            curveTo(6f, 19.21f, 7.79f, 21f, 10f, 21f)
            curveTo(12.21f, 21f, 14f, 19.21f, 14f, 17f)
            verticalLineTo(7f)
            horizontalLineTo(18f)
            verticalLineTo(3f)
            horizontalLineTo(12f)
            close()
        }
    }.build()

    val Lyrics: ImageVector = ImageVector.Builder(
        name = "Lyrics",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f)
            verticalLineTo(12.55f)
            curveTo(11.41f, 12.21f, 10.73f, 12f, 10f, 12f)
            curveTo(7.79f, 12f, 6f, 13.79f, 6f, 16f)
            curveTo(6f, 18.21f, 7.79f, 20f, 10f, 20f)
            curveTo(12.21f, 20f, 14f, 18.21f, 14f, 16f)
            verticalLineTo(7f)
            horizontalLineTo(18f)
            verticalLineTo(3f)
            horizontalLineTo(12f)
            close()
            moveTo(3f, 6f)
            horizontalLineTo(9f)
            verticalLineTo(8f)
            horizontalLineTo(3f)
            close()
            moveTo(3f, 10f)
            horizontalLineTo(9f)
            verticalLineTo(12f)
            horizontalLineTo(3f)
            close()
        }
    }.build()

    val LockOpen: ImageVector = ImageVector.Builder(
        name = "LockOpen",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 17f)
            curveTo(13.1f, 17f, 14f, 16.1f, 14f, 15f)
            curveTo(14f, 13.9f, 13.1f, 13f, 12f, 13f)
            curveTo(10.9f, 13f, 10f, 13.9f, 10f, 15f)
            curveTo(10f, 16.1f, 10.9f, 17f, 12f, 17f)
            close()
            moveTo(18f, 8f)
            horizontalLineTo(17f)
            verticalLineTo(6f)
            curveTo(17f, 3.24f, 14.76f, 1f, 12f, 1f)
            curveTo(9.24f, 1f, 7f, 3.24f, 7f, 6f)
            horizontalLineTo(8.9f)
            curveTo(8.9f, 4.29f, 10.29f, 2.9f, 12f, 2.9f)
            curveTo(13.71f, 2.9f, 15.1f, 4.29f, 15.1f, 6f)
            verticalLineTo(8f)
            horizontalLineTo(6f)
            curveTo(4.9f, 8f, 4f, 8.9f, 4f, 10f)
            verticalLineTo(20f)
            curveTo(4f, 21.1f, 4.9f, 22f, 6f, 22f)
            horizontalLineTo(18f)
            curveTo(19.1f, 22f, 20f, 21.1f, 20f, 20f)
            verticalLineTo(10f)
            curveTo(20f, 8.9f, 19.1f, 8f, 18f, 8f)
            close()
            moveTo(18f, 20f)
            horizontalLineTo(6f)
            verticalLineTo(10f)
            horizontalLineTo(18f)
            verticalLineTo(20f)
            close()
        }
    }.build()

    val ScreenRotation: ImageVector = ImageVector.Builder(
        name = "ScreenRotation",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(16.48f, 2.52f)
            curveTo(17.26f, 3.3f, 17.65f, 4.28f, 17.65f, 5.26f)
            horizontalLineTo(19.65f)
            curveTo(19.65f, 3.74f, 19.06f, 2.22f, 17.89f, 1.05f)
            curveTo(15.55f, -1.29f, 11.75f, -1.29f, 9.41f, 1.05f)
            lineTo(8f, 2.46f)
            verticalLineTo(0f)
            horizontalLineTo(6f)
            verticalLineTo(6f)
            horizontalLineTo(12f)
            verticalLineTo(4f)
            horizontalLineTo(9.41f)
            lineTo(10.82f, 2.59f)
            curveTo(12.38f, 1.03f, 14.92f, 1.03f, 16.48f, 2.52f)
            close()
            moveTo(7.52f, 21.48f)
            curveTo(6.74f, 20.7f, 6.35f, 19.72f, 6.35f, 18.74f)
            horizontalLineTo(4.35f)
            curveTo(4.35f, 20.26f, 4.94f, 21.78f, 6.11f, 22.95f)
            curveTo(8.45f, 25.29f, 12.25f, 25.29f, 14.59f, 22.95f)
            lineTo(16f, 21.54f)
            verticalLineTo(24f)
            horizontalLineTo(18f)
            verticalLineTo(18f)
            horizontalLineTo(12f)
            verticalLineTo(20f)
            horizontalLineTo(14.59f)
            lineTo(13.18f, 21.41f)
            curveTo(11.62f, 22.97f, 9.08f, 22.97f, 7.52f, 21.48f)
            close()
        }
    }.build()

    val Folder: ImageVector = ImageVector.Builder(
        name = "Folder",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(10f, 4f)
            horizontalLineTo(4f)
            curveTo(2.9f, 4f, 2f, 4.9f, 2f, 6f)
            verticalLineTo(18f)
            curveTo(2f, 19.1f, 2.9f, 20f, 4f, 20f)
            horizontalLineTo(20f)
            curveTo(21.1f, 20f, 22f, 19.1f, 22f, 18f)
            verticalLineTo(8f)
            curveTo(22f, 6.9f, 21.1f, 6f, 20f, 6f)
            horizontalLineTo(12f)
            lineTo(10f, 4f)
            close()
        }
    }.build()

    val Videocam: ImageVector = ImageVector.Builder(
        name = "Videocam",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(17f, 10.5f)
            verticalLineTo(7f)
            curveTo(17f, 6.45f, 16.55f, 6f, 16f, 6f)
            horizontalLineTo(4f)
            curveTo(3.45f, 6f, 3f, 6.45f, 3f, 7f)
            verticalLineTo(17f)
            curveTo(3f, 17.55f, 3.45f, 18f, 4f, 18f)
            horizontalLineTo(16f)
            curveTo(16.55f, 18f, 17f, 17.55f, 17f, 17f)
            verticalLineTo(13.5f)
            lineTo(21f, 17.5f)
            verticalLineTo(6.5f)
            lineTo(17f, 10.5f)
            close()
        }
    }.build()

    val Audiotrack: ImageVector = ImageVector.Builder(
        name = "Audiotrack",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f)
            verticalLineTo(13.55f)
            curveTo(11.41f, 13.21f, 10.73f, 13f, 10f, 13f)
            curveTo(7.79f, 13f, 6f, 14.79f, 6f, 17f)
            curveTo(6f, 19.21f, 7.79f, 21f, 10f, 21f)
            curveTo(12.21f, 21f, 14f, 19.21f, 14f, 17f)
            verticalLineTo(7f)
            horizontalLineTo(18f)
            verticalLineTo(3f)
            horizontalLineTo(12f)
            close()
        }
    }.build()

    val SwapVert: ImageVector = ImageVector.Builder(
        name = "SwapVert",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(16f, 17.01f)
            verticalLineTo(10f)
            horizontalLineTo(14f)
            verticalLineTo(17.01f)
            horizontalLineTo(11f)
            lineTo(15f, 21f)
            lineTo(19f, 17.01f)
            horizontalLineTo(16f)
            close()
            moveTo(9f, 3f)
            lineTo(5f, 6.99f)
            horizontalLineTo(8f)
            verticalLineTo(14f)
            horizontalLineTo(10f)
            verticalLineTo(6.99f)
            horizontalLineTo(13f)
            lineTo(9f, 3f)
            close()
        }
    }.build()

    val ViewList: ImageVector = ImageVector.Builder(
        name = "ViewList",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(4f, 14f)
            horizontalLineTo(8f)
            verticalLineTo(10f)
            horizontalLineTo(4f)
            verticalLineTo(14f)
            close()
            moveTo(4f, 19f)
            horizontalLineTo(8f)
            verticalLineTo(15f)
            horizontalLineTo(4f)
            verticalLineTo(19f)
            close()
            moveTo(4f, 9f)
            horizontalLineTo(8f)
            verticalLineTo(5f)
            horizontalLineTo(4f)
            verticalLineTo(9f)
            close()
            moveTo(9f, 14f)
            horizontalLineTo(21f)
            verticalLineTo(10f)
            horizontalLineTo(9f)
            verticalLineTo(14f)
            close()
            moveTo(9f, 19f)
            horizontalLineTo(21f)
            verticalLineTo(15f)
            horizontalLineTo(9f)
            verticalLineTo(19f)
            close()
            moveTo(9f, 5f)
            verticalLineTo(9f)
            horizontalLineTo(21f)
            verticalLineTo(5f)
            horizontalLineTo(9f)
            close()
        }
    }.build()

    val GridView: ImageVector = ImageVector.Builder(
        name = "GridView",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(3f, 3f)
            verticalLineTo(11f)
            horizontalLineTo(11f)
            verticalLineTo(3f)
            horizontalLineTo(3f)
            close()
            moveTo(9f, 9f)
            horizontalLineTo(5f)
            verticalLineTo(5f)
            horizontalLineTo(9f)
            verticalLineTo(9f)
            close()
            moveTo(13f, 3f)
            verticalLineTo(11f)
            horizontalLineTo(21f)
            verticalLineTo(3f)
            horizontalLineTo(13f)
            close()
            moveTo(19f, 9f)
            horizontalLineTo(15f)
            verticalLineTo(5f)
            horizontalLineTo(19f)
            verticalLineTo(9f)
            close()
            moveTo(3f, 13f)
            verticalLineTo(21f)
            horizontalLineTo(11f)
            verticalLineTo(13f)
            horizontalLineTo(3f)
            close()
            moveTo(9f, 19f)
            horizontalLineTo(5f)
            verticalLineTo(15f)
            horizontalLineTo(9f)
            verticalLineTo(19f)
            close()
            moveTo(13f, 13f)
            verticalLineTo(21f)
            horizontalLineTo(21f)
            verticalLineTo(13f)
            horizontalLineTo(13f)
            close()
            moveTo(19f, 19f)
            horizontalLineTo(15f)
            verticalLineTo(15f)
            horizontalLineTo(19f)
            verticalLineTo(19f)
            close()
        }
    }.build()

    val VisibilityOff: ImageVector = ImageVector.Builder(
        name = "VisibilityOff",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 7f)
            curveTo(13.37f, 7f, 14.59f, 7.57f, 15.48f, 8.48f)
            lineTo(18.31f, 5.65f)
            curveTo(16.63f, 4.35f, 14.47f, 3.5f, 12f, 3.5f)
            curveTo(7f, 3.5f, 2.73f, 6.61f, 1f, 11f)
            curveTo(1.88f, 13.23f, 3.37f, 15.11f, 5.25f, 16.42f)
            lineTo(7.7f, 13.97f)
            curveTo(7.26f, 13.39f, 7f, 12.72f, 7f, 12f)
            curveTo(7f, 9.24f, 9.24f, 7f, 12f, 7f)
            close()
            moveTo(2f, 4.27f)
            lineTo(4.28f, 6.55f)
            lineTo(4.73f, 7f)
            curveTo(3.08f, 8.3f, 1.78f, 10.02f, 1f, 12f)
            curveTo(2.73f, 16.39f, 7f, 19.5f, 12f, 19.5f)
            curveTo(13.55f, 19.5f, 15.03f, 19.2f, 16.38f, 18.66f)
            lineTo(16.73f, 19.01f)
            lineTo(19.73f, 22.01f)
            lineTo(21f, 20.74f)
            lineTo(3.27f, 3f)
            lineTo(2f, 4.27f)
            close()
        }
    }.build()

    val Palette: ImageVector = ImageVector.Builder(
        name = "Palette",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f)
            curveTo(6.5f, 3f, 2f, 6.5f, 2f, 12f)
            curveTo(2f, 15.5f, 4.5f, 18.5f, 8f, 19.5f)
            curveTo(8.5f, 19.6f, 9f, 19.2f, 9f, 18.7f)
            verticalLineTo(17.5f)
            curveTo(9f, 16.1f, 10.1f, 15f, 11.5f, 15f)
            horizontalLineTo(13f)
            curveTo(17.4f, 15f, 21f, 11.4f, 21f, 7f)
            curveTo(21f, 4.8f, 17f, 3f, 12f, 3f)
            close()
            moveTo(6.5f, 11.5f)
            curveTo(5.7f, 11.5f, 5f, 10.8f, 5f, 10f)
            curveTo(5f, 9.2f, 5.7f, 8.5f, 6.5f, 8.5f)
            curveTo(7.3f, 8.5f, 8f, 9.2f, 8f, 10f)
            curveTo(8f, 10.8f, 7.3f, 11.5f, 6.5f, 11.5f)
            close()
            moveTo(9.5f, 7.5f)
            curveTo(8.7f, 7.5f, 8f, 6.8f, 8f, 6f)
            curveTo(8f, 5.2f, 8.7f, 4.5f, 9.5f, 4.5f)
            curveTo(10.3f, 4.5f, 11f, 5.2f, 11f, 6f)
            curveTo(11f, 6.8f, 10.3f, 7.5f, 9.5f, 7.5f)
            close()
            moveTo(14.5f, 7.5f)
            curveTo(13.7f, 7.5f, 13f, 6.8f, 13f, 6f)
            curveTo(13f, 5.2f, 13.7f, 4.5f, 14.5f, 4.5f)
            curveTo(15.3f, 4.5f, 16f, 5.2f, 16f, 6f)
            curveTo(16f, 6.8f, 15.3f, 7.5f, 14.5f, 7.5f)
            close()
            moveTo(17.5f, 11.5f)
            curveTo(16.7f, 11.5f, 16f, 10.8f, 16f, 10f)
            curveTo(16f, 9.2f, 16.7f, 8.5f, 17.5f, 8.5f)
            curveTo(18.3f, 8.5f, 19f, 9.2f, 19f, 10f)
            curveTo(19f, 10.8f, 18.3f, 11.5f, 17.5f, 11.5f)
            close()
        }
    }.build()

    val Wallpaper: ImageVector = ImageVector.Builder(
        name = "Wallpaper",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(4f, 4f)
            horizontalLineTo(7f)
            verticalLineTo(2f)
            horizontalLineTo(4f)
            curveTo(2.9f, 2f, 2f, 2.9f, 2f, 4f)
            verticalLineTo(7f)
            horizontalLineTo(4f)
            verticalLineTo(4f)
            close()
            moveTo(4f, 17f)
            horizontalLineTo(2f)
            verticalLineTo(20f)
            curveTo(2f, 21.1f, 2.9f, 22f, 4f, 22f)
            horizontalLineTo(7f)
            verticalLineTo(20f)
            horizontalLineTo(4f)
            verticalLineTo(17f)
            close()
            moveTo(20f, 20f)
            horizontalLineTo(17f)
            verticalLineTo(22f)
            horizontalLineTo(20f)
            curveTo(21.1f, 22f, 22f, 21.1f, 22f, 20f)
            verticalLineTo(17f)
            horizontalLineTo(20f)
            verticalLineTo(20f)
            close()
            moveTo(20f, 4f)
            verticalLineTo(7f)
            horizontalLineTo(22f)
            verticalLineTo(4f)
            curveTo(22f, 2.9f, 21.1f, 2f, 20f, 2f)
            horizontalLineTo(17f)
            verticalLineTo(4f)
            horizontalLineTo(20f)
            close()
            moveTo(10f, 13f)
            lineTo(7f, 17f)
            horizontalLineTo(17f)
            lineTo(13.5f, 12.5f)
            lineTo(11f, 15.5f)
            lineTo(10f, 13f)
            close()
        }
    }.build()

    val AddPhoto: ImageVector = ImageVector.Builder(
        name = "AddPhoto",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(19f, 7f)
            verticalLineTo(4f)
            horizontalLineTo(17f)
            verticalLineTo(7f)
            horizontalLineTo(14f)
            verticalLineTo(9f)
            horizontalLineTo(17f)
            verticalLineTo(12f)
            horizontalLineTo(19f)
            verticalLineTo(9f)
            horizontalLineTo(22f)
            verticalLineTo(7f)
            horizontalLineTo(19f)
            close()
            moveTo(16f, 11.5f)
            verticalLineTo(14f)
            horizontalLineTo(5f)
            verticalLineTo(5f)
            horizontalLineTo(13.5f)
            verticalLineTo(3f)
            horizontalLineTo(5f)
            curveTo(3.9f, 3f, 3f, 3.9f, 3f, 5f)
            verticalLineTo(19f)
            curveTo(3f, 20.1f, 3.9f, 21f, 5f, 21f)
            horizontalLineTo(19f)
            curveTo(20.1f, 21f, 21f, 20.1f, 21f, 19f)
            verticalLineTo(11.5f)
            horizontalLineTo(16f)
            close()
        }
    }.build()

    val Pattern: ImageVector = ImageVector.Builder(
        name = "Pattern",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 6f)
            horizontalLineTo(8f)
            verticalLineTo(8f)
            horizontalLineTo(6f)
            close()
            moveTo(11f, 6f)
            horizontalLineTo(13f)
            verticalLineTo(8f)
            horizontalLineTo(11f)
            close()
            moveTo(16f, 6f)
            horizontalLineTo(18f)
            verticalLineTo(8f)
            horizontalLineTo(16f)
            close()
            moveTo(6f, 11f)
            horizontalLineTo(8f)
            verticalLineTo(13f)
            horizontalLineTo(6f)
            close()
            moveTo(11f, 11f)
            horizontalLineTo(13f)
            verticalLineTo(13f)
            horizontalLineTo(11f)
            close()
            moveTo(16f, 11f)
            horizontalLineTo(18f)
            verticalLineTo(13f)
            horizontalLineTo(16f)
            close()
            moveTo(6f, 16f)
            horizontalLineTo(8f)
            verticalLineTo(18f)
            horizontalLineTo(6f)
            close()
            moveTo(11f, 16f)
            horizontalLineTo(13f)
            verticalLineTo(18f)
            horizontalLineTo(11f)
            close()
            moveTo(16f, 16f)
            horizontalLineTo(18f)
            verticalLineTo(18f)
            horizontalLineTo(16f)
            close()
        }
    }.build()

    val Backspace: ImageVector = ImageVector.Builder(
        name = "Backspace",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(22f, 3f)
            horizontalLineTo(7f)
            curveTo(6.31f, 3f, 5.7f, 3.43f, 5.42f, 4.07f)
            lineTo(0f, 12f)
            lineTo(5.42f, 19.93f)
            curveTo(5.7f, 20.57f, 6.31f, 21f, 7f, 21f)
            horizontalLineTo(22f)
            curveTo(23.1f, 21f, 24f, 20.1f, 24f, 19f)
            verticalLineTo(5f)
            curveTo(24f, 3.9f, 23.1f, 3f, 22f, 3f)
            close()
            moveTo(19f, 15.59f)
            lineTo(17.59f, 17f)
            lineTo(14f, 13.41f)
            lineTo(10.41f, 17f)
            lineTo(9f, 15.59f)
            lineTo(12.59f, 12f)
            lineTo(9f, 8.41f)
            lineTo(10.41f, 7f)
            lineTo(14f, 10.59f)
            lineTo(17.59f, 7f)
            lineTo(19f, 8.41f)
            lineTo(15.41f, 12f)
            lineTo(19f, 15.59f)
            close()
        }
    }.build()

    val Restore: ImageVector = ImageVector.Builder(
        name = "Restore",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(13f, 3f)
            curveTo(8.03f, 3f, 4f, 7.03f, 4f, 12f)
            horizontalLineTo(1f)
            lineTo(4.89f, 15.89f)
            lineTo(5f, 16f)
            lineTo(9f, 12f)
            horizontalLineTo(6f)
            curveTo(6f, 8.13f, 9.13f, 5f, 13f, 5f)
            curveTo(16.87f, 5f, 20f, 8.13f, 20f, 12f)
            curveTo(20f, 15.87f, 16.87f, 19f, 13f, 19f)
            curveTo(11.07f, 19f, 9.32f, 18.21f, 8.06f, 16.94f)
            lineTo(6.64f, 18.36f)
            curveTo(8.27f, 20f, 10.51f, 21f, 13f, 21f)
            curveTo(17.97f, 21f, 22f, 16.97f, 22f, 12f)
            curveTo(22f, 7.03f, 17.97f, 3f, 13f, 3f)
            close()
            moveTo(12f, 8f)
            verticalLineTo(13f)
            lineTo(16.28f, 15.54f)
            lineTo(17f, 14.33f)
            lineTo(13.5f, 12.25f)
            verticalLineTo(8f)
            horizontalLineTo(12f)
            close()
        }
    }.build()
}
