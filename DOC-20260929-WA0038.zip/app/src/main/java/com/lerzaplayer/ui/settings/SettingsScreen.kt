package com.lerzaplayer.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import com.lerzaplayer.ui.player.EqualizerSheet
import com.lerzaplayer.update.AppUpdateManager
import kotlinx.coroutines.launch
import java.io.File

data class AboutFeatureItem(
    val icon: ImageVector,
    val title: String,
    val description: String
)

val ABOUT_FEATURES = listOf(
    AboutFeatureItem(
        Icons.Default.GraphicEq,
        "10-Band Pro Audio Equalizer",
        "Fine-tune 10 frequency bands (31Hz - 16kHz) with Bass Booster, Vocal Enhancer, and Treble Booster."
    ),
    AboutFeatureItem(
        Icons.Default.VisibilityOff,
        "Secure Private Vault",
        "Protect personal music and video files inside an encrypted vault locked with PIN code or pattern gesture."
    ),
    AboutFeatureItem(
        Icons.Default.Palette,
        "Theme & Wallpaper Studio",
        "Customize player with personal gallery photos, real-time opacity dimming slider, and 11 vibrant accent palettes."
    ),
    AboutFeatureItem(
        Icons.Default.ViewStream,
        "Song Size & Density Adjuster",
        "Scale track row height, thumbnail size, and typography to Compact, Normal, Comfortable, or Extra Bold."
    ),
    AboutFeatureItem(
        Icons.Default.NotificationsActive,
        "Enhanced Media Notification",
        "System media controls with interactive timeline seekbar, Previous, Play/Pause, and Next buttons."
    ),
    AboutFeatureItem(
        Icons.Default.VideoLibrary,
        "Lossless Audio & HD Video Engine",
        "Hardware-accelerated playback with speed adjustments, background playback, and auto-resume."
    ),
    AboutFeatureItem(
        Icons.Default.Alarm,
        "Smart Sleep Timer & Playtime Insights",
        "Auto-stop playback timer for bedtime listening with detailed statistics of your daily music journey."
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    onOpenEqualizer: () -> Unit = {},
    onScanMedia: () -> Unit,
    onOpenVault: () -> Unit = {},
    recentlyDeleted: List<RecentlyDeletedEntity> = emptyList(),
    onPlayRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onRestoreRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onPermanentlyDeleteRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current
    val activeColor = ThemeManager.currentAccentColor

    val appPlayerManager = remember { PlayerManager.getInstance(context) }
    val sleepMinutes by appPlayerManager.sleepTimerMinutes.collectAsState()

    var currentSubScreen by remember { mutableStateOf<String?>(null) }
    var showSleepTimerSheet by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }

    BackHandler(enabled = currentSubScreen != null || showEqualizerSheet) {
        if (showEqualizerSheet) {
            showEqualizerSheet = false
        } else {
            currentSubScreen = null
        }
    }

    // 10-Band Equalizer Sheet directly on SettingsScreen
    if (showEqualizerSheet) {
        EqualizerSheet(
            onDismiss = { showEqualizerSheet = false }
        )
    }

    if (currentSubScreen == "theme") {
        ThemeScreen(
            prefManager = prefManager,
            onBack = { currentSubScreen = null }
        )
        return
    }

    if (currentSubScreen == "recently_deleted") {
        RecentlyDeletedScreen(
            items = recentlyDeleted,
            onBack = { currentSubScreen = null },
            onPlay = onPlayRecentlyDeleted,
            onRestore = onRestoreRecentlyDeleted,
            onPermanentlyDelete = onPermanentlyDeleteRecentlyDeleted
        )
        return
    }

    // Backup & Restore Screen (Coming Soon, Wait for Update)
    if (currentSubScreen == "backup_restore") {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "Backup & Restore",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = colors.textPrimary
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Back",
                                tint = colors.textPrimary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background)
                )
            },
            containerColor = colors.background
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = colors.card,
                    border = BorderStroke(1.dp, activeColor.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(activeColor.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = null,
                                tint = activeColor,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Text(
                            text = "Coming Soon",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = colors.textPrimary
                        )

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = activeColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "ویٹ فار اپ ڈیٹ • Wait for Update",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = activeColor,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }

                        Text(
                            text = "Cloud backup and restore is currently in progress. Please wait for the upcoming app update to synchronize your songs, playlists, and settings.",
                            fontSize = 13.sp,
                            color = colors.textSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            lineHeight = 19.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = { currentSubScreen = null },
                            colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(46.dp)
                        ) {
                            Text("OK / Back", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
        return
    }

    // About Screen (Version 0.0.0.0, Features list, Developed by Faraz Munawar at the bottom)
    if (currentSubScreen == "about") {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "About LerzaPlayer",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = colors.textPrimary
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { currentSubScreen = null }) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Back",
                                tint = colors.textPrimary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background)
                )
            },
            containerColor = colors.background
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header with App Branding and Version 0.0.0.0
                item {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = colors.card,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(
                                        Brush.linearGradient(
                                            listOf(activeColor, activeColor.copy(alpha = 0.7f))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(40.dp)
                                )
                            }

                            Text(
                                text = "LerzaPlayer",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = colors.textPrimary
                            )

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = activeColor.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "Version 0.0.0.0",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = activeColor,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                                )
                            }

                            Text(
                                text = "Ultra High-Definition Music & Video Engine with Studio Grade Audio Enhancements",
                                fontSize = 12.sp,
                                color = colors.textSecondary,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                lineHeight = 17.sp
                            )
                        }
                    }
                }

                // Features Header
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "APP FEATURES",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = colors.textSecondary,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${ABOUT_FEATURES.size} Premium Tools",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = activeColor
                        )
                    }
                }

                // Beautiful Frames for Each Feature
                items(ABOUT_FEATURES.size) { index ->
                    val feature = ABOUT_FEATURES[index]
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = colors.card,
                        border = BorderStroke(0.8.dp, colors.divider.copy(alpha = 0.7f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(activeColor.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = feature.icon,
                                    contentDescription = null,
                                    tint = activeColor,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = feature.title,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = feature.description,
                                    fontSize = 11.5.sp,
                                    color = colors.textSecondary,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }

                // DEVELOPER INFO AT THE VERY BOTTOM
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = colors.card,
                        border = BorderStroke(1.5.dp, activeColor.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(activeColor.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Code,
                                    contentDescription = null,
                                    tint = activeColor,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Text(
                                text = "Developed by Faraz Munawar",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = colors.textPrimary
                            )

                            Text(
                                text = "ڈویلپر بائے فراز منور",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = activeColor
                            )

                            Text(
                                text = "Crafted with passion for premium audio • All Rights Reserved",
                                fontSize = 10.5.sp,
                                color = colors.textSecondary
                            )
                        }
                    }
                }
            }
        }
        return
    }

    // Main Settings Screen
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = colors.textPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = colors.textPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background)
            )
        },
        containerColor = colors.background,
        modifier = modifier
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Group 1: Playtime & Backup & Restore
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.AccessTime,
                        title = "Playtime Insights",
                        badge = "Statistics",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "about"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.CloudSync,
                        title = "Backup & restore",
                        badge = "Coming Soon",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "backup_restore"
                        }
                    )
                }
            }

            // Group 2: Theme & Sleep Timer & Equalizer (Opens 10-Band EQ Sheet directly)
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.Palette,
                        title = "Theme & Colors",
                        badge = ThemeManager.currentThemeName,
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "theme"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Alarm,
                        title = "Sleep timer",
                        badge = if (sleepMinutes > 0) "$sleepMinutes min" else "Off",
                        accentColor = activeColor,
                        onClick = {
                            showSleepTimerSheet = true
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.GraphicEq,
                        title = "Audio Equalizer & Bass",
                        badge = "10-Band EQ",
                        accentColor = activeColor,
                        onClick = {
                            showEqualizerSheet = true
                        }
                    )
                }
            }

            // Group 3: Hidden Files & Recently Deleted
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.VisibilityOff,
                        title = "Hidden files (Vault)",
                        badge = "Protected",
                        accentColor = activeColor,
                        onClick = onOpenVault
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.DeleteOutline,
                        title = "Recently deleted",
                        badge = "${recentlyDeleted.size} files",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "recently_deleted"
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Refresh,
                        title = "Scan Media Library",
                        badge = "Rescan",
                        accentColor = activeColor,
                        onClick = onScanMedia
                    )
                }
            }

            // Group 4: About & In-App OTA Update Check
            item {
                SettingsGroupCard {
                    LarkSettingsRow(
                        icon = Icons.Default.SystemUpdate,
                        title = "Check for Updates",
                        badge = "Check now",
                        accentColor = activeColor,
                        onClick = {
                            scope.launch {
                                Toast.makeText(context, "Checking server for updates...", Toast.LENGTH_SHORT).show()
                                val update = AppUpdateManager.checkForUpdates(context)
                                if (update == null) {
                                    Toast.makeText(context, "You are using the latest version!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    )
                    SettingsDivider()
                    LarkSettingsRow(
                        icon = Icons.Default.Info,
                        title = "App Version & About",
                        badge = "0.0.0.0",
                        accentColor = activeColor,
                        onClick = {
                            currentSubScreen = "about"
                        }
                    )
                }
            }
        }
    }

    if (showSleepTimerSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSleepTimerSheet = false },
            containerColor = colors.card
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "Sleep Timer",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                listOf(0, 10, 15, 30, 45, 60, 90).forEach { mins ->
                    SleepTimerOptionRow(
                        title = if (mins == 0) "Turn off" else "$mins minutes",
                        isSelected = sleepMinutes == mins,
                        accentColor = activeColor,
                        onClick = {
                            appPlayerManager.setSleepTimer(mins)
                            showSleepTimerSheet = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsGroupCard(content: @Composable ColumnScope.() -> Unit) {
    val colors = LocalLerzaColors.current
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = colors.card,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            content()
        }
    }
}

@Composable
private fun LarkSettingsRow(
    icon: ImageVector,
    title: String,
    badge: String? = null,
    accentColor: Color,
    onClick: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Text(
            text = title,
            fontSize = 15.sp,
            color = colors.textPrimary,
            modifier = Modifier.weight(1f)
        )

        if (badge != null) {
            Text(
                text = badge,
                fontSize = 13.sp,
                color = colors.textSecondary
            )
            Spacer(modifier = Modifier.width(6.dp))
        }

        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = colors.textSecondary.copy(alpha = 0.5f),
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun SettingsDivider() {
    val colors = LocalLerzaColors.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(0.6.dp)
            .background(colors.divider)
    )
}

@Composable
private fun SleepTimerOptionRow(
    title: String,
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            fontSize = 15.sp,
            color = if (isSelected) accentColor else colors.textPrimary
        )
        if (isSelected) {
            Icon(Icons.Default.Check, contentDescription = null, tint = accentColor)
        }
    }
}