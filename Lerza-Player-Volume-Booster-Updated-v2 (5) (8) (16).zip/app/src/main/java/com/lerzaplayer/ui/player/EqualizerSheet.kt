package com.lerzaplayer.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.collectAsState
import androidx.compose.material3.ExperimentalMaterial3Api
import com.lerzaplayer.playback.PlayerManager

private val EqCyan = Color(0xFF45E6FF)
private val EqPurple = Color(0xFFB67CFF)
private val EqPink = Color(0xFFFF64B4)
private val EqGreen = Color(0xFF67F5C1)
private val EqPanel = Color(0xFF111827)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerSheet(
    playerManager: PlayerManager,
    onDismiss: () -> Unit
) {
    val snapshot by playerManager.equalizerSnapshot.collectAsState()
    val enabled by playerManager.equalizerEnabled.collectAsState()
    val bassStrength by playerManager.bassBoostStrength.collectAsState()
    val virtualizerStrength by playerManager.virtualizerStrength.collectAsState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = EqPanel,
        contentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF172B48), Color(0xFF30204C), Color(0xFF142D38))
                        )
                    )
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(color = EqCyan.copy(alpha = 0.16f), shape = CircleShape) {
                    androidx.compose.material3.Icon(
                        imageVector = Icons.Filled.GraphicEq,
                        contentDescription = null,
                        tint = EqCyan,
                        modifier = Modifier.padding(11.dp).size(27.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Lerza Audio Lab", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (snapshot.supported) "Live audio processing" else "Audio effects initializing",
                        color = EqCyan.copy(alpha = 0.86f),
                        fontSize = 12.sp
                    )
                }
                Switch(checked = enabled, onCheckedChange = playerManager::setEqualizerEnabled)
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF192235))
                    .padding(16.dp)
            ) {
                Text("SOUND PROFILES", color = EqCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Spacer(Modifier.height(10.dp))
                if (snapshot.presetNames.isEmpty()) {
                    Text("No hardware presets are available on this device.", color = Color.LightGray, fontSize = 13.sp)
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        snapshot.presetNames.forEachIndexed { index, name ->
                            FilterChip(
                                selected = snapshot.selectedPreset == index,
                                onClick = { playerManager.setEqualizerPreset(index.toShort()) },
                                label = { Text(name.replaceFirstChar { it.uppercase() }) }
                            )
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF192235))
                    .padding(16.dp)
            ) {
                Text("FREQUENCY MIXER", color = EqPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Spacer(Modifier.height(8.dp))
                if (!snapshot.supported || snapshot.bandLevels.isEmpty()) {
                    Text(
                        "The device equalizer is not available yet. Start audio playback and reopen this panel.",
                        color = Color.LightGray,
                        fontSize = 13.sp
                    )
                } else {
                    snapshot.bandLevels.forEachIndexed { index, level ->
                        val centerHz = snapshot.bandCentersHz.getOrNull(index) ?: 0
                        val minLevel = snapshot.minimumBandLevel.toFloat()
                        val maxLevel = snapshot.maximumBandLevel.toFloat()
                        val safeRange = if (maxLevel > minLevel) minLevel..maxLevel else -1500f..1500f
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = formatFrequency(centerHz),
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 11.sp,
                                modifier = Modifier.width(52.dp)
                            )
                            Slider(
                                value = level.toFloat().coerceIn(safeRange.start, safeRange.endInclusive),
                                onValueChange = { value ->
                                    playerManager.setEqualizerBand(index.toShort(), value.toInt().toShort())
                                },
                                valueRange = safeRange,
                                enabled = enabled,
                                colors = SliderDefaults.colors(
                                    thumbColor = EqPurple,
                                    activeTrackColor = EqPurple,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.12f)
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "%+.1f".format(level / 100f),
                                color = EqPurple,
                                fontSize = 10.sp,
                                modifier = Modifier.width(40.dp)
                            )
                        }
                    }
                }
            }

            StrengthControl(
                title = "Bass impact",
                subtitle = "Low-frequency punch",
                value = bassStrength,
                accent = EqPink,
                icon = { androidx.compose.material3.Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = EqPink) },
                enabled = enabled,
                onValueChange = { playerManager.setBassBoostStrength(it.toShort()) }
            )
            StrengthControl(
                title = "Stereo space",
                subtitle = "Virtualizer / wider soundstage",
                value = virtualizerStrength,
                accent = EqGreen,
                icon = { androidx.compose.material3.Icon(Icons.Filled.Headphones, contentDescription = null, tint = EqGreen) },
                enabled = enabled,
                onValueChange = { playerManager.setVirtualizerStrength(it.toShort()) }
            )

            TextButton(
                onClick = {
                    val neutral = 0.toShort().coerceIn(snapshot.minimumBandLevel, snapshot.maximumBandLevel)
                    snapshot.bandLevels.indices.forEach { index ->
                        playerManager.setEqualizerBand(index.toShort(), neutral)
                    }
                    playerManager.setBassBoostStrength(0)
                    playerManager.setVirtualizerStrength(0)
                },
                modifier = Modifier.align(Alignment.End)
            ) {
                androidx.compose.material3.Icon(Icons.Filled.Refresh, contentDescription = null, tint = EqCyan)
                Spacer(Modifier.width(6.dp))
                Text("Reset sound", color = EqCyan)
            }
        }
    }
}

@Composable
private fun StrengthControl(
    title: String,
    subtitle: String,
    value: Int,
    accent: Color,
    icon: @Composable () -> Unit,
    enabled: Boolean,
    onValueChange: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF192235))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(color = accent.copy(alpha = 0.14f), shape = CircleShape, modifier = Modifier.size(38.dp)) {
                androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) { icon() }
            }
            Column(modifier = Modifier.weight(1f).padding(start = 10.dp)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(subtitle, color = Color.LightGray.copy(alpha = 0.75f), fontSize = 11.sp)
            }
            Text("${value / 10}%", color = accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Slider(
            value = value.toFloat().coerceIn(0f, 1000f),
            onValueChange = { onValueChange(it.toInt()) },
            valueRange = 0f..1000f,
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = Color.White.copy(alpha = 0.12f)
            )
        )
    }
}

private fun formatFrequency(hz: Int): String = when {
    hz >= 1000 -> "${"%.1f".format(hz / 1000f).trimEnd('0').trimEnd('.')} kHz"
    else -> "$hz Hz"
}
