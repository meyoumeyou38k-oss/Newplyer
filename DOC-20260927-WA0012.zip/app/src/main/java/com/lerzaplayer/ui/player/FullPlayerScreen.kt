package com.lerzaplayer.ui.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SongLyrics
import com.lerzaplayer.lyrics.LyricsManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.PaletteExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun FullPlayerScreen(
    playerManager: PlayerManager,
    onCollapse: () -> Unit,
    onFavoriteToggle: (SongItem) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    val configuration = LocalConfiguration.current

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()
    val currentPosition by playerManager.currentPosition.collectAsState()
    val duration by playerManager.duration.collectAsState()
    val queue by playerManager.queue.collectAsState()
    val currentIndex by playerManager.currentIndex.collectAsState()
    val isShuffle by playerManager.isShuffle.collectAsState()
    val repeatMode by playerManager.repeatMode.collectAsState()
    val playbackSpeed by playerManager.playbackSpeed.collectAsState()
    val sleepMinutes by playerManager.sleepTimerRemainingMinutes.collectAsState()

    var showOptionsSheet by remember { mutableStateOf(false) }
    var showEqSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showLyricsDialog by remember { mutableStateOf(false) }

    var lyricsState by remember { mutableStateOf<SongLyrics?>(null) }
    var isLoadingLyrics by remember { mutableStateOf(false) }
    var lyricsLanguage by remember { mutableStateOf("Original") }

    LaunchedEffect(currentSong?.id) {
        val song = currentSong
        if (song != null) {
            isLoadingLyrics = true
            lyricsState = LyricsManager.getLyricsForSong(context, song)
            isLoadingLyrics = false
        } else {
            lyricsState = null
        }
        lyricsLanguage = "Original"
    }

    val dynamicPalette = remember(currentSong?.id) {
        PaletteExtractor.extractPalette(null, currentSong?.id ?: 0L)
    }

    // सॉलिड और लाइट बैकग्राउंड कलर तैयार करना
    val solidLightBackgroundColor = remember(dynamicPalette) {
        val dom = dynamicPalette.dominantColor
        Color(
            red = dom.red + (1f - dom.red) * 0.70f,
            green = dom.green + (1f - dom.green) * 0.70f,
            blue = dom.blue + (1f - dom.blue) * 0.70f,
            alpha = 1f
        )
    }

    var dragOffsetY by remember { mutableStateOf(0f) }
    val draggableState = rememberDraggableState { delta ->
        if (delta > 0 || dragOffsetY > 0) {
            dragOffsetY = (dragOffsetY + delta).coerceAtLeast(0f)
            if (dragOffsetY > 300f) {
                onCollapse()
            }
        }
    }

    val pagerState = rememberPagerState(
        initialPage = currentIndex.coerceAtLeast(0),
        pageCount = { queue.size.coerceAtLeast(1) }
    )

    LaunchedEffect(currentIndex) {
        if (queue.isNotEmpty() && currentIndex in queue.indices && pagerState.currentPage != currentIndex) {
            pagerState.animateScrollToPage(currentIndex)
        }
    }

    LaunchedEffect(pagerState.currentPage) {
        if (queue.isNotEmpty() && pagerState.currentPage in queue.indices && pagerState.currentPage != currentIndex) {
            playerManager.playSongList(queue, pagerState.currentPage)
        }
    }

    val progressFraction = if (duration > 0) {
        (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Box(
        modifier = modifier
            .fillMaxSize()
            .offset { IntOffset(0, dragOffsetY.roundToInt()) }
            .graphicsLayer {
                alpha = (1f - (dragOffsetY / 600f)).coerceIn(0.2f, 1f)
            }
            .draggable(
                state = draggableState,
                orientation = Orientation.Vertical,
                onDragStopped = {
                    if (dragOffsetY > 200f) {
                        onCollapse()
                    }
                    dragOffsetY = 0f
                }
            )
            .background(solidLightBackgroundColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                IconButton(
                    onClick = onCollapse,
                    modifier = Modifier.align(Alignment.CenterStart)
                ) {
                    Icon(
                        imageVector = LerzaIcons.KeyboardArrowDown,
                        contentDescription = "Collapse",
                        tint = Color(0xFF1C1B1F),
                        modifier = Modifier.size(32.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black.copy(alpha = 0.08f))
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "LERZA PLAYER",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = Color(0xFF1C1B1F)
                    )
                }

                IconButton(
                    onClick = { showOptionsSheet = true },
                    modifier = Modifier.align(Alignment.CenterEnd)
                ) {
                    Icon(
                        imageVector = LerzaIcons.MoreVert,
                        contentDescription = "Options",
                        tint = Color(0xFF1C1B1F),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(290.dp),
                pageSpacing = 24.dp
            ) { page ->
                val songForPage = queue.getOrNull(page) ?: currentSong
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(260.dp)
                            .shadow(
                                elevation = 20.dp,
                                shape = RoundedCornerShape(24.dp),
                                spotColor = dynamicPalette.accentColor,
                                ambientColor = dynamicPalette.dominantColor
                            )
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(0xFF131A26)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (songForPage?.albumArtUri != null) {
                            AsyncImage(
                                model = songForPage.albumArtUri,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(220.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF16161D)),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.radialGradient(
                                                listOf(
                                                    dynamicPalette.accentColor,
                                                    dynamicPalette.dominantColor.copy(alpha = 0.6f)
                                                )
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = LerzaIcons.MusicNote,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Song Title & Artist + Favorite button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentSong?.title ?: "No Track Playing",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1C1B1F),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currentSong?.artist ?: "Unknown Artist",
                        fontSize = 14.sp,
                        color = Color(0xFF49454F),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = {
                        currentSong?.let { song ->
                            onFavoriteToggle(song)
                        }
                    },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = if (currentSong?.isFavorite == true) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (currentSong?.isFavorite == true) Color(0xFFFF334B) else Color(0xFF1C1B1F).copy(alpha = 0.7f),
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Slider & Timing
            Column(modifier = Modifier.fillMaxWidth()) {
                Slider(
                    value = progressFraction,
                    onValueChange = { frac ->
                        val targetMs = (frac * duration).toLong()
                        playerManager.seekTo(targetMs)
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = dynamicPalette.accentColor,
                        activeTrackColor = dynamicPalette.accentColor,
                        inactiveTrackColor = Color.Black.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val posSec = currentPosition / 1000
                    val durSec = duration / 1000
                    Text(
                        text = "%d:%02d".format(posSec / 60, posSec % 60),
                        fontSize = 12.sp,
                        color = Color(0xFF49454F)
                    )
                    Text(
                        text = "%d:%02d".format(durSec / 60, durSec % 60),
                        fontSize = 12.sp,
                        color = Color(0xFF49454F)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Playback Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { playerManager.toggleShuffle() }) {
                    Icon(
                        imageVector = LerzaIcons.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (isShuffle) Color(0xFF00B0FF) else Color(0xFF1C1B1F).copy(alpha = 0.6f),
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(
                    onClick = { playerManager.playPreviousTrack() },
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SkipPrevious,
                        contentDescription = "Previous",
                        tint = Color(0xFF1C1B1F),
                        modifier = Modifier.size(38.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF00E5FF), Color(0xFF00B0FF))
                            )
                        )
                        .clickable { playerManager.playPause() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) LerzaIcons.Pause else LerzaIcons.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.Black,
                        modifier = Modifier.size(40.dp)
                    )
                }

                IconButton(
                    onClick = { playerManager.playNextTrack() },
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SkipNext,
                        contentDescription = "Next",
                        tint = Color(0xFF1C1B1F),
                        modifier = Modifier.size(38.dp)
                    )
                }

                IconButton(onClick = { playerManager.cycleRepeatMode() }) {
                    Icon(
                        imageVector = if (repeatMode == 1) LerzaIcons.RepeatOne else LerzaIcons.Repeat,
                        contentDescription = "Repeat",
                        tint = if (repeatMode != 0) Color(0xFF00B0FF) else Color(0xFF1C1B1F).copy(alpha = 0.6f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bottom Auxiliary Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { showEqSheet = true }) {
                    Icon(
                        imageVector = LerzaIcons.Tune,
                        contentDescription = "Equalizer",
                        tint = Color(0xFF1C1B1F).copy(alpha = 0.8f),
                        modifier = Modifier.size(24.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black.copy(alpha = 0.08f))
                        .clickable { showLyricsDialog = true }
                        .padding(horizontal = 18.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = LerzaIcons.Lyrics,
                            contentDescription = null,
                            tint = Color(0xFF1C1B1F),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Lyrics",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1C1B1F)
                        )
                    }
                }

                IconButton(onClick = { showQueueSheet = true }) {
                    Icon(
                        imageVector = LerzaIcons.QueueMusic,
                        contentDescription = "Queue",
                        tint = Color(0xFF1C1B1F).copy(alpha = 0.8f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }

    // New FullPlayerOptionsSheet Integration
    if (showOptionsSheet && currentSong != null) {
        FullPlayerOptionsSheet(
            song = currentSong!!,
            playerManager = playerManager,
            dynamicPalette = dynamicPalette,
            onDismiss = { showOptionsSheet = false },
            onAddToPlaylist = {
                // Add to playlist logic
            },
            onHideInVault = {
                currentSong?.let { song ->
                    (context.applicationContext as? com.lerzaplayer.LerzaApp)?.vaultManager?.let { vault ->
                        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                            vault.hideSong(song)
                        }
                    }
                }
            },
            onDeleteSong = {
                currentSong?.let { song ->
                    onCollapse()
                    // MainActivity delete dialog will handle it safely
                    (context as? com.lerzaplayer.MainActivity)?.let { activity ->
                        activity.lifecycleScope.launch {
                            com.lerzaplayer.data.repository.MediaRepository(context).deleteMedia(song)
                        }
                    }
                }
            }
        )
    }

    // dynamicPalette کو ایکولائزر میں پاس کیا گیا ہے
    if (showEqSheet) {
        EqualizerSheet(
            playerManager = playerManager,
            dynamicPalette = dynamicPalette,
            onDismiss = { showEqSheet = false }
        )
    }

    if (showQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            containerColor = Color(0xFF131A26)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Playing Queue (${queue.size})",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    TextButton(onClick = { playerManager.clearQueue() }) {
                        Text("Clear All", color = Color(0xFFFF334B))
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                queue.forEachIndexed { index, song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { playerManager.playSongList(queue, index) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${index + 1}",
                            fontSize = 13.sp,
                            color = if (index == currentIndex) Color(0xFF00E5FF) else Color.Gray,
                            modifier = Modifier.width(28.dp)
                        )
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.08f)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (song.albumArtUri != null) {
                                AsyncImage(
                                    model = song.albumArtUri,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(
                                    LerzaIcons.MusicNote,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.65f),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                fontSize = 14.sp,
                                fontWeight = if (index == currentIndex) FontWeight.Bold else FontWeight.Normal,
                                color = if (index == currentIndex) Color(0xFF00E5FF) else Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = song.artist,
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        IconButton(onClick = { playerManager.removeFromQueue(index) }) {
                            Icon(LerzaIcons.Close, contentDescription = "Remove", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }

    if (showLyricsDialog) {
        AlertDialog(
            onDismissRequest = { showLyricsDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = currentSong?.title ?: "Lyrics",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Tap any line to seek • Offline Sync",
                            color = dynamicPalette.accentColor,
                            fontSize = 11.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(dynamicPalette.accentColor.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (lyricsState?.isGenerated == true) "AI SYNC" else "LRC SYNC",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = dynamicPalette.accentColor
                        )
                    }
                }
            },
            text = {
                val lyricsListState = androidx.compose.foundation.lazy.rememberLazyListState()
                val currentLines = lyricsState?.lines ?: emptyList()
                val activeLyricIndex = remember(currentPosition, currentLines) {
                    currentLines.indexOfLast { currentPosition >= it.timestampMs }
                }

                LaunchedEffect(activeLyricIndex) {
                    if (activeLyricIndex >= 0) {
                        try {
                            lyricsListState.animateScrollToItem(maxOf(0, activeLyricIndex - 1))
                        } catch (_: Exception) {}
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                ) {
                    if (isLoadingLyrics) {
                        CircularProgressIndicator(
                            color = dynamicPalette.accentColor,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    } else if (currentLines.isNotEmpty()) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("Original", "اردو", "हिंदी", "English").forEach { language ->
                                    FilterChip(
                                        selected = lyricsLanguage == language,
                                        onClick = { lyricsLanguage = language },
                                        label = { Text(language, fontSize = 10.sp) }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            androidx.compose.foundation.lazy.LazyColumn(
                                state = lyricsListState,
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(currentLines.size) { idx ->
                                    val line = currentLines[idx]
                                    val isLineActive = idx == activeLyricIndex
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (isLineActive) dynamicPalette.accentColor.copy(alpha = 0.22f)
                                                else Color.Transparent
                                            )
                                            .clickable { playerManager.seekTo(line.timestampMs) }
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = line.timeFormatted,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = if (isLineActive) dynamicPalette.accentColor else Color.Gray,
                                            modifier = Modifier.width(42.dp)
                                        )
                                        Text(
                                            text = line.text,
                                            fontSize = if (isLineActive) 15.sp else 13.sp,
                                            fontWeight = if (isLineActive) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isLineActive) Color.White else Color(0xFFB0BEC5),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "No lyrics found for this track.",
                            color = Color.Gray,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLyricsDialog = false }) {
                    Text("Close", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF131A26)
        )
    }
}
