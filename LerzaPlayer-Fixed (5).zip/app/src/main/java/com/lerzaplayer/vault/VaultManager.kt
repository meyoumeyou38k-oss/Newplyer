package com.lerzaplayer.vault

import android.content.Context
import android.media.MediaScannerConnection
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.preferences.PreferenceManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.*
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class VaultManager private constructor(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val vaultDao = db.vaultDao()
    private val prefManager = PreferenceManager(context)

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    val vaultMediaFlow: Flow<List<VaultMediaEntity>> = vaultDao.getAllVaultMedia()
    val lockTypeFlow: Flow<VaultLockType> = prefManager.vaultLockTypeFlow
    val pinFlow: Flow<String?> = prefManager.vaultPinFlow
    val patternFlow: Flow<String?> = prefManager.vaultPatternFlow

    private val vaultDir: File by lazy {
        File(context.filesDir, "vault_storage").apply { if (!exists()) mkdirs() }
    }

    fun hashInput(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray())
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    suspend fun verifyPin(enteredPin: String): Boolean {
        val savedHash = prefManager.vaultPinFlow.first()
        if (savedHash == null) {
            val newHash = hashInput(enteredPin)
            prefManager.setVaultPin(newHash)
            _isUnlocked.value = true
            return true
        }
        val match = hashInput(enteredPin) == savedHash
        if (match) _isUnlocked.value = true
        return match
    }

    suspend fun verifyPattern(patternPoints: List<Int>): Boolean {
        val enteredPattern = patternPoints.joinToString("-")
        val savedHash = prefManager.vaultPatternFlow.first()
        if (savedHash == null) {
            val newHash = hashInput(enteredPattern)
            prefManager.setVaultPattern(newHash)
            _isUnlocked.value = true
            return true
        }
        val match = hashInput(enteredPattern) == savedHash
        if (match) _isUnlocked.value = true
        return match
    }

    suspend fun setLockMode(type: VaultLockType) {
        prefManager.setVaultLockType(type)
    }

    fun lockVault() {
        _isUnlocked.value = false
    }

    fun onAppBackgrounded() {
        _isUnlocked.value = false
    }

    suspend fun hideSong(song: SongItem) = withContext(Dispatchers.IO) {
        try {
            val originalFile = File(song.path)
            if (!originalFile.exists()) return@withContext
            val encryptedFile = File(vaultDir, "vault_song_${song.id}.bin")
            val encryptedTemp = File(vaultDir, "${encryptedFile.name}.tmp")
            encryptCopy(originalFile, encryptedTemp)
            if (encryptedFile.exists()) encryptedFile.delete()
            if (!encryptedTemp.renameTo(encryptedFile)) {
                encryptedTemp.copyTo(encryptedFile, overwrite = true)
                encryptedTemp.delete()
            }
            vaultDao.insertVaultMedia(
                VaultMediaEntity(
                    originalPath = song.path,
                    encryptedPath = encryptedFile.absolutePath,
                    originalName = song.title,
                    mediaType = "AUDIO",
                    duration = song.duration,
                    size = originalFile.length()
                )
            )
            originalFile.delete()
            try {
                context.contentResolver.delete(song.contentUri, null, null)
            } catch (_: Exception) {}
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun hideVideo(video: VideoItem) = withContext(Dispatchers.IO) {
        try {
            val originalFile = File(video.path)
            if (!originalFile.exists()) return@withContext
            val encryptedFile = File(vaultDir, "vault_vid_${video.id}.bin")
            val encryptedTemp = File(vaultDir, "${encryptedFile.name}.tmp")
            encryptCopy(originalFile, encryptedTemp)
            if (encryptedFile.exists()) encryptedFile.delete()
            if (!encryptedTemp.renameTo(encryptedFile)) {
                encryptedTemp.copyTo(encryptedFile, overwrite = true)
                encryptedTemp.delete()
            }
            vaultDao.insertVaultMedia(
                VaultMediaEntity(
                    originalPath = video.path,
                    encryptedPath = encryptedFile.absolutePath,
                    originalName = video.title,
                    mediaType = "VIDEO",
                    duration = video.duration,
                    size = originalFile.length()
                )
            )
            originalFile.delete()
            try {
                context.contentResolver.delete(video.contentUri, null, null)
            } catch (_: Exception) {}
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun createPlaybackCopy(entity: VaultMediaEntity): File? = withContext(Dispatchers.IO) {
        try {
            val encryptedFile = File(entity.encryptedPath)
            if (!encryptedFile.exists()) return@withContext null
            val playbackDir = File(context.cacheDir, "vault_playback").apply { mkdirs() }
            val extension = File(entity.originalPath).extension.takeIf { it.isNotBlank() } ?: "media"
            val target = File(playbackDir, "${Integer.toHexString(entity.originalPath.hashCode())}.$extension")
            val temp = File(playbackDir, "${target.name}.tmp")
            decryptCopy(encryptedFile, temp)
            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            target
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    suspend fun restoreMedia(entity: VaultMediaEntity) = withContext(Dispatchers.IO) {
        try {
            val encFile = File(entity.encryptedPath)
            val destFile = File(entity.originalPath)
            if (encFile.exists()) {
                destFile.parentFile?.mkdirs()
                decryptCopy(encFile, destFile)
                MediaScannerConnection.scanFile(context, arrayOf(destFile.absolutePath), null, null)
                encFile.delete()
                vaultDao.deleteVaultMedia(entity)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun deletePermanently(entity: VaultMediaEntity) = withContext(Dispatchers.IO) {
        try {
            val encFile = File(entity.encryptedPath)
            if (encFile.exists()) encFile.delete()
            vaultDao.deleteVaultMedia(entity)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun restoreAllMedia(list: List<VaultMediaEntity>) = withContext(Dispatchers.IO) {
        list.forEach { entity -> restoreMedia(entity) }
    }

    suspend fun resetVaultLock() {
        prefManager.setVaultPin(null)
        prefManager.setVaultPattern(null)
        prefManager.setVaultLockType(VaultLockType.PIN)
        _isUnlocked.value = false
    }

    suspend fun updatePin(newPin: String) {
        val newHash = hashInput(newPin)
        prefManager.setVaultPin(newHash)
        prefManager.setVaultLockType(VaultLockType.PIN)
    }

    suspend fun updatePattern(patternPoints: List<Int>) {
        val enteredPattern = patternPoints.joinToString("-")
        val newHash = hashInput(enteredPattern)
        prefManager.setVaultPattern(newHash)
        prefManager.setVaultLockType(VaultLockType.PATTERN)
    }

    private fun encryptCopy(src: File, dst: File) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateVaultKey())
        val iv = cipher.iv
        FileInputStream(src).use { input ->
            FileOutputStream(dst).use { rawOutput ->
                rawOutput.write(ENCRYPTED_FILE_MAGIC)
                rawOutput.write(iv.size)
                rawOutput.write(iv)
                CipherOutputStream(rawOutput, cipher).use { encryptedOutput ->
                    input.copyTo(encryptedOutput)
                }
            }
        }
    }

    private fun decryptCopy(src: File, dst: File) {
        FileInputStream(src).use { input ->
            FileOutputStream(dst).use { output ->
                input.copyTo(output)
            }
        }
    }

    private fun getOrCreateVaultKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(VAULT_KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                VAULT_KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        private const val VAULT_KEY_ALIAS = "lerza_vault_media_key_v1"
        private val ENCRYPTED_FILE_MAGIC = byteArrayOf(0x4C, 0x5A, 0x45, 0x4E, 0x43, 0x31)

        @Volatile
        private var INSTANCE: VaultManager? = null

        fun getInstance(context: Context): VaultManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: VaultManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
