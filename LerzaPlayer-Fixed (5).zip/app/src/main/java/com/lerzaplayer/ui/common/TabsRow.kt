package com.lerzaplayer.ui.common

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.theme.LocalLerzaColors

@Composable
fun TabsRow(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val tabs = listOf("VIDEOS", "SONGS", "PLAYLISTS", "FOLDERS", "ALBUMS", "ARTISTS")
    val colors = LocalLerzaColors.current

    ScrollableTabRow(
        selectedTabIndex = selectedTab,
        containerColor = colors.surface,
        contentColor = colors.primary,
        edgePadding = 12.dp,
        indicator = { tabPositions ->
            if (selectedTab < tabPositions.size) {
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    height = 3.dp,
                    color = colors.primary
                )
            }
        },
        divider = {
            HorizontalDivider(color = colors.card, thickness = 1.dp)
        },
        modifier = modifier.fillMaxWidth()
    ) {
        tabs.forEachIndexed { index, title ->
            val isSelected = selectedTab == index
            Tab(
                selected = isSelected,
                onClick = { onTabSelected(index) },
                text = {
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) colors.primary else colors.textSecondary
                    )
                }
            )
        }
    }
}
