package com.lerzaplayer.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object LerzaIcons {
    private fun createIcon(name: String, block: ImageVector.Builder.() -> Unit): ImageVector {
        return ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply(block).build()
    }

    val Play: ImageVector = createIcon("Play") {
        path(fill = SolidColor(Color.White)) {
            moveTo(8f, 5f)
            verticalLineTo(19f)
            lineTo(19f, 12f)
            close()
        }
    }

    val Pause: ImageVector = createIcon("Pause") {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 19f)
            horizontalLineTo(10f)
            verticalLineTo(5f)
            horizontalLineTo(6f)
            verticalLineTo(19f)
            close()
            moveTo(14f, 5f)
            verticalLineTo(19f)
            horizontalLineTo(18f)
            verticalLineTo(5f)
            horizontalLineTo(14f)
            close()
        }
    }

    val SkipNext: ImageVector = createIcon("SkipNext") {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 18f)
            lineTo(14.5f, 12f)
            lineTo(6f, 6f)
            verticalLineTo(18f)
            close()
            moveTo(16f, 6f)
            verticalLineTo(18f)
            horizontalLineTo(18f)
            verticalLineTo(6f)
            horizontalLineTo(16f)
            close()
        }
    }

    val SkipPrevious: ImageVector = createIcon("SkipPrevious") {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 6f)
            horizontalLineTo(8f)
            verticalLineTo(18f)
            horizontalLineTo(6f)
            close()
            moveTo(9.5f, 12f)
            lineTo(18f, 18f)
            verticalLineTo(6f)
            lineTo(9.5f, 12f)
            close()
        }
    }

    val Shuffle: ImageVector = createIcon("Shuffle") {
        path(fill = SolidColor(Color.White)) {
            moveTo(10.59f, 9.17f)
            lineTo(5.41f, 4f)
            lineTo(4f, 5.41f)
            lineTo(9.17f, 10.59f)
            lineTo(10.59f, 9.17f)
            close()
            moveTo(14.5f, 4f)
            lineTo(16.54f, 6.04f)
            lineTo(4f, 18.59f)
            lineTo(5.41f, 20f)
            lineTo(17.96f, 7.46f)
            lineTo(20f, 9.5f)
            verticalLineTo(4f)
            horizontalLineTo(14.5f)
            close()
            moveTo(14.83f, 13.41f)
            lineTo(13.42f, 14.83f)
            lineTo(16.55f, 17.95f)
            lineTo(14.5f, 20f)
            horizontalLineTo(20f)
            verticalLineTo(14.5f)
            lineTo(17.96f, 16.54f)
            lineTo(14.83f, 13.41f)
            close()
        }
    }

    val Repeat: ImageVector = createIcon("Repeat") {
        path(fill = SolidColor(Color.White)) {
            moveTo(7f, 7f)
            horizontalLineTo(17f)
            verticalLineTo(10f)
            lineTo(21f, 6f)
            lineTo(17f, 2f)
            verticalLineTo(5f)
            horizontalLineTo(5f)
            verticalLineTo(11f)
            horizontalLineTo(7f)
            verticalLineTo(7f)
            close()
            moveTo(17f, 17f)
            horizontalLineTo(7f)
            verticalLineTo(14f)
            lineTo(3f, 18f)
            lineTo(7f, 22f)
            verticalLineTo(19f)
            horizontalLineTo(19f)
            verticalLineTo(13f)
            horizontalLineTo(17f)
            verticalLineTo(17f)
            close()
        }
    }

    val RepeatOne: ImageVector = createIcon("RepeatOne") {
        path(fill = SolidColor(Color.White)) {
            moveTo(7f, 7f)
            horizontalLineTo(17f)
            verticalLineTo(10f)
            lineTo(21f, 6f)
            lineTo(17f, 2f)
            verticalLineTo(5f)
            horizontalLineTo(5f)
            verticalLineTo(11f)
            horizontalLineTo(7f)
            verticalLineTo(7f)
            close()
            moveTo(17f, 17f)
            horizontalLineTo(7f)
            verticalLineTo(14f)
            lineTo(3f, 18f)
            lineTo(7f, 22f)
            verticalLineTo(19f)
            horizontalLineTo(19f)
            verticalLineTo(13f)
            horizontalLineTo(17f)
            verticalLineTo(17f)
            close()
            moveTo(13f, 15f)
            verticalLineTo(9f)
            horizontalLineTo(12f)
            lineTo(10f, 10f)
            verticalLineTo(11f)
            lineTo(11.5f, 10.25f)
            verticalLineTo(15f)
            horizontalLineTo(13f)
            close()
        }
    }

    val QueueMusic: ImageVector = createIcon("QueueMusic") {
        path(fill = SolidColor(Color.White)) {
            moveTo(15f, 6f); horizontalLineTo(3f); verticalLineTo(8f); horizontalLineTo(15f); verticalLineTo(6f); close()
            moveTo(15f, 10f); horizontalLineTo(3f); verticalLineTo(12f); horizontalLineTo(15f); verticalLineTo(10f); close()
            moveTo(3f, 16f); horizontalLineTo(11f); verticalLineTo(14f); horizontalLineTo(3f); verticalLineTo(16f); close()
            moveTo(17f, 6f); verticalLineTo(14.18f); curveTo(16.69f, 14.07f, 16.35f, 14f, 16f, 14f); curveTo(14.34f, 14f, 13f, 15.34f, 13f, 17f); curveTo(13f, 18.66f, 14.34f, 20f, 16f, 20f); curveTo(17.66f, 20f, 19f, 18.66f, 19f, 17f); verticalLineTo(8f); horizontalLineTo(22f); verticalLineTo(6f); horizontalLineTo(17f); close()
        }
    }

    val Tune: ImageVector = createIcon("Tune") {
        path(fill = SolidColor(Color.White)) {
            moveTo(3f, 17f); verticalLineTo(19f); horizontalLineTo(9f); verticalLineTo(17f); horizontalLineTo(3f); close()
            moveTo(3f, 5f); verticalLineTo(7f); horizontalLineTo(13f); verticalLineTo(5f); horizontalLineTo(3f); close()
            moveTo(13f, 21f); verticalLineTo(19f); horizontalLineTo(21f); verticalLineTo(17f); horizontalLineTo(13f); verticalLineTo(15f); horizontalLineTo(11f); verticalLineTo(21f); horizontalLineTo(13f); close()
            moveTo(7f, 9f); verticalLineTo(11f); horizontalLineTo(3f); verticalLineTo(13f); horizontalLineTo(7f); verticalLineTo(15f); horizontalLineTo(9f); verticalLineTo(9f); horizontalLineTo(7f); close()
            moveTo(21f, 13f); verticalLineTo(11f); horizontalLineTo(11f); verticalLineTo(13f); horizontalLineTo(21f); close()
            moveTo(15f, 9f); horizontalLineTo(17f); verticalLineTo(7f); horizontalLineTo(21f); verticalLineTo(5f); horizontalLineTo(17f); verticalLineTo(3f); horizontalLineTo(15f); verticalLineTo(9f); close()
        }
    }

    val MusicNote: ImageVector = createIcon("MusicNote") {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f); verticalLineTo(13.55f); curveTo(11.41f, 13.21f, 10.73f, 13f, 10f, 13f); curveTo(7.79f, 13f, 6f, 14.79f, 6f, 17f); curveTo(6f, 19.21f, 7.79f, 21f, 10f, 21f); curveTo(12.21f, 21f, 14f, 19.21f, 14f, 17f); verticalLineTo(7f); horizontalLineTo(18f); verticalLineTo(3f); horizontalLineTo(12f); close()
        }
    }

    val Lyrics: ImageVector = createIcon("Lyrics") {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f); verticalLineTo(12.55f); curveTo(11.41f, 12.21f, 10.73f, 12f, 10f, 12f); curveTo(7.79f, 12f, 6f, 13.79f, 6f, 16f); curveTo(6f, 18.21f, 7.79f, 20f, 10f, 20f); curveTo(12.21f, 20f, 14f, 18.21f, 14f, 16f); verticalLineTo(7f); horizontalLineTo(18f); verticalLineTo(3f); horizontalLineTo(12f); close()
            moveTo(3f, 6f); horizontalLineTo(9f); verticalLineTo(8f); horizontalLineTo(3f); close()
            moveTo(3f, 10f); horizontalLineTo(9f); verticalLineTo(12f); horizontalLineTo(3f); close()
        }
    }

    val Lock: ImageVector = createIcon("Lock") {
        path(fill = SolidColor(Color.White)) {
            moveTo(18f, 8f); horizontalLineTo(17f); verticalLineTo(6f); curveTo(17f, 3.24f, 14.76f, 1f, 12f, 1f); curveTo(9.24f, 1f, 7f, 3.24f, 7f, 6f); verticalLineTo(8f); horizontalLineTo(6f); curveTo(4.9f, 8f, 4f, 8.9f, 4f, 10f); verticalLineTo(20f); curveTo(4f, 21.1f, 4.9f, 22f, 6f, 22f); horizontalLineTo(18f); curveTo(19.1f, 22f, 20f, 21.1f, 20f, 20f); verticalLineTo(10f); curveTo(20f, 8.9f, 19.1f, 8f, 18f, 8f); close()
            moveTo(9f, 6f); curveTo(9f, 4.34f, 10.34f, 3f, 12f, 3f); curveTo(13.66f, 3f, 15f, 4.34f, 15f, 6f); verticalLineTo(8f); horizontalLineTo(9f); verticalLineTo(6f); close()
        }
    }

    val LockOpen: ImageVector = createIcon("LockOpen") {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 17f); curveTo(13.1f, 17f, 14f, 16.1f, 14f, 15f); curveTo(14f, 13.9f, 13.1f, 13f, 12f, 13f); curveTo(10.9f, 13f, 10f, 13.9f, 10f, 15f); curveTo(10f, 16.1f, 10.9f, 17f, 12f, 17f); close()
            moveTo(18f, 8f); horizontalLineTo(17f); verticalLineTo(6f); curveTo(17f, 3.24f, 14.76f, 1f, 12f, 1f); curveTo(9.24f, 1f, 7f, 3.24f, 7f, 6f); horizontalLineTo(8.9f); curveTo(8.9f, 4.29f, 10.29f, 2.9f, 12f, 2.9f); curveTo(13.71f, 2.9f, 15.1f, 4.29f, 15.1f, 6f); verticalLineTo(8f); horizontalLineTo(6f); curveTo(4.9f, 8f, 4f, 8.9f, 4f, 10f); verticalLineTo(20f); curveTo(4f, 21.1f, 4.9f, 22f, 6f, 22f); horizontalLineTo(18f); curveTo(19.1f, 22f, 20f, 21.1f, 20f, 20f); verticalLineTo(10f); curveTo(20f, 8.9f, 19.1f, 8f, 18f, 8f); close()
            moveTo(18f, 20f); horizontalLineTo(6f); verticalLineTo(10f); horizontalLineTo(18f); verticalLineTo(20f); close()
        }
    }

    val PlayArrow = Play
    val ScreenRotation: ImageVector = createIcon("ScreenRotation") {
        path(fill = SolidColor(Color.White)) {
            moveTo(16.48f, 2.52f); lineTo(8f, 2.46f); verticalLineTo(0f); horizontalLineTo(6f); verticalLineTo(6f); horizontalLineTo(12f); verticalLineTo(4f); close()
            moveTo(7.52f, 21.48f); lineTo(16f, 21.54f); verticalLineTo(24f); horizontalLineTo(18f); verticalLineTo(18f); horizontalLineTo(12f); verticalLineTo(20f); close()
        }
    }
    val AspectRatio: ImageVector = createIcon("AspectRatio") {
        path(fill = SolidColor(Color.White)) {
            moveTo(19f, 4f); horizontalLineTo(5f); curveTo(3.9f, 4f, 3f, 4.9f, 3f, 6f); verticalLineTo(18f); curveTo(3f, 19.1f, 3.9f, 20f, 5f, 20f); horizontalLineTo(19f); curveTo(20.1f, 20f, 21f, 19.1f, 21f, 18f); verticalLineTo(6f); curveTo(21f, 4.9f, 20.1f, 4f, 19f, 4f); close()
            moveTo(19f, 18f); horizontalLineTo(5f); verticalLineTo(6f); horizontalLineTo(19f); verticalLineTo(18f); close()
        }
    }
    val Folder: ImageVector = createIcon("Folder") {
        path(fill = SolidColor(Color.White)) {
            moveTo(10f, 4f); horizontalLineTo(4f); curveTo(2.9f, 4f, 2f, 4.9f, 2f, 6f); verticalLineTo(18f); curveTo(2f, 19.1f, 2.9f, 20f, 4f, 20f); horizontalLineTo(20f); curveTo(21.1f, 20f, 22f, 19.1f, 22f, 18f); verticalLineTo(8f); curveTo(22f, 6.9f, 21.1f, 6f, 20f, 6f); horizontalLineTo(12f); lineTo(10f, 4f); close()
        }
    }
    val Videocam: ImageVector = createIcon("Videocam") {
        path(fill = SolidColor(Color.White)) {
            moveTo(17f, 10.5f); verticalLineTo(7f); curveTo(17f, 6.45f, 16.55f, 6f, 16f, 6f); horizontalLineTo(4f); curveTo(3.45f, 6f, 3f, 6.45f, 3f, 7f); verticalLineTo(17f); curveTo(3f, 17.55f, 3.45f, 18f, 4f, 18f); horizontalLineTo(16f); curveTo(16.55f, 18f, 17f, 17.55f, 17f, 17f); verticalLineTo(13.5f); lineTo(21f, 17.5f); verticalLineTo(6.5f); lineTo(17f, 10.5f); close()
        }
    }
    val Audiotrack = MusicNote
    val SwapVert: ImageVector = createIcon("SwapVert") {
        path(fill = SolidColor(Color.White)) {
            moveTo(16f, 17.01f); verticalLineTo(10f); horizontalLineTo(14f); verticalLineTo(17.01f); horizontalLineTo(11f); lineTo(15f, 21f); lineTo(19f, 17.01f); horizontalLineTo(16f); close()
            moveTo(9f, 3f); lineTo(5f, 6.99f); horizontalLineTo(8f); verticalLineTo(14f); horizontalLineTo(10f); verticalLineTo(6.99f); horizontalLineTo(13f); lineTo(9f, 3f); close()
        }
    }
    val ViewList: ImageVector = createIcon("ViewList") {
        path(fill = SolidColor(Color.White)) {
            moveTo(4f, 14f); horizontalLineTo(8f); verticalLineTo(10f); horizontalLineTo(4f); close()
            moveTo(9f, 14f); horizontalLineTo(21f); verticalLineTo(10f); horizontalLineTo(9f); close()
        }
    }
    val GridView: ImageVector = createIcon("GridView") {
        path(fill = SolidColor(Color.White)) {
            moveTo(3f, 3f); verticalLineTo(11f); horizontalLineTo(11f); verticalLineTo(3f); close()
            moveTo(13f, 3f); verticalLineTo(11f); horizontalLineTo(21f); verticalLineTo(3f); close()
            moveTo(3f, 13f); verticalLineTo(21f); horizontalLineTo(11f); verticalLineTo(13f); close()
            moveTo(13f, 13f); verticalLineTo(21f); horizontalLineTo(21f); verticalLineTo(13f); close()
        }
    }
    val VisibilityOff: ImageVector = createIcon("VisibilityOff") {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 7f); curveTo(13.37f, 7f, 14.59f, 7.57f, 15.48f, 8.48f); lineTo(18.31f, 5.65f); close()
            moveTo(2f, 4.27f); lineTo(21f, 20.74f); close()
        }
    }
    val Palette: ImageVector = createIcon("Palette") {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f); curveTo(6.5f, 3f, 2f, 6.5f, 2f, 12f); curveTo(2f, 15.5f, 4.5f, 18.5f, 8f, 19.5f); close()
        }
    }
    val Wallpaper: ImageVector = createIcon("Wallpaper") {
        path(fill = SolidColor(Color.White)) {
            moveTo(4f, 4f); horizontalLineTo(7f); verticalLineTo(2f); horizontalLineTo(4f); close()
            moveTo(20f, 20f); horizontalLineTo(17f); verticalLineTo(22f); horizontalLineTo(20f); close()
        }
    }
    val AddPhoto = Folder
    val Pattern = GridView
    val Backspace: ImageVector = createIcon("Backspace") {
        path(fill = SolidColor(Color.White)) {
            moveTo(22f, 3f); horizontalLineTo(7f); lineTo(0f, 12f); lineTo(7f, 21f); horizontalLineTo(22f); close()
        }
    }
    val Restore = RefreshIcon()
    val KeyboardArrowDown: ImageVector = createIcon("KeyboardArrowDown") {
        path(fill = SolidColor(Color.White)) {
            moveTo(7.41f, 8.59f); lineTo(12f, 13.17f); lineTo(16.59f, 8.59f); lineTo(18f, 10f); lineTo(12f, 16f); lineTo(6f, 10f); close()
        }
    }
    val Favorite: ImageVector = createIcon("Favorite") {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 21.35f); lineTo(10.55f, 20.03f); curveTo(5.4f, 15.36f, 2f, 12.28f, 2f, 8.5f); curveTo(2f, 5.42f, 4.42f, 3f, 7.5f, 3f); curveTo(9.24f, 3f, 10.91f, 3.81f, 12f, 5.09f); curveTo(13.09f, 3.81f, 14.76f, 3f, 16.5f, 3f); curveTo(19.58f, 3f, 22f, 5.42f, 22f, 8.5f); curveTo(22f, 12.28f, 18.6f, 15.36f, 13.45f, 20.04f); close()
        }
    }
    val FavoriteBorder = Favorite
    val MoreVert: ImageVector = createIcon("MoreVert") {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 8f); curveTo(13.1f, 8f, 14f, 7.1f, 14f, 6f); curveTo(14f, 4.9f, 13.1f, 4f, 12f, 4f); curveTo(10.9f, 4f, 10f, 4.9f, 10f, 6f); curveTo(10f, 7.1f, 10.9f, 8f, 12f, 8f); close()
            moveTo(12f, 10f); curveTo(10.9f, 10f, 10f, 10.9f, 10f, 12f); curveTo(10f, 13.1f, 10.9f, 14f, 12f, 14f); curveTo(13.1f, 14f, 14f, 13.1f, 14f, 12f); curveTo(14f, 10.9f, 13.1f, 10f, 12f, 10f); close()
            moveTo(12f, 16f); curveTo(10.9f, 16f, 10f, 16.9f, 10f, 18f); curveTo(10f, 19.1f, 10.9f, 20f, 12f, 20f); curveTo(13.1f, 20f, 14f, 19.1f, 14f, 18f); curveTo(14f, 16.9f, 13.1f, 16f, 12f, 16f); close()
        }
    }
    val Close: ImageVector = createIcon("Close") {
        path(fill = SolidColor(Color.White)) {
            moveTo(19f, 6.41f); lineTo(17.59f, 5f); lineTo(12f, 10.59f); lineTo(6.41f, 5f); lineTo(5f, 6.41f); lineTo(10.59f, 12f); lineTo(5f, 17.59f); lineTo(6.41f, 19f); lineTo(12f, 13.41f); lineTo(17.59f, 19f); lineTo(19f, 17.59f); lineTo(13.41f, 12f); close()
        }
    }
    val ArrowBack: ImageVector = createIcon("ArrowBack") {
        path(fill = SolidColor(Color.White)) {
            moveTo(20f, 11f); horizontalLineTo(7.83f); lineTo(13.42f, 5.41f); lineTo(12f, 4f); lineTo(4f, 12f); lineTo(12f, 20f); lineTo(13.41f, 18.59f); lineTo(7.83f, 13f); horizontalLineTo(20f); verticalLineTo(11f); close()
        }
    }
    val ArrowDropDown = KeyboardArrowDown
    val CheckCircle: ImageVector = createIcon("CheckCircle") {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 2f); curveTo(6.48f, 2f, 2f, 6.48f, 2f, 12f); curveTo(2f, 17.52f, 6.48f, 22f, 12f, 22f); curveTo(17.52f, 22f, 22f, 17.52f, 22f, 12f); curveTo(22f, 6.48f, 17.52f, 2f, 12f, 2f); close()
            moveTo(10f, 17f); lineTo(5f, 12f); lineTo(6.41f, 10.59f); lineTo(10f, 14.17f); lineTo(17.59f, 6.58f); lineTo(19f, 8f); lineTo(10f, 17f); close()
        }
    }
    val Check = CheckCircle
    val Add: ImageVector = createIcon("Add") {
        path(fill = SolidColor(Color.White)) {
            moveTo(19f, 13f); horizontalLineTo(13f); verticalLineTo(19f); horizontalLineTo(11f); verticalLineTo(13f); horizontalLineTo(5f); verticalLineTo(11f); horizontalLineTo(11f); verticalLineTo(5f); horizontalLineTo(13f); verticalLineTo(11f); horizontalLineTo(19f); verticalLineTo(13f); close()
        }
    }
    val Delete: ImageVector = createIcon("Delete") {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 19f); curveTo(6f, 20.1f, 6.9f, 21f, 8f, 21f); horizontalLineTo(16f); curveTo(17.1f, 21f, 18f, 20.1f, 18f, 19f); verticalLineTo(7f); horizontalLineTo(6f); verticalLineTo(19f); close()
            moveTo(19f, 4f); horizontalLineTo(15.5f); lineTo(14.5f, 3f); horizontalLineTo(9.5f); lineTo(8.5f, 4f); horizontalLineTo(5f); verticalLineTo(6f); horizontalLineTo(19f); close()
        }
    }
    val Refresh = RefreshIcon()
    val Search: ImageVector = createIcon("Search") {
        path(fill = SolidColor(Color.White)) {
            moveTo(15.5f, 14f); horizontalLineTo(14.71f); lineTo(14.43f, 13.73f); curveTo(15.41f, 12.59f, 16f, 11.11f, 16f, 9.5f); curveTo(16f, 5.91f, 13.09f, 3f, 9.5f, 3f); curveTo(5.91f, 3f, 3f, 5.91f, 3f, 9.5f); curveTo(3f, 13.09f, 5.91f, 16f, 9.5f, 16f); curveTo(11.11f, 16f, 12.59f, 15.41f, 13.73f, 14.43f); lineTo(14f, 14.71f); verticalLineTo(15.5f); lineTo(19f, 20.49f); lineTo(20.49f, 19f); lineTo(15.5f, 14f); close()
            moveTo(9.5f, 14f); curveTo(7.01f, 14f, 5f, 11.99f, 5f, 9.5f); curveTo(5f, 7.01f, 7.01f, 5f, 9.5f, 5f); curveTo(11.99f, 5f, 14f, 7.01f, 14f, 9.5f); curveTo(14f, 11.99f, 11.99f, 14f, 9.5f, 14f); close()
        }
    }
    val Settings: ImageVector = createIcon("Settings") {
        path(fill = SolidColor(Color.White)) {
            moveTo(19.14f, 12.94f); curveTo(19.18f, 12.63f, 19.21f, 12.32f, 19.21f, 12f); curveTo(19.21f, 11.68f, 19.18f, 11.37f, 19.14f, 11.06f); lineTo(21.41f, 9.28f); close()
        }
    }
    val FastRewind = SkipPrevious
    val FastForward = SkipNext
    val Speed = Tune
    val Headphones = MusicNote
    val Info = CheckCircle
    val Share = Add
    val PlaylistAdd = Add
    val Shield = Lock

    private fun RefreshIcon(): ImageVector = createIcon("Refresh") {
        path(fill = SolidColor(Color.White)) {
            moveTo(17.65f, 6.35f); curveTo(16.2f, 4.9f, 14.21f, 4f, 12f, 4f); curveTo(7.58f, 4f, 4.01f, 7.58f, 4.01f, 12f); curveTo(4.01f, 16.42f, 7.58f, 20f, 12f, 20f); close()
        }
    }
}
