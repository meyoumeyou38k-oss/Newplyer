package com.lerzaplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.lerzaplayer.data.database.PlaylistEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.repository.MediaRepository
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaTheme
import com.lerzaplayer.ui.home.HomeCategoryTab
import com.lerzaplayer.ui.home.HomeScreen
import com.lerzaplayer.ui.player.FullPlayerScreen
import com.lerzaplayer.ui.player.MiniPlayer
import com.lerzaplayer.ui.search.SearchScreen
import com.lerzaplayer.ui.settings.SettingsScreen
import com.lerzaplayer.ui.vault.VaultScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

enum class MainScreenState {
    HOME,
    SEARCH,
    SETTINGS,
    VAULT
}

class MainActivity : ComponentActivity() {
    private lateinit var mediaRepository: MediaRepository
    private lateinit var playerManager: PlayerManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        mediaRepository = MediaRepository(this)
        playerManager = PlayerManager.getInstance(this)

        setContent {
            val app = application as LerzaApp
            val currentTheme by app.preferenceManager.selectedTheme.collectAsState(initial = "Green")

            LerzaTheme(themeName = currentTheme) {
                var currentScreen by remember { mutableStateOf(MainScreenState.HOME) }
                var selectedTab by remember { mutableStateOf(HomeCategoryTab.SONGS) }
                var showFullPlayer by remember { mutableStateOf(false) }

                var songs by remember { mutableStateOf<List<SongItem>>(emptyList()) }
                var videos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                val playlists by app.database.playlistDao().getAllPlaylists().collectAsState(initial = emptyList())

                val currentSong by playerManager.currentSong.collectAsState()
                val currentVideo by playerManager.currentVideo.collectAsState()
                val isPlaying by playerManager.isPlaying.collectAsState()

                val scope = rememberCoroutineScope()

                // Media Scanner Function
                val scanMedia = {
                    scope.launch {
                        val fetchedSongs = mediaRepository.getAllSongs()
                        val fetchedVideos = mediaRepository.getAllVideos()

                        // Check matching video for song (MV Switcher requirement)
                        val songsWithMv = fetchedSongs.map { s ->
                            val match = mediaRepository.findMatchingVideoForSong(s, fetchedVideos)
                            if (match != null) s.copy(matchingVideoUri = match.contentUri) else s
                        }

                        songs = songsWithMv
                        videos = fetchedVideos
                    }
                }

                // Android Permissions Launcher
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) { permissions ->
                    scanMedia()
                }

                LaunchedEffect(Unit) {
                    val permissionsToRequest = mutableListOf<String>()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
                        permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
                        permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
                    }

                    val notGranted = permissionsToRequest.filter {
                        ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED
                    }

                    if (notGranted.isNotEmpty()) {
                        permissionLauncher.launch(notGranted.toTypedArray())
                    } else {
                        scanMedia()
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        when (currentScreen) {
                            MainScreenState.HOME -> {
                                val folders = remember(songs, videos) {
                                    mediaRepository.groupIntoFolders(songs, videos)
                                }
                                val albums = remember(songs) {
                                    mediaRepository.groupIntoAlbums(songs)
                                }
                                val artists = remember(songs) {
                                    mediaRepository.groupIntoArtists(songs)
                                }

                                Scaffold(
                                    bottomBar = {
                                        MiniPlayer(
                                            currentSong = currentSong,
                                            currentVideo = currentVideo,
                                            isPlaying = isPlaying,
                                            onTogglePlayPause = { playerManager.togglePlayPause() },
                                            onNext = { playerManager.next() },
                                            onClick = { showFullPlayer = true }
                                        )
                                    }
                                ) { padding ->
                                    HomeScreen(
                                        songs = songs,
                                        videos = videos,
                                        playlists = playlists,
                                        folders = folders,
                                        albums = albums,
                                        artists = artists,
                                        selectedTab = selectedTab,
                                        onTabSelected = { selectedTab = it },
                                        onSongClick = { s -> playerManager.playSong(s, songs) },
                                        onVideoClick = { v -> playerManager.playVideo(v) },
                                        onHideSong = { s ->
                                            app.vaultManager.hideMedia(
                                                uriString = s.contentUri.toString(),
                                                title = s.title,
                                                artistOrFolder = s.artist,
                                                durationMs = s.durationMs,
                                                isVideo = false,
                                                filePath = s.dataPath
                                            )
                                            scanMedia()
                                        },
                                        onHideVideo = { v ->
                                            app.vaultManager.hideMedia(
                                                uriString = v.contentUri.toString(),
                                                title = v.title,
                                                artistOrFolder = v.folderName,
                                                durationMs = v.durationMs,
                                                isVideo = true,
                                                filePath = v.dataPath
                                            )
                                            scanMedia()
                                        },
                                        onCreatePlaylist = { name ->
                                            scope.launch {
                                                app.database.playlistDao().insertPlaylist(
                                                    PlaylistEntity(name = name)
                                                )
                                            }
                                        },
                                        onOpenSearch = { currentScreen = MainScreenState.SEARCH },
                                        onOpenSettings = { currentScreen = MainScreenState.SETTINGS },
                                        modifier = Modifier.padding(padding)
                                    )
                                }
                            }

                            MainScreenState.SEARCH -> {
                                SearchScreen(
                                    allSongs = songs,
                                    allVideos = videos,
                                    onSongClick = { s ->
                                        playerManager.playSong(s, songs)
                                        currentScreen = MainScreenState.HOME
                                    },
                                    onVideoClick = { v ->
                                        playerManager.playVideo(v)
                                        currentScreen = MainScreenState.HOME
                                    },
                                    onBack = { currentScreen = MainScreenState.HOME }
                                )
                            }

                            MainScreenState.SETTINGS -> {
                                SettingsScreen(
                                    prefManager = app.preferenceManager,
                                    playerManager = playerManager,
                                    onOpenVault = { currentScreen = MainScreenState.VAULT },
                                    onRescanMedia = { scanMedia() },
                                    onBack = { currentScreen = MainScreenState.HOME }
                                )
                            }

                            MainScreenState.VAULT -> {
                                VaultScreen(
                                    vaultManager = app.vaultManager,
                                    onClose = {
                                        app.vaultManager.lockVault()
                                        currentScreen = MainScreenState.HOME
                                        scanMedia()
                                    },
                                    onPlayMedia = { item ->
                                        // Play hidden media
                                    }
                                )
                            }
                        }

                        // Full Player Modal Overlay
                        if (showFullPlayer && (currentSong != null || currentVideo != null)) {
                            FullPlayerScreen(
                                playerManager = playerManager,
                                onClose = { showFullPlayer = false }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        (application as LerzaApp).vaultManager.onAppBackgrounded()
    }
}
