package com.lerzaplayer.vault

import android.content.Context
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.data.preferences.PreferenceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.security.MessageDigest

class VaultManager private constructor(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.Main)
    private val prefManager = PreferenceManager(context)
    private val vaultDao = AppDatabase.getDatabase(context).vaultDao()

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    val vaultItems = vaultDao.getAllVaultMedia()

    private var autoLockJob: Job? = null

    fun unlockWithPin(inputPin: String, onResult: (Boolean) -> Unit) {
        scope.launch {
            val storedHash = prefManager.vaultPinHash.first()
            if (storedHash == null) {
                // First time setup
                setPin(inputPin)
                _isUnlocked.value = true
                resetAutoLockTimer()
                onResult(true)
            } else {
                val inputHash = hashString(inputPin)
                val success = inputHash == storedHash
                _isUnlocked.value = success
                if (success) resetAutoLockTimer()
                onResult(success)
            }
        }
    }

    fun unlockWithPattern(patternCoords: String, onResult: (Boolean) -> Unit) {
        scope.launch {
            val storedHash = prefManager.vaultPatternHash.first()
            if (storedHash == null) {
                setPattern(patternCoords)
                _isUnlocked.value = true
                resetAutoLockTimer()
                onResult(true)
            } else {
                val inputHash = hashString(patternCoords)
                val success = inputHash == storedHash
                _isUnlocked.value = success
                if (success) resetAutoLockTimer()
                onResult(success)
            }
        }
    }

    fun setPin(pin: String) {
        scope.launch {
            prefManager.setVaultPinHash(hashString(pin))
        }
    }

    fun setPattern(pattern: String) {
        scope.launch {
            prefManager.setVaultPatternHash(hashString(pattern))
        }
    }

    fun lockVault() {
        autoLockJob?.cancel()
        _isUnlocked.value = false
    }

    fun onAppBackgrounded() {
        lockVault()
    }

    fun resetAutoLockTimer() {
        autoLockJob?.cancel()
        autoLockJob = scope.launch {
            // Auto lock after 3 minutes of inactivity
            delay(180000)
            lockVault()
        }
    }

    fun hideMedia(
        uriString: String,
        title: String,
        artistOrFolder: String,
        durationMs: Long,
        isVideo: Boolean,
        filePath: String
    ) {
        scope.launch(Dispatchers.IO) {
            vaultDao.hideMedia(
                VaultMediaEntity(
                    mediaUriString = uriString,
                    title = title,
                    artistOrFolder = artistOrFolder,
                    durationMs = durationMs,
                    isVideo = isVideo,
                    filePath = filePath
                )
            )
        }
    }

    fun unhideMedia(uriString: String) {
        scope.launch(Dispatchers.IO) {
            vaultDao.unhideMedia(uriString)
        }
    }

    private fun hashString(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        @Volatile
        private var INSTANCE: VaultManager? = null

        fun getInstance(context: Context): VaultManager {
            return INSTANCE ?: synchronized(this) {
                val instance = VaultManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
