package com.lerzaplayer.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

fun getLerzaColorScheme(themeName: String): ColorScheme {
    return when (themeName.lowercase()) {
        "green" -> darkColorScheme(
            primary = NeonGreen,
            onPrimary = Color.Black,
            primaryContainer = Color(0xFF00391C),
            onPrimaryContainer = NeonGreen,
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurfaceVariant,
            onBackground = Color.White,
            onSurface = Color.White,
            secondary = Color(0xFF81C784)
        )
        "blue" -> darkColorScheme(
            primary = ElectricBlue,
            onPrimary = Color.White,
            primaryContainer = Color(0xFF0D47A1),
            onPrimaryContainer = ElectricBlue,
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurfaceVariant,
            onBackground = Color.White,
            onSurface = Color.White,
            secondary = Color(0xFF64B5F6)
        )
        "purple" -> darkColorScheme(
            primary = DeepPurple,
            onPrimary = Color.White,
            primaryContainer = Color(0xFF311B92),
            onPrimaryContainer = VividPurple,
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurfaceVariant,
            onBackground = Color.White,
            onSurface = Color.White,
            secondary = VividPurple
        )
        "red" -> darkColorScheme(
            primary = CrimsonRed,
            onPrimary = Color.White,
            primaryContainer = Color(0xFF880E4F),
            onPrimaryContainer = CrimsonRed,
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurfaceVariant,
            onBackground = Color.White,
            onSurface = Color.White,
            secondary = Color(0xFFFF8A80)
        )
        "orange" -> darkColorScheme(
            primary = SunsetOrange,
            onPrimary = Color.Black,
            primaryContainer = Color(0xFFE65100),
            onPrimaryContainer = SunsetOrange,
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurfaceVariant,
            onBackground = Color.White,
            onSurface = Color.White,
            secondary = Color(0xFFFFB74D)
        )
        "pink" -> darkColorScheme(
            primary = NeonPink,
            onPrimary = Color.White,
            primaryContainer = Color(0xFF880E4F),
            onPrimaryContainer = NeonPink,
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurfaceVariant,
            onBackground = Color.White,
            onSurface = Color.White,
            secondary = Color(0xFFFF80AB)
        )
        "teal" -> darkColorScheme(
            primary = OceanTeal,
            onPrimary = Color.Black,
            primaryContainer = Color(0xFF006064),
            onPrimaryContainer = OceanTeal,
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurfaceVariant,
            onBackground = Color.White,
            onSurface = Color.White,
            secondary = Color(0xFF80DEEA)
        )
        "light", "white" -> lightColorScheme(
            primary = Color(0xFF006C4C),
            onPrimary = Color.White,
            primaryContainer = Color(0xFF89F8C7),
            onPrimaryContainer = Color(0xFF002114),
            background = LightBackground,
            surface = LightSurface,
            surfaceVariant = LightSurfaceVariant,
            onBackground = LightOnSurface,
            onSurface = LightOnSurface,
            secondary = Color(0xFF4D6357)
        )
        "amoled" -> darkColorScheme(
            primary = NeonGreen,
            onPrimary = Color.Black,
            primaryContainer = Color(0xFF00220F),
            onPrimaryContainer = NeonGreen,
            background = AmoledBackground,
            surface = AmoledSurface,
            surfaceVariant = AmoledSurfaceVariant,
            onBackground = Color.White,
            onSurface = Color.White,
            secondary = Color(0xFF69F0AE)
        )
        else -> darkColorScheme( // "Dark"
            primary = Color(0xFF80CBC4),
            onPrimary = Color.Black,
            primaryContainer = Color(0xFF004D40),
            onPrimaryContainer = Color(0xFF80CBC4),
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurfaceVariant,
            onBackground = Color.White,
            onSurface = Color.White,
            secondary = Color(0xFFB2DFDB)
        )
    }
}

@Composable
fun LerzaTheme(
    themeName: String = "Green",
    content: @Composable () -> Unit
) {
    val colorScheme = getLerzaColorScheme(themeName)

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
