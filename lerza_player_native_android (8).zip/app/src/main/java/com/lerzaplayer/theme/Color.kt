package com.lerzaplayer.theme

import androidx.compose.ui.graphics.Color

// Accent Colors for 10 Themes
val NeonGreen = Color(0xFF00E676)
val ElectricBlue = Color(0xFF2979FF)
val VividPurple = Color(0xFFB388FF)
val DeepPurple = Color(0xFF7C4DFF)
val CrimsonRed = Color(0xFFFF1744)
val SunsetOrange = Color(0xFFFF9100)
val NeonPink = Color(0xFFFF4081)
val OceanTeal = Color(0xFF00E5FF)

// Background & Surface palettes
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkSurfaceVariant = Color(0xFF2C2C2C)

val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF0A0A0A)
val AmoledSurfaceVariant = Color(0xFF141414)

val LightBackground = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE9ECEF)
val LightOnSurface = Color(0xFF1A1A1A)
val LightOnSurfaceVariant = Color(0xFF495057)
