package com.lerzaplayer.data.repository

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class MediaRepository(private val context: Context) {
    private val database = AppDatabase.getDatabase(context)
    private val vaultDao = database.vaultDao()

    private fun Cursor.getSafeString(colName: String, default: String = ""): String {
        val idx = getColumnIndex(colName)
        return if (idx >= 0 && !isNull(idx)) getString(idx) ?: default else default
    }

    private fun Cursor.getSafeLong(colName: String, default: Long = 0L): Long {
        val idx = getColumnIndex(colName)
        return if (idx >= 0 && !isNull(idx)) getLong(idx) else default
    }

    private fun Cursor.getSafeInt(colName: String, default: Int = 0): Int {
        val idx = getColumnIndex(colName)
        return if (idx >= 0 && !isNull(idx)) getInt(idx) else default
    }

    suspend fun getAllSongs(): List<SongItem> = withContext(Dispatchers.IO) {
        val hiddenUris = try {
            vaultDao.getAllHiddenUrisList().toSet()
        } catch (_: Throwable) {
            emptySet()
        }

        val songList = mutableListOf<SongItem>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.ALBUM_ID
        )

        // Do not restrict IS_MUSIC since many downloaded songs have IS_MUSIC=0 on MIUI/Samsung/etc.
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )

            cursor?.use {
                while (it.moveToNext()) {
                    val id = it.getSafeLong(MediaStore.Audio.Media._ID)
                    if (id <= 0) continue

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    if (hiddenUris.contains(contentUri.toString())) {
                        continue
                    }

                    val title = it.getSafeString(MediaStore.Audio.Media.TITLE, "Audio Track")
                    val artist = it.getSafeString(MediaStore.Audio.Media.ARTIST, "Unknown Artist")
                    val album = it.getSafeString(MediaStore.Audio.Media.ALBUM, "Unknown Album")
                    val duration = it.getSafeLong(MediaStore.Audio.Media.DURATION, 0L)
                    val data = it.getSafeString(MediaStore.Audio.Media.DATA, "")
                    val size = it.getSafeLong(MediaStore.Audio.Media.SIZE, 0L)
                    val dateAdded = it.getSafeLong(MediaStore.Audio.Media.DATE_ADDED, 0L)
                    val albumId = it.getSafeLong(MediaStore.Audio.Media.ALBUM_ID, -1L)

                    // Skip very short notification tones (< 1.5s) only if duration is known
                    if (duration in 1..1500) continue

                    val artworkUri = if (albumId > 0) {
                        ContentUris.withAppendedId(
                            Uri.parse("content://media/external/audio/albumart"),
                            albumId
                        )
                    } else {
                        contentUri
                    }

                    songList.add(
                        SongItem(
                            id = id,
                            title = title.ifBlank { File(data).nameWithoutExtension.ifBlank { "Track $id" } },
                            artist = if (artist.contains("<unknown>", ignoreCase = true) || artist.isBlank()) "Unknown Artist" else artist,
                            album = if (album.contains("<unknown>", ignoreCase = true) || album.isBlank()) "Unknown Album" else album,
                            durationMs = duration,
                            contentUri = contentUri,
                            albumArtUri = artworkUri,
                            dataPath = data,
                            sizeBytes = size,
                            dateAddedSecs = dateAdded
                        )
                    )
                }
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        songList
    }

    suspend fun getAllVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val hiddenUris = try {
            vaultDao.getAllHiddenUrisList().toSet()
        } catch (_: Throwable) {
            emptySet()
        }

        val videoList = mutableListOf<VideoItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )

            cursor?.use {
                while (it.moveToNext()) {
                    val id = it.getSafeLong(MediaStore.Video.Media._ID)
                    if (id <= 0) continue

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    if (hiddenUris.contains(contentUri.toString())) {
                        continue
                    }

                    val title = it.getSafeString(MediaStore.Video.Media.TITLE, "")
                    val duration = it.getSafeLong(MediaStore.Video.Media.DURATION, 0L)
                    val data = it.getSafeString(MediaStore.Video.Media.DATA, "")
                    val size = it.getSafeLong(MediaStore.Video.Media.SIZE, 0L)
                    val dateAdded = it.getSafeLong(MediaStore.Video.Media.DATE_ADDED, 0L)
                    val width = it.getSafeInt(MediaStore.Video.Media.WIDTH, 0)
                    val height = it.getSafeInt(MediaStore.Video.Media.HEIGHT, 0)
                    val folder = it.getSafeString(MediaStore.Video.Media.BUCKET_DISPLAY_NAME).ifEmpty {
                        if (data.isNotEmpty()) File(data).parentFile?.name ?: "Videos" else "Videos"
                    }

                    videoList.add(
                        VideoItem(
                            id = id,
                            title = title.ifBlank { File(data).nameWithoutExtension.ifBlank { "Video $id" } },
                            durationMs = duration,
                            contentUri = contentUri,
                            thumbnailUri = contentUri,
                            folderName = folder,
                            dataPath = data,
                            sizeBytes = size,
                            dateAddedSecs = dateAdded,
                            width = width,
                            height = height
                        )
                    )
                }
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        videoList
    }

    fun findMatchingVideoForSong(song: SongItem, allVideos: List<VideoItem>): VideoItem? {
        val cleanSongTitle = cleanName(song.title)
        val cleanArtist = cleanName(song.artist)

        if (cleanSongTitle.length < 3) return null

        for (video in allVideos) {
            val cleanVideoTitle = cleanName(video.title)
            val videoFileName = cleanName(File(video.dataPath).nameWithoutExtension)

            val titleMatch = cleanVideoTitle.contains(cleanSongTitle) ||
                    videoFileName.contains(cleanSongTitle) ||
                    cleanSongTitle.contains(cleanVideoTitle)

            val artistMatch = cleanArtist != "unknown" && (
                    cleanVideoTitle.contains(cleanArtist) || videoFileName.contains(cleanArtist)
                    )

            if (titleMatch && (artistMatch || cleanSongTitle.length > 6)) {
                return video
            }
        }
        return null
    }

    private fun cleanName(raw: String): String {
        return raw.lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9]"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
    }

    fun groupIntoAlbums(songs: List<SongItem>): List<AlbumItem> {
        return songs.groupBy { it.album }
            .map { (albumName, albumSongs) ->
                val first = albumSongs.first()
                AlbumItem(
                    id = first.id,
                    name = albumName,
                    artist = first.artist,
                    songCount = albumSongs.size,
                    artworkUri = first.albumArtUri
                )
            }
    }

    fun groupIntoArtists(songs: List<SongItem>): List<ArtistItem> {
        return songs.groupBy { it.artist }
            .map { (artistName, artistSongs) ->
                val albumCount = artistSongs.map { it.album }.distinct().size
                ArtistItem(
                    id = artistSongs.first().id,
                    name = artistName,
                    trackCount = artistSongs.size,
                    albumCount = albumCount
                )
            }
    }

    fun groupIntoFolders(songs: List<SongItem>, videos: List<VideoItem>): List<FolderItem> {
        val folderMap = mutableMapOf<String, Pair<Int, Int>>()

        songs.forEach { song ->
            val dir = File(song.dataPath).parent ?: "Music"
            val current = folderMap.getOrDefault(dir, Pair(0, 0))
            folderMap[dir] = Pair(current.first + 1, current.second)
        }

        videos.forEach { video ->
            val dir = File(video.dataPath).parent ?: "Video"
            val current = folderMap.getOrDefault(dir, Pair(0, 0))
            folderMap[dir] = Pair(current.first, current.second + 1)
        }

        return folderMap.map { (path, counts) ->
            FolderItem(
                name = File(path).name.ifEmpty { "Storage" },
                path = path,
                songCount = counts.first,
                videoCount = counts.second
            )
        }
    }
}
