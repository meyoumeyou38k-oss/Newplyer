package com.lerzaplayer.data.model

import android.net.Uri

enum class MediaType {
    AUDIO,
    VIDEO
}

enum class SortOption {
    NAME,
    ARTIST,
    ALBUM,
    DURATION,
    DATE_ADDED,
    RECENTLY_PLAYED,
    MOST_PLAYED
}

enum class ViewMode {
    LIST,
    GRID
}

data class SongItem(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val contentUri: Uri,
    val albumArtUri: Uri? = null,
    val dataPath: String = "",
    val sizeBytes: Long = 0,
    val dateAddedSecs: Long = 0,
    val hasLyrics: Boolean = false,
    val matchingVideoUri: Uri? = null
)

data class VideoItem(
    val id: Long,
    val title: String,
    val durationMs: Long,
    val contentUri: Uri,
    val thumbnailUri: Uri? = null,
    val folderName: String = "",
    val dataPath: String = "",
    val sizeBytes: Long = 0,
    val dateAddedSecs: Long = 0,
    val width: Int = 0,
    val height: Int = 0
)

data class AlbumItem(
    val id: Long,
    val name: String,
    val artist: String,
    val songCount: Int,
    val artworkUri: Uri? = null
)

data class ArtistItem(
    val id: Long,
    val name: String,
    val trackCount: Int,
    val albumCount: Int
)

data class FolderItem(
    val name: String,
    val path: String,
    val songCount: Int,
    val videoCount: Int
)

data class LyricsData(
    val available: Boolean,
    val lines: List<String> = emptyList()
)
