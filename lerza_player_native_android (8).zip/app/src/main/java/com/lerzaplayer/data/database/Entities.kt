package com.lerzaplayer.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_items")
data class PlaylistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val mediaUriString: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val artworkUriString: String? = null,
    val orderIndex: Int = 0
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val mediaUriString: String,
    val title: String,
    val artistOrFolder: String,
    val durationMs: Long,
    val isVideo: Boolean = false,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "vault_media")
data class VaultMediaEntity(
    @PrimaryKey val mediaUriString: String,
    val title: String,
    val artistOrFolder: String,
    val durationMs: Long,
    val isVideo: Boolean = false,
    val filePath: String = "",
    val hiddenAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "play_history")
data class PlayHistoryEntity(
    @PrimaryKey val mediaUriString: String,
    val title: String,
    val artist: String,
    val lastPlayedTimestamp: Long = System.currentTimeMillis(),
    val playCount: Int = 1,
    val lastPositionMs: Long = 0
)
