package com.lerzaplayer.ui.home

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.R
import com.lerzaplayer.data.database.PlaylistEntity
import com.lerzaplayer.data.model.*
import com.lerzaplayer.ui.folders.FoldersScreen
import com.lerzaplayer.ui.playlists.PlaylistsScreen
import com.lerzaplayer.ui.songs.SongListScreen
import com.lerzaplayer.ui.videos.VideoListScreen
import java.io.File

enum class HomeCategoryTab(val label: String) {
    SONGS("Songs"),
    VIDEOS("Videos"),
    PLAYLISTS("Playlists"),
    FOLDERS("Folders"),
    ALBUMS("Albums"),
    ARTISTS("Artists")
}

@Composable
fun HomeScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    playlists: List<PlaylistEntity>,
    folders: List<FolderItem>,
    albums: List<AlbumItem>,
    artists: List<ArtistItem>,
    selectedTab: HomeCategoryTab,
    isScanning: Boolean = false,
    onTabSelected: (HomeCategoryTab) -> Unit,
    onSongClick: (SongItem) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onHideSong: (SongItem) -> Unit,
    onHideVideo: (VideoItem) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onRescanMedia: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isHeaderVisible by remember { mutableStateOf(true) }

    val nestedScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -16f) {
                    isHeaderVisible = false
                } else if (available.y > 16f) {
                    isHeaderVisible = true
                }
                return Offset.Zero
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .nestedScroll(nestedScrollConnection)
    ) {
        // APPLICATION HEADER
        AnimatedVisibility(
            visible = isHeaderVisible,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Surface(
                color = MaterialTheme.colorScheme.background,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Logo & Brand
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                painter = androidx.compose.ui.res.painterResource(id = R.drawable.ic_logo_transparent),
                                contentDescription = "Lerza Player Logo",
                                tint = Color.Unspecified,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "LERZA PLAYER",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "${songs.size} songs • ${videos.size} videos",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Action buttons
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onRescanMedia) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Rescan Media",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        IconButton(onClick = onOpenSearch) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                        IconButton(onClick = onOpenSettings) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            }
        }

        // STICKY CATEGORY TABS (LazyRow ensures instant responsiveness on every touch)
        Surface(
            color = MaterialTheme.colorScheme.background,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentPadding = PaddingValues(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(HomeCategoryTab.values()) { tab ->
                    val isSelected = tab == selectedTab
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shadowElevation = if (isSelected) 3.dp else 0.dp,
                        modifier = Modifier.clickable { onTabSelected(tab) }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = tab.label,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Content Area according to selected sticky tab
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (selectedTab) {
                HomeCategoryTab.SONGS -> SongListScreen(
                    songs = songs,
                    onSongClick = onSongClick,
                    onHideSong = onHideSong,
                    isScanning = isScanning,
                    onRescan = onRescanMedia
                )
                HomeCategoryTab.VIDEOS -> VideoListScreen(
                    videos = videos,
                    onVideoClick = onVideoClick,
                    onHideVideo = onHideVideo,
                    isScanning = isScanning,
                    onRescan = onRescanMedia
                )
                HomeCategoryTab.PLAYLISTS -> PlaylistsScreen(
                    playlists = playlists,
                    onCreatePlaylist = onCreatePlaylist,
                    onPlaylistClick = { playlist ->
                        // Play playlist songs
                        if (songs.isNotEmpty()) onSongClick(songs.first())
                    }
                )
                HomeCategoryTab.FOLDERS -> FoldersScreen(
                    folders = folders,
                    onFolderClick = { folder ->
                        val folderSongs = songs.filter { File(it.dataPath).parent == folder.path }
                        if (folderSongs.isNotEmpty()) onSongClick(folderSongs.first())
                    }
                )
                HomeCategoryTab.ALBUMS -> {
                    if (albums.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No albums found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
                            items(albums) { album ->
                                ListItem(
                                    headlineContent = { Text(album.name, fontWeight = FontWeight.SemiBold) },
                                    supportingContent = { Text("${album.artist} • ${album.songCount} songs") },
                                    leadingContent = {
                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Album, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            AsyncImage(
                                                model = album.artworkUri,
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }
                                    },
                                    modifier = Modifier.clickable {
                                        val albumSong = songs.firstOrNull { it.album == album.name }
                                        if (albumSong != null) onSongClick(albumSong)
                                    }
                                )
                            }
                        }
                    }
                }
                HomeCategoryTab.ARTISTS -> {
                    if (artists.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("No artists found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
                            items(artists) { artist ->
                                ListItem(
                                    headlineContent = { Text(artist.name, fontWeight = FontWeight.SemiBold) },
                                    supportingContent = { Text("${artist.trackCount} tracks • ${artist.albumCount} albums") },
                                    leadingContent = {
                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        }
                                    },
                                    modifier = Modifier.clickable {
                                        val artistSong = songs.firstOrNull { it.artist == artist.name }
                                        if (artistSong != null) onSongClick(artistSong)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
