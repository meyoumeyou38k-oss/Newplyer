package com.lerzaplayer.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale

@Composable
fun MediaDetailsDialog(
    title: String,
    artistOrFolder: String,
    durationMs: Long,
    filePath: String,
    sizeBytes: Long,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "Media Details") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text = "Title: $title", style = MaterialTheme.typography.bodyMedium)
                Text(text = "Artist/Folder: $artistOrFolder", style = MaterialTheme.typography.bodyMedium)
                val mins = (durationMs / 1000) / 60
                val secs = (durationMs / 1000) % 60
                Text(text = "Duration: %02d:%02d".format(mins, secs), style = MaterialTheme.typography.bodyMedium)
                val mb = sizeBytes / (1024.0 * 1024.0)
                Text(text = "File Size: %.2f MB".format(Locale.US, mb), style = MaterialTheme.typography.bodyMedium)
                if (filePath.isNotEmpty()) {
                    Text(text = "Path: $filePath", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
