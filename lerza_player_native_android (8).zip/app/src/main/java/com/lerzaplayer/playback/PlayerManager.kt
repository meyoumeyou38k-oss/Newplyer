package com.lerzaplayer.playback

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.PlayHistoryEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

@OptIn(markerClass = [UnstableApi::class])
class PlayerManager private constructor(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val database = AppDatabase.getDatabase(context)

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context.applicationContext)
        .setHandleAudioBecomingNoisy(true)
        .build()

    private val _currentSong = MutableStateFlow<SongItem?>(null)
    val currentSong: StateFlow<SongItem?> = _currentSong.asStateFlow()

    private val _currentVideo = MutableStateFlow<VideoItem?>(null)
    val currentVideo: StateFlow<VideoItem?> = _currentVideo.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _queue = MutableStateFlow<List<SongItem>>(emptyList())
    val queue: StateFlow<List<SongItem>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(-1)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _isVideoMode = MutableStateFlow(false)
    val isVideoMode: StateFlow<Boolean> = _isVideoMode.asStateFlow()

    private val _sleepTimerRemainingMinutes = MutableStateFlow(0)
    val sleepTimerRemainingMinutes: StateFlow<Int> = _sleepTimerRemainingMinutes.asStateFlow()

    private val _playbackErrorMessage = MutableStateFlow<String?>(null)
    val playbackErrorMessage: StateFlow<String?> = _playbackErrorMessage.asStateFlow()

    private var sleepTimerJob: Job? = null
    private var positionTickerJob: Job? = null

    // Audio Effects
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null

    init {
        setupPlayerListener()
        startPositionTicker()
    }

    private fun setupPlayerListener() {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                _isPlaying.value = playing
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) {
                    _durationMs.value = exoPlayer.duration.coerceAtLeast(0L)
                } else if (state == Player.STATE_ENDED) {
                    onTrackEnded()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                _playbackErrorMessage.value = "Playback error: ${error.message ?: "Format unsupported"}"
            }
        })
    }

    private fun startPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = scope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _currentPositionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
                }
                delay(500)
            }
        }
    }

    fun playSong(song: SongItem, playlist: List<SongItem> = listOf(song), startIndex: Int = -1) {
        _isVideoMode.value = false
        _currentVideo.value = null
        _currentSong.value = song
        _queue.value = playlist

        val targetIndex = if (startIndex >= 0) startIndex else playlist.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
        _currentIndex.value = targetIndex

        val mediaMetadata = MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .setAlbumTitle(song.album)
            .setArtworkUri(song.albumArtUri)
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(song.contentUri)
            .setMediaMetadata(mediaMetadata)
            .build()

        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.play()

        // Record history
        scope.launch(Dispatchers.IO) {
            database.historyDao().recordPlay(
                PlayHistoryEntity(
                    mediaUriString = song.contentUri.toString(),
                    title = song.title,
                    artist = song.artist
                )
            )
        }
    }

    fun playVideo(video: VideoItem) {
        _currentSong.value = null
        _currentVideo.value = video
        _isVideoMode.value = true

        val mediaMetadata = MediaMetadata.Builder()
            .setTitle(video.title)
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(video.contentUri)
            .setMediaMetadata(mediaMetadata)
            .build()

        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            exoPlayer.play()
        }
    }

    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs)
        _currentPositionMs.value = positionMs
    }

    fun seekForward10s() {
        val newPos = (exoPlayer.currentPosition + 10000).coerceAtMost(exoPlayer.duration)
        seekTo(newPos)
    }

    fun seekBackward10s() {
        val newPos = (exoPlayer.currentPosition - 10000).coerceAtLeast(0)
        seekTo(newPos)
    }

    fun next() {
        val q = _queue.value
        if (q.isEmpty()) return

        var nextIdx = _currentIndex.value + 1
        if (nextIdx >= q.size) {
            nextIdx = 0
        }
        playSong(q[nextIdx], q, nextIdx)
    }

    fun previous() {
        val q = _queue.value
        if (q.isEmpty()) return

        if (exoPlayer.currentPosition > 3000) {
            seekTo(0)
            return
        }

        var prevIdx = _currentIndex.value - 1
        if (prevIdx < 0) {
            prevIdx = q.size - 1
        }
        playSong(q[prevIdx], q, prevIdx)
    }

    fun toggleShuffle() {
        val newShuffle = !_isShuffle.value
        _isShuffle.value = newShuffle
        exoPlayer.shuffleModeEnabled = newShuffle
    }

    fun cycleRepeatMode() {
        val nextMode = when (_repeatMode.value) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        _repeatMode.value = nextMode
        exoPlayer.repeatMode = nextMode
    }

    fun switchAudioVideoMode(toVideo: Boolean, matchingVideoUri: Uri?) {
        val currentPos = exoPlayer.currentPosition
        val wasPlaying = exoPlayer.isPlaying

        if (toVideo && matchingVideoUri != null) {
            _isVideoMode.value = true
            val mediaItem = MediaItem.fromUri(matchingVideoUri)
            exoPlayer.setMediaItem(mediaItem, currentPos)
            exoPlayer.prepare()
            if (wasPlaying) exoPlayer.play()
        } else {
            _isVideoMode.value = false
            _currentSong.value?.let { song ->
                val mediaItem = MediaItem.fromUri(song.contentUri)
                exoPlayer.setMediaItem(mediaItem, currentPos)
                exoPlayer.prepare()
                if (wasPlaying) exoPlayer.play()
            }
        }
    }

    private fun onTrackEnded() {
        if (_repeatMode.value == Player.REPEAT_MODE_ONE) {
            seekTo(0)
            exoPlayer.play()
        } else {
            next()
        }
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _sleepTimerRemainingMinutes.value = minutes

        if (minutes <= 0) return

        sleepTimerJob = scope.launch {
            var rem = minutes
            while (rem > 0) {
                delay(60000)
                rem--
                _sleepTimerRemainingMinutes.value = rem
            }
            exoPlayer.pause()
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _sleepTimerRemainingMinutes.value = 0
    }

    fun clearErrorMessage() {
        _playbackErrorMessage.value = null
    }

    fun setupEqualizer() {
        try {
            val sessionId = exoPlayer.audioSessionId
            if (sessionId != 0 && equalizer == null) {
                equalizer = Equalizer(0, sessionId).apply { enabled = true }
                bassBoost = BassBoost(0, sessionId).apply { enabled = true }
                virtualizer = Virtualizer(0, sessionId).apply { enabled = true }
            }
        } catch (_: Exception) {}
    }

    fun release() {
        positionTickerJob?.cancel()
        sleepTimerJob?.cancel()
        equalizer?.release()
        bassBoost?.release()
        virtualizer?.release()
        exoPlayer.release()
    }

    companion object {
        @Volatile
        private var INSTANCE: PlayerManager? = null

        fun getInstance(context: Context): PlayerManager {
            return INSTANCE ?: synchronized(this) {
                val instance = PlayerManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
