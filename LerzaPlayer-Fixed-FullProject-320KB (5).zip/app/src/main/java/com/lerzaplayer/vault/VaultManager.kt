package com.lerzaplayer.vault

import android.content.Context
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.preferences.PreferenceManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

class VaultManager private constructor(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val vaultDao = db.vaultDao()
    private val prefManager = PreferenceManager(context)
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    val vaultMediaFlow: Flow<List<VaultMediaEntity>> = vaultDao.getAllVaultMedia()

    private val vaultDir: File by lazy {
        File(context.filesDir, "vault_storage").apply { if (!exists()) mkdirs() }
    }

    fun hashInput(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray())
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    suspend fun verifyPin(enteredPin: String): Boolean {
        val savedHash = prefManager.vaultPinFlow.first()
        if (savedHash == null) {
            val newHash = hashInput(enteredPin)
            prefManager.setVaultPin(newHash)
            _isUnlocked.value = true
            return true
        }
        val match = hashInput(enteredPin) == savedHash
        if (match) _isUnlocked.value = true
        return match
    }

    suspend fun verifyPattern(patternPoints: List<Int>): Boolean {
        val enteredPattern = patternPoints.joinToString("-")
        val savedHash = prefManager.vaultPatternFlow.first()
        if (savedHash == null) {
            val newHash = hashInput(enteredPattern)
            prefManager.setVaultPattern(newHash)
            _isUnlocked.value = true
            return true
        }
        val match = hashInput(enteredPattern) == savedHash
        if (match) _isUnlocked.value = true
        return match
    }

    suspend fun setLockMode(type: VaultLockType) {
        prefManager.setVaultLockType(type)
    }

    fun lockVault() {
        _isUnlocked.value = false
    }

    fun onAppBackgrounded() {
        _isUnlocked.value = false
    }

    suspend fun hideSong(song: SongItem) = withContext(Dispatchers.IO) {
        try {
            val originalFile = File(song.path)
            if (!originalFile.exists()) return@withContext
            val encryptedFile = File(vaultDir, "vault_song_${song.id}.bin")
            xorCopy(originalFile, encryptedFile)
            vaultDao.insertVaultMedia(
                VaultMediaEntity(
                    originalPath = song.path,
                    encryptedPath = encryptedFile.absolutePath,
                    originalName = song.title,
                    mediaType = "AUDIO",
                    duration = song.duration,
                    size = song.size
                )
            )
            originalFile.delete()
            try {
                context.contentResolver.delete(song.contentUri, null, null)
            } catch (_: Exception) {}
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun hideVideo(video: VideoItem) = withContext(Dispatchers.IO) {
        try {
            val originalFile = File(video.path)
            if (!originalFile.exists()) return@withContext
            val encryptedFile = File(vaultDir, "vault_vid_${video.id}.bin")
            xorCopy(originalFile, encryptedFile)
            vaultDao.insertVaultMedia(
                VaultMediaEntity(
                    originalPath = video.path,
                    encryptedPath = encryptedFile.absolutePath,
                    originalName = video.title,
                    mediaType = "VIDEO",
                    duration = video.duration,
                    size = video.size
                )
            )
            originalFile.delete()
            try {
                context.contentResolver.delete(video.contentUri, null, null)
            } catch (_: Exception) {}
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun restoreMedia(entity: VaultMediaEntity) = withContext(Dispatchers.IO) {
        try {
            val encFile = File(entity.encryptedPath)
            val destFile = File(entity.originalPath)
            if (encFile.exists()) {
                destFile.parentFile?.mkdirs()
                xorCopy(encFile, destFile)
                encFile.delete()
            }
            vaultDao.deleteVaultMedia(entity)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun deletePermanently(entity: VaultMediaEntity) = withContext(Dispatchers.IO) {
        try {
            val encFile = File(entity.encryptedPath)
            if (encFile.exists()) {
                encFile.delete()
            }
            vaultDao.deleteVaultMedia(entity)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun restoreAllMedia(list: List<VaultMediaEntity>) = withContext(Dispatchers.IO) {
        list.forEach { entity ->
            val encFile = File(entity.encryptedPath)
            val destFile = File(entity.originalPath)
            if (encFile.exists()) {
                destFile.parentFile?.mkdirs()
                xorCopy(encFile, destFile)
                encFile.delete()
            }
            vaultDao.deleteVaultMedia(entity)
        }
    }

    suspend fun resetVaultLock() {
        prefManager.setVaultPin(null)
        prefManager.setVaultPattern(null)
        _isUnlocked.value = false
    }

    suspend fun updatePin(newPin: String) {
        val newHash = hashInput(newPin)
        prefManager.setVaultPin(newHash)
        prefManager.setVaultLockType(VaultLockType.PIN)
    }

    suspend fun updatePattern(patternPoints: List<Int>) {
        val enteredPattern = patternPoints.joinToString("-")
        val newHash = hashInput(enteredPattern)
        prefManager.setVaultPattern(newHash)
        prefManager.setVaultLockType(VaultLockType.PATTERN)
    }

    private fun xorCopy(src: File, dst: File) {
        val key: Byte = 0x5A
        FileInputStream(src).use { input ->
            FileOutputStream(dst).use { output ->
                val buffer = ByteArray(8192)
                var bytesRead: Int
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    for (i in 0 until bytesRead) {
                        buffer[i] = (buffer[i].toInt() xor key.toInt()).toByte()
                    }
                    output.write(buffer, 0, bytesRead)
                }
            }
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: VaultManager? = null

        fun getInstance(context: Context): VaultManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: VaultManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
