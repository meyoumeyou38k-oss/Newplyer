package com.lerzaplayer.lyrics

import android.content.Context
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.LyricsEntity
import com.lerzaplayer.data.model.LyricLine
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SongLyrics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object LyricsManager {

    suspend fun getLyricsForSong(context: Context, song: SongItem): SongLyrics = withContext(Dispatchers.IO) {
        val db = AppDatabase.getDatabase(context)
        val cached = db.lyricsDao().getLyrics(song.id)
        if (cached != null) {
            val lines = parseJsonToLyrics(cached.lyricsJson)
            if (lines.isNotEmpty()) {
                return@withContext SongLyrics(song.id, lines, isGenerated = false)
            }
        }

        // Check if an external .lrc file exists in same directory
        if (song.path.isNotEmpty()) {
            try {
                val lrcPath = song.path.substringBeforeLast(".") + ".lrc"
                val lrcFile = File(lrcPath)
                if (lrcFile.exists() && lrcFile.canRead()) {
                    val lrcLines = parseLrcContent(lrcFile.readText())
                    if (lrcLines.isNotEmpty()) {
                        saveLyrics(context, song.id, lrcLines)
                        return@withContext SongLyrics(song.id, lrcLines, isGenerated = false)
                    }
                }
            } catch (_: Exception) {}
        }

        // Offline rhythmic lyrics generator tailored to song title, artist and duration
        val generatedLines = generateOfflineLyrics(song)
        saveLyrics(context, song.id, generatedLines)
        SongLyrics(song.id, generatedLines, isGenerated = true)
    }

    suspend fun saveLyrics(context: Context, songId: Long, lines: List<LyricLine>) = withContext(Dispatchers.IO) {
        val array = JSONArray()
        lines.forEach { line ->
            val obj = JSONObject()
            obj.put("timestampMs", line.timestampMs)
            obj.put("text", line.text)
            obj.put("timeFormatted", line.timeFormatted)
            array.put(obj)
        }
        val entity = LyricsEntity(
            songId = songId,
            lyricsJson = array.toString()
        )
        AppDatabase.getDatabase(context).lyricsDao().insertLyrics(entity)
    }

    private fun parseJsonToLyrics(json: String): List<LyricLine> {
        val list = mutableListOf<LyricLine>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    LyricLine(
                        timestampMs = obj.getLong("timestampMs"),
                        text = obj.getString("text"),
                        timeFormatted = obj.getString("timeFormatted")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun parseLrcContent(content: String): List<LyricLine> {
        val result = mutableListOf<LyricLine>()
        val regex = Regex("\[(\d{2}):(\d{2})\.(\d{2,3})\](.*)")
        content.lines().forEach { line ->
            val match = regex.find(line.trim())
            if (match != null) {
                val min = match.groupValues[1].toLongOrNull() ?: 0L
                val sec = match.groupValues[2].toLongOrNull() ?: 0L
                val msStr = match.groupValues[3]
                val ms = if (msStr.length == 2) (msStr.toLongOrNull() ?: 0L) * 10 else (msStr.toLongOrNull() ?: 0L)
                val totalMs = (min * 60 + sec) * 1000 + ms
                val text = match.groupValues[4].trim()
                if (text.isNotEmpty()) {
                    result.add(LyricLine(totalMs, text, "%02d:%02d".format(min, sec)))
                }
            }
        }
        return result.sortedBy { it.timestampMs }
    }

    private fun generateOfflineLyrics(song: SongItem): List<LyricLine> {
        val dur = if (song.duration > 15000L) song.duration else 180000L
        val cleanTitle = song.title.replace(Regex("[^a-zA-Z0-9 ]"), "").trim()
        val artist = if (song.artist.contains("unknown", ignoreCase = true)) "Lerza Audio" else song.artist

        val templates = listOf(
            "♪ [Intro - Acoustic Melody] ♪",
            "Feel the rhythm, feeling so alive tonight",
            "Lost in the music of $cleanTitle",
            "Every heartbeat syncs with the bassline",
            "Hear the sound by $artist taking over",
            "♪ [Beat Drop & Harmonic Rhythm] ♪",
            "We are drifting through the melodic wave",
            "This moment never has to fade away",
            "Raise the sound higher, feel the vibe inside",
            "♪ [Chorus - $cleanTitle] ♪",
            "Sing along to the melody and let it ride",
            "Can you feel the harmony in the night air",
            "Every second echoing everywhere",
            "♪ [Guitar & Synth Solo] ♪",
            "Moving with the passion that will never die",
            "Forever in this song under open sky",
            "♪ [Outro - Fading Soft Rhythm] ♪"
        )

        val stepMs = (dur - 4000L) / templates.size.coerceAtLeast(1)
        val list = mutableListOf<LyricLine>()

        templates.forEachIndexed { index, text ->
            val timeMs = (index * stepMs).coerceAtMost(dur - 1000L)
            val sec = timeMs / 1000
            val min = sec / 60
            val s = sec % 60
            list.add(LyricLine(timeMs, text, "%02d:%02d".format(min, s)))
        }

        return list
    }
}
