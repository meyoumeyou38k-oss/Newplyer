package com.lerzaplayer.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_items")
data class PlaylistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val songId: Long,
    val addedAt: Long = System.currentTimeMillis(),
    val sortOrder: Int = 0
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val mediaId: Long,
    val mediaType: String, // "AUDIO" or "VIDEO"
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "vault_media")
data class VaultMediaEntity(
    @PrimaryKey val originalPath: String,
    val encryptedPath: String,
    val originalName: String,
    val mediaType: String,
    val duration: Long,
    val size: Long,
    val hiddenAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "play_history")
data class PlayHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mediaId: Long,
    val mediaType: String,
    val title: String,
    val artist: String = "",
    val uriString: String,
    val playedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "song_lyrics")
data class LyricsEntity(
    @PrimaryKey val songId: Long,
    val lyricsJson: String,
    val isUserSaved: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
