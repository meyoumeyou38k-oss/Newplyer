@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@file:androidx.media3.common.util.UnstableApi
@file:Suppress("UnsafeOptInUsageError", "OPT_IN_USAGE_DEFAULT", "DEPRECATION")

package com.lerzaplayer.ui.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.net.Uri
import android.provider.Settings
import android.util.Rational
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.playback.PlaytimeTracker
import com.lerzaplayer.data.repository.CustomTitleManager
import com.lerzaplayer.theme.LerzaIcons
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

enum class VideoGestureMode {
    VOLUME,
    BRIGHTNESS
}

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@androidx.media3.common.util.UnstableApi
@Composable
fun VideoPlayerScreen(
    video: VideoItem,
    onClose: () -> Unit,
    onPreviousVideo: () -> Unit = {},
    onNextVideo: () -> Unit = {},
    onPlayAsAudio: () -> Unit = {},
    onDeleteVideo: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager }
    val maxAudioVolume = remember(audioManager) {
        audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15
    }

    val exoPlayer = remember(video.id, video.contentUri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.contentUri))
            prepare()
            playWhenReady = true
        }
    }

    // 🔊 300% Volume Booster via LoudnessEnhancer
    val loudnessEnhancer = remember(exoPlayer) {
        runCatching {
            val sessionId = exoPlayer.audioSessionId
            if (sessionId != C.AUDIO_SESSION_ID_UNSET && sessionId > 0) {
                LoudnessEnhancer(sessionId).apply { enabled = true }
            } else null
        }.getOrNull()
    }

    var isPlaying by remember { mutableStateOf(true) }
    var currentPos by remember { mutableStateOf(0L) }
    var totalDur by remember { mutableStateOf(video.duration.coerceAtLeast(1L)) }
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPos by remember { mutableFloatStateOf(0f) }

    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var isLandscape by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableStateOf(1.0f) }
    var resizeMode by remember { mutableStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }

    // Dialog & Menu visibility states
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var isLooping by remember { mutableStateOf(false) }

    // 6X Speed on screen long press
    var isFastForwarding by remember { mutableStateOf(false) }

    // Two-finger Pinch to Zoom & Pan
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var zoomOffsetX by remember { mutableFloatStateOf(0f) }
    var zoomOffsetY by remember { mutableFloatStateOf(0f) }

    var showRenameVideoDialog by remember { mutableStateOf(false) }
    var newVideoTitle by remember(video.title) { mutableStateOf(video.title) }

    // Gesture swipe HUD overlay state
    var activeGesture by remember { mutableStateOf<VideoGestureMode?>(null) }
    var gestureProgress by remember { mutableFloatStateOf(0f) } // Brightness: 0..100, Volume: 0..300
    var gestureHideJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

    // Double tap feedback overlay (+10s / -10s)
    var doubleTapFeedback by remember { mutableStateOf<String?>(null) }
    var feedbackHideJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

    fun showFeedback(text: String) {
        feedbackHideJob?.cancel()
        doubleTapFeedback = text
        feedbackHideJob = scope.launch {
            delay(750)
            doubleTapFeedback = null
        }
    }

    // Auto-play Next Video on STATE_ENDED
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    if (!isLooping) {
                        onNextVideo()
                    }
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
            runCatching { loudnessEnhancer?.release() }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Auto-hide controls timer
    LaunchedEffect(controlsVisible, showMoreMenu, showSpeedDialog, showInfoDialog, showDeleteConfirm, isFastForwarding) {
        if (controlsVisible && !isLocked && !showMoreMenu && !showSpeedDialog && !showInfoDialog && !showDeleteConfirm && !isFastForwarding) {
            delay(4000)
            controlsVisible = false
        }
    }

    // 🌟 Robust Position Tracker (Keyed to exoPlayer and video.id so next video slider NEVER freezes!)
    LaunchedEffect(exoPlayer, video.id) {
        currentPos = 0L
        totalDur = video.duration.coerceAtLeast(1L)
        isPlaying = true
        controlsVisible = true
        isScrubbing = false

        while (isActive) {
            if (exoPlayer.isPlaying && !isScrubbing) {
                currentPos = exoPlayer.currentPosition
                totalDur = exoPlayer.duration.coerceAtLeast(video.duration).coerceAtLeast(1L)
                PlaytimeTracker.addVideoTime(context, 250L)
            }
            delay(250)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            // 1. Gesture detection: LEFT SIDE = Brightness (0-100%), RIGHT SIDE = Volume (0-300%)
            .pointerInput(isLocked) {
                if (!isLocked) {
                    var isRightSide = false
                    var totalDragY = 0f
                    var initialVolPercent = 0f
                    var initialBrightnessFraction = 0f
                    val screenHeight = size.height.toFloat()

                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            // Avoid bottom slider area
                            if (offset.y >= screenHeight * 0.72f) return@detectVerticalDragGestures
                            gestureHideJob?.cancel()
                            isRightSide = offset.x >= (size.width / 2f)
                            totalDragY = 0f

                            if (isRightSide) {
                                // 🔊 Volume & 300% Boost setup
                                val curVol = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
                                initialVolPercent = (curVol.toFloat() / maxAudioVolume.coerceAtLeast(1).toFloat()) * 100f
                                activeGesture = VideoGestureMode.VOLUME
                                gestureProgress = initialVolPercent.coerceIn(0f, 300f)
                            } else {
                                // ☀️ Screen brightness setup
                                val curBrightness = activity?.window?.attributes?.screenBrightness ?: -1f
                                initialBrightnessFraction = if (curBrightness < 0f) {
                                    try {
                                        Settings.System.getInt(
                                            context.contentResolver,
                                            Settings.System.SCREEN_BRIGHTNESS
                                        ) / 255f
                                    } catch (_: Exception) { 0.5f }
                                } else curBrightness
                                activeGesture = VideoGestureMode.BRIGHTNESS
                                gestureProgress = (initialBrightnessFraction * 100f).coerceIn(0f, 100f)
                            }
                        },
                        onVerticalDrag = { change, dragAmount ->
                            change.consume()
                            totalDragY -= dragAmount

                            if (isRightSide) {
                                // Volume up to 300%
                                val deltaPercent = (totalDragY / (screenHeight * 0.65f)) * 150f
                                val newVolPercent = (initialVolPercent + deltaPercent).coerceIn(0f, 300f)
                                gestureProgress = newVolPercent

                                if (newVolPercent <= 100f) {
                                    val streamVol = ((newVolPercent / 100f) * maxAudioVolume).toInt().coerceIn(0, maxAudioVolume)
                                    audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, streamVol, 0)
                                    exoPlayer.volume = 1.0f
                                    runCatching {
                                        loudnessEnhancer?.apply {
                                            enabled = false
                                            setTargetGain(0)
                                        }
                                    }
                                } else {
                                    // Over 100% up to 300% boost!
                                    audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, maxAudioVolume, 0)
                                    val boostFraction = (newVolPercent - 100f) / 200f // 0.0 to 1.0
                                    val targetGainMb = (boostFraction * 2000f).toInt() // up to +2000 mB
                                    runCatching {
                                        loudnessEnhancer?.apply {
                                            enabled = true
                                            setTargetGain(targetGainMb)
                                        }
                                    }
                                    exoPlayer.volume = (1.0f + boostFraction * 0.8f).coerceAtMost(2.0f)
                                }
                            } else {
                                // Brightness 0 to 100%
                                val deltaFraction = totalDragY / (screenHeight * 0.65f)
                                val newFraction = (initialBrightnessFraction + deltaFraction).coerceIn(0f, 1f)
                                gestureProgress = (newFraction * 100f).coerceIn(0f, 100f)

                                val lp = activity?.window?.attributes
                                if (lp != null) {
                                    lp.screenBrightness = newFraction.coerceIn(0.01f, 1.0f)
                                    activity.window.attributes = lp
                                }
                            }
                        },
                        onDragEnd = {
                            gestureHideJob = scope.launch {
                                delay(1200)
                                activeGesture = null
                            }
                        },
                        onDragCancel = {
                            activeGesture = null
                        }
                    )
                }
            }
            // 2. Double tap to seek (+10s right, -10s left), Tap to toggle controls, Long press for 6X Speed
            .pointerInput(isLocked, playbackSpeed) {
                detectTapGestures(
                    onPress = {
                        if (!isLocked) {
                            val originalSpeed = playbackSpeed
                            var isSpeeding = false
                            try {
                                val released = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                                    tryAwaitRelease()
                                }
                                if (released == null) {
                                    // 🚀 6X Speed on long press!
                                    isSpeeding = true
                                    isFastForwarding = true
                                    exoPlayer.playbackParameters = PlaybackParameters(6.0f)
                                    tryAwaitRelease()
                                }
                            } finally {
                                if (isSpeeding) {
                                    isFastForwarding = false
                                    exoPlayer.playbackParameters = PlaybackParameters(originalSpeed)
                                }
                            }
                        }
                    },
                    onTap = {
                        if (!isLocked) {
                            controlsVisible = !controlsVisible
                        } else {
                            controlsVisible = true
                        }
                    },
                    onDoubleTap = { offset ->
                        if (!isLocked) {
                            if (offset.x < size.width / 2f) {
                                // Left side -> Rewind 10s
                                val target = (exoPlayer.currentPosition - 10000L).coerceAtLeast(0L)
                                exoPlayer.seekTo(target)
                                currentPos = target
                                showFeedback("-10s ⏪")
                            } else {
                                // Right side -> Forward 10s
                                val target = (exoPlayer.currentPosition + 10000L).coerceAtMost(exoPlayer.duration.coerceAtLeast(0L))
                                exoPlayer.seekTo(target)
                                currentPos = target
                                showFeedback("+10s ⏩")
                            }
                        }
                    }
                )
            }
    ) {
        // Video View with 2-finger Pinch-to-Zoom & Pan
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    this.resizeMode = resizeMode
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { playerView ->
                playerView.player = exoPlayer
                playerView.resizeMode = resizeMode
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = zoomScale,
                    scaleY = zoomScale,
                    translationX = zoomOffsetX,
                    translationY = zoomOffsetY
                )
                .pointerInput(isLocked) {
                    if (!isLocked) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val newScale = (zoomScale * zoom).coerceIn(1f, 4.5f)
                            zoomScale = newScale
                            if (newScale > 1f) {
                                val maxPanX = (size.width * (newScale - 1f)) / 2f
                                val maxPanY = (size.height * (newScale - 1f)) / 2f
                                zoomOffsetX = (zoomOffsetX + pan.x * newScale).coerceIn(-maxPanX, maxPanX)
                                zoomOffsetY = (zoomOffsetY + pan.y * newScale).coerceIn(-maxPanY, maxPanY)
                            } else {
                                zoomOffsetX = 0f
                                zoomOffsetY = 0f
                            }
                        }
                    }
                }
        )

        // ☀️ Left Side HUD: Brightness (Matches screenshot IMG-20261001-WA0192.jpg)
        AnimatedVisibility(
            visible = activeGesture == VideoGestureMode.BRIGHTNESS,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 24.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.BrightnessMedium,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "${gestureProgress.toInt()}%",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Box(
                    modifier = Modifier
                        .width(18.dp)
                        .height(130.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(Color.White.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight((gestureProgress / 100f).coerceIn(0f, 1f))
                            .clip(RoundedCornerShape(9.dp))
                            .background(Color.White)
                    )
                }
            }
        }

        // 🔊 Right Side HUD: Volume with 300% Boost (Matches screenshot IMG-20261001-WA0191.jpg)
        AnimatedVisibility(
            visible = activeGesture == VideoGestureMode.VOLUME,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 24.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val volIcon = when {
                    gestureProgress <= 0f -> Icons.Default.VolumeMute
                    gestureProgress > 100f -> Icons.Default.VolumeUp
                    else -> Icons.Default.VolumeDown
                }
                Icon(
                    imageVector = volIcon,
                    contentDescription = null,
                    tint = if (gestureProgress > 100f) Color(0xFFFF5252) else Color.White,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "${gestureProgress.toInt()}%" + if (gestureProgress > 100f) " (Boost)" else "",
                    color = if (gestureProgress > 100f) Color(0xFFFF5252) else Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Box(
                    modifier = Modifier
                        .width(18.dp)
                        .height(130.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(Color.White.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight((gestureProgress / 300f).coerceIn(0f, 1f))
                            .clip(RoundedCornerShape(9.dp))
                            .background(if (gestureProgress > 100f) Color(0xFFFF5252) else Color.White)
                    )
                }
            }
        }

        // ⚡ 6X Fast Forward Top Badge
        AnimatedVisibility(
            visible = isFastForwarding,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 70.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.Black.copy(alpha = 0.85f),
                border = BorderStroke(1.5.dp, Color(0xFF00E5FF))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.FastForward,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "6X Fast Forward",
                        color = Color(0xFF00E5FF),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // ⏩ Double Tap Feedback HUD (+10s / -10s)
        AnimatedVisibility(
            visible = doubleTapFeedback != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.Black.copy(alpha = 0.80f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.20f))
            ) {
                Text(
                    text = doubleTapFeedback ?: "",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                )
            }
        }

        // 🔒 Locked Floating Unlock Button
        if (isLocked) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.70f))
                        .border(1.5.dp, Color.White.copy(alpha = 0.40f), CircleShape)
                        .clickable {
                            isLocked = false
                            controlsVisible = true
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.LockOpen,
                        contentDescription = "Unlock",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        // 🎮 Modern Controls Layer (Exactly matching IMG-20261001-WA0187.jpg)
        AnimatedVisibility(
            visible = controlsVisible && !isLocked,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                // Top Bar: Back, Title, 3-Dots Menu
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        IconButton(onClick = onClose, modifier = Modifier.size(40.dp)) {
                            Icon(
                                imageVector = LerzaIcons.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Text(
                            text = video.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Box {
                        IconButton(onClick = { showMoreMenu = true }, modifier = Modifier.size(40.dp)) {
                            Icon(
                                imageVector = LerzaIcons.MoreVert,
                                contentDescription = "Options",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false },
                            modifier = Modifier.background(Color(0xFF161C24))
                        ) {
                            VideoMenuItem(
                                icon = LerzaIcons.Share,
                                title = "Share",
                                accentTint = Color(0xFF00B0FF),
                                onClick = {
                                    showMoreMenu = false
                                    runCatching {
                                        val share = Intent(Intent.ACTION_SEND).apply {
                                            type = "video/*"
                                            putExtra(Intent.EXTRA_STREAM, video.contentUri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(share, "Share video"))
                                    }
                                }
                            )
                            VideoMenuItem(
                                icon = LerzaIcons.Videocam,
                                title = "Floating window (PiP)",
                                accentTint = Color(0xFF00E5FF),
                                onClick = {
                                    showMoreMenu = false
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                        runCatching {
                                            activity?.enterPictureInPictureMode(
                                                PictureInPictureParams.Builder()
                                                    .setAspectRatio(Rational(16, 9))
                                                    .build()
                                            )
                                        }
                                    }
                                }
                            )
                            VideoMenuItem(
                                icon = LerzaIcons.Repeat,
                                title = if (isLooping) "Repeat: One" else "Repeat: Off",
                                accentTint = Color(0xFF9C27B0),
                                onClick = {
                                    isLooping = !isLooping
                                    exoPlayer.repeatMode = if (isLooping) {
                                        Player.REPEAT_MODE_ONE
                                    } else {
                                        Player.REPEAT_MODE_OFF
                                    }
                                    showMoreMenu = false
                                }
                            )
                            VideoMenuItem(
                                icon = Icons.Default.Edit,
                                title = "Rename Video",
                                accentTint = Color(0xFFFFB300),
                                onClick = {
                                    showMoreMenu = false
                                    showRenameVideoDialog = true
                                }
                            )
                            VideoMenuItem(
                                icon = LerzaIcons.ScreenRotation,
                                title = "Screen rotation",
                                accentTint = Color(0xFF3D5AFE),
                                onClick = {
                                    isLandscape = !isLandscape
                                    activity?.requestedOrientation = if (isLandscape) {
                                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    } else {
                                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                    }
                                    showMoreMenu = false
                                }
                            )
                            VideoMenuItem(
                                icon = LerzaIcons.Info,
                                title = "Video details",
                                accentTint = Color(0xFF00ACC1),
                                onClick = {
                                    showMoreMenu = false
                                    showInfoDialog = true
                                }
                            )
                            HorizontalDivider(color = Color.White.copy(alpha = 0.12f), thickness = 0.8.dp)
                            VideoMenuItem(
                                icon = LerzaIcons.Delete,
                                title = "Delete video",
                                accentTint = Color(0xFFFF334B),
                                textColor = Color(0xFFFF334B),
                                onClick = {
                                    showMoreMenu = false
                                    showDeleteConfirm = true
                                }
                            )
                        }
                    }
                }

                // Bottom Controls Container (Action row + Timeline + Center Circular Play controls)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                ) {
                    // 1. Utility Action Buttons Row (Headphones, Speed, Lock, Resize)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Headphones (Play as audio)
                        IconButton(onClick = onPlayAsAudio, modifier = Modifier.size(42.dp)) {
                            Icon(
                                imageVector = LerzaIcons.Headphones,
                                contentDescription = "Play as audio",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Speedometer Button (1.0x with speed icon)
                        TextButton(
                            onClick = { showSpeedDialog = true },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = LerzaIcons.Speed,
                                    contentDescription = "Speed",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "${playbackSpeed}x",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Lock Button
                        IconButton(
                            onClick = {
                                isLocked = true
                                controlsVisible = false
                            },
                            modifier = Modifier.size(42.dp)
                        ) {
                            Icon(
                                imageVector = LerzaIcons.Lock,
                                contentDescription = "Lock controls",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // Resize / Aspect ratio Button
                        IconButton(
                            onClick = {
                                resizeMode = when (resizeMode) {
                                    AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                    AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                    else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                }
                            },
                            modifier = Modifier.size(42.dp)
                        ) {
                            Icon(
                                imageVector = LerzaIcons.AspectRatio,
                                contentDescription = "Aspect ratio",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    // 2. Timeline Progress bar with current and total duration
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val displayCurPos = if (isScrubbing) scrubPos.toLong() else currentPos
                        val curSec = (displayCurPos / 1000).coerceAtLeast(0)
                        val totSec = (totalDur / 1000).coerceAtLeast(0)

                        Text(
                            text = "%d:%02d".format(curSec / 60, curSec % 60),
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )

                        val sliderProgress = if (totalDur > 0) {
                            (displayCurPos.toFloat() / totalDur.toFloat()).coerceIn(0f, 1f)
                        } else 0f

                        Slider(
                            value = sliderProgress,
                            onValueChange = { frac ->
                                isScrubbing = true
                                scrubPos = (frac * totalDur).coerceIn(0f, totalDur.toFloat())
                            },
                            onValueChangeFinished = {
                                exoPlayer.seekTo(scrubPos.toLong())
                                currentPos = scrubPos.toLong()
                                isScrubbing = false
                            },
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFF4081),
                                activeTrackColor = Color(0xFFFF4081),
                                inactiveTrackColor = Color.White.copy(alpha = 0.30f)
                            )
                        )

                        Text(
                            text = "%d:%02d".format(totSec / 60, totSec % 60),
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // 3. Main Bottom Media Controls (Previous, Play/Pause, Next) - Modern Dark Glass, NO BLUE!
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp, bottom = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Previous Video Button
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.16f))
                                .clickable(onClick = onPreviousVideo),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = LerzaIcons.SkipPrevious,
                                contentDescription = "Previous video",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(38.dp))

                        // Center Play / Pause Button (Clean White on Dark Glass)
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.22f))
                                .clickable {
                                    if (exoPlayer.isPlaying) {
                                        exoPlayer.pause()
                                        isPlaying = false
                                    } else {
                                        exoPlayer.play()
                                        isPlaying = true
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) LerzaIcons.Pause else LerzaIcons.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(38.dp))

                        // Next Video Button
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.16f))
                                .clickable(onClick = onNextVideo),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = LerzaIcons.SkipNext,
                                contentDescription = "Next video",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Rename Video Dialog
    if (showRenameVideoDialog) {
        AlertDialog(
            onDismissRequest = { showRenameVideoDialog = false },
            title = { Text("Rename Video", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Enter new name for the video:", fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newVideoTitle,
                        onValueChange = { newVideoTitle = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newVideoTitle.isNotBlank()) {
                            CustomTitleManager.setTitle(video.id, newVideoTitle)
                            Toast.makeText(context, "Video renamed to: $newVideoTitle", Toast.LENGTH_SHORT).show()
                        }
                        showRenameVideoDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameVideoDialog = false }) {
                    Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                }
            },
            containerColor = Color(0xFF161C24)
        )
    }

    // Playback Speed Dialog
    if (showSpeedDialog) {
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            title = { Text("Playback speed", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 3.0f, 4.0f)
                    speeds.forEach { spd ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    playbackSpeed = spd
                                    exoPlayer.playbackParameters = PlaybackParameters(spd)
                                    showSpeedDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${spd}x",
                                color = if (playbackSpeed == spd) Color(0xFF00E5FF) else Color.White,
                                fontWeight = if (playbackSpeed == spd) FontWeight.Bold else FontWeight.Normal
                            )
                            if (playbackSpeed == spd) {
                                Icon(LerzaIcons.Check, contentDescription = null, tint = Color(0xFF00E5FF))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSpeedDialog = false }) {
                    Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                }
            },
            containerColor = Color(0xFF161C24)
        )
    }

    // Video Details Dialog
    if (showInfoDialog) {
        AlertDialog(
            onDismissRequest = { showInfoDialog = false },
            title = { Text("Video Details", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Title: ${video.title}", fontSize = 13.sp)
                    Text("Duration: ${video.durationFormatted}", fontSize = 13.sp)
                    Text("Resolution: ${video.resolution}", fontSize = 13.sp)
                    Text("File size: ${video.sizeFormatted}", fontSize = 13.sp)
                    Text("Location: ${video.path}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
                }
            },
            confirmButton = {
                TextButton(onClick = { showInfoDialog = false }) {
                    Text("OK", color = Color(0xFF00E5FF))
                }
            },
            containerColor = Color(0xFF161C24)
        )
    }

    // Delete Confirmation Dialog
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Video", fontWeight = FontWeight.Bold) },
            text = {
                Text("Are you sure you want to move \"${video.title}\" to Recently Deleted?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteVideo()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF334B))
                ) {
                    Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                }
            },
            containerColor = Color(0xFF161C24)
        )
    }
}

@Composable
fun VideoMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    accentTint: Color = Color.White,
    textColor: Color = Color.White,
    onClick: () -> Unit
) {
    DropdownMenuItem(
        text = {
            Text(
                text = title,
                color = textColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        },
        leadingIcon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentTint,
                modifier = Modifier.size(20.dp)
            )
        },
        onClick = onClick
    )
}
