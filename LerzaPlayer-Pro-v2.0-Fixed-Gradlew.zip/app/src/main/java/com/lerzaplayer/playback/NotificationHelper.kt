package com.lerzaplayer.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaStyleNotificationHelper
import com.lerzaplayer.MainActivity
import com.lerzaplayer.R
import com.lerzaplayer.data.model.SongItem

object NotificationHelper {
    const val CHANNEL_PLAYBACK_ID = "lerza_playback_channel_v2"
    const val CHANNEL_DOWNLOAD_ID = "lerza_download_channel_v2"
    const val NOTIFICATION_ID = 1001
    private const val NEW_MEDIA_NOTIFICATION_ID_BASE = 3000

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val playbackChannel = NotificationChannel(
                CHANNEL_PLAYBACK_ID,
                "Media Playback & Controls",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Now playing media player controls, skip previous/next, pause and seek"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(playbackChannel)

            val downloadChannel = NotificationChannel(
                CHANNEL_DOWNLOAD_ID,
                "New Media Download Radar",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Real-time AI alerts when new audio or video is downloaded"
                enableVibration(true)
                setShowBadge(true)
            }
            manager.createNotificationChannel(downloadChannel)
        }
    }

    fun buildMediaNotification(
        context: Context,
        song: SongItem?,
        isPlaying: Boolean,
        albumArt: Bitmap?,
        currentPosition: Long = 0L,
        duration: Long = 0L,
        mediaSession: MediaSession? = null
    ): Notification {
        createNotificationChannels(context)

        val mainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val mainPendingIntent = PendingIntent.getActivity(
            context, 0, mainIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val prevPending = servicePendingIntent(context, 101, PlaybackService.ACTION_PREV)
        val playPauseAction = if (isPlaying) PlaybackService.ACTION_PAUSE else PlaybackService.ACTION_PLAY
        val playPausePending = servicePendingIntent(context, 102, playPauseAction)
        val nextPending = servicePendingIntent(context, 103, PlaybackService.ACTION_NEXT)

        val builder = NotificationCompat.Builder(context, CHANNEL_PLAYBACK_ID)
            .setSmallIcon(R.drawable.ic_logo_transparent)
            .setContentTitle(song?.title ?: "Lerza Player Pro")
            .setContentText(song?.artist ?: "Hardware Hi-Fi Playback")
            .setSubText("Lerza GPU Audio")
            .setContentIntent(mainPendingIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(isPlaying)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOnlyAlertOnce(true)
            .addAction(R.drawable.ic_skip_previous, "Previous", prevPending)
            .addAction(
                if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                if (isPlaying) "Pause" else "Play",
                playPausePending
            )
            .addAction(R.drawable.ic_skip_next, "Next", nextPending)

        if (mediaSession != null) {
            builder.setStyle(
                MediaStyleNotificationHelper.MediaStyle(mediaSession)
                    .setShowActionsInCompactView(0, 1, 2)
            )
        }
        if (albumArt != null) builder.setLargeIcon(albumArt)
        return builder.build()
    }

    private fun servicePendingIntent(context: Context, requestCode: Int, action: String): PendingIntent {
        val intent = Intent(context, PlaybackService::class.java).apply { this.action = action }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PendingIntent.getForegroundService(
                context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else {
            PendingIntent.getService(
                context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }

    fun showNewMediaNotification(
        context: Context,
        heading: String,
        title: String,
        detail: String,
        thumbnail: Bitmap?,
        mediaKey: String
    ) {
        createNotificationChannels(context)
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("OPEN_MEDIA_KEY", mediaKey)
        }
        val pendingIntent = PendingIntent.getActivity(
            context, mediaKey.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(context, CHANNEL_DOWNLOAD_ID)
            .setSmallIcon(R.drawable.ic_logo_transparent)
            .setContentTitle("✨ AI Media Radar: $heading")
            .setContentText(title)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$title\n$detail\n⚡ Tap to play in Lerza Hi-Fi!"))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
        if (thumbnail != null) builder.setLargeIcon(thumbnail)
        val notificationId = NEW_MEDIA_NOTIFICATION_ID_BASE + (mediaKey.hashCode() and 0x7fffffff) % 100000
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        runCatching { notificationManager.notify(notificationId, builder.build()) }
    }
}