package com.lerzaplayer.data.repository

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.model.SongItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MediaRepository(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val recentlyDeletedDao = db.recentlyDeletedDao()

    suspend fun deleteMedia(song: SongItem) = withContext(Dispatchers.IO) {
        val trashDir = File(context.filesDir, "recently_deleted").apply { mkdirs() }
        val backup = File(trashDir, "${System.currentTimeMillis()}_${song.title.take(40)}")
        val source = File(song.path)

        if (source.exists()) {
            source.copyTo(backup, overwrite = true)
            source.delete()
        } else {
            context.contentResolver.openInputStream(song.contentUri)?.use { input ->
                FileOutputStream(backup).use { output -> input.copyTo(output) }
            }
        }

        try { context.contentResolver.delete(song.contentUri, null, null) } catch (_: Exception) {}
        if (song.path.isNotBlank()) {
            MediaScannerConnection.scanFile(context, arrayOf(song.path), null, null)
        }

        if (backup.exists()) {
            recentlyDeletedDao.insert(
                RecentlyDeletedEntity(
                    originalPath = song.path,
                    backupPath = backup.absolutePath,
                    originalName = song.title,
                    mediaType = "AUDIO",
                    duration = song.duration,
                    size = song.size
                )
            )
        }
        recentlyDeletedDao.deleteExpired(System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000)
    }

    suspend fun restoreRecentlyDeleted(item: RecentlyDeletedEntity) = withContext(Dispatchers.IO) {
        val backup = File(item.backupPath)
        if (!backup.exists()) return@withContext
        val dest = File(item.originalPath)
        dest.parentFile?.mkdirs()
        backup.copyTo(dest, overwrite = true)
        MediaScannerConnection.scanFile(context, arrayOf(dest.absolutePath), null, null)
        backup.delete()
        recentlyDeletedDao.delete(item)
    }

    suspend fun permanentlyDeleteRecentlyDeleted(item: RecentlyDeletedEntity) = withContext(Dispatchers.IO) {
        runCatching { File(item.backupPath).delete() }
        recentlyDeletedDao.delete(item)
    }
}