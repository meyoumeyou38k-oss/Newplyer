package com.lerzaplayer.playback

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.atomic.AtomicLong

/**
 * HIGH-PERFORMANCE PLAYTIME TRACKER (Zero-Jank Hardware Buffering)
 *
 * Performance Fix:
 * Previously wrote to SharedPreferences on every 400ms tick (~150 disk flushes/min).
 * Now accumulates deltas in memory via AtomicLong and asynchronously flushes
 * to disk every 15-30 seconds or upon app lifecycle events.
 */
object PlaytimeTracker {
    private const val PREF_NAME = "lerza_playtime_prefs"
    private const val KEY_TOTAL_MUSIC_MS = "total_music_ms"
    private const val KEY_TOTAL_VIDEO_MS = "total_video_ms"
    private const val FLUSH_THRESHOLD_MS = 15_000L // Flush every 15s

    private var prefs: SharedPreferences? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _musicPlaytimeMs = MutableStateFlow(0L)
    val musicPlaytimeMs: StateFlow<Long> = _musicPlaytimeMs.asStateFlow()

    private val _videoPlaytimeMs = MutableStateFlow(0L)
    val videoPlaytimeMs: StateFlow<Long> = _videoPlaytimeMs.asStateFlow()

    private val pendingMusicDelta = AtomicLong(0L)
    private val pendingVideoDelta = AtomicLong(0L)
    private var lastFlushTime = System.currentTimeMillis()

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            _musicPlaytimeMs.value = prefs?.getLong(KEY_TOTAL_MUSIC_MS, 0L) ?: 0L
            _videoPlaytimeMs.value = prefs?.getLong(KEY_TOTAL_VIDEO_MS, 0L) ?: 0L
        }
    }

    private fun getPrefs(context: Context): SharedPreferences {
        if (prefs == null) init(context)
        return prefs!!
    }

    fun addMusicTime(context: Context, deltaMs: Long) {
        val currentTotal = _musicPlaytimeMs.value + deltaMs
        _musicPlaytimeMs.value = currentTotal
        val accumulated = pendingMusicDelta.addAndGet(deltaMs)

        if (accumulated >= FLUSH_THRESHOLD_MS || System.currentTimeMillis() - lastFlushTime > 20_000L) {
            flushPlaytimeAsync(context)
        }
    }

    fun addVideoTime(context: Context, deltaMs: Long) {
        val currentTotal = _videoPlaytimeMs.value + deltaMs
        _videoPlaytimeMs.value = currentTotal
        val accumulated = pendingVideoDelta.addAndGet(deltaMs)

        if (accumulated >= FLUSH_THRESHOLD_MS || System.currentTimeMillis() - lastFlushTime > 20_000L) {
            flushPlaytimeAsync(context)
        }
    }

    fun flushPlaytimeAsync(context: Context) {
        val mDelta = pendingMusicDelta.getAndSet(0L)
        val vDelta = pendingVideoDelta.getAndSet(0L)
        if (mDelta == 0L && vDelta == 0L) return

        lastFlushTime = System.currentTimeMillis()
        scope.launch {
            try {
                val p = getPrefs(context)
                val editor = p.edit()
                if (mDelta > 0L) {
                    val prev = p.getLong(KEY_TOTAL_MUSIC_MS, 0L)
                    editor.putLong(KEY_TOTAL_MUSIC_MS, prev + mDelta)
                    val monthKey = "month_" + SimpleDateFormat("yyyy_MM", Locale.ENGLISH).format(Date())
                    val dayKey = "day_" + SimpleDateFormat("yyyy_MM_dd", Locale.ENGLISH).format(Date())
                    editor.putLong(monthKey, p.getLong(monthKey, 0L) + mDelta)
                    editor.putLong(dayKey, p.getLong(dayKey, 0L) + mDelta)
                }
                if (vDelta > 0L) {
                    val prevV = p.getLong(KEY_TOTAL_VIDEO_MS, 0L)
                    editor.putLong(KEY_TOTAL_VIDEO_MS, prevV + vDelta)
                    val monthKeyV = "month_v_" + SimpleDateFormat("yyyy_MM", Locale.ENGLISH).format(Date())
                    val dayKeyV = "day_v_" + SimpleDateFormat("yyyy_MM_dd", Locale.ENGLISH).format(Date())
                    editor.putLong(monthKeyV, p.getLong(monthKeyV, 0L) + vDelta)
                    editor.putLong(dayKeyV, p.getLong(dayKeyV, 0L) + vDelta)
                }
                editor.apply()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun getMonthPlaytimeMs(context: Context): Long {
        val p = getPrefs(context)
        val monthKey = "month_" + SimpleDateFormat("yyyy_MM", Locale.ENGLISH).format(Date())
        return p.getLong(monthKey, 0L) + pendingMusicDelta.get()
    }

    fun getTodayPlaytimeMs(context: Context): Long {
        val p = getPrefs(context)
        val dayKey = "day_" + SimpleDateFormat("yyyy_MM_dd", Locale.ENGLISH).format(Date())
        return p.getLong(dayKey, 0L) + pendingMusicDelta.get()
    }

    fun getCurrentMonthName(): String = SimpleDateFormat("MMMM", Locale.ENGLISH).format(Date())

    fun formatLarkTime(ms: Long): String {
        val totalSec = ms / 1000
        val hours = totalSec / 3600
        val mins = (totalSec % 3600) / 60
        val secs = totalSec % 60
        return when {
            hours > 0 -> "${hours}h ${mins}m"
            mins > 0 -> "${mins}m"
            secs > 0 -> "${secs}s"
            else -> "0m"
        }
    }
}
