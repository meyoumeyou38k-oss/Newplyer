# Add project specific ProGuard rules here.
-keep class com.lerzaplayer.data.database.** { *; }
-keep class com.lerzaplayer.playback.** { *; }
-keep class com.lerzaplayer.data.model.** { *; }
-keepattributes *Annotation*
-dontwarn androidx.media3.**

# Optimize Compose compiler generated classes
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
}
