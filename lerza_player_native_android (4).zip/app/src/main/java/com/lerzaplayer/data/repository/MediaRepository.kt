package com.lerzaplayer.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class MediaRepository(private val context: Context) {
    private val database = AppDatabase.getDatabase(context)
    private val vaultDao = database.vaultDao()

    suspend fun getAllSongs(): List<SongItem> = withContext(Dispatchers.IO) {
        val hiddenUris = try {
            vaultDao.getAllHiddenUris().first().toSet()
        } catch (_: Exception) {
            emptySet()
        }

        val songList = mutableListOf<SongItem>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.ALBUM_ID
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 10000"
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )

            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val sizeCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val albumIdCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    if (hiddenUris.contains(contentUri.toString())) {
                        continue
                    }

                    val title = it.getString(titleCol) ?: "Unknown Track"
                    val artist = it.getString(artistCol) ?: "Unknown Artist"
                    val album = it.getString(albumCol) ?: "Unknown Album"
                    val duration = it.getLong(durCol)
                    val data = it.getString(dataCol) ?: ""
                    val size = it.getLong(sizeCol)
                    val dateAdded = it.getLong(dateCol)
                    val albumId = it.getLong(albumIdCol)

                    val artworkUri = ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"),
                        albumId
                    )

                    songList.add(
                        SongItem(
                            id = id,
                            title = title,
                            artist = if (artist.contains("<unknown>", ignoreCase = true)) "Unknown Artist" else artist,
                            album = if (album.contains("<unknown>", ignoreCase = true)) "Unknown Album" else album,
                            durationMs = duration,
                            contentUri = contentUri,
                            albumArtUri = artworkUri,
                            dataPath = data,
                            sizeBytes = size,
                            dateAddedSecs = dateAdded
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        songList
    }

    suspend fun getAllVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val hiddenUris = try {
            vaultDao.getAllHiddenUris().first().toSet()
        } catch (_: Exception) {
            emptySet()
        }

        val videoList = mutableListOf<VideoItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )

            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val durCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val dataCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val sizeCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val wCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val hCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val bucketCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    if (hiddenUris.contains(contentUri.toString())) {
                        continue
                    }

                    val title = it.getString(titleCol) ?: "Video $id"
                    val duration = it.getLong(durCol)
                    val data = it.getString(dataCol) ?: ""
                    val size = it.getLong(sizeCol)
                    val dateAdded = it.getLong(dateCol)
                    val width = it.getInt(wCol)
                    val height = it.getInt(hCol)
                    val folder = it.getString(bucketCol) ?: "Videos"

                    videoList.add(
                        VideoItem(
                            id = id,
                            title = title,
                            durationMs = duration,
                            contentUri = contentUri,
                            thumbnailUri = contentUri,
                            folderName = folder,
                            dataPath = data,
                            sizeBytes = size,
                            dateAddedSecs = dateAdded,
                            width = width,
                            height = height
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        videoList
    }

    fun findMatchingVideoForSong(song: SongItem, allVideos: List<VideoItem>): VideoItem? {
        val cleanSongTitle = cleanName(song.title)
        val cleanArtist = cleanName(song.artist)

        if (cleanSongTitle.length < 3) return null

        for (video in allVideos) {
            val cleanVideoTitle = cleanName(video.title)
            val videoFileName = cleanName(File(video.dataPath).nameWithoutExtension)

            val titleMatch = cleanVideoTitle.contains(cleanSongTitle) ||
                    videoFileName.contains(cleanSongTitle) ||
                    cleanSongTitle.contains(cleanVideoTitle)

            val artistMatch = cleanArtist != "unknown" && (
                    cleanVideoTitle.contains(cleanArtist) || videoFileName.contains(cleanArtist)
                    )

            if (titleMatch && (artistMatch || cleanSongTitle.length > 6)) {
                return video
            }
        }
        return null
    }

    private fun cleanName(raw: String): String {
        return raw.lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9]"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
    }

    fun groupIntoAlbums(songs: List<SongItem>): List<AlbumItem> {
        return songs.groupBy { it.album }
            .map { (albumName, albumSongs) ->
                val first = albumSongs.first()
                AlbumItem(
                    id = first.id,
                    name = albumName,
                    artist = first.artist,
                    songCount = albumSongs.size,
                    artworkUri = first.albumArtUri
                )
            }
    }

    fun groupIntoArtists(songs: List<SongItem>): List<ArtistItem> {
        return songs.groupBy { it.artist }
            .map { (artistName, artistSongs) ->
                val albumCount = artistSongs.map { it.album }.distinct().size
                ArtistItem(
                    id = artistSongs.first().id,
                    name = artistName,
                    trackCount = artistSongs.size,
                    albumCount = albumCount
                )
            }
    }

    fun groupIntoFolders(songs: List<SongItem>, videos: List<VideoItem>): List<FolderItem> {
        val folderMap = mutableMapOf<String, Pair<Int, Int>>()

        songs.forEach { song ->
            val dir = File(song.dataPath).parent ?: "Music"
            val current = folderMap.getOrDefault(dir, Pair(0, 0))
            folderMap[dir] = Pair(current.first + 1, current.second)
        }

        videos.forEach { video ->
            val dir = File(video.dataPath).parent ?: "Video"
            val current = folderMap.getOrDefault(dir, Pair(0, 0))
            folderMap[dir] = Pair(current.first, current.second + 1)
        }

        return folderMap.map { (path, counts) ->
            FolderItem(
                name = File(path).name.ifEmpty { "Storage" },
                path = path,
                songCount = counts.first,
                videoCount = counts.second
            )
        }
    }
}
