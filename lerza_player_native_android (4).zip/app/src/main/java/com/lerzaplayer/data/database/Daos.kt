package com.lerzaplayer.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun getAllPlaylists(): Flow<List<PlaylistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("UPDATE playlists SET name = :newName WHERE id = :id")
    suspend fun renamePlaylist(id: Long, newName: String)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun deletePlaylist(id: Long)

    @Query("DELETE FROM playlist_items WHERE playlistId = :playlistId")
    suspend fun deleteItemsForPlaylist(playlistId: Long)

    @Query("SELECT * FROM playlist_items WHERE playlistId = :playlistId ORDER BY orderIndex ASC")
    fun getItemsForPlaylist(playlistId: Long): Flow<List<PlaylistItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistItem(item: PlaylistItemEntity): Long

    @Query("DELETE FROM playlist_items WHERE id = :itemId")
    suspend fun removePlaylistItem(itemId: Long)
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY addedAt DESC")
    fun getAllFavorites(): Flow<List<FavoriteEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE mediaUriString = :uriString)")
    fun isFavorite(uriString: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(fav: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE mediaUriString = :uriString")
    suspend fun removeFavorite(uriString: String)
}

@Dao
interface VaultDao {
    @Query("SELECT * FROM vault_media ORDER BY hiddenAt DESC")
    fun getAllVaultMedia(): Flow<List<VaultMediaEntity>>

    @Query("SELECT mediaUriString FROM vault_media")
    fun getAllHiddenUris(): Flow<List<String>>

    @Query("SELECT EXISTS(SELECT 1 FROM vault_media WHERE mediaUriString = :uriString)")
    suspend fun isHidden(uriString: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun hideMedia(item: VaultMediaEntity)

    @Query("DELETE FROM vault_media WHERE mediaUriString = :uriString")
    suspend fun unhideMedia(uriString: String)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM play_history ORDER BY lastPlayedTimestamp DESC LIMIT 50")
    fun getRecentlyPlayed(): Flow<List<PlayHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun recordPlay(entry: PlayHistoryEntity)

    @Query("UPDATE play_history SET lastPositionMs = :position WHERE mediaUriString = :uriString")
    suspend fun updatePosition(uriString: String, position: Long)

    @Query("SELECT lastPositionMs FROM play_history WHERE mediaUriString = :uriString")
    suspend fun getLastPosition(uriString: String): Long?
}
