package com.lerzaplayer.ui.home

import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.R
import com.lerzaplayer.data.database.PlaylistEntity
import com.lerzaplayer.data.model.*
import com.lerzaplayer.ui.folders.FoldersScreen
import com.lerzaplayer.ui.playlists.PlaylistsScreen
import com.lerzaplayer.ui.songs.SongListScreen
import com.lerzaplayer.ui.videos.VideoListScreen

enum class HomeCategoryTab(val label: String) {
    VIDEOS("Videos"),
    SONGS("Songs"),
    PLAYLISTS("Playlists"),
    FOLDERS("Folders"),
    ALBUMS("Albums"),
    ARTISTS("Artists")
}

@Composable
fun HomeScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    playlists: List<PlaylistEntity>,
    folders: List<FolderItem>,
    albums: List<AlbumItem>,
    artists: List<ArtistItem>,
    selectedTab: HomeCategoryTab,
    onTabSelected: (HomeCategoryTab) -> Unit,
    onSongClick: (SongItem) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onHideSong: (SongItem) -> Unit,
    onHideVideo: (VideoItem) -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Collapsing header state management
    var isHeaderVisible by remember { mutableStateOf(true) }

    val nestedScrollConnection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -12f) {
                    // Scrolling DOWN -> Collapse large header
                    isHeaderVisible = false
                } else if (available.y > 12f) {
                    // Scrolling UP -> Expand header smoothly
                    isHeaderVisible = true
                }
                return Offset.Zero
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .nestedScroll(nestedScrollConnection)
    ) {
        // STATE A & C: Expandable / Collapsible Application Header
        AnimatedVisibility(
            visible = isHeaderVisible,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Surface(
                color = MaterialTheme.colorScheme.background,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Logo & Brand
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                painter = androidx.compose.ui.res.painterResource(id = com.lerzaplayer.R.drawable.ic_logo_transparent),
                                contentDescription = "Lerza Player Logo",
                                tint = androidx.compose.ui.graphics.Color.Unspecified,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "LERZA PLAYER",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    // Action buttons
                    Row {
                        IconButton(onClick = onOpenSearch) {
                            Icon(Icons.Default.Search, contentDescription = "Search")
                        }
                        IconButton(onClick = onOpenSettings) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings")
                        }
                    }
                }
            }
        }

        // STATE B: STICKY MEDIA CATEGORY TABS (Always pinned at the top)
        Surface(
            color = MaterialTheme.colorScheme.background,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab.ordinal,
                edgePadding = 12.dp,
                divider = {},
                indicator = {}
            ) {
                HomeCategoryTab.values().forEach { tab ->
                    val isSelected = tab == selectedTab
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .padding(horizontal = 4.dp, vertical = 8.dp)
                            .clickable { onTabSelected(tab) }
                    ) {
                        Text(
                            text = tab.label,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Content Area according to selected sticky tab
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (selectedTab) {
                HomeCategoryTab.SONGS -> SongListScreen(
                    songs = songs,
                    onSongClick = onSongClick,
                    onHideSong = onHideSong
                )
                HomeCategoryTab.VIDEOS -> VideoListScreen(
                    videos = videos,
                    onVideoClick = onVideoClick,
                    onHideVideo = onHideVideo
                )
                HomeCategoryTab.PLAYLISTS -> PlaylistsScreen(
                    playlists = playlists,
                    onCreatePlaylist = onCreatePlaylist,
                    onPlaylistClick = { /* open playlist */ }
                )
                HomeCategoryTab.FOLDERS -> FoldersScreen(
                    folders = folders,
                    onFolderClick = { /* open folder */ }
                )
                HomeCategoryTab.ALBUMS -> {
                    // Album grid / list
                    SongListScreen(
                        songs = songs,
                        onSongClick = onSongClick,
                        onHideSong = onHideSong
                    )
                }
                HomeCategoryTab.ARTISTS -> {
                    // Artists list
                    SongListScreen(
                        songs = songs,
                        onSongClick = onSongClick,
                        onHideSong = onHideSong
                    )
                }
            }
        }
    }
}
