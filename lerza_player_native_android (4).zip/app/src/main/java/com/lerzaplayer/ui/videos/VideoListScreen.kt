package com.lerzaplayer.ui.videos

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.ui.dialogs.MediaDetailsDialog

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VideoListScreen(
    videos: List<VideoItem>,
    onVideoClick: (VideoItem) -> Unit,
    onHideVideo: (VideoItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var detailsVideo by remember { mutableStateOf<VideoItem?>(null) }
    var menuVideo by remember { mutableStateOf<VideoItem?>(null) }

    if (videos.isEmpty()) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = null,
                    modifier = Modifier.size(64.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No videos found",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    } else {
        LazyColumn(
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(videos, key = { it.id }) { video ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .combinedClickable(
                            onClick = { onVideoClick(video) },
                            onLongClick = { onHideVideo(video) }
                        )
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(80.dp)
                            .height(52.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.BottomEnd
                    ) {
                        AsyncImage(
                            model = video.thumbnailUri,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        val mins = (video.durationMs / 1000) / 60
                        val secs = (video.durationMs / 1000) % 60
                        Surface(
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                            shape = RoundedCornerShape(topStart = 4.dp),
                            modifier = Modifier.padding(2.dp)
                        ) {
                            Text(
                                text = "%02d:%02d".format(mins, secs),
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = video.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = video.folderName,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Box {
                        IconButton(onClick = { menuVideo = video }) {
                            Icon(imageVector = Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(
                            expanded = menuVideo == video,
                            onDismissRequest = { menuVideo = null }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Play") },
                                onClick = {
                                    menuVideo = null
                                    onVideoClick(video)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Hide to Vault") },
                                onClick = {
                                    menuVideo = null
                                    onHideVideo(video)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Details") },
                                onClick = {
                                    menuVideo = null
                                    detailsVideo = video
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    detailsVideo?.let { v ->
        MediaDetailsDialog(
            title = v.title,
            artistOrFolder = v.folderName,
            durationMs = v.durationMs,
            filePath = v.dataPath,
            sizeBytes = v.sizeBytes,
            onDismiss = { detailsVideo = null }
        )
    }
}
