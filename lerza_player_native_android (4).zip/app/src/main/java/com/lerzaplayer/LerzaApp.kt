package com.lerzaplayer

import android.app.Application
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.vault.VaultManager

class LerzaApp : Application() {
    lateinit var database: AppDatabase
        private set
    lateinit var preferenceManager: PreferenceManager
        private set
    lateinit var playerManager: PlayerManager
        private set
    lateinit var vaultManager: VaultManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = AppDatabase.getDatabase(this)
        preferenceManager = PreferenceManager(this)
        playerManager = PlayerManager.getInstance(this)
        vaultManager = VaultManager.getInstance(this)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_UI_HIDDEN) {
            vaultManager.onAppBackgrounded()
        }
    }

    companion object {
        lateinit var instance: LerzaApp
            private set
    }
}
