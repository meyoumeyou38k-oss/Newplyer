package com.lerzaplayer.ui.common

import android.os.Build
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.RingVolume

import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.playback.RingtoneHelper
import com.lerzaplayer.data.repository.CustomTitleManager
import android.media.RingtoneManager
import android.provider.Settings
import android.content.Intent
import android.net.Uri
import android.widget.Toast

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongItemRow(
    song: SongItem,
    isPlaying: Boolean,
    isCurrent: Boolean,
    isMultiSelectActive: Boolean,
    isSelected: Boolean,
    onSongClick: () -> Unit,
    onSongLongClick: () -> Unit,
    onToggleSelect: () -> Unit,
    onToggleFavorite: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onHideInVault: () -> Unit,
    onDelete: () -> Unit,
    densityScale: Float = 1.15f,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    var menuExpanded by remember { mutableStateOf(false) }
    var showDetailsDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showRingtoneDialog by remember { mutableStateOf(false) }
    var newSongTitle by remember(song.title) { mutableStateOf(song.title) }
    var isImageLoadFailed by remember(song.id, song.albumArtUri) { mutableStateOf(false) }

    val thumbSize = (44f * densityScale).coerceIn(40f, 68f).dp
    val verticalPadding = (6f * densityScale).coerceIn(4f, 14f).dp
    val titleSize = (13.5f * densityScale).coerceIn(13f, 18f).sp
    val artistSize = (11f * densityScale).coerceIn(10f, 14f).sp

    val rowBackground = when {
        isSelected -> colors.primary.copy(alpha = 0.15f)
        isCurrent -> colors.primary.copy(alpha = 0.10f)
        else -> Color.Transparent
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(rowBackground)
            .combinedClickable(
                onClick = {
                    if (isMultiSelectActive) onToggleSelect() else onSongClick()
                },
                onLongClick = onSongLongClick
            )
            .padding(horizontal = 14.dp, vertical = verticalPadding),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isMultiSelectActive) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelect() },
                colors = CheckboxDefaults.colors(
                    checkedColor = colors.primary,
                    uncheckedColor = colors.textSecondary
                ),
                modifier = Modifier.padding(end = 6.dp)
            )
        }

        Box(
            modifier = Modifier
                .size(thumbSize)
                .clip(RoundedCornerShape(if (densityScale > 1.2f) 14.dp else 10.dp))
                .background(colors.card),
            contentAlignment = Alignment.Center
        ) {
            if (song.albumArtUri != null && !isImageLoadFailed) {
                AsyncImage(
                    model = song.albumArtUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    onError = { isImageLoadFailed = true }
                )
            } else {
                SongArtPlaceholder(song = song)
            }

            if (isCurrent && isPlaying) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.50f)),
                    contentAlignment = Alignment.Center
                ) {
                    PlayingAudioBars(color = colors.primary)
                }
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = song.title,
                fontSize = titleSize,
                fontWeight = if (densityScale > 1.2f) FontWeight.Bold else FontWeight.SemiBold,
                color = if (isCurrent) colors.primary else colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(if (densityScale > 1.2f) 4.dp else 2.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(colors.card)
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "LYRICS",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textSecondary
                    )
                }

                Text(
                    text = "${song.artist}   ${song.durationFormatted}",
                    fontSize = artistSize,
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(colors.card)
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = song.codecLabel,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textSecondary
                    )
                }
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (song.isFavorite) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (song.isFavorite) Color(0xFFFF334B) else colors.textSecondary.copy(alpha = 0.6f),
                    modifier = Modifier.size(20.dp)
                )
            }

            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.MoreVert,
                        contentDescription = "Options",
                        tint = colors.textSecondary.copy(alpha = 0.7f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }

    if (menuExpanded) {
        ModalBottomSheet(
            onDismissRequest = { menuExpanded = false },
            containerColor = colors.surface,
            dragHandle = {
                Box(
                    Modifier
                        .padding(vertical = 12.dp)
                        .width(38.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(colors.textSecondary.copy(alpha = 0.35f))
                )
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 18.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.padding(bottom = 14.dp)
                ) {
                    Box(
                        Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(colors.card),
                        contentAlignment = Alignment.Center
                    ) {
                        if (song.albumArtUri != null && !isImageLoadFailed) {
                            AsyncImage(
                                model = song.albumArtUri,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            SongArtPlaceholder(song = song)
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(song.title, color = colors.textPrimary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(song.artist, color = colors.textSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { menuExpanded = false }) {
                        Icon(LerzaIcons.Close, contentDescription = "Close", tint = colors.textSecondary)
                    }
                }
                HorizontalDivider(color = colors.card)
                Spacer(modifier = Modifier.height(6.dp))
                SongSheetAction(LerzaIcons.PlayArrow, "Play next", colors.textPrimary, colors.primary) {
                    menuExpanded = false
                    onPlayNext()
                }
                SongSheetAction(LerzaIcons.QueueMusic, "Add to queue", colors.textPrimary, Color(0xFF00B0FF)) {
                    menuExpanded = false
                    onAddToQueue()
                }
                SongSheetAction(LerzaIcons.Add, "Add to playlist", colors.textPrimary, Color(0xFF00E676)) {
                    menuExpanded = false
                    onAddToPlaylist()
                }
                SongSheetAction(Icons.Default.Edit, "Edit Song Title", colors.textPrimary, Color(0xFFFFB300)) {
                    menuExpanded = false
                    showRenameDialog = true
                }
                SongSheetAction(Icons.Default.RingVolume, "Set as Ringtone", colors.textPrimary, Color(0xFFE91E63)) {
                    menuExpanded = false
                    showRingtoneDialog = true
                }
                SongSheetAction(LerzaIcons.VisibilityOff, "Hide in vault", colors.textPrimary, Color(0xFF9C27B0)) {
                    menuExpanded = false
                    onHideInVault()
                }
                SongSheetAction(LerzaIcons.Info, "Track details", colors.textPrimary, Color(0xFF00ACC1)) {
                    menuExpanded = false
                    showDetailsDialog = true
                }
                SongSheetAction(LerzaIcons.CheckCircle, "Select song", colors.textPrimary, Color(0xFF3D5AFE)) {
                    menuExpanded = false
                    onSongLongClick()
                }
                SongSheetAction(LerzaIcons.Delete, "Delete from library", Color(0xFFFF334B), Color(0xFFFF334B)) {
                    menuExpanded = false
                    onDelete()
                }
            }
        }
    }

    
    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename Song Title", fontWeight = FontWeight.Bold, color = colors.textPrimary) },
            text = {
                Column {
                    Text("Enter new name for the track:", fontSize = 13.sp, color = colors.textSecondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newSongTitle,
                        onValueChange = { newSongTitle = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (newSongTitle.isNotBlank()) {
                        CustomTitleManager.setTitle(song.id, newSongTitle)
                        Toast.makeText(context, "Song title updated!", Toast.LENGTH_SHORT).show()
                    }
                    showRenameDialog = false
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("Cancel")
                }
            },
            containerColor = colors.surface
        )
    }

    if (showRingtoneDialog) {
        var ringtoneStartSec by remember { mutableFloatStateOf(0f) }
        val totalSec = (song.duration / 1000).coerceAtLeast(1).toFloat()

        AlertDialog(
            onDismissRequest = { showRingtoneDialog = false },
            title = { Text("Set as Phone Ringtone", fontWeight = FontWeight.Bold, color = colors.textPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Song: ${song.title}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = colors.textPrimary, maxLines = 1)
                    Text("Select start point for ringtone: ${ringtoneStartSec.toInt()}s", fontSize = 12.sp, color = colors.textSecondary)
                    Slider(
                        value = ringtoneStartSec,
                        onValueChange = { ringtoneStartSec = it },
                        valueRange = 0f..totalSec.coerceAtLeast(1f)
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    showRingtoneDialog = false
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (!Settings.System.canWrite(context)) {
                            Toast.makeText(context, "Please allow Write Settings permission", Toast.LENGTH_LONG).show()
                            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                                data = Uri.parse("package:" + context.packageName)
                            }
                            context.startActivity(intent)
                            return@Button
                        }
                    }
                    kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                        RingtoneHelper.setSongAsRingtone(context, song)
                    }
                }) {
                    Text("Set Ringtone")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRingtoneDialog = false }) {
                    Text("Cancel")
                }
            },
            containerColor = colors.surface
        )
    }

    if (showDetailsDialog) {
        AlertDialog(
            onDismissRequest = { showDetailsDialog = false },
            title = {
                Text(
                    text = "Track Information",
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Title: ${song.title}", color = colors.textPrimary, fontSize = 13.sp)
                    Text("Artist: ${song.artist}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Album: ${song.album}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Duration: ${song.durationFormatted}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Format / Quality: ${song.codecLabel}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Storage Path: ${song.path}", color = colors.textSecondary.copy(alpha = 0.7f), fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showDetailsDialog = false }) {
                    Text("Done", color = colors.primary)
                }
            },
            containerColor = colors.surface
        )
    }
}

@Composable
private fun SongArtPlaceholder(song: SongItem) {
    val charCode = song.title.firstOrNull()?.code ?: 0
    val gradientColors = when (charCode % 5) {
        0 -> listOf(Color(0xFF8E24AA), Color(0xFFE91E63))
        1 -> listOf(Color(0xFF1E88E5), Color(0xFF00ACC1))
        2 -> listOf(Color(0xFF43A047), Color(0xFF00B0FF))
        3 -> listOf(Color(0xFFFF6D00), Color(0xFFFFB300))
        else -> listOf(Color(0xFF5E35B1), Color(0xFF3949AB))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(gradientColors)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = song.title.take(1).uppercase(),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
    }
}

@Composable
private fun SongSheetAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    tint: Color,
    accentColor: Color? = null,
    onClick: () -> Unit
) {
    val iconTint = accentColor ?: tint
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(iconTint.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(20.dp)
            )
        }
        Text(
            text = title,
            color = tint,
            fontSize = 14.5.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun PlayingAudioBars(color: Color = Color(0xFF00E5FF)) {
    val infiniteTransition = rememberInfiniteTransition(label = "audioBars")
    val bar1Height by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar1"
    )
    val bar2Height by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(350, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar2"
    )
    val bar3Height by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar3"
    )

    Row(
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.Bottom,
        modifier = Modifier.height(18.dp)
    ) {
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight(bar1Height)
                .clip(RoundedCornerShape(2.dp))
                .background(color)
        )
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight(bar2Height)
                .clip(RoundedCornerShape(2.dp))
                .background(color)
        )
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight(bar3Height)
                .clip(RoundedCornerShape(2.dp))
                .background(color)
        )
    }
}