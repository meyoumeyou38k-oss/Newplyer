package com.lerzaplayer.ui.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun FullPlayerScreen(
    playerManager: PlayerManager,
    onCollapse: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val scope = rememberCoroutineScope()
    val configuration = LocalConfiguration.current

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()
    val currentPosition by playerManager.currentPosition.collectAsState()
    val duration by playerManager.duration.collectAsState()
    val queue by playerManager.queue.collectAsState()
    val currentIndex by playerManager.currentIndex.collectAsState()
    val isShuffle by playerManager.isShuffle.collectAsState()
    val repeatMode by playerManager.repeatMode.collectAsState()
    val playbackSpeed by playerManager.playbackSpeed.collectAsState()
    val volumeBoost by playerManager.volumeBoostPercent.collectAsState()
    val sleepMinutes by playerManager.sleepTimerRemainingMinutes.collectAsState()

    var showOptionsSheet by remember { mutableStateOf(false) }
    var showEqSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showLyricsDialog by remember { mutableStateOf(false) }
    val equalizerLevels = remember { androidx.compose.runtime.mutableStateListOf(0f, 0f, 0f, 0f, 0f) }
    var bassLevel by remember { mutableStateOf(300f) }
    var spatialEnabled by remember { mutableStateOf(false) }
    var selectedEqPreset by remember { mutableStateOf(0) }

    var dragOffsetY by remember { mutableStateOf(0f) }
    val draggableState = rememberDraggableState { delta ->
        if (delta > 0 || dragOffsetY > 0) {
            dragOffsetY = (dragOffsetY + delta).coerceAtLeast(0f)
            if (dragOffsetY > 300f) {
                onCollapse()
            }
        }
    }

    val pagerState = rememberPagerState(
        initialPage = currentIndex.coerceAtLeast(0),
        pageCount = { queue.size.coerceAtLeast(1) }
    )

    LaunchedEffect(currentIndex) {
        if (queue.isNotEmpty() && currentIndex in queue.indices && pagerState.currentPage != currentIndex) {
            pagerState.animateScrollToPage(currentIndex)
        }
    }

    LaunchedEffect(pagerState.currentPage) {
        if (queue.isNotEmpty() && pagerState.currentPage in queue.indices && pagerState.currentPage != currentIndex) {
            playerManager.playSongList(queue, pagerState.currentPage)
        }
    }

    val progressFraction = if (duration > 0) {
        (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Box(
        modifier = modifier
            .fillMaxSize()
            .offset { IntOffset(0, dragOffsetY.roundToInt()) }
            .graphicsLayer {
                alpha = (1f - (dragOffsetY / 600f)).coerceIn(0.2f, 1f)
            }
            .draggable(
                state = draggableState,
                orientation = Orientation.Vertical,
                onDragStopped = {
                    if (dragOffsetY > 200f) {
                        onCollapse()
                    }
                    dragOffsetY = 0f
                }
            )
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0D1B2A),
                        Color(0xFF08121D),
                        Color(0xFF000814)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onCollapse) {
                    Icon(
                        imageVector = LerzaIcons.KeyboardArrowDown,
                        contentDescription = "Collapse",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(alpha = 0.1f))
                        .padding(horizontal = 14.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "LERZA PLAYER",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }

                IconButton(onClick = { showOptionsSheet = true }) {
                    Icon(
                        imageVector = LerzaIcons.MoreVert,
                        contentDescription = "Options",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp),
                pageSpacing = 24.dp
            ) { page ->
                val songForPage = queue.getOrNull(page) ?: currentSong
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(260.dp)
                            .shadow(24.dp, RoundedCornerShape(24.dp), spotColor = Color(0xFF00E5FF))
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(0xFF131A26)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (songForPage?.albumArtUri != null) {
                            AsyncImage(
                                model = songForPage.albumArtUri,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(220.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF16161D)),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.radialGradient(
                                                listOf(Color(0xFF00E5FF), Color(0xFF002244))
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = LerzaIcons.MusicNote,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Song Title & Artist + Favorite button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentSong?.title ?: "No Track Playing",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currentSong?.artist ?: "Unknown Artist",
                        fontSize = 14.sp,
                        color = Color(0xFFB0BEC5),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = { /* Toggle Favorite */ },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = if (currentSong?.isFavorite == true) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (currentSong?.isFavorite == true) Color(0xFFFF334B) else Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Slider & Timing
            Column(modifier = Modifier.fillMaxWidth()) {
                Slider(
                    value = progressFraction,
                    onValueChange = { frac ->
                        val targetMs = (frac * duration).toLong()
                        playerManager.seekTo(targetMs)
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF00E5FF),
                        activeTrackColor = Color(0xFF00E5FF),
                        inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val posSec = currentPosition / 1000
                    val durSec = duration / 1000
                    Text(
                        text = "%d:%02d".format(posSec / 60, posSec % 60),
                        fontSize = 12.sp,
                        color = Color(0xFF90A4AE)
                    )
                    Text(
                        text = "%d:%02d".format(durSec / 60, durSec % 60),
                        fontSize = 12.sp,
                        color = Color(0xFF90A4AE)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Playback Controls - Using LerzaIcons.Pause / PlayArrow
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Shuffle
                IconButton(onClick = { playerManager.toggleShuffle() }) {
                    Icon(
                        imageVector = LerzaIcons.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (isShuffle) Color(0xFF00E5FF) else Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Previous
                IconButton(
                    onClick = { playerManager.playPreviousTrack() },
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SkipPrevious,
                        contentDescription = "Previous",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }

                // Play / Pause (Large Circular Button) - Fixed reference using LerzaIcons.Pause
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF00E5FF), Color(0xFF00B0FF))
                            )
                        )
                        .clickable { playerManager.playPause() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) LerzaIcons.Pause else LerzaIcons.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.Black,
                        modifier = Modifier.size(40.dp)
                    )
                }

                // Next
                IconButton(
                    onClick = { playerManager.playNextTrack() },
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SkipNext,
                        contentDescription = "Next",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }

                // Repeat Mode
                IconButton(onClick = { playerManager.cycleRepeatMode() }) {
                    Icon(
                        imageVector = if (repeatMode == 1) LerzaIcons.RepeatOne else LerzaIcons.Repeat,
                        contentDescription = "Repeat",
                        tint = if (repeatMode != 0) Color(0xFF00E5FF) else Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bottom Auxiliary Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { showEqSheet = true }) {
                    Icon(
                        imageVector = LerzaIcons.Tune,
                        contentDescription = "Equalizer",
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(24.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.12f))
                        .clickable { showLyricsDialog = true }
                        .padding(horizontal = 18.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = LerzaIcons.Lyrics,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Lyrics",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                }

                IconButton(onClick = { showQueueSheet = true }) {
                    Icon(
                        imageVector = LerzaIcons.QueueMusic,
                        contentDescription = "Queue",
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }

    if (showOptionsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showOptionsSheet = false },
            containerColor = Color(0xFFF8F6EE),
            contentColor = Color(0xFF172033),
            dragHandle = {
                BottomSheetDefaults.DragHandle(color = Color(0xFFD0D2D4))
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Speed,
                            contentDescription = null,
                            tint = Color(0xFF2478D4),
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = "Playback Options",
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF172033)
                        )
                    }
                    IconButton(onClick = { showOptionsSheet = false }) {
                        Icon(LerzaIcons.Close, contentDescription = "Close", tint = Color(0xFF172033))
                    }
                }
                HorizontalDivider(color = Color(0xFFE5E1D7))
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Playback Speed", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF172033))
                    Text("${playbackSpeed}x", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2674D8))
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { speed ->
                        val selected = playbackSpeed == speed
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selected) Color(0xFF2168E8) else Color(0xFFEDEBE3))
                                .clickable { playerManager.setPlaybackSpeed(speed) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${speed}x",
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected) Color.White else Color(0xFF303644)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = Color(0xFFE5E1D7))
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Outlined.VolumeUp, contentDescription = null, tint = Color(0xFFF2A000))
                        Text("Super Volume Boost", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF172033))
                    }
                    Text(
                        "$volumeBoost%",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB86B00),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFFFE9C2))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(100, 150, 200, 300).forEach { boost ->
                        val selected = volumeBoost == boost
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) Color(0xFFF5A000) else Color(0xFFEDEBE3))
                                .clickable { playerManager.setVolumeBoostPercent(boost) }
                                .padding(vertical = 11.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "$boost%",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selected) Color.White else Color(0xFF303644)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = Color(0xFFE5E1D7))
                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PlaybackOptionTile(
                        title = "Equalizer & Bass",
                        subtitle = "5-Band Audio DSP",
                        icon = LerzaIcons.Tune,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            showOptionsSheet = false
                            showEqSheet = true
                        }
                    )
                    PlaybackOptionTile(
                        title = "Lyrics",
                        subtitle = "View Song Words",
                        icon = LerzaIcons.Lyrics,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            showOptionsSheet = false
                            showLyricsDialog = true
                        },
                        accent = Color(0xFF1DA878)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PlaybackOptionTile(
                        title = "Add to Queue",
                        subtitle = "Play next",
                        icon = LerzaIcons.QueueMusic,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            currentSong?.let { playerManager.playNext(it) }
                            showOptionsSheet = false
                        },
                        accent = Color(0xFFE49A25)
                    )
                    PlaybackOptionTile(
                        title = "Shuffle Mode",
                        subtitle = if (isShuffle) "On" else "Off",
                        icon = LerzaIcons.Shuffle,
                        modifier = Modifier.weight(1f),
                        onClick = { playerManager.toggleShuffle() },
                        selected = isShuffle,
                        accent = Color(0xFF475569)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                PlaybackOptionTile(
                    title = "Repeat Mode",
                    subtitle = when (repeatMode) {
                        1 -> "One"
                        2 -> "All"
                        else -> "Off"
                    },
                    icon = if (repeatMode == 1) LerzaIcons.RepeatOne else LerzaIcons.Repeat,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { playerManager.cycleRepeatMode() },
                    selected = repeatMode != 0,
                    accent = Color(0xFF2168E8)
                )
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Color(0xFFE5E1D7))
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Outlined.AccessTime, contentDescription = null, tint = Color(0xFF8A43D6))
                        Text("Sleep Timer", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF172033))
                    }
                    Text(
                        if (sleepMinutes > 0) "${sleepMinutes}m" else "Off",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF843ED0),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFF0DFFF))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    listOf(0, 15, 30, 45, 60).forEach { mins ->
                        val selected = sleepMinutes == mins
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selected) Color(0xFF8825D6) else Color(0xFFEDEBE3))
                                .clickable { playerManager.setSleepTimer(mins) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                if (mins == 0) "Off" else "${mins}m",
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected) Color.White else Color(0xFF303644)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                Column(modifier = Modifier.padding(bottom = 22.dp)) {
                    PlayerMetadataRow("Format", currentSong?.codecLabel ?: "—")
                    PlayerMetadataRow("Duration", currentSong?.durationFormatted ?: "—")
                    PlayerMetadataRow("Album", currentSong?.album?.takeIf { it.isNotBlank() } ?: "Unknown")
                }
            }
        }
    }

    if (showEqSheet) {
        ModalBottomSheet(
            onDismissRequest = { showEqSheet = false },
            containerColor = Color(0xFFF8F6EE),
            contentColor = Color(0xFF172033),
            dragHandle = {
                BottomSheetDefaults.DragHandle(color = Color(0xFFD0D2D4))
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            LerzaIcons.Tune,
                            contentDescription = null,
                            tint = Color(0xFF149CC2),
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFE0F7FB))
                                .padding(8.dp)
                        )
                        Column {
                            Text(
                                text = "5-Band Equalizer",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF172033)
                            )
                            Text(
                                text = "Android Audio Hardware Filters",
                                fontSize = 12.sp,
                                color = Color(0xFF6B7280)
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            onClick = {
                                selectedEqPreset = 0
                                equalizerLevels.indices.forEach { equalizerLevels[it] = 0f }
                                playerManager.setEqualizerPreset(0)
                                equalizerLevels.indices.forEach {
                                    playerManager.setEqualizerBandLevel(it.toShort(), 0)
                                }
                                bassLevel = 0f
                                playerManager.setBassBoostStrength(0)
                            }
                        ) {
                            Text("Reset", color = Color(0xFF64748B))
                        }
                        IconButton(onClick = { showEqSheet = false }) {
                            Icon(LerzaIcons.Close, contentDescription = "Close", tint = Color(0xFF172033))
                        }
                    }
                }
                HorizontalDivider(color = Color(0xFFE5E1D7))
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "SOUND PRESETS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.7.sp,
                    color = Color(0xFF64748B)
                )
                Spacer(modifier = Modifier.height(8.dp))
                val presets = listOf("Flat", "Bass Boost", "Pop", "Rock", "Vocal", "Jazz", "Electronic")
                listOf(presets.take(4), presets.drop(4)).forEach { presetRow ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        presetRow.forEach { preset ->
                            val index = presets.indexOf(preset)
                            val selected = selectedEqPreset == index
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(if (selected) Color(0xFF168FBE) else Color(0xFFF1F2F1))
                                    .clickable {
                                        selectedEqPreset = index
                                        playerManager.setEqualizerPreset(index.toShort())
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    preset,
                                    fontSize = 12.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                                    color = if (selected) Color.White else Color(0xFF334155)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(7.dp))
                }
                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val bandNames = listOf("Sub-\nBass", "Bass", "Mid", "Upper-\nMid", "Treble")
                    val frequencies = listOf("60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(198.dp)
                            .padding(horizontal = 8.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        equalizerLevels.forEachIndexed { index, level ->
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "${if (level > 0) "+" else ""}${(level / 100f).toInt()} dB",
                                    fontSize = 10.sp,
                                    color = Color(0xFF168FBE),
                                    maxLines = 1
                                )
                                VerticalEqualizerSlider(
                                    value = level,
                                    onValueChange = { next ->
                                        equalizerLevels[index] = next
                                        playerManager.setEqualizerBandLevel(index.toShort(), next.toInt().toShort())
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                                Text(
                                    text = frequencies[index],
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF1F2937),
                                    maxLines = 1
                                )
                                Text(
                                    text = bandNames[index],
                                    fontSize = 9.sp,
                                    color = Color(0xFF64748B),
                                    textAlign = TextAlign.Center,
                                    lineHeight = 12.sp
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Outlined.VolumeUp, contentDescription = null, tint = Color(0xFF168FBE))
                        Text("Bass Boost", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF172033))
                    }
                    Text(
                        "${(bassLevel / 10).toInt()}%",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF168FBE)
                    )
                }
                Slider(
                    value = bassLevel,
                    onValueChange = {
                        bassLevel = it
                        playerManager.setBassBoostStrength(it.toInt().toShort())
                    },
                    valueRange = 0f..1000f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF168FBE),
                        activeTrackColor = Color(0xFF168FBE),
                        inactiveTrackColor = Color(0xFFE1E5E9)
                    )
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 22.dp, top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Spatial 3D Virtualizer", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF172033))
                        Text("Expands stereo field width", fontSize = 11.sp, color = Color(0xFF64748B))
                    }
                    Switch(
                        checked = spatialEnabled,
                        onCheckedChange = {
                            spatialEnabled = it
                            playerManager.setVirtualizerStrength(if (it) 1000.toShort() else 0.toShort())
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF168FBE)
                        )
                    )
                }
            }
        }
    }

    if (showQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            containerColor = Color(0xFF131A26)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Playing Queue (${queue.size})",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    TextButton(onClick = { playerManager.clearQueue() }) {
                        Text("Clear All", color = Color(0xFFFF334B))
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                queue.forEachIndexed { index, song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { playerManager.playSongList(queue, index) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${index + 1}",
                            fontSize = 13.sp,
                            color = if (index == currentIndex) Color(0xFF00E5FF) else Color.Gray,
                            modifier = Modifier.width(28.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                fontSize = 14.sp,
                                fontWeight = if (index == currentIndex) FontWeight.Bold else FontWeight.Normal,
                                color = if (index == currentIndex) Color(0xFF00E5FF) else Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = song.artist,
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        IconButton(onClick = { playerManager.removeFromQueue(index) }) {
                            Icon(LerzaIcons.Close, contentDescription = "Remove", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }

    if (showLyricsDialog) {
        AlertDialog(
            onDismissRequest = { showLyricsDialog = false },
            title = {
                Text(
                    text = currentSong?.title ?: "Lyrics",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = "${currentSong?.title}\n\n(Synchronized lyrics file .lrc or embedded ID3 lyrics will render here with active scrolling).",
                        color = Color(0xFFECEFF1),
                        fontSize = 15.sp,
                        lineHeight = 24.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showLyricsDialog = false }) {
                    Text("Close", color = Color(0xFF00E5FF))
                }
            },
            containerColor = Color(0xFF131A26)
        )
    }
}

@Composable
private fun PlaybackOptionTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    selected: Boolean = false,
    accent: Color = Color(0xFF2168E8)
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(15.dp))
            .background(if (selected) Color(0xFFDCE7FA) else Color(0xFFEDEBE3))
            .then(
                if (selected) Modifier.border(1.dp, accent.copy(alpha = 0.3f), RoundedCornerShape(15.dp))
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(19.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                title,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF172033),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                subtitle,
                fontSize = 10.sp,
                color = Color(0xFF737B89),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun PlayerMetadataRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = Color(0xFF8A8D92))
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFF3C4149))
    }
}

@Composable
private fun VerticalEqualizerSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val latestValueChange by rememberUpdatedState(onValueChange)
    Canvas(
        modifier = modifier
            .pointerInput(Unit) {
                fun updateValue(y: Float) {
                    if (size.height <= 0) return
                    val fraction = (1f - y / size.height.toFloat()).coerceIn(0f, 1f)
                    latestValueChange(fraction * 3000f - 1500f)
                }
                detectTapGestures { updateValue(it.y) }
            }
            .pointerInput(Unit) {
                fun updateValue(y: Float) {
                    if (size.height <= 0) return
                    val fraction = (1f - y / size.height.toFloat()).coerceIn(0f, 1f)
                    latestValueChange(fraction * 3000f - 1500f)
                }
                detectDragGestures(
                    onDragStart = { updateValue(it.y) },
                    onDrag = { change, _ ->
                        change.consume()
                        updateValue(change.position.y)
                    }
                )
            }
    ) {
        val x = size.width / 2f
        val top = 5.dp.toPx()
        val bottom = (size.height - 5.dp.toPx()).coerceAtLeast(top)
        val center = (top + bottom) / 2f
        val fraction = ((value + 1500f) / 3000f).coerceIn(0f, 1f)
        val thumbY = bottom - (bottom - top) * fraction
        drawLine(
            color = Color(0xFFDCE2E8),
            start = Offset(x, top),
            end = Offset(x, bottom),
            strokeWidth = 4.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFF18A8C4),
            start = Offset(x, center),
            end = Offset(x, thumbY),
            strokeWidth = 4.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawCircle(
            color = Color(0xFF18A8C4),
            radius = 8.dp.toPx(),
            center = Offset(x, thumbY)
        )
        drawCircle(
            color = Color.White,
            radius = 3.dp.toPx(),
            center = Offset(x, thumbY)
        )
    }
}
