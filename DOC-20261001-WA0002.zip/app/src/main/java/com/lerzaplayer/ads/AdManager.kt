package com.lerzaplayer.ads

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import android.widget.Toast
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AdManager {
    private const val TAG = "LerzaAdManager"
    private const val PREFS_NAME = "lerza_ad_prefs"
    private const val REMOTE_CONFIG_URL = "https://lerzaplayer.vercel.app/ads.json"

    // Default IDs provided by the user
    const val DEFAULT_APP_ID = "ca-app-pub-7375534389683057~7020773641"
    var appOpenAdUnitId: String = "ca-app-pub-7375534389683057/3906515984"
    var nativeAdUnitId: String = "ca-app-pub-7375534389683057/8388686475"
    var interstitialAdUnitId: String = "ca-app-pub-7375534389683057/1823278127"
    var rewardedAdUnitId: String = "ca-app-pub-7375534389683057/7678240038"

    var isMasterAdsEnabled: Boolean = true
    var isAppOpenEnabled: Boolean = true
    var isSongsListAdEnabled: Boolean = true
    var isVideosListAdEnabled: Boolean = true
    var isSettingsClickAdEnabled: Boolean = true
    var isVaultRewardAdEnabled: Boolean = true

    private var appOpenAd: AppOpenAd? = null
    private var isAppOpenLoading = false
    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false
    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    fun init(context: Context) {
        loadCachedConfig(context)
        fetchRemoteConfig(context)
        preloadAds(context)
    }

    fun isNetworkAvailable(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val activeNet = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(activeNet) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
               caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    fun fetchRemoteConfig(context: Context) {
        if (!isNetworkAvailable(context)) return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val url = URL(REMOTE_CONFIG_URL)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                conn.requestMethod = "GET"
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(body)
                    isMasterAdsEnabled = json.optBoolean("master_ads_enabled", true)
                    isAppOpenEnabled = json.optBoolean("app_open_ad_enabled", true)
                    isSongsListAdEnabled = json.optBoolean("songs_list_ad_enabled", true)
                    isVideosListAdEnabled = json.optBoolean("videos_list_ad_enabled", true)
                    isSettingsClickAdEnabled = json.optBoolean("settings_click_ad_enabled", true)
                    isVaultRewardAdEnabled = json.optBoolean("vault_reward_ad_enabled", true)

                    appOpenAdUnitId = json.optString("app_open_ad_unit_id", appOpenAdUnitId)
                    nativeAdUnitId = json.optString("songs_list_ad_unit_id", nativeAdUnitId)
                    interstitialAdUnitId = json.optString("settings_click_ad_unit_id", interstitialAdUnitId)
                    rewardedAdUnitId = json.optString("vault_reward_ad_unit_id", rewardedAdUnitId)

                    saveCachedConfig(context, body)
                    Log.d(TAG, "Remote config synced successfully!")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to fetch remote config: ${e.message}")
            }
        }
    }

    private fun saveCachedConfig(context: Context, jsonStr: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("cached_json", jsonStr).apply()
    }

    private fun loadCachedConfig(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val cached = prefs.getString("cached_json", null) ?: return
        try {
            val json = JSONObject(cached)
            isMasterAdsEnabled = json.optBoolean("master_ads_enabled", true)
            isAppOpenEnabled = json.optBoolean("app_open_ad_enabled", true)
            isSongsListAdEnabled = json.optBoolean("songs_list_ad_enabled", true)
            isVideosListAdEnabled = json.optBoolean("videos_list_ad_enabled", true)
            isSettingsClickAdEnabled = json.optBoolean("settings_click_ad_enabled", true)
            isVaultRewardAdEnabled = json.optBoolean("vault_reward_ad_enabled", true)

            appOpenAdUnitId = json.optString("app_open_ad_unit_id", appOpenAdUnitId)
            nativeAdUnitId = json.optString("songs_list_ad_unit_id", nativeAdUnitId)
            interstitialAdUnitId = json.optString("settings_click_ad_unit_id", interstitialAdUnitId)
            rewardedAdUnitId = json.optString("vault_reward_ad_unit_id", rewardedAdUnitId)
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing cached config", e)
        }
    }

    fun preloadAds(context: Context) {
        if (!isNetworkAvailable(context) || !isMasterAdsEnabled) return
        loadAppOpenAd(context)
        loadInterstitial(context)
        loadRewarded(context)
    }

    // --- 1. App Open Ad ---
    private fun loadAppOpenAd(context: Context) {
        if (isAppOpenLoading || appOpenAd != null || !isNetworkAvailable(context) || !isMasterAdsEnabled || !isAppOpenEnabled) return
        isAppOpenLoading = true
        val request = AdRequest.Builder().build()
        AppOpenAd.load(context, appOpenAdUnitId, request, object : AppOpenAd.AppOpenAdLoadCallback() {
            override fun onAdLoaded(ad: AppOpenAd) {
                appOpenAd = ad
                isAppOpenLoading = false
                Log.d(TAG, "AppOpenAd loaded")
            }
            override fun onAdFailedToLoad(error: LoadAdError) {
                appOpenAd = null
                isAppOpenLoading = false
                Log.w(TAG, "AppOpenAd failed: ${error.message}")
            }
        })
    }

    fun checkAndShowAppOpenAd(activity: Activity) {
        val prefs = activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val launchCount = prefs.getInt("launch_count", 0) + 1
        prefs.edit().putInt("launch_count", launchCount).apply()

        // As requested: Skip ad on the very first launch, show on 2nd and subsequent launches if internet is available
        if (launchCount <= 1) {
            Log.d(TAG, "First app launch: skipping AppOpen ad for smooth onboarding.")
            return
        }

        if (!isNetworkAvailable(activity) || !isMasterAdsEnabled || !isAppOpenEnabled) return

        if (appOpenAd != null) {
            appOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    appOpenAd = null
                    loadAppOpenAd(activity)
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    appOpenAd = null
                }
            }
            appOpenAd?.show(activity)
        } else {
            // Load and try once ready
            val request = AdRequest.Builder().build()
            AppOpenAd.load(activity, appOpenAdUnitId, request, object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            appOpenAd = null
                        }
                    }
                    ad.show(activity)
                }
                override fun onAdFailedToLoad(error: LoadAdError) {}
            })
        }
    }

    // --- 2. Interstitial Ad (Settings click) ---
    private fun loadInterstitial(context: Context) {
        if (isInterstitialLoading || interstitialAd != null || !isNetworkAvailable(context) || !isMasterAdsEnabled || !isSettingsClickAdEnabled) return
        isInterstitialLoading = true
        val request = AdRequest.Builder().build()
        InterstitialAd.load(context, interstitialAdUnitId, request, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) {
                interstitialAd = ad
                isInterstitialLoading = false
                Log.d(TAG, "Interstitial loaded")
            }
            override fun onAdFailedToLoad(error: LoadAdError) {
                interstitialAd = null
                isInterstitialLoading = false
                Log.w(TAG, "Interstitial failed: ${error.message}")
            }
        })
    }

    fun showSettingsInterstitial(activity: Activity, onComplete: () -> Unit) {
        if (!isNetworkAvailable(activity) || !isMasterAdsEnabled || !isSettingsClickAdEnabled) {
            onComplete()
            return
        }

        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onComplete()
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onComplete()
                }
            }
            ad.show(activity)
        } else {
            // If ad is not ready, navigate directly without blocking the user
            onComplete()
            loadInterstitial(activity)
        }
    }

    // --- 3. Rewarded Video Ad (Vault Forgot Password) ---
    private fun loadRewarded(context: Context) {
        if (isRewardedLoading || rewardedAd != null || !isNetworkAvailable(context) || !isMasterAdsEnabled || !isVaultRewardAdEnabled) return
        isRewardedLoading = true
        val request = AdRequest.Builder().build()
        RewardedAd.load(context, rewardedAdUnitId, request, object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) {
                rewardedAd = ad
                isRewardedLoading = false
                Log.d(TAG, "Rewarded ad loaded")
            }
            override fun onAdFailedToLoad(error: LoadAdError) {
                rewardedAd = null
                isRewardedLoading = false
                Log.w(TAG, "Rewarded ad failed: ${error.message}")
            }
        })
    }

    fun showVaultRewardAd(
        activity: Activity,
        onRewarded: () -> Unit,
        onFailedOrDismissed: (String) -> Unit
    ) {
        if (!isNetworkAvailable(activity)) {
            onFailedOrDismissed("Cannot connect: No Network Connection. Please turn on Wi-Fi or Mobile Data.")
            return
        }

        if (!isMasterAdsEnabled || !isVaultRewardAdEnabled) {
            // If admin turned off rewarded ads, grant access directly
            onRewarded()
            return
        }

        val ad = rewardedAd
        if (ad != null) {
            var earned = false
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewarded(activity)
                    if (earned) {
                        onRewarded()
                    } else {
                        onFailedOrDismissed("You must watch the full ad to reset password.")
                    }
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    loadRewarded(activity)
                    onFailedOrDismissed("Ad failed to play. Please try again.")
                }
            }
            ad.show(activity) { _ ->
                earned = true
            }
        } else {
            // Load on demand
            Toast.makeText(activity, "Loading Ad, please wait a moment...", Toast.LENGTH_SHORT).show()
            val request = AdRequest.Builder().build()
            RewardedAd.load(activity, rewardedAdUnitId, request, object : RewardedAdLoadCallback() {
                override fun onAdLoaded(newAd: RewardedAd) {
                    rewardedAd = newAd
                    showVaultRewardAd(activity, onRewarded, onFailedOrDismissed)
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    onFailedOrDismissed("Failed to load video ad: ${error.message}")
                }
            })
        }
    }
}
