package com.lerzaplayer.lyrics

import android.content.Context
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.LyricsEntity
import com.lerzaplayer.data.model.LyricLine
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SongLyrics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object LyricsManager {
    suspend fun getLyricsForSong(context: Context, song: SongItem): SongLyrics = withContext(Dispatchers.IO) {
        val db = AppDatabase.getDatabase(context)
        val cached = db.lyricsDao().getLyrics(song.id)
        if (cached != null) {
            val lines = parseJsonToLyrics(cached.lyricsJson)
            if (lines.isNotEmpty()) {
                return@withContext SongLyrics(song.id, lines, isGenerated = false)
            }
        }

        if (song.path.isNotEmpty()) {
            try {
                val lrcPath = song.path.substringBeforeLast(".") + ".lrc"
                val lrcFile = File(lrcPath)
                if (lrcFile.exists() && lrcFile.canRead()) {
                    val lrcLines = parseLrcContent(lrcFile.readText())
                    if (lrcLines.isNotEmpty()) {
                        saveLyrics(context, song.id, lrcLines)
                        return@withContext SongLyrics(song.id, lrcLines, isGenerated = false)
                    }
                }
            } catch (_: Exception) {}
        }

        val generatedLines = generateOfflineLyrics(song)
        saveLyrics(context, song.id, generatedLines)
        SongLyrics(song.id, generatedLines, isGenerated = true)
    }

    suspend fun saveLyrics(context: Context, songId: Long, lines: List<LyricLine>) = withContext(Dispatchers.IO) {
        val array = JSONArray()
        lines.forEach { line ->
            val obj = JSONObject()
            obj.put("timestampMs", line.timestampMs)
            obj.put("text", line.text)
            obj.put("timeFormatted", line.timeFormatted)
            array.put(obj)
        }
        val entity = LyricsEntity(
            songId = songId,
            lyricsJson = array.toString()
        )
        AppDatabase.getDatabase(context).lyricsDao().insertLyrics(entity)
    }

    private fun parseJsonToLyrics(json: String): List<LyricLine> {
        val list = mutableListOf<LyricLine>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    LyricLine(
                        timestampMs = obj.getLong("timestampMs"),
                        text = obj.getString("text"),
                        timeFormatted = obj.getString("timeFormatted")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun parseLrcContent(content: String): List<LyricLine> {
        val result = mutableListOf<LyricLine>()
        content.lines().forEach { rawLine ->
            val line = rawLine.trim()
            val open = line.indexOf('[')
            val close = line.indexOf(']')
            if (open >= 0 && close > open) {
                val timeStr = line.substring(open + 1, close)
                val text = line.substring(close + 1).trim()
                val colonIdx = timeStr.indexOf(':')
                if (colonIdx > 0) {
                    val min = timeStr.substring(0, colonIdx).toLongOrNull() ?: 0L
                    val rest = timeStr.substring(colonIdx + 1)
                    val dotIdx = rest.indexOf('.')
                    val sec = if (dotIdx > 0) rest.substring(0, dotIdx).toLongOrNull() ?: 0L else rest.toLongOrNull() ?: 0L
                    val ms = if (dotIdx > 0 && dotIdx < rest.length - 1) {
                        val msPart = rest.substring(dotIdx + 1)
                        if (msPart.length == 2) (msPart.toLongOrNull() ?: 0L) * 10 else (msPart.toLongOrNull() ?: 0L)
                    } else 0L
                    val totalMs = (min * 60 + sec) * 1000 + ms
                    if (text.isNotEmpty()) {
                        result.add(LyricLine(totalMs, text, "%02d:%02d".format(min, sec)))
                    }
                }
            }
        }
        return result.sortedBy { it.timestampMs }
    }

    private fun generateOfflineLyrics(song: SongItem): List<LyricLine> {
        val dur = if (song.duration > 15000L) song.duration else 180000L
        val cleanTitle = song.title.filter { it.isLetterOrDigit() || it.isWhitespace() }.trim()
        val artist = if (song.artist.contains("unknown", ignoreCase = true)) "Lerza Audio" else song.artist

        val templates = listOf(
            "♪ [Intro - Acoustic Melody] ♪",
            "Feel the rhythm, feeling so alive tonight",
            "Lost in the music of $cleanTitle",
            "Every heartbeat syncs with the bassline",
            "Hear the sound by $artist taking over",
            "♪ [Beat Drop & Harmonic Rhythm] ♪",
            "We are drifting through the melodic wave",
            "This moment never has to fade away",
            "Raise the sound higher, feel the vibe inside",
            "♪ [Chorus - $cleanTitle] ♪",
            "Sing along to the melody and let it ride",
            "Every second echoing everywhere",
            "♪ [Outro - Fading Soft Rhythm] ♪"
        )

        val stepMs = (dur - 4000L) / templates.size.coerceAtLeast(1)
        val list = mutableListOf<LyricLine>()
        templates.forEachIndexed { index, text ->
            val timeMs = (index * stepMs).coerceAtMost(dur - 1000L)
            val sec = timeMs / 1000
            val min = sec / 60
            val s = sec % 60
            list.add(LyricLine(timeMs, text, "%02d:%02d".format(min, s)))
        }
        return list
    }
}
