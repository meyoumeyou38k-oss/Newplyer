package com.lerzaplayer.ui.folders

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors

data class FolderGroup(
    val folderName: String,
    val songs: List<SongItem>
)

@Composable
fun FoldersScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem, List<SongItem>, Int) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val folderGroups = remember(songs) {
        songs.groupBy { song ->
            val dir = if (song.path.contains('/')) {
                song.path.substringBeforeLast('/').substringAfterLast('/')
            } else ""
            if (dir.isBlank()) "Internal storage" else dir
        }.map { (name, list) -> FolderGroup(name, list) }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(folderGroups, key = { it.folderName }) { group ->
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.card),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(LerzaIcons.Folder, contentDescription = null, tint = Color(0xFF29B6F6))
                    Spacer(modifier = Modifier.width(14.dp))
                    Text(text = "${group.folderName} (${group.songs.size})", fontWeight = FontWeight.Bold, color = colors.textPrimary)
                }
            }
        }
    }
}
