package com.lerzaplayer.ui.search

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow

@Composable
fun SearchScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onBack: () -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onAddToQueue: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var query by remember { mutableStateOf("") }

    BackHandler {
        onBack()
    }

    val filteredSongs = remember(query, songs) {
        if (query.isBlank()) emptyList()
        else {
            val q = query.trim().lowercase()
            songs.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
        }
    }

    Column(modifier = modifier.fillMaxSize().background(colors.background)) {
        Surface(color = colors.surface, tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                }
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search songs and videos...") },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filteredSongs, key = { it.id }) { song ->
                SongItemRow(
                    song = song,
                    isPlaying = isPlaying,
                    isCurrent = currentSong?.id == song.id,
                    isMultiSelectActive = false,
                    isSelected = false,
                    onSongClick = { onSongClick(song) },
                    onSongLongClick = {},
                    onToggleSelect = {},
                    onToggleFavorite = { onToggleFavoriteSong(song) },
                    onPlayNext = { onSongClick(song) },
                    onAddToQueue = { onAddToQueue(song) },
                    onAddToPlaylist = {},
                    onHideInVault = {},
                    onDelete = {}
                )
            }
        }
    }
}
