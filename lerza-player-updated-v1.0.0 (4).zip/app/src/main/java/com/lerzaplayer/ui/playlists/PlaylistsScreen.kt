package com.lerzaplayer.ui.playlists

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow

@Composable
fun PlaylistsScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem, List<SongItem>, Int) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var selectedPlaylistTitle by remember { mutableStateOf<String?>(null) }
    var selectedPlaylistSongs by remember { mutableStateOf<List<SongItem>>(emptyList()) }

    BackHandler(enabled = selectedPlaylistTitle != null) {
        selectedPlaylistTitle = null
        selectedPlaylistSongs = emptyList()
    }

    if (selectedPlaylistTitle != null) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(colors.background)
        ) {
            Surface(
                color = colors.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = { selectedPlaylistTitle = null }) {
                        Icon(
                            imageVector = LerzaIcons.ArrowBack,
                            contentDescription = "Back",
                            tint = colors.textPrimary
                        )
                    }
                    Text(
                        text = selectedPlaylistTitle ?: "Playlist",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Spacer(modifier = Modifier.width(48.dp))
                }
            }

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(selectedPlaylistSongs, key = { it.id }) { song ->
                    val idx = selectedPlaylistSongs.indexOf(song)
                    SongItemRow(
                        song = song,
                        isPlaying = isPlaying,
                        isCurrent = currentSong?.id == song.id,
                        isMultiSelectActive = false,
                        isSelected = false,
                        onSongClick = { onSongClick(song, selectedPlaylistSongs, idx) },
                        onSongLongClick = {},
                        onToggleSelect = {},
                        onToggleFavorite = { onToggleFavorite(song) },
                        onPlayNext = { onSongClick(song, selectedPlaylistSongs, idx) },
                        onAddToQueue = {},
                        onAddToPlaylist = {},
                        onHideInVault = { onHideInVault(song) },
                        onDelete = { onDelete(song) }
                    )
                }
            }
        }
        return
    }

    val likedSongs = remember(songs) { songs.filter { it.isFavorite } }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.card),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        selectedPlaylistTitle = "Liked songs"
                        selectedPlaylistSongs = likedSongs
                    }
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(LerzaIcons.Favorite, contentDescription = null, tint = Color(0xFFFF334B))
                    Spacer(modifier = Modifier.width(14.dp))
                    Text(text = "Liked songs (${likedSongs.size})", fontWeight = FontWeight.Bold, color = colors.textPrimary)
                }
            }
        }
    }
}
