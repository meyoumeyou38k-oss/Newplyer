package com.lerzaplayer.ui.vault

import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.vault.VaultManager
import kotlinx.coroutines.launch

@Composable
fun VaultScreen(
    vaultManager: VaultManager,
    onBack: () -> Unit,
    onPlayMedia: (VaultMediaEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val scope = rememberCoroutineScope()
    val isUnlocked by vaultManager.isUnlocked.collectAsState()
    val vaultMedia by vaultManager.vaultMediaFlow.collectAsState(initial = emptyList())
    val savedLockType by vaultManager.lockTypeFlow.collectAsState(initial = VaultLockType.PIN)
    val savedPinHash by vaultManager.pinFlow.collectAsState(initial = null)
    val savedPatternHash by vaultManager.patternFlow.collectAsState(initial = null)

    var lockType by remember { mutableStateOf(VaultLockType.PIN) }
    var enteredPin by remember { mutableStateOf("") }
    var patternNodes by remember { mutableStateOf<List<Int>>(emptyList()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(savedLockType) {
        lockType = savedLockType
    }

    Scaffold(
        topBar = {
            Surface(
                color = colors.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Text(
                            text = "Private Vault",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }

                    if (isUnlocked) {
                        IconButton(onClick = { vaultManager.lockVault() }) {
                            Icon(LerzaIcons.Lock, contentDescription = "Lock", tint = Color(0xFFFF334B))
                        }
                    }
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (!isUnlocked) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E60F2).copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = LerzaIcons.Lock,
                            contentDescription = null,
                            tint = Color(0xFF1E60F2),
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = if (lockType == VaultLockType.PIN) "Enter Vault PIN" else "Draw Pattern Lock",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    if (lockType == VaultLockType.PIN) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(bottom = 28.dp)
                        ) {
                            repeat(4) { idx ->
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (idx < enteredPin.length) Color(0xFF1E60F2) else colors.card
                                        )
                                        .border(1.dp, Color(0xFF1E60F2), CircleShape)
                                )
                            }
                        }

                        val rows = listOf(
                            listOf("1", "2", "3"),
                            listOf("4", "5", "6"),
                            listOf("7", "8", "9"),
                            listOf("PAT", "0", "DEL")
                        )
                        rows.forEach { row ->
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(24.dp),
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                row.forEach { key ->
                                    Box(
                                        modifier = Modifier
                                            .size(64.dp)
                                            .clip(CircleShape)
                                            .background(colors.card)
                                            .clickable {
                                                when (key) {
                                                    "DEL" -> if (enteredPin.isNotEmpty()) enteredPin = enteredPin.dropLast(1)
                                                    "PAT" -> {
                                                        lockType = VaultLockType.PATTERN
                                                        enteredPin = ""
                                                    }
                                                    else -> {
                                                        if (enteredPin.length < 4) {
                                                            enteredPin += key
                                                            if (enteredPin.length == 4) {
                                                                scope.launch {
                                                                    val ok = vaultManager.verifyPin(enteredPin)
                                                                    if (!ok) {
                                                                        errorMessage = "Incorrect PIN"
                                                                        enteredPin = ""
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = key, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                                    }
                                }
                            }
                        }
                    } else {
                        Button(onClick = { lockType = VaultLockType.PIN }) {
                            Text("Switch to PIN")
                        }
                    }

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage ?: "",
                            color = Color(0xFFFF334B),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 14.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(vaultMedia) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(colors.card)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = item.originalName, color = colors.textPrimary, modifier = Modifier.weight(1f))
                            Row {
                                IconButton(onClick = { onPlayMedia(item) }) {
                                    Icon(LerzaIcons.PlayArrow, contentDescription = "Play", tint = Color(0xFF1E60F2))
                                }
                                IconButton(onClick = { scope.launch { vaultManager.restoreMedia(item) } }) {
                                    Icon(LerzaIcons.Restore, contentDescription = "Restore", tint = Color(0xFF00C853))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
