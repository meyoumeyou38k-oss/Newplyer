package com.lerzaplayer.ui.settings

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onScanMedia: () -> Unit,
    onOpenVault: () -> Unit = {},
    recentlyDeleted: List<RecentlyDeletedEntity> = emptyList(),
    onRestoreRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onPermanentlyDeleteRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentTheme by prefManager.themeFlow.collectAsState(initial = "Pure White")

    Scaffold(
        topBar = {
            Surface(
                color = colors.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(
                                imageVector = LerzaIcons.ArrowBack,
                                contentDescription = "Back",
                                tint = colors.textPrimary
                            )
                        }
                        Column {
                            Text(
                                text = "Lerza Player Settings",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "Media, Vault, Trash & Equalizer",
                                fontSize = 11.sp,
                                color = colors.textSecondary
                            )
                        }
                    }
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = LerzaIcons.Close,
                            contentDescription = "Close",
                            tint = colors.textSecondary
                        )
                    }
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item {
                SettingsCard(
                    title = "SCAN & IMPORT MEDIA",
                    icon = LerzaIcons.Folder
                ) {
                    Text(
                        text = "Scan storage to index newly downloaded songs, albums, and video files.",
                        fontSize = 13.sp,
                        color = colors.textSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onScanMedia,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60F2)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(LerzaIcons.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Import & Rescan Media")
                    }
                }
            }

            item {
                SettingsCard(
                    title = "PRIVATE MEDIA VAULT",
                    icon = LerzaIcons.Lock
                ) {
                    Text(
                        text = "Protected by AES-256 GCM Android Keystore with PIN and Pattern auto-lock.",
                        fontSize = 13.sp,
                        color = colors.textSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onOpenVault,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60F2)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(LerzaIcons.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Open Private Vault")
                    }
                }
            }

            item {
                SettingsCard(
                    title = "RECENTLY DELETED (30-DAY TRASH)",
                    icon = LerzaIcons.Delete
                ) {
                    Text(
                        text = if (recentlyDeleted.isEmpty()) {
                            "Deleted media stays here for 30 days before it is removed forever."
                        } else {
                            "${recentlyDeleted.size} item(s) are recoverable for 30 days."
                        },
                        fontSize = 13.sp,
                        color = colors.textSecondary
                    )
                    if (recentlyDeleted.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        recentlyDeleted.take(8).forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (item.mediaType == "AUDIO") LerzaIcons.Audiotrack else LerzaIcons.Videocam,
                                    contentDescription = null,
                                    tint = Color(0xFF1E60F2),
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    item.originalName,
                                    color = colors.textPrimary,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(horizontal = 8.dp)
                                )
                                TextButton(onClick = { onRestoreRecentlyDeleted(item) }) {
                                    Text("Restore", color = Color(0xFF00C853), fontSize = 11.sp)
                                }
                                IconButton(
                                    onClick = { onPermanentlyDeleteRecentlyDeleted(item) },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(
                                        LerzaIcons.Delete,
                                        contentDescription = "Delete forever",
                                        tint = Color(0xFFFF334B),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = LocalLerzaColors.current
    Surface(
        color = colors.surface,
        shape = RoundedCornerShape(22.dp),
        shadowElevation = if (colors.isDark) 0.dp else 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(19.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFF1E60F2),
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E60F2)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}
