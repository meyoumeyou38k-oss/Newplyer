package com.lerzaplayer

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.MediaDownloadMonitor
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.vault.VaultManager

/**
 * Main Application class for Lerza Player Pro.
 * Provides singleton dependencies, 120 FPS Coil image loading caching,
 * and background media download monitoring.
 */
class LerzaApp : Application(), ImageLoaderFactory {

    lateinit var database: AppDatabase
        private set

    lateinit var preferenceManager: PreferenceManager
        private set

    lateinit var playerManager: PlayerManager
        private set

    lateinit var vaultManager: VaultManager
        private set

    private lateinit var mediaDownloadMonitor: MediaDownloadMonitor

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .components {
                add(VideoFrameDecoder.Factory())
            }
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizeBytes(100L * 1024 * 1024)
                    .build()
            }
            .crossfade(false) // Disabled crossfade for maximum 120 FPS scrolling smoothness
            .respectCacheHeaders(false)
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getDatabase(this)
        preferenceManager = PreferenceManager(this)
        playerManager = PlayerManager.getInstance(this)
        vaultManager = VaultManager.getInstance(this)

        // Initialize smart new media detector
        mediaDownloadMonitor = MediaDownloadMonitor(this)
        mediaDownloadMonitor.start()
    }

    fun startMediaDownloadMonitoring() {
        if (::mediaDownloadMonitor.isInitialized) {
            mediaDownloadMonitor.start()
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_UI_HIDDEN) {
            // Requirement 8: Auto lock vault immediately when app goes to background
            vaultManager.onAppBackgrounded()
        }
    }

    companion object {
        lateinit var instance: LerzaApp
            private set
    }
}
