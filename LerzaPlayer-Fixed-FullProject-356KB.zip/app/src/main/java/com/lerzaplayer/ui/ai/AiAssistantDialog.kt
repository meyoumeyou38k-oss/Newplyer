package com.lerzaplayer.ui.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.lerzaplayer.ai.AiMasteringConfig
import com.lerzaplayer.ai.AiPlaylistRecommendation
import com.lerzaplayer.ai.GeminiAiService
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LocalLerzaColors
import kotlinx.coroutines.launch

@Composable
fun AiAssistantDialog(
    songs: List<SongItem>,
    currentSong: SongItem?,
    playerManager: PlayerManager,
    onDismiss: () -> Unit
) {
    val colors = LocalLerzaColors.current
    val scope = rememberCoroutineScope()
    val aiService = remember { GeminiAiService() }

    var selectedTab by remember { mutableStateOf(0) }
    var selectedMood by remember { mutableStateOf("Gym Hype") }
    var generatedPlaylist by remember { mutableStateOf<AiPlaylistRecommendation?>(null) }
    var masteringConfig by remember { mutableStateOf<AiMasteringConfig?>(null) }
    var isGenerating by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
                .clip(RoundedCornerShape(24.dp)),
            color = colors.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "✨", fontSize = 20.sp)
                        Text(
                            text = "AI Studio Intelligence",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }

                    TextButton(onClick = onDismiss) {
                        Text("Done", color = Color(0xFF00B0FF), fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(colors.card)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val tabNames = listOf("AI DJ Mix", "AI Mastering", "Song Insights")
                    tabNames.forEachIndexed { idx, name ->
                        val active = selectedTab == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) Color(0xFF1E60F2) else Color.Transparent)
                                .clickable { selectedTab = idx }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = name,
                                fontSize = 12.sp,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                color = if (active) Color.White else colors.textSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tab Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    when (selectedTab) {
                        0 -> {
                            // AI DJ Playlist Generator
                            Text(
                                text = "Select Playlist Energy & Mood",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            val moods = listOf("Gym Hype", "Late Night Chill", "Deep Focus", "Party Bass", "Road Trip")
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                moods.take(3).forEach { mood ->
                                    val isCur = selectedMood == mood
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isCur) Color(0xFF00B0FF) else colors.card)
                                            .clickable { selectedMood = mood }
                                            .padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = mood,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isCur) Color.White else colors.textSecondary
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    scope.launch {
                                        isGenerating = true
                                        generatedPlaylist = aiService.generateSmartPlaylist(selectedMood, songs)
                                        isGenerating = false
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60F2))
                            ) {
                                Text(if (isGenerating) "AI Curating..." else "✨ Generate AI Mix")
                            }

                            generatedPlaylist?.let { pl ->
                                Spacer(modifier = Modifier.height(14.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = colors.card),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(
                                            text = pl.title,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF00E5FF)
                                        )
                                        Text(
                                            text = pl.reasoning,
                                            fontSize = 12.sp,
                                            color = colors.textSecondary,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        pl.transitionTips.forEach { tip ->
                                            Text(
                                                text = "• $tip",
                                                fontSize = 11.sp,
                                                color = colors.textPrimary
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))
                                        Button(
                                            onClick = {
                                                val queued = songs.filter { pl.recommendedSongIds.contains(it.id) }
                                                if (queued.isNotEmpty()) {
                                                    playerManager.playSongList(queued, 0)
                                                    onDismiss()
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))
                                        ) {
                                            Text("Play AI Smart Mix Now", color = Color.Black, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        1 -> {
                            // AI Audio Mastering
                            Text(
                                text = "Instant AI Audio Mastering & EQ",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "AI automatically optimizes 5-Band EQ, Low-End Bass Boost, and Spatial Virtualizer for your music.",
                                fontSize = 12.sp,
                                color = colors.textSecondary
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    scope.launch {
                                        val conf = aiService.recommendMastering("Electronic", 8)
                                        masteringConfig = conf
                                        playerManager.applyAiMastering(
                                            conf.bands,
                                            conf.bassBoostStrength,
                                            conf.virtualizerStrength
                                        )
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8A2BE2))
                            ) {
                                Text("✨ Auto-Master & Apply EQ")
                            }

                            masteringConfig?.let { conf ->
                                Spacer(modifier = Modifier.height(12.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = colors.card),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(
                                            text = "Mastering Active: ${conf.presetName}",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF00E5FF)
                                        )
                                        Text(
                                            text = conf.acousticComment,
                                            fontSize = 12.sp,
                                            color = colors.textSecondary,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                        Text(
                                            text = "Status: Applied directly to Android DSP Audio Session.",
                                            fontSize = 11.sp,
                                            color = Color(0xFF00E676),
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(top = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        else -> {
                            // Song Insights
                            if (currentSong == null) {
                                Box(
                                    modifier = Modifier.fillMaxWidth().height(150.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("Play a track to view AI musical insights.", color = colors.textSecondary)
                                }
                            } else {
                                var insight by remember { mutableStateOf<com.lerzaplayer.ai.AiSongInsight?>(null) }
                                LaunchedEffect(currentSong.id) {
                                    insight = aiService.analyzeSongInsights(currentSong)
                                }

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = colors.card),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(
                                            text = currentSong.title,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = colors.textPrimary
                                        )
                                        Text(
                                            text = currentSong.artist,
                                            fontSize = 13.sp,
                                            color = colors.textSecondary
                                        )

                                        insight?.let { ins ->
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text(
                                                text = "Estimated Tempo: ${ins.bpmEstimate} BPM  •  Key: ${ins.musicalKey}",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color(0xFF00E5FF)
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = ins.lyricalTheme,
                                                fontSize = 12.sp,
                                                color = colors.textPrimary
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = "💡 ${ins.listeningTips}",
                                                fontSize = 11.sp,
                                                color = colors.textSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
