package com.lerzaplayer.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.lerzaplayer.data.database.FavoriteEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.data.preferences.ViewMode
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.ai.AiAssistantDialog
import com.lerzaplayer.ui.common.AutoHidingHeader
import com.lerzaplayer.ui.common.MultiSelectActionBar
import com.lerzaplayer.ui.common.TabsRow
import com.lerzaplayer.ui.common.WallpaperBackground
import com.lerzaplayer.ui.player.MiniPlayer
import com.lerzaplayer.ui.songs.SongListScreen
import com.lerzaplayer.ui.videos.VideoListScreen
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    playerManager: PlayerManager,
    prefManager: PreferenceManager,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onOpenVault: () -> Unit,
    onExpandFullPlayer: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onToggleFavoriteVideo: (VideoItem) -> Unit,
    onHideSongInVault: (SongItem) -> Unit,
    onHideVideoInVault: (VideoItem) -> Unit,
    onDeleteSong: (SongItem) -> Unit,
    onDeleteVideo: (VideoItem) -> Unit,
    onScanDevice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()

    val wallpaperUri by prefManager.wallpaperUriFlow.collectAsState(initial = null)
    val wallpaperOpacity by prefManager.wallpaperOpacityFlow.collectAsState(initial = 0.75f)
    val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
    val videoViewMode by prefManager.videoViewModeFlow.collectAsState(initial = ViewMode.GRID)

    val pagerState = rememberPagerState(initialPage = 1, pageCount = { 6 })

    // Continuous 1:1 finger tracking collapsing header
    val headerHeightDp = 56.dp
    val headerHeightPx = with(density) { headerHeightDp.toPx() }
    var headerOffsetPx by remember { mutableFloatStateOf(0f) }

    val nestedScrollConnection = remember(headerHeightPx) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val delta = available.y
                val newOffset = (headerOffsetPx + delta).coerceIn(-headerHeightPx, 0f)
                val consumed = newOffset - headerOffsetPx
                headerOffsetPx = newOffset
                // Return consumed delta so finger movement and header collapse are 100% synchronized
                return Offset(0f, consumed)
            }
        }
    }

    var isAiDialogVisible by remember { mutableStateOf(false) }
    var isMultiSelectMode by remember { mutableStateOf(false) }
    val selectedSongIds = remember { mutableStateListOf<Long>() }

    BackHandler(enabled = isMultiSelectMode) {
        isMultiSelectMode = false
        selectedSongIds.clear()
    }

    BackHandler(enabled = !isMultiSelectMode && pagerState.currentPage != 1) {
        scope.launch { pagerState.animateScrollToPage(1) }
    }

    fun toggleSongSelection(id: Long) {
        if (selectedSongIds.contains(id)) {
            selectedSongIds.remove(id)
            if (selectedSongIds.isEmpty()) isMultiSelectMode = false
        } else {
            selectedSongIds.add(id)
        }
    }

    WallpaperBackground(
        wallpaperUri = wallpaperUri,
        opacity = wallpaperOpacity
    ) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .nestedScroll(nestedScrollConnection)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Header pinned flush to top with synchronous finger translation
                AutoHidingHeader(
                    offsetY = headerOffsetPx,
                    onSearchClick = onSearchClick,
                    onSettingsClick = onSettingsClick,
                    onAiClick = { isAiDialogVisible = true }
                )

                // Toolbar follows immediately with GPU acceleration
                TabsRow(
                    selectedTab = pagerState.currentPage,
                    onTabSelected = { index ->
                        scope.launch { pagerState.animateScrollToPage(index) }
                    },
                    modifier = Modifier.graphicsLayer {
                        translationY = headerOffsetPx
                    }
                )

                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier
                        .weight(1f)
                        .graphicsLayer {
                            translationY = headerOffsetPx
                        }
                ) { page ->
                    when (page) {
                        0 -> {
                            VideoListScreen(
                                videos = videos,
                                viewMode = videoViewMode,
                                onVideoClick = onPlayVideo,
                                onViewModeToggle = {
                                    scope.launch {
                                        val nextMode = if (videoViewMode == ViewMode.GRID) ViewMode.LIST else ViewMode.GRID
                                        prefManager.setVideoViewMode(nextMode)
                                    }
                                },
                                onScanDevice = onScanDevice,
                                onToggleFavorite = onToggleFavoriteVideo,
                                onHideInVault = onHideVideoInVault,
                                onDelete = onDeleteVideo
                            )
                        }
                        1 -> {
                            SongListScreen(
                                songs = songs,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                currentSort = songSort,
                                selectedSongIds = selectedSongIds.toSet(),
                                isMultiSelectMode = isMultiSelectMode,
                                onSongClick = { song, index ->
                                    playerManager.playSongList(songs, index)
                                },
                                onToggleSelect = { id ->
                                    toggleSongSelection(id)
                                },
                                onStartMultiSelect = { id ->
                                    isMultiSelectMode = true
                                    selectedSongIds.add(id)
                                },
                                onSortChanged = { option ->
                                    scope.launch { prefManager.setSongSort(option) }
                                },
                                onToggleFavorite = onToggleFavoriteSong,
                                onPlayNext = { playerManager.playNext(it) },
                                onAddToQueue = { playerManager.addToQueue(it) },
                                onAddToPlaylist = { },
                                onHideInVault = onHideSongInVault,
                                onDelete = onDeleteSong
                            )
                        }
                        2 -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Playlists feature", color = colors.textSecondary)
                            }
                        }
                        3 -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Folders view", color = colors.textSecondary)
                            }
                        }
                        4 -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Albums view", color = colors.textSecondary)
                            }
                        }
                        else -> {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Artists view", color = colors.textSecondary)
                            }
                        }
                    }
                }
            }

            // MiniPlayer
            if (currentSong != null) {
                MiniPlayer(
                    currentSong = currentSong,
                    isPlaying = isPlaying,
                    onExpand = onExpandFullPlayer,
                    onPlayPause = { playerManager.playPause() },
                    onNext = { playerManager.playNextTrack() },
                    onOpenQueue = onExpandFullPlayer,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }

            // MultiSelect
            MultiSelectActionBar(
                visible = isMultiSelectMode,
                selectedCount = selectedSongIds.size,
                onClearSelection = {
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onSelectAll = {
                    selectedSongIds.clear()
                    selectedSongIds.addAll(songs.map { it.id })
                },
                onHideSelected = {
                    val toHide = songs.filter { selectedSongIds.contains(it.id) }
                    toHide.forEach { onHideSongInVault(it) }
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                onDeleteSelected = {
                    val toDelete = songs.filter { selectedSongIds.contains(it.id) }
                    toDelete.forEach { onDeleteSong(it) }
                    selectedSongIds.clear()
                    isMultiSelectMode = false
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )

            // AI Dialog
            if (isAiDialogVisible) {
                AiAssistantDialog(
                    songs = songs,
                    currentSong = currentSong,
                    playerManager = playerManager,
                    onDismiss = { isAiDialogVisible = false }
                )
            }
        }
    }
}
