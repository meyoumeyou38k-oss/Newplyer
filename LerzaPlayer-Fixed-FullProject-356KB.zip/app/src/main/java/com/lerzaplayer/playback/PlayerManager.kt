package com.lerzaplayer.playback

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PlayerManager private constructor(private val context: Context) {

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context).build()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val _currentSong = MutableStateFlow<SongItem?>(null)
    val currentSong: StateFlow<SongItem?> = _currentSong.asStateFlow()

    private val _currentVideo = MutableStateFlow<VideoItem?>(null)
    val currentVideo: StateFlow<VideoItem?> = _currentVideo.asStateFlow()

    private val _queue = MutableStateFlow<List<SongItem>>(emptyList())
    val queue: StateFlow<List<SongItem>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _repeatMode = MutableStateFlow(Player.REPEAT_MODE_ALL)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _volumeBoostPercent = MutableStateFlow(100)
    val volumeBoostPercent: StateFlow<Int> = _volumeBoostPercent.asStateFlow()

    private val _sleepTimerRemainingMinutes = MutableStateFlow(0)
    val sleepTimerRemainingMinutes: StateFlow<Int> = _sleepTimerRemainingMinutes.asStateFlow()

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var sleepTimerJob: Job? = null

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                _isPlaying.value = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)
                    initializeAudioEffects()
                } else if (playbackState == Player.STATE_ENDED) {
                    playNextTrack()
                }
            }
        })

        scope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _currentPosition.value = exoPlayer.currentPosition.coerceAtLeast(0L)
                }
                delay(500)
            }
        }
    }

    private fun initializeAudioEffects() {
        try {
            val audioSessionId = exoPlayer.audioSessionId
            if (audioSessionId != 0) {
                if (equalizer == null) {
                    equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
                }
                if (bassBoost == null) {
                    bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
                }
                if (virtualizer == null) {
                    virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun playSong(song: SongItem) {
        _currentSong.value = song
        _queue.value = listOf(song)
        _currentIndex.value = 0
        exoPlayer.setMediaItem(MediaItem.fromUri(song.contentUri))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun playSongList(songs: List<SongItem>, startIndex: Int = 0) {
        if (songs.isEmpty()) return
        val validIndex = startIndex.coerceIn(0, songs.size - 1)
        _queue.value = songs
        _currentIndex.value = validIndex
        _currentSong.value = songs[validIndex]

        val mediaItems = songs.map { MediaItem.fromUri(it.contentUri) }
        exoPlayer.setMediaItems(mediaItems, validIndex, 0L)
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun playPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            exoPlayer.play()
        }
    }

    fun pause() {
        exoPlayer.pause()
    }

    fun resume() {
        exoPlayer.play()
    }

    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs)
        _currentPosition.value = positionMs
    }

    fun playNextTrack() {
        val q = _queue.value
        if (q.isEmpty()) return
        val nextIdx = if (_isShuffle.value) {
            (0 until q.size).random()
        } else {
            (_currentIndex.value + 1) % q.size
        }
        _currentIndex.value = nextIdx
        val nextSong = q[nextIdx]
        _currentSong.value = nextSong
        exoPlayer.setMediaItem(MediaItem.fromUri(nextSong.contentUri))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun playPreviousTrack() {
        val q = _queue.value
        if (q.isEmpty()) return
        if (exoPlayer.currentPosition > 3000) {
            exoPlayer.seekTo(0)
            return
        }
        val prevIdx = if (_currentIndex.value > 0) _currentIndex.value - 1 else q.size - 1
        _currentIndex.value = prevIdx
        val prevSong = q[prevIdx]
        _currentSong.value = prevSong
        exoPlayer.setMediaItem(MediaItem.fromUri(prevSong.contentUri))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun addToQueue(song: SongItem) {
        _queue.value = _queue.value + song
        exoPlayer.addMediaItem(MediaItem.fromUri(song.contentUri))
    }

    fun playNext(song: SongItem) {
        val currentIdx = _currentIndex.value
        val list = _queue.value.toMutableList()
        val insertIndex = (currentIdx + 1).coerceAtMost(list.size)
        list.add(insertIndex, song)
        _queue.value = list
        exoPlayer.addMediaItem(insertIndex, MediaItem.fromUri(song.contentUri))
    }

    fun toggleShuffle() {
        _isShuffle.value = !_isShuffle.value
    }

    fun cycleRepeatMode() {
        _repeatMode.value = when (_repeatMode.value) {
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
            else -> Player.REPEAT_MODE_ALL
        }
        exoPlayer.repeatMode = _repeatMode.value
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        exoPlayer.playbackParameters = PlaybackParameters(speed)
    }

    fun setVolumeBoostPercent(percent: Int) {
        _volumeBoostPercent.value = percent
        val volumeMultiplier = (percent.toFloat() / 100f).coerceIn(0.1f, 3.0f)
        exoPlayer.volume = volumeMultiplier
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        _sleepTimerRemainingMinutes.value = minutes
        if (minutes <= 0) return
        sleepTimerJob = scope.launch {
            var left = minutes
            while (left > 0) {
                delay(60000)
                left--
                _sleepTimerRemainingMinutes.value = left
            }
            pause()
        }
    }

    fun setEqualizerPreset(presetIndex: Short) {
        try {
            equalizer?.usePreset(presetIndex)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setEqualizerBandLevel(band: Short, level: Short) {
        try {
            equalizer?.setBandLevel(band, level)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun applyAiMastering(bands: ShortArray, bassBoostStrength: Short, virtualizerStrength: Short) {
        try {
            initializeAudioEffects()
            equalizer?.let { eq ->
                val numBands = eq.numberOfBands.toInt()
                for (i in 0 until minOf(numBands, bands.size)) {
                    eq.setBandLevel(i.toShort(), bands[i])
                }
            }
            bassBoost?.setStrength(bassBoostStrength)
            virtualizer?.setStrength(virtualizerStrength)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setBassBoostStrength(strength: Short) {
        try {
            bassBoost?.setStrength(strength)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setVirtualizerStrength(strength: Short) {
        try {
            virtualizer?.setStrength(strength)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: PlayerManager? = null

        fun getInstance(context: Context): PlayerManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PlayerManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
