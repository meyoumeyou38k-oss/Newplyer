package com.lerzaplayer.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.*
import kotlinx.coroutines.launch

data class LarkColorCircle(
    val id: String,
    val title: String,
    val circleColor: Color,
    val isNone: Boolean = false
)

val THEME_CIRCLES = listOf(
    LarkColorCircle("None", "Pure White", Color(0xFFFFFFFF), isNone = true),
    LarkColorCircle("WhiteSilver", "Silver Frost", Color(0xFFECEFF1), isNone = false),
    LarkColorCircle("Green", "Mint Green", LarkGreen),
    LarkColorCircle("Blue", "Lerza Blue", LerzaBlue),
    LarkColorCircle("Purple", "Royal Purple", LarkPurple),
    LarkColorCircle("Orange", "Sunset Orange", LarkOrange),
    LarkColorCircle("Red", "Crimson Red", LarkRed),
    LarkColorCircle("Pink", "Rose Pink", LarkPink),
    LarkColorCircle("Cyan", "Ocean Cyan", LarkCyan),
    LarkColorCircle("Amber", "Golden Amber", LarkAmber),
    LarkColorCircle("Lavender", "Soft Lavender", Color(0xFF9C27B0))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current
    val currentThemeColor = ThemeManager.currentThemeColor
    val currentThemeName = ThemeManager.currentThemeName
    val currentMode = ThemeManager.currentThemeMode
    val wallpaperUri by prefManager.wallpaperUriFlow.collectAsState(initial = null)
    val wallpaperOpacity by prefManager.wallpaperOpacityFlow.collectAsState(initial = 0.75f)
    val songDensity by prefManager.songItemDensityFlow.collectAsState(initial = 1.15f)

    var liveDensity by remember { mutableFloatStateOf(1.15f) }
    LaunchedEffect(songDensity) { liveDensity = songDensity }

    var liveOpacity by remember { mutableFloatStateOf(0.75f) }
    LaunchedEffect(wallpaperOpacity) { liveOpacity = wallpaperOpacity }

    val animatedColor by animateColorAsState(
        targetValue = currentThemeColor,
        animationSpec = tween(350),
        label = "ThemePreviewColor"
    )
    val onTextColor = getContrastTextColor(animatedColor)

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            scope.launch { prefManager.setWallpaperUri(uri.toString()) }
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = colors.textPrimary
                        )
                    }
                    Text(
                        text = "Theme & Customization",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = animatedColor,
                    contentColor = onTextColor
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = onTextColor
                        )
                        Text(
                            text = currentThemeName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = onTextColor
                        )
                    }
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Phone Mockup with Live Density & Wallpaper Opacity Preview
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.94f)
                    .height(245.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .border(2.dp, animatedColor.copy(alpha = 0.45f), RoundedCornerShape(26.dp))
                    .background(colors.background)
            ) {
                if (!wallpaperUri.isNullOrBlank()) {
                    AsyncImage(
                        model = wallpaperUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(colors.background.copy(alpha = liveOpacity.coerceIn(0.15f, 0.95f)))
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                ) {
                    // Mockup Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LERZA PLAYER",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp,
                            color = colors.textPrimary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = colors.textSecondary,
                                modifier = Modifier.size(15.dp)
                            )
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = colors.textSecondary,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Mockup Tab Row
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = animatedColor,
                            contentColor = onTextColor
                        ) {
                            Text(
                                text = "Songs",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = onTextColor,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = colors.card.copy(alpha = 0.85f),
                            contentColor = colors.textSecondary
                        ) {
                            Text(
                                text = "Videos",
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = colors.card.copy(alpha = 0.85f),
                            contentColor = colors.textSecondary
                        ) {
                            Text(
                                text = "Playlists",
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Scaled Song Items based on liveDensity
                    val mockThumb = (32f * liveDensity).coerceIn(28f, 48f).dp
                    val mockPad = (3.5f * liveDensity).coerceIn(2f, 8f).dp
                    val mockText = (10.5f * liveDensity).coerceIn(10f, 15f).sp

                    listOf(
                        "Dil Laga Liya Maine" to "Alka Yagnik",
                        "Yeh Raaten Yeh Mausam" to "Sanam ft. Simran",
                        "Unko Bhi Humse Mohabbat" to "ReGa Music",
                        "White Brown Black" to "Karan Aujla"
                    ).forEach { (title, artist) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = mockPad),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(mockThumb)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(animatedColor.copy(alpha = 0.28f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = animatedColor,
                                    modifier = Modifier.size((16f * liveDensity).coerceIn(14f, 24f).dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = title,
                                    fontSize = mockText,
                                    fontWeight = if (liveDensity > 1.2f) FontWeight.Bold else FontWeight.SemiBold,
                                    color = colors.textPrimary,
                                    maxLines = 1
                                )
                                Text(
                                    text = artist,
                                    fontSize = 9.sp,
                                    color = colors.textSecondary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // 2. WALLPAPER PHOTO & OPACITY SLIDER CARD
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = colors.card,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                tint = animatedColor,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Background Wallpaper & Opacity",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                        }

                        if (!wallpaperUri.isNullOrBlank()) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = animatedColor.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "${(liveOpacity * 100).toInt()}% Opacity",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = animatedColor,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }

                    Text(
                        text = if (!wallpaperUri.isNullOrBlank())
                            "Adjust photo overlay opacity / dimming for maximum text clarity"
                        else
                            "Select any photo from your gallery to set as player background",
                        fontSize = 11.5.sp,
                        color = colors.textSecondary
                    )

                    // Photo Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { photoPickerLauncher.launch(arrayOf("image/*")) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = animatedColor,
                                contentColor = onTextColor
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (wallpaperUri.isNullOrBlank()) "Choose Photo" else "Change Photo",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (!wallpaperUri.isNullOrBlank()) {
                            OutlinedButton(
                                onClick = {
                                    scope.launch { prefManager.setWallpaperUri(null) }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = colors.textSecondary
                                ),
                                modifier = Modifier.wrapContentWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "Remove", fontSize = 12.sp)
                            }
                        }
                    }

                    // Opacity Slider (Interactive when photo is set)
                    if (!wallpaperUri.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Overlay Opacity (Dimming)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = colors.textPrimary
                            )
                            Text(
                                text = "${(liveOpacity * 100).toInt()}%",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = animatedColor
                            )
                        }

                        Slider(
                            value = liveOpacity,
                            onValueChange = { newValue ->
                                liveOpacity = newValue
                                scope.launch { prefManager.setWallpaperOpacity(newValue) }
                            },
                            valueRange = 0.15f..0.95f,
                            colors = SliderDefaults.colors(
                                thumbColor = animatedColor,
                                activeTrackColor = animatedColor,
                                inactiveTrackColor = colors.divider
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Quick Opacity Presets
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            listOf(
                                "30% (Light)" to 0.30f,
                                "50% (Medium)" to 0.50f,
                                "75% (Standard)" to 0.75f,
                                "90% (Dark)" to 0.90f
                            ).forEach { (presetName, presetVal) ->
                                val isChosen = kotlin.math.abs(liveOpacity - presetVal) < 0.08f
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isChosen) animatedColor else colors.surface)
                                        .clickable {
                                            liveOpacity = presetVal
                                            scope.launch { prefManager.setWallpaperOpacity(presetVal) }
                                        }
                                        .padding(horizontal = 8.dp, vertical = 5.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = presetName,
                                        fontSize = 10.5.sp,
                                        fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isChosen) onTextColor else colors.textPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. SONG LIST SIZE & THICKNESS ADJUSTER CARD
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = colors.card,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ViewStream,
                                contentDescription = null,
                                tint = animatedColor,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Song Item Size & Thickness",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                        }

                        val densityLabel = when {
                            liveDensity < 0.95f -> "Compact (85%)"
                            liveDensity < 1.10f -> "Normal (100%)"
                            liveDensity < 1.25f -> "Large (120%)"
                            else -> "Extra Bold (140%)"
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = animatedColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = densityLabel,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = animatedColor,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Text(
                        text = "Slide to adjust song row height, font size, thumbnail, and list density",
                        fontSize = 11.5.sp,
                        color = colors.textSecondary
                    )

                    Slider(
                        value = liveDensity,
                        onValueChange = { newValue ->
                            liveDensity = newValue
                            scope.launch { prefManager.setSongItemDensity(newValue) }
                        },
                        valueRange = 0.85f..1.40f,
                        colors = SliderDefaults.colors(
                            thumbColor = animatedColor,
                            activeTrackColor = animatedColor,
                            inactiveTrackColor = colors.divider
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf(
                            "Compact" to 0.85f,
                            "Normal" to 1.0f,
                            "Thick" to 1.20f,
                            "Extra Bold" to 1.38f
                        ).forEach { (presetName, presetVal) ->
                            val isChosen = kotlin.math.abs(liveDensity - presetVal) < 0.08f
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isChosen) animatedColor else colors.surface)
                                    .clickable {
                                        liveDensity = presetVal
                                        scope.launch { prefManager.setSongItemDensity(presetVal) }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = presetName,
                                    fontSize = 11.sp,
                                    fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isChosen) onTextColor else colors.textPrimary
                                )
                            }
                        }
                    }
                }
            }

            // 4. Dark / Light / System Mode
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = colors.card,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(
                        "Dark" to Icons.Default.DarkMode,
                        "Light" to Icons.Default.LightMode,
                        "System" to Icons.Default.SettingsBrightness
                    ).forEach { (mode, icon) ->
                        val isSelected = currentMode == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(24.dp))
                                .background(if (isSelected) animatedColor else Color.Transparent)
                                .clickable { ThemeManager.setMode(context, mode) },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isSelected) onTextColor else colors.textSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = mode,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) onTextColor else colors.textSecondary
                                )
                            }
                        }
                    }
                }
            }

            // 5. Accent Color Circles & Themes
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Accent Colors & Themes",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textSecondary,
                    modifier = Modifier.align(Alignment.Start)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp)
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(colors.card)
                            .border(1.5.dp, animatedColor.copy(alpha = 0.5f), CircleShape)
                            .clickable { photoPickerLauncher.launch(arrayOf("image/*")) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Pick Wallpaper",
                            tint = animatedColor,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    THEME_CIRCLES.forEach { circleItem ->
                        val isSel = if (circleItem.isNone) {
                            currentThemeName.equals("None", ignoreCase = true)
                        } else {
                            !currentThemeName.equals("None", ignoreCase = true) &&
                                    currentThemeColor.value == circleItem.circleColor.value
                        }
                        val checkColor = if (circleItem.isNone) Color(0xFF101418) else getContrastTextColor(circleItem.circleColor)

                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(circleItem.circleColor)
                                .border(
                                    width = if (isSel) 3.dp else 1.dp,
                                    color = if (isSel) (if (circleItem.isNone) Color(0xFF101418) else Color.White) else Color.White.copy(alpha = 0.25f),
                                    shape = CircleShape
                                )
                                .clickable {
                                    if (circleItem.isNone) {
                                        ThemeManager.setTheme(context, Color.Transparent, "None")
                                        ThemeManager.setMode(context, "Light")
                                    } else {
                                        ThemeManager.setTheme(context, circleItem.circleColor, circleItem.id)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (circleItem.isNone && !isSel) {
                                Text("None", fontSize = 10.sp, color = Color(0xFF101418), fontWeight = FontWeight.Bold)
                            } else if (isSel) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = checkColor,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}