package com.lerzaplayer.ui.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SongLyrics
import com.lerzaplayer.lyrics.LyricsManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.PaletteExtractor
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun FullPlayerScreen(
    playerManager: PlayerManager,
    onCollapse: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val configuration = LocalConfiguration.current

    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()
    val currentPosition by playerManager.currentPosition.collectAsState()
    val duration by playerManager.duration.collectAsState()
    val queue by playerManager.queue.collectAsState()
    val currentIndex by playerManager.currentIndex.collectAsState()
    val isShuffle by playerManager.isShuffle.collectAsState()
    val repeatMode by playerManager.repeatMode.collectAsState()
    val playbackSpeed by playerManager.playbackSpeed.collectAsState()
    val volumeBoost by playerManager.volumeBoostPercent.collectAsState()
    val sleepMinutes by playerManager.sleepTimerRemainingMinutes.collectAsState()

    var showOptionsSheet by remember { mutableStateOf(false) }
    var showEqSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showLyricsDialog by remember { mutableStateOf(false) }

    var lyricsState by remember { mutableStateOf<SongLyrics?>(null) }
    var isLoadingLyrics by remember { mutableStateOf(false) }
    var lyricsLanguage by remember { mutableStateOf("Original") }

    LaunchedEffect(currentSong?.id) {
        val song = currentSong
        if (song != null) {
            isLoadingLyrics = true
            lyricsState = LyricsManager.getLyricsForSong(context, song)
            isLoadingLyrics = false
        } else {
            lyricsState = null
        }
        lyricsLanguage = "Original"
    }

    val dynamicPalette = remember(currentSong?.id) {
        PaletteExtractor.extractPalette(null, currentSong?.id ?: 0L)
    }

    var dragOffsetY by remember { mutableStateOf(0f) }
    val draggableState = rememberDraggableState { delta ->
        if (delta > 0 || dragOffsetY > 0) {
            dragOffsetY = (dragOffsetY + delta).coerceAtLeast(0f)
            if (dragOffsetY > 300f) {
                onCollapse()
            }
        }
    }

    val pagerState = rememberPagerState(
        initialPage = currentIndex.coerceAtLeast(0),
        pageCount = { queue.size.coerceAtLeast(1) }
    )

    LaunchedEffect(currentIndex) {
        if (queue.isNotEmpty() && currentIndex in queue.indices && pagerState.currentPage != currentIndex) {
            pagerState.animateScrollToPage(currentIndex)
        }
    }

    LaunchedEffect(pagerState.currentPage) {
        if (queue.isNotEmpty() && pagerState.currentPage in queue.indices && pagerState.currentPage != currentIndex) {
            playerManager.playSongList(queue, pagerState.currentPage)
        }
    }

    val progressFraction = if (duration > 0) {
        (currentPosition.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Box(
        modifier = modifier
            .fillMaxSize()
            .offset { IntOffset(0, dragOffsetY.roundToInt()) }
            .graphicsLayer {
                alpha = (1f - (dragOffsetY / 600f)).coerceIn(0.2f, 1f)
            }
            .draggable(
                state = draggableState,
                orientation = Orientation.Vertical,
                onDragStopped = {
                    if (dragOffsetY > 200f) {
                        onCollapse()
                    }
                    dragOffsetY = 0f
                }
            )
            .background(
                Brush.verticalGradient(
                    listOf(
                        dynamicPalette.dominantColor.copy(alpha = 0.88f),
                        dynamicPalette.deepDarkColor,
                        Color(0xFF04060A)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onCollapse) {
                    Icon(
                        imageVector = LerzaIcons.KeyboardArrowDown,
                        contentDescription = "Collapse",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.1f))
                            .padding(horizontal = 14.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "LERZA PLAYER",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                    if (volumeBoost > 100) {
                        Text(
                            text = "🔊 ${volumeBoost}%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E5FF)
                        )
                    }
                }

                IconButton(onClick = { showOptionsSheet = true }) {
                    Icon(
                        imageVector = LerzaIcons.MoreVert,
                        contentDescription = "Options",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(290.dp),
                pageSpacing = 24.dp
            ) { page ->
                val songForPage = queue.getOrNull(page) ?: currentSong
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Dynamic Backlight Ambient Halo Glow adapting to thumbnail colors
                    Box(
                        modifier = Modifier
                            .size(290.dp)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        dynamicPalette.dominantColor.copy(alpha = 0.65f),
                                        dynamicPalette.accentColor.copy(alpha = 0.30f),
                                        Color.Transparent
                                    )
                                ),
                                CircleShape
                            )
                    )

                    Box(
                        modifier = Modifier
                            .size(260.dp)
                            .shadow(
                                elevation = 28.dp,
                                shape = RoundedCornerShape(24.dp),
                                spotColor = dynamicPalette.accentColor,
                                ambientColor = dynamicPalette.dominantColor
                            )
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(0xFF131A26)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (songForPage?.albumArtUri != null) {
                            AsyncImage(
                                model = songForPage.albumArtUri,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(220.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF16161D)),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.radialGradient(
                                                listOf(dynamicPalette.accentColor, dynamicPalette.dominantColor.copy(alpha = 0.6f))
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = LerzaIcons.MusicNote,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Song Title & Artist + Favorite button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentSong?.title ?: "No Track Playing",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currentSong?.artist ?: "Unknown Artist",
                        fontSize = 14.sp,
                        color = Color(0xFFB0BEC5),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = { /* Toggle Favorite */ },
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = if (currentSong?.isFavorite == true) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (currentSong?.isFavorite == true) Color(0xFFFF334B) else Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Slider & Timing with dynamic palette tint
            Column(modifier = Modifier.fillMaxWidth()) {
                Slider(
                    value = progressFraction,
                    onValueChange = { frac ->
                        val targetMs = (frac * duration).toLong()
                        playerManager.seekTo(targetMs)
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = dynamicPalette.accentColor,
                        activeTrackColor = dynamicPalette.accentColor,
                        inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val posSec = currentPosition / 1000
                    val durSec = duration / 1000
                    Text(
                        text = "%d:%02d".format(posSec / 60, posSec % 60),
                        fontSize = 12.sp,
                        color = Color(0xFF90A4AE)
                    )
                    Text(
                        text = "%d:%02d".format(durSec / 60, durSec % 60),
                        fontSize = 12.sp,
                        color = Color(0xFF90A4AE)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Playback Controls - Using LerzaIcons.Pause / PlayArrow
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Shuffle
                IconButton(onClick = { playerManager.toggleShuffle() }) {
                    Icon(
                        imageVector = LerzaIcons.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (isShuffle) Color(0xFF00E5FF) else Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Previous
                IconButton(
                    onClick = { playerManager.playPreviousTrack() },
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SkipPrevious,
                        contentDescription = "Previous",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }

                // Play / Pause (Large Circular Button) - Fixed reference using LerzaIcons.Pause
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF00E5FF), Color(0xFF00B0FF))
                            )
                        )
                        .clickable { playerManager.playPause() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) LerzaIcons.Pause else LerzaIcons.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.Black,
                        modifier = Modifier.size(40.dp)
                    )
                }

                // Next
                IconButton(
                    onClick = { playerManager.playNextTrack() },
                    modifier = Modifier.size(54.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.SkipNext,
                        contentDescription = "Next",
                        tint = Color.White,
                        modifier = Modifier.size(38.dp)
                    )
                }

                // Repeat Mode
                IconButton(onClick = { playerManager.cycleRepeatMode() }) {
                    Icon(
                        imageVector = if (repeatMode == 1) LerzaIcons.RepeatOne else LerzaIcons.Repeat,
                        contentDescription = "Repeat",
                        tint = if (repeatMode != 0) Color(0xFF00E5FF) else Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bottom Auxiliary Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { showEqSheet = true }) {
                    Icon(
                        imageVector = LerzaIcons.Tune,
                        contentDescription = "Equalizer",
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(24.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.12f))
                        .clickable { showLyricsDialog = true }
                        .padding(horizontal = 18.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = LerzaIcons.Lyrics,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Lyrics",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                }

                IconButton(onClick = { showQueueSheet = true }) {
                    Icon(
                        imageVector = LerzaIcons.QueueMusic,
                        contentDescription = "Queue",
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }

    if (showOptionsSheet) {
        val speedSteps = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val selectedSpeedIndex = speedSteps.indices.minByOrNull { index ->
            kotlin.math.abs(speedSteps[index] - playbackSpeed)
        } ?: 2

        ModalBottomSheet(
            onDismissRequest = { showOptionsSheet = false },
            containerColor = Color(0xFF111820),
            contentColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(start = 24.dp, end = 24.dp, top = 4.dp, bottom = 24.dp)
            ) {
                Text(
                    text = "Playback",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(22.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Playback speed",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                        Text(
                            text = "Slow down or speed up",
                            fontSize = 12.sp,
                            color = Color(0xFF9AA8B5)
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        FilledTonalIconButton(
                            onClick = {
                                playerManager.setPlaybackSpeed(speedSteps[(selectedSpeedIndex - 1).coerceAtLeast(0)])
                            },
                            enabled = selectedSpeedIndex > 0,
                            modifier = Modifier.size(40.dp),
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = Color.White.copy(alpha = 0.09f),
                                contentColor = Color.White,
                                disabledContainerColor = Color.White.copy(alpha = 0.04f),
                                disabledContentColor = Color.White.copy(alpha = 0.3f)
                            )
                        ) {
                            Icon(Icons.Outlined.Remove, contentDescription = "Decrease speed")
                        }
                        Text(
                            text = "${"%.2f".format(playbackSpeed).trimEnd('0').trimEnd('.')}x",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            modifier = Modifier.widthIn(min = 48.dp),
                            textAlign = TextAlign.Center
                        )
                        FilledTonalIconButton(
                            onClick = {
                                playerManager.setPlaybackSpeed(speedSteps[(selectedSpeedIndex + 1).coerceAtMost(speedSteps.lastIndex)])
                            },
                            enabled = selectedSpeedIndex < speedSteps.lastIndex,
                            modifier = Modifier.size(40.dp),
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = Color.White.copy(alpha = 0.09f),
                                contentColor = Color.White,
                                disabledContainerColor = Color.White.copy(alpha = 0.04f),
                                disabledContentColor = Color.White.copy(alpha = 0.3f)
                            )
                        ) {
                            Icon(Icons.Outlined.Add, contentDescription = "Increase speed")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color.White.copy(alpha = 0.08f))
                )
                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Sleep timer",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                        Text(
                            text = if (sleepMinutes > 0) "$sleepMinutes min remaining" else "Stop playback after",
                            fontSize = 12.sp,
                            color = if (sleepMinutes > 0) Color(0xFF80CBC4) else Color(0xFF9AA8B5)
                        )
                    }
                    if (sleepMinutes > 0) {
                        TextButton(
                            onClick = { playerManager.setSleepTimer(0) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Cancel", color = Color(0xFF80CBC4), fontSize = 13.sp)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(15, 30, 45, 60, 90, 120).forEach { minutes ->
                        val isSelected = sleepMinutes == minutes
                        Surface(
                            onClick = { playerManager.setSleepTimer(minutes) },
                            shape = RoundedCornerShape(18.dp),
                            color = if (isSelected) Color(0xFF80CBC4) else Color.White.copy(alpha = 0.07f)
                        ) {
                            Text(
                                text = "${minutes}m",
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                                color = if (isSelected) Color(0xFF10201F) else Color.White.copy(alpha = 0.86f)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Playback will pause automatically when the timer ends.",
                    fontSize = 11.sp,
                    color = Color(0xFF7F8C98)
                )
            }
        }
    }

    if (showEqSheet) {
        ModalBottomSheet(
            onDismissRequest = { showEqSheet = false },
            containerColor = Color(0xFF131A26)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "5-Band Equalizer",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Pro Audio Engine",
                        fontSize = 12.sp,
                        color = Color(0xFF00E5FF)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Flat", "Bass Boost", "Pop", "Rock", "Vocal").forEachIndexed { idx, name ->
                        FilterChip(
                            selected = idx == 0,
                            onClick = { playerManager.setEqualizerPreset(idx.toShort()) },
                            label = { Text(name) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))

                var bandLevels by remember { mutableStateOf(List(5) { 0f }) }
                val bandLabels = listOf("60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz")
                bandLabels.forEachIndexed { index, label ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = label,
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 11.sp,
                            modifier = Modifier.width(52.dp)
                        )
                        Slider(
                            value = bandLevels[index],
                            onValueChange = { value ->
                                bandLevels = bandLevels.toMutableList().also { it[index] = value }
                                playerManager.setEqualizerBand(index.toShort(), value.toInt().toShort())
                            },
                            valueRange = -1500f..1500f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00E5FF),
                                activeTrackColor = Color(0xFF00E5FF)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                TextButton(
                    onClick = {
                        bandLevels = List(5) { 0f }
                        playerManager.setEqualizerPreset(0)
                        playerManager.setBassBoostStrength(0)
                    }
                ) {
                    Text("Reset bands", color = Color(0xFF00E5FF))
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    if (showQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            containerColor = Color(0xFF131A26)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Playing Queue (${queue.size})",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    TextButton(onClick = { playerManager.clearQueue() }) {
                        Text("Clear All", color = Color(0xFFFF334B))
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                queue.forEachIndexed { index, song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { playerManager.playSongList(queue, index) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${index + 1}",
                            fontSize = 13.sp,
                            color = if (index == currentIndex) Color(0xFF00E5FF) else Color.Gray,
                            modifier = Modifier.width(28.dp)
                        )
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.08f)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (song.albumArtUri != null) {
                                AsyncImage(
                                    model = song.albumArtUri,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Icon(
                                    LerzaIcons.MusicNote,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.65f),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                fontSize = 14.sp,
                                fontWeight = if (index == currentIndex) FontWeight.Bold else FontWeight.Normal,
                                color = if (index == currentIndex) Color(0xFF00E5FF) else Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = song.artist,
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        IconButton(onClick = { playerManager.removeFromQueue(index) }) {
                            Icon(LerzaIcons.Close, contentDescription = "Remove", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }

    if (showLyricsDialog) {
        AlertDialog(
            onDismissRequest = { showLyricsDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = currentSong?.title ?: "Lyrics",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Tap any line to seek • Offline Sync",
                            color = dynamicPalette.accentColor,
                            fontSize = 11.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(dynamicPalette.accentColor.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (lyricsState?.isGenerated == true) "AI SYNC" else "LRC SYNC",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = dynamicPalette.accentColor
                        )
                    }
                }
            },
            text = {
                val lyricsListState = androidx.compose.foundation.lazy.rememberLazyListState()
                val currentLines = lyricsState?.lines ?: emptyList()
                val activeLyricIndex = remember(currentPosition, currentLines) {
                    currentLines.indexOfLast { currentPosition >= it.timestampMs }
                }

                LaunchedEffect(activeLyricIndex) {
                    if (activeLyricIndex >= 0) {
                        try {
                            lyricsListState.animateScrollToItem(maxOf(0, activeLyricIndex - 1))
                        } catch (_: Exception) {}
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                ) {
                    if (isLoadingLyrics) {
                        CircularProgressIndicator(
                            color = dynamicPalette.accentColor,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    } else if (currentLines.isNotEmpty()) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("Original", "اردو", "हिंदी", "English").forEach { language ->
                                    FilterChip(
                                        selected = lyricsLanguage == language,
                                        onClick = { lyricsLanguage = language },
                                        label = { Text(language, fontSize = 10.sp) }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            androidx.compose.foundation.lazy.LazyColumn(
                                state = lyricsListState,
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(currentLines.size) { idx ->
                                    val line = currentLines[idx]
                                    val isLineActive = idx == activeLyricIndex
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (isLineActive) dynamicPalette.accentColor.copy(alpha = 0.22f)
                                                else Color.Transparent
                                            )
                                            .clickable { playerManager.seekTo(line.timestampMs) }
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = line.timeFormatted,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = if (isLineActive) dynamicPalette.accentColor else Color.Gray,
                                            modifier = Modifier.width(42.dp)
                                        )
                                        Text(
                                            text = line.text,
                                            fontSize = if (isLineActive) 15.sp else 13.sp,
                                            fontWeight = if (isLineActive) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isLineActive) Color.White else Color(0xFFB0BEC5),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "No lyrics found for this track.",
                            color = Color.Gray,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLyricsDialog = false }) {
                    Text("Close", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF131A26)
        )
    }
}
