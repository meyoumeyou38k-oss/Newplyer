package com.lerzaplayer.playback

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.lerzaplayer.MainActivity
import com.lerzaplayer.R

object NotificationHelper {
    const val CHANNEL_PLAYBACK_ID = "lerza_playback_channel"
    const val CHANNEL_REMINDER_ID = "lerza_reminder_channel"
    const val REMINDER_NOTIFICATION_ID = 2001

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val playbackChannel = NotificationChannel(
                CHANNEL_PLAYBACK_ID,
                "Playback Controls",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows now playing music notification with media controls"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(playbackChannel)

            val reminderChannel = NotificationChannel(
                CHANNEL_REMINDER_ID,
                "Music Recommendations & Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifies you when you have not played music in a while with favorite suggestions"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(reminderChannel)
        }
    }

    fun showInactivityReminder(context: Context, songTitle: String, artist: String) {
        createNotificationChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDER_ID)
            .setSmallIcon(R.drawable.ic_logo_transparent)
            .setContentTitle("Missing your tunes? Play \"$songTitle\"")
            .setContentText("Tap to resume listening to $artist!")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Your favorite song \"$songTitle\" by $artist is ready. Tap to open Lerza Player Pro!"))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(REMINDER_NOTIFICATION_ID, notification)
    }
}
