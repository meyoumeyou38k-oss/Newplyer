package com.lerzaplayer.ui.vault

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.vault.VaultManager
import kotlinx.coroutines.launch

@Composable
fun VaultScreen(
    vaultManager: VaultManager,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val scope = rememberCoroutineScope()
    val isUnlocked by vaultManager.isUnlocked.collectAsState()
    val vaultMedia by vaultManager.vaultMediaFlow.collectAsState(initial = emptyList())
    var lockType by remember { mutableStateOf(VaultLockType.PIN) }
    var enteredPin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            Surface(
                color = colors.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Text(
                            text = "Private Vault",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textPrimary
                        )
                    }
                    if (isUnlocked) {
                        IconButton(onClick = { vaultManager.lockVault() }) {
                            Icon(LerzaIcons.Lock, contentDescription = "Lock", tint = Color(0xFFFF334B))
                        }
                    }
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (!isUnlocked) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = LerzaIcons.Lock,
                        contentDescription = null,
                        tint = Color(0xFF1E60F2),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (lockType == VaultLockType.PIN) "Enter Vault PIN" else "Draw Vault Pattern",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                    Text(
                        text = "Your hidden media files are encrypted with AES standard.",
                        fontSize = 12.sp,
                        color = colors.textSecondary
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    if (lockType == VaultLockType.PIN) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(bottom = 32.dp)
                        ) {
                            repeat(4) { idx ->
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (idx < enteredPin.length) Color(0xFF1E60F2) else colors.card
                                        )
                                        .border(1.dp, Color(0xFF1E60F2), CircleShape)
                                )
                            }
                        }

                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val rows = listOf(
                                listOf("1", "2", "3"),
                                listOf("4", "5", "6"),
                                listOf("7", "8", "9"),
                                listOf("PAT", "0", "DEL")
                            )
                            rows.forEach { row ->
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                                ) {
                                    row.forEach { key ->
                                        Box(
                                            modifier = Modifier
                                                .size(64.dp)
                                                .clip(CircleShape)
                                                .background(colors.card)
                                                .clickable {
                                                    when (key) {
                                                        "DEL" -> if (enteredPin.isNotEmpty()) enteredPin = enteredPin.dropLast(1)
                                                        "PAT" -> lockType = VaultLockType.PATTERN
                                                        else -> {
                                                            if (enteredPin.length < 4) {
                                                                enteredPin += key
                                                                if (enteredPin.length == 4) {
                                                                    scope.launch {
                                                                        val success = vaultManager.verifyPin(enteredPin)
                                                                        if (!success) {
                                                                            errorMessage = "Incorrect PIN"
                                                                            enteredPin = ""
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (key == "DEL") {
                                                Icon(LerzaIcons.Backspace, contentDescription = "Delete", tint = colors.textPrimary)
                                            } else if (key == "PAT") {
                                                Icon(LerzaIcons.Pattern, contentDescription = "Pattern", tint = colors.textPrimary)
                                            } else {
                                                Text(
                                                    text = key,
                                                    fontSize = 22.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = colors.textPrimary
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        TextButton(onClick = { lockType = VaultLockType.PIN }) {
                            Text("Switch to PIN Mode", color = Color(0xFF1E60F2))
                        }
                    }

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage ?: "",
                            color = Color(0xFFFF334B),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 16.dp)
                        )
                    }
                }
            } else {
                if (vaultMedia.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(LerzaIcons.Lock, contentDescription = null, tint = colors.textSecondary, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No files currently hidden in Vault", color = colors.textSecondary)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(vaultMedia) { item ->
                            VaultMediaRow(
                                media = item,
                                onRestore = {
                                    scope.launch { vaultManager.restoreMedia(item) }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VaultMediaRow(
    media: VaultMediaEntity,
    onRestore: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(colors.card)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = if (media.mediaType == "AUDIO") LerzaIcons.Audiotrack else LerzaIcons.Videocam,
                contentDescription = null,
                tint = Color(0xFF1E60F2)
            )
            Column {
                Text(
                    text = media.originalName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary,
                    maxLines = 1
                )
                Text(
                    text = "Encrypted • ${media.mediaType}",
                    fontSize = 11.sp,
                    color = colors.textSecondary
                )
            }
        }
        IconButton(onClick = onRestore) {
            Icon(
                imageVector = LerzaIcons.Restore,
                contentDescription = "Restore to Library",
                tint = Color(0xFF00C853)
            )
        }
    }
}
