# Lerza Player Pro — Android source and build guide

## Latest update

- Smooth animated collapsing header with status-bar-safe spacing.
- Song long-press actions use an animated bottom sheet.
- Video player includes speed and overflow actions, audio-track selection, PiP, rotation/scale/play modes, delete confirmation, 10-second seek, and separate previous/next video controls. Existing video thumbnails remain enabled in list and grid views.
- Song playback starts the foreground media notification with artwork and previous/play-pause/next actions.
- Vault audio and video can be previewed without removing their vault copy. New vault files use AES-GCM with an Android Keystore key; older XOR-format vault items remain readable.
- The 3 × 3 pattern flow waits for an explicit unlock tap, lock changes can save a selected pattern, and the forgot-lock action appears after six failed attempts. Resetting the lock preserves vault media.
- Settings has a refreshed visual header and card styling.
- A GitHub Actions workflow builds and uploads the debug APK.

## Build

Open this folder in Android Studio, or build from a machine with Java 17 and Android SDK 34 installed:

```bash
./gradlew assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`. On GitHub, push to `main`/`master` or run **Actions → Android build**; download the `Lerza-Player-debug` workflow artifact.

The ZIP contains source code and build setup, not a prebuilt APK. Build verification requires an Android SDK and Java 17 environment.

## 🛠️ Errors Resolved in this Build:
1. **LyricsManager.kt:84 Illegal escape: '['**:
   - Cause: Regex escape string literal in Kotlin source file.
   - Fix: Replaced with robust character/string parsing that is 100% immune to regex escape issues.
2. **VideoPlayerScreen.kt: Unresolved reference 'AspectRatio' and 'TextOverflow'**:
   - Cause: Missing `LerzaIcons.AspectRatio` ImageVector and missing `TextOverflow` / `RoundedCornerShape` imports.
   - Fix: Added high-quality `AspectRatio` vector icon to `LerzaIcons` and imported `TextOverflow` & `RoundedCornerShape`.
3. **FoldersScreen.kt: None of the following functions can be called with the arguments supplied (PaddingValues)**:
   - Cause: Invalid combination of named arguments `horizontal = 14.dp, bottom = 90.dp`.
   - Fix: Replaced with `start = 14.dp, end = 14.dp, bottom = 90.dp`.
4. **PlaylistsScreen.kt: Type mismatch: inferred type is Uri? but String? was expected**:
   - Cause: `coverUri` was declared as `String?` while `SongItem.albumArtUri` is `Uri?`.
   - Fix: Changed `coverUri` type to `Uri?` and added `import android.net.Uri`.
5. **MainActivity.kt:146:33 Cannot find a parameter with this name: onOpenVault**:
   - Cause: `SettingsScreen` signature in `SettingsScreen.kt` lacked `onOpenVault`.
   - Fix: Connected `onOpenVault` parameter to Private Media Vault tile.
2. **AI-Style Typo-Tolerant Search & Categorized Discovery**:
   - Subsequence and token fuzzy matching (handles misspellings, partial names, and Roman Urdu/Punjabi transliterations).
   - Fast filter chips: "All", "Songs", "Artists", "Videos", "Sad", "Punjabi", "Remix".
3. **Dynamic Backlight Ambient Halo Glow (Screenshot 7)**:
   - Replaced static blue backlight with dynamic ambient aura adapting in real-time to album artwork palette (dominant, accent, and contrast tones).
4. **Auto-Launch Full Screen & 3-Dots Menu (Screenshots 2 & 7)**:
   - Tapping any track in any list automatically starts playback and expands into the full-screen player.
   - 3-dots popup menu with Play Next, Add to Queue, Add to Playlist, Vault, Track Details, and Delete.
5. **Smart AI Mood Playlists & Custom Creator (Screenshot 6)**:
   - Automatically generated "Sad Songs Special", "Punjabi Hits", "Romantic & Soulful", and "Remix & Bass Party" smart mixes, plus "+ Add new" playlist creator.
6. **Folders, Albums & Artists Library Sections (Screenshots 3, 4, 5)**:
   - "Folders" tab grouping storage directories (SHAREit, SnapTube_Audio, download, etc.).
   - "Albums" tab with album artwork and track listings.
   - "Artists" tab with circular avatars and "+ Add collection/playlist" floating action button.
7. **Offline Interactive Synced Lyrics**:
   - Real-time lyrics with active line auto-scrolling and tap-to-seek jump.
   - Reads external `.lrc` files and falls back to offline rhythm-timed generation.
8. **Hardware & GPU Performance**:
   - Configured `android:hardwareAccelerated="true"` and `android:largeHeap="true"` for zero-lag 120 FPS scrolling.

## 🚀 How to Build on GitHub Actions:
1. Push this code or extract the ZIP to your repository root.
2. Ensure `.github/workflows/build-apk.yml` is present.
3. Push to `main` or trigger via "Run workflow" in GitHub Actions tab.
4. The generated APK will be available in the workflow run summary under **Artifacts** -> `Lerza-Player-v1.0.0-Debug`.
