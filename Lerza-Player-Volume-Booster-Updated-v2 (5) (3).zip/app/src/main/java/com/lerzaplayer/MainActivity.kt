package com.lerzaplayer

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.compose.ui.graphics.toArgb
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.FavoriteEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.repository.MediaRepository
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaPlayerTheme
import com.lerzaplayer.ui.home.HomeScreen
import com.lerzaplayer.ui.player.FullPlayerScreen
import com.lerzaplayer.ui.player.VideoPlayerScreen
import com.lerzaplayer.ui.search.SearchScreen
import com.lerzaplayer.ui.settings.SettingsScreen
import com.lerzaplayer.ui.vault.VaultScreen
import kotlinx.coroutines.launch

enum class AppDestination {
    HOME,
    SETTINGS,
    VAULT,
    SEARCH
}

class MainActivity : ComponentActivity() {

    private lateinit var mediaRepository: MediaRepository
    private lateinit var playerManager: PlayerManager

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (::mediaRepository.isInitialized) mediaRepository.refreshMedia()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as LerzaApp
        mediaRepository = MediaRepository(this)
        playerManager = app.playerManager

        requestRequiredPermissions()

        setContent {
            val prefManager = app.preferenceManager
            val currentTheme by prefManager.themeFlow.collectAsState(initial = "Pure White")
            val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
            val scope = rememberCoroutineScope()

            val songs by mediaRepository.getSongsFlow(songSort).collectAsState(initial = emptyList())
            val videos by mediaRepository.getVideosFlow(SortOption.DATE_ADDED_DESC).collectAsState(initial = emptyList())
            val recentlyDeleted by mediaRepository.getRecentlyDeletedFlow().collectAsState(initial = emptyList())

            var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
            var isFullPlayerVisible by remember { mutableStateOf(false) }
            var activePlayingVideo by remember { mutableStateOf<VideoItem?>(null) }

            // Back Press Handling: Deeply integrated hierarchical back navigation
            BackHandler(enabled = activePlayingVideo != null) {
                activePlayingVideo = null
            }

            BackHandler(enabled = activePlayingVideo == null && isFullPlayerVisible) {
                isFullPlayerVisible = false
            }

            BackHandler(enabled = activePlayingVideo == null && !isFullPlayerVisible && currentDestination != AppDestination.HOME) {
                currentDestination = AppDestination.HOME
            }

            LerzaPlayerTheme(themeName = currentTheme) {
                val themeColors = com.lerzaplayer.theme.LocalLerzaColors.current
                SideEffect {
                    window.statusBarColor = themeColors.surface.toArgb()
                    window.navigationBarColor = themeColors.background.toArgb()
                    WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars =
                        !themeColors.isDark
                    WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars =
                        !themeColors.isDark
                }
                Box(modifier = Modifier.fillMaxSize()) {
                    // Navigation Views
                    when (currentDestination) {
                        AppDestination.HOME -> {
                            HomeScreen(
                                songs = songs,
                                videos = videos,
                                playerManager = playerManager,
                                prefManager = prefManager,
                                onSearchClick = { currentDestination = AppDestination.SEARCH },
                                onSettingsClick = { currentDestination = AppDestination.SETTINGS },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                onExpandFullPlayer = { isFullPlayerVisible = true },
                                onPlayVideo = { video ->
                                    playerManager.pause()
                                    activePlayingVideo = video
                                },
                                onToggleFavoriteSong = { song ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (song.isFavorite) {
                                            favDao.removeFavorite(song.id, "AUDIO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                        }
                                    }
                                },
                                onToggleFavoriteVideo = { video ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (video.isFavorite) {
                                            favDao.removeFavorite(video.id, "VIDEO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(video.id, "VIDEO"))
                                        }
                                    }
                                },
                                onHideSongInVault = { song ->
                                    scope.launch { app.vaultManager.hideSong(song) }
                                },
                                onHideVideoInVault = { video ->
                                    scope.launch { app.vaultManager.hideVideo(video) }
                                },
                                onDeleteSong = { song ->
                                    scope.launch { mediaRepository.deleteMedia(song) }
                                },
                                onDeleteVideo = { video ->
                                    scope.launch { mediaRepository.deleteMedia(video) }
                                },
                                onScanDevice = {
                                    mediaRepository.refreshMedia()
                                }
                            )
                        }
                        AppDestination.SETTINGS -> {
                            SettingsScreen(
                                prefManager = prefManager,
                                onBack = { currentDestination = AppDestination.HOME },
                                onOpenEqualizer = { isFullPlayerVisible = true },
                                onScanMedia = { mediaRepository.refreshMedia() },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                recentlyDeleted = recentlyDeleted,
                                onRestoreRecentlyDeleted = { item ->
                                    scope.launch { mediaRepository.restoreRecentlyDeleted(item) }
                                },
                                onPermanentlyDeleteRecentlyDeleted = { item ->
                                    scope.launch { mediaRepository.permanentlyDeleteRecentlyDeleted(item) }
                                }
                            )
                        }
                        AppDestination.VAULT -> {
                            VaultScreen(
                                vaultManager = app.vaultManager,
                                onBack = {
                                    playerManager.clearQueue()
                                    isFullPlayerVisible = false
                                    currentDestination = AppDestination.HOME
                                },
                                onPlayMedia = { entity ->
                                    scope.launch {
                                        val playableFile = app.vaultManager.createPlaybackCopy(entity)
                                        if (playableFile != null) {
                                            val playableUri = Uri.fromFile(playableFile)
                                            val playableId = entity.originalPath.hashCode().toLong()
                                            if (entity.mediaType == "AUDIO") {
                                                playerManager.playSong(
                                                    SongItem(
                                                        id = playableId,
                                                        title = entity.originalName,
                                                        artist = "Private Vault",
                                                        album = "Private Vault",
                                                        duration = entity.duration,
                                                        contentUri = playableUri,
                                                        size = entity.size,
                                                        path = playableFile.absolutePath,
                                                        mimeType = "audio/*"
                                                    )
                                                )
                                                isFullPlayerVisible = true
                                            } else {
                                                activePlayingVideo = VideoItem(
                                                    id = playableId,
                                                    title = entity.originalName,
                                                    duration = entity.duration,
                                                    contentUri = playableUri,
                                                    size = entity.size,
                                                    path = playableFile.absolutePath,
                                                    folderName = "Private Vault"
                                                )
                                            }
                                        }
                                    }
                                }
                            )
                        }
                        AppDestination.SEARCH -> {
                            val currentSong by playerManager.currentSong.collectAsState()
                            val isPlaying by playerManager.isPlaying.collectAsState()

                            SearchScreen(
                                songs = songs,
                                videos = videos,
                                currentSong = currentSong,
                                isPlaying = isPlaying,
                                onSongClick = { song ->
                                    val index = songs.indexOfFirst { it.id == song.id }
                                    if (index != -1) {
                                        playerManager.playSongList(songs, index)
                                    } else {
                                        playerManager.playSong(song)
                                    }
                                    isFullPlayerVisible = true
                                },
                                onVideoClick = { video ->
                                    playerManager.pause()
                                    activePlayingVideo = video
                                },
                                onBack = { currentDestination = AppDestination.HOME },
                                onToggleFavoriteSong = { song ->
                                    scope.launch {
                                        val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                        if (song.isFavorite) {
                                            favDao.removeFavorite(song.id, "AUDIO")
                                        } else {
                                            favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                        }
                                    }
                                },
                                onAddToQueue = { song -> playerManager.addToQueue(song) }
                            )
                        }
                    }

                    // Full Player Overlay (Slide in / Swipe down to collapse)
                    AnimatedVisibility(
                        visible = isFullPlayerVisible,
                        enter = slideInVertically(initialOffsetY = { it }),
                        exit = slideOutVertically(targetOffsetY = { it })
                    ) {
                        FullPlayerScreen(
                            playerManager = playerManager,
                            onCollapse = { isFullPlayerVisible = false }
                        )
                    }

                    // Video Player Overlay
                    activePlayingVideo?.let { vid ->
                        VideoPlayerScreen(
                            video = vid,
                            onClose = { activePlayingVideo = null },
                            onPreviousVideo = {
                                val index = videos.indexOfFirst { it.id == vid.id }
                                if (index > 0) activePlayingVideo = videos[index - 1]
                            },
                            onNextVideo = {
                                val index = videos.indexOfFirst { it.id == vid.id }
                                if (index >= 0 && index < videos.lastIndex) {
                                    activePlayingVideo = videos[index + 1]
                                }
                            },
                            onPlayAsAudio = {
                                playerManager.playSong(
                                    SongItem(
                                        id = vid.id,
                                        title = vid.title,
                                        artist = "Video audio",
                                        album = vid.folderName,
                                        duration = vid.duration,
                                        contentUri = vid.contentUri,
                                        albumArtUri = vid.contentUri,
                                        size = vid.size,
                                        path = vid.path,
                                        mimeType = "audio/*"
                                    )
                                )
                                activePlayingVideo = null
                                isFullPlayerVisible = true
                            },
                            onDeleteVideo = {
                                scope.launch { mediaRepository.deleteMedia(vid) }
                            }
                        )
                    }

                }
            }
        }
    }


    private fun requestRequiredPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }
}
