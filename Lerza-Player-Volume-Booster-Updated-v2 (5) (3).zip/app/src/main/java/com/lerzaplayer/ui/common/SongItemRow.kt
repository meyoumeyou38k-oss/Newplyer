package com.lerzaplayer.ui.common

import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongItemRow(
    song: SongItem,
    isPlaying: Boolean,
    isCurrent: Boolean,
    isMultiSelectActive: Boolean,
    isSelected: Boolean,
    onSongClick: () -> Unit,
    onSongLongClick: () -> Unit,
    onToggleSelect: () -> Unit,
    onToggleFavorite: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onHideInVault: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var menuExpanded by remember { mutableStateOf(false) }
    var showDetailsDialog by remember { mutableStateOf(false) }

    val rowBackground = when {
        isSelected -> Color(0xFF1E60F2).copy(alpha = 0.15f)
        isCurrent -> Color(0xFF00B0FF).copy(alpha = 0.08f)
        else -> Color.Transparent
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(rowBackground)
            .combinedClickable(
                onClick = {
                    if (isMultiSelectActive) {
                        onToggleSelect()
                    } else {
                        onSongClick()
                    }
                },
                onLongClick = {
                    onSongLongClick()
                }
            )
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isMultiSelectActive) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelect() },
                colors = CheckboxDefaults.colors(
                    checkedColor = Color(0xFF1E60F2),
                    uncheckedColor = colors.textSecondary
                ),
                modifier = Modifier.padding(end = 6.dp)
            )
        }

        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF1A1A24)),
            contentAlignment = Alignment.Center
        ) {
            if (song.albumArtUri != null) {
                AsyncImage(
                    model = song.albumArtUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF111118)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(Color(0xFF00E5FF), Color(0xFF002244))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                        )
                    }
                }
            }

            if (isCurrent && isPlaying) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    PlayingAudioBars()
                }
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = song.title,
                fontSize = 15.sp,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.SemiBold,
                color = if (isCurrent) Color(0xFF1E60F2) else colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(3.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(colors.card)
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = "LYRICS",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textSecondary
                    )
                }

                Text(
                    text = "${song.artist} • ${song.durationFormatted}",
                    fontSize = 12.sp,
                    color = colors.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(colors.card)
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = song.codecLabel,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textSecondary
                    )
                }
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (song.isFavorite) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (song.isFavorite) Color(0xFFFF334B) else colors.textSecondary.copy(alpha = 0.6f),
                    modifier = Modifier.size(19.dp)
                )
            }

            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.MoreVert,
                        contentDescription = "Options",
                        tint = colors.textSecondary.copy(alpha = 0.7f),
                        modifier = Modifier.size(20.dp)
                    )
                }

            }
        }
    }

    if (menuExpanded) {
        ModalBottomSheet(
            onDismissRequest = { menuExpanded = false },
            containerColor = colors.surface,
            dragHandle = {
                Box(
                    Modifier
                        .padding(vertical = 12.dp)
                        .width(38.dp)
                        .height(4.dp)
                        .clip(CircleShape)
                        .background(colors.textSecondary.copy(alpha = 0.35f))
                )
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 18.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.padding(bottom = 14.dp)
                ) {
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(colors.card),
                        contentAlignment = Alignment.Center
                    ) {
                        if (song.albumArtUri != null) {
                            AsyncImage(
                                model = song.albumArtUri,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(LerzaIcons.MusicNote, contentDescription = null, tint = colors.textSecondary)
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(song.title, color = colors.textPrimary, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(song.artist, color = colors.textSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { menuExpanded = false }) {
                        Icon(LerzaIcons.Close, contentDescription = "Close", tint = colors.textSecondary)
                    }
                }
                Divider(color = colors.card)
                SongSheetAction(LerzaIcons.PlayArrow, "Play next", colors.textPrimary) {
                    menuExpanded = false
                    onPlayNext()
                }
                SongSheetAction(LerzaIcons.QueueMusic, "Add to queue", colors.textPrimary) {
                    menuExpanded = false
                    onAddToQueue()
                }
                SongSheetAction(LerzaIcons.Add, "Add to playlist", colors.textPrimary) {
                    menuExpanded = false
                    onAddToPlaylist()
                }
                SongSheetAction(LerzaIcons.VisibilityOff, "Hide in vault", colors.textPrimary) {
                    menuExpanded = false
                    onHideInVault()
                }
                SongSheetAction(LerzaIcons.Info, "Track details", colors.textPrimary) {
                    menuExpanded = false
                    showDetailsDialog = true
                }
                SongSheetAction(LerzaIcons.CheckCircle, "Select song", colors.textPrimary) {
                    menuExpanded = false
                    onSongLongClick()
                }
                SongSheetAction(LerzaIcons.Delete, "Delete from library", Color(0xFFFF334B)) {
                    menuExpanded = false
                    onDelete()
                }
            }
        }
    }

    if (showDetailsDialog) {
        AlertDialog(
            onDismissRequest = { showDetailsDialog = false },
            title = {
                Text(
                    text = "Track Info",
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Title: ${song.title}", color = colors.textPrimary, fontSize = 13.sp)
                    Text("Artist: ${song.artist}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Album: ${song.album}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Duration: ${song.durationFormatted}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Format / Codec: ${song.codecLabel}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Folder: ${song.folderName}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Path: ${song.path}", color = colors.textSecondary.copy(alpha = 0.7f), fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showDetailsDialog = false }) {
                    Text("Close", color = Color(0xFF1E60F2))
                }
            },
            containerColor = colors.surface
        )
    }
}

@Composable
private fun SongSheetAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    tint: Color,
    onClick: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(21.dp))
        Text(title, color = tint, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PlayingAudioBars() {
    val infiniteTransition = rememberInfiniteTransition()
    val bar1Height by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )
    val bar2Height by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(350, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )
    val bar3Height by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Row(
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.Bottom,
        modifier = Modifier.height(18.dp)
    ) {
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight(bar1Height)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0xFF00E5FF))
        )
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight(bar2Height)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0xFF00E5FF))
        )
        Box(
            modifier = Modifier
                .width(3.dp)
                .fillMaxHeight(bar3Height)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0xFF00E5FF))
        )
    }
}
