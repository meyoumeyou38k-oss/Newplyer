@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@file:androidx.media3.common.util.UnstableApi
@file:Suppress("UnsafeOptInUsageError", "OPT_IN_USAGE_DEFAULT", "DEPRECATION")

package com.lerzaplayer.ui.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Build
import android.net.Uri
import android.util.Rational
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.theme.LerzaIcons
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@androidx.media3.common.util.UnstableApi
@Composable
fun VideoPlayerScreen(
    video: VideoItem,
    onClose: () -> Unit,
    onPreviousVideo: () -> Unit = {},
    onNextVideo: () -> Unit = {},
    onPlayAsAudio: () -> Unit = {},
    onDeleteVideo: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val exoPlayer = remember(video.contentUri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.contentUri))
            prepare()
            playWhenReady = true
        }
    }

    var isPlaying by remember { mutableStateOf(true) }
    var currentPos by remember { mutableStateOf(0L) }
    var totalDur by remember { mutableStateOf(video.duration) }
    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var isLandscape by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableStateOf(1.0f) }
    var resizeMode by remember { mutableStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showAudioTracks by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var isLooping by remember { mutableStateOf(false) }
    val audioTrackOptions = exoPlayer.currentTracks.groups
        .filter { it.type == C.TRACK_TYPE_AUDIO }
        .flatMap { group ->
            (0 until group.length).map { index ->
                val format = group.getTrackFormat(index)
                AudioTrackOption(
                    group = group.mediaTrackGroup,
                    index = index,
                    label = format.label ?: format.language ?: "Audio ${index + 1}"
                )
            }
        }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.release()
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    LaunchedEffect(video.id) {
        currentPos = 0L
        totalDur = video.duration
        isPlaying = true
        controlsVisible = true
    }

    LaunchedEffect(controlsVisible) {
        if (controlsVisible && !isLocked) {
            delay(4500)
            controlsVisible = false
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            if (exoPlayer.isPlaying) {
                currentPos = exoPlayer.currentPosition
                totalDur = exoPlayer.duration.coerceAtLeast(video.duration)
            }
            delay(400)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        if (!isLocked) {
                            controlsVisible = !controlsVisible
                        } else {
                            controlsVisible = true
                        }
                    },
                    onDoubleTap = {
                        if (!isLocked) {
                            if (exoPlayer.isPlaying) {
                                exoPlayer.pause()
                                isPlaying = false
                            } else {
                                exoPlayer.play()
                                isPlaying = true
                            }
                        }
                    }
                )
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    this.resizeMode = resizeMode
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { playerView ->
                playerView.resizeMode = resizeMode
            },
            modifier = Modifier.fillMaxSize()
        )

        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(16.dp)
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        IconButton(onClick = onClose) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        Text(
                            text = video.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(onClick = { isLocked = !isLocked }) {
                            Icon(
                                imageVector = if (isLocked) LerzaIcons.Lock else LerzaIcons.LockOpen,
                                contentDescription = "Lock",
                                tint = if (isLocked) Color(0xFF00E5FF) else Color.White
                            )
                        }
                        if (!isLocked) {
                            IconButton(onClick = { showSpeedDialog = true }) {
                                Icon(LerzaIcons.Speed, contentDescription = "Speed", tint = Color.White)
                            }
                            Box {
                                IconButton(onClick = { showMoreMenu = true }) {
                                    Icon(LerzaIcons.MoreVert, contentDescription = "Video options", tint = Color.White)
                                }
                                DropdownMenu(
                                    expanded = showMoreMenu,
                                    onDismissRequest = { showMoreMenu = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Share") },
                                        leadingIcon = { Icon(LerzaIcons.Share, null) },
                                        onClick = {
                                            showMoreMenu = false
                                            runCatching {
                                                val share = Intent(Intent.ACTION_SEND).apply {
                                                    type = "video/*"
                                                    putExtra(Intent.EXTRA_STREAM, video.contentUri)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(share, "Share video"))
                                            }
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Floating window") },
                                        leadingIcon = { Icon(LerzaIcons.Videocam, null) },
                                        onClick = {
                                            showMoreMenu = false
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                runCatching {
                                                    activity?.enterPictureInPictureMode(
                                                        PictureInPictureParams.Builder()
                                                            .setAspectRatio(Rational(16, 9))
                                                            .build()
                                                    )
                                                }
                                            }
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(if (isLooping) "Play mode: Repeat one" else "Play mode: Normal") },
                                        leadingIcon = { Icon(LerzaIcons.Repeat, null) },
                                        onClick = {
                                            isLooping = !isLooping
                                            exoPlayer.repeatMode = if (isLooping) {
                                                androidx.media3.common.Player.REPEAT_MODE_ONE
                                            } else {
                                                androidx.media3.common.Player.REPEAT_MODE_OFF
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Scale adjust") },
                                        leadingIcon = { Icon(LerzaIcons.AspectRatio, null) },
                                        onClick = {
                                            resizeMode = when (resizeMode) {
                                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                                                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Audio track") },
                                        leadingIcon = { Icon(LerzaIcons.Headphones, null) },
                                        onClick = {
                                            showMoreMenu = false
                                            showAudioTracks = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Screen rotation") },
                                        leadingIcon = { Icon(LerzaIcons.ScreenRotation, null) },
                                        onClick = {
                                            isLandscape = !isLandscape
                                            activity?.requestedOrientation = if (isLandscape) {
                                                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                            } else {
                                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                            }
                                            showMoreMenu = false
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Video details") },
                                        leadingIcon = { Icon(LerzaIcons.Info, null) },
                                        onClick = {
                                            showMoreMenu = false
                                            showInfoDialog = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Delete", color = Color(0xFFFF334B)) },
                                        leadingIcon = { Icon(LerzaIcons.Delete, null, tint = Color(0xFFFF334B)) },
                                        onClick = {
                                            showMoreMenu = false
                                            showDeleteConfirm = true
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Center Controls with 10s Rewind and 10s Forward
                if (!isLocked) {
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onPreviousVideo, modifier = Modifier.size(42.dp)) {
                            Icon(LerzaIcons.SkipPrevious, contentDescription = "Previous video", tint = Color.White, modifier = Modifier.size(27.dp))
                        }
                        IconButton(
                            onClick = {
                                val target = (currentPos - 10000L).coerceAtLeast(0L)
                                exoPlayer.seekTo(target)
                            },
                            modifier = Modifier.size(42.dp)
                        ) {
                            Icon(
                                imageVector = LerzaIcons.FastRewind,
                                contentDescription = "Rewind 10s",
                                tint = Color.White,
                                modifier = Modifier.size(30.dp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00E5FF).copy(alpha = 0.85f))
                                .clickable {
                                    if (exoPlayer.isPlaying) {
                                        exoPlayer.pause()
                                        isPlaying = false
                                    } else {
                                        exoPlayer.play()
                                        isPlaying = true
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) LerzaIcons.Pause else LerzaIcons.PlayArrow,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(34.dp)
                            )
                        }

                        IconButton(
                            onClick = {
                                val target = (currentPos + 10000L).coerceAtMost(totalDur)
                                exoPlayer.seekTo(target)
                            },
                            modifier = Modifier.size(42.dp)
                        ) {
                            Icon(
                                imageVector = LerzaIcons.FastForward,
                                contentDescription = "Forward 10s",
                                tint = Color.White,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                        IconButton(onClick = onNextVideo, modifier = Modifier.size(42.dp)) {
                            Icon(LerzaIcons.SkipNext, contentDescription = "Next video", tint = Color.White, modifier = Modifier.size(27.dp))
                        }
                    }
                }

                // Bottom Timeline and Status
                if (!isLocked) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                    ) {
                        val progressFraction = if (totalDur > 0) (currentPos.toFloat() / totalDur.toFloat()).coerceIn(0f, 1f) else 0f
                        Slider(
                            value = progressFraction,
                            onValueChange = { frac ->
                                val target = (frac * totalDur).toLong()
                                exoPlayer.seekTo(target)
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00E5FF),
                                activeTrackColor = Color(0xFF00E5FF)
                            )
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val curSec = currentPos / 1000
                            val totSec = totalDur / 1000
                            Text(
                                text = "%d:%02d".format(curSec / 60, curSec % 60),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (playbackSpeed != 1.0f) {
                                    Text(
                                        text = "${playbackSpeed}x",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "%d:%02d".format(totSec / 60, totSec % 60),
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 12.sp
                                )
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onPlayAsAudio) {
                                Icon(LerzaIcons.Headphones, contentDescription = "Audio track", tint = Color.White)
                            }
                            IconButton(onClick = {
                                isLandscape = !isLandscape
                                activity?.requestedOrientation = if (isLandscape) {
                                    ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                } else {
                                    ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                }
                            }) {
                                Icon(LerzaIcons.ScreenRotation, contentDescription = "Rotate screen", tint = Color.White)
                            }
                            IconButton(onClick = { isLocked = true; controlsVisible = false }) {
                                Icon(LerzaIcons.Lock, contentDescription = "Lock controls", tint = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Playback Speed Dialog
        if (showSpeedDialog) {
            AlertDialog(
                onDismissRequest = { showSpeedDialog = false },
                title = { Text("Playback Speed", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (playbackSpeed == spd) Color(0xFF00E5FF).copy(alpha = 0.2f) else Color.Transparent)
                                    .clickable {
                                        playbackSpeed = spd
                                        exoPlayer.playbackParameters = androidx.media3.common.PlaybackParameters(spd)
                                        showSpeedDialog = false
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (spd == 1.0f) "1.0x (Normal)" else "${spd}x",
                                    color = if (playbackSpeed == spd) Color(0xFF00E5FF) else Color.White,
                                    fontWeight = if (playbackSpeed == spd) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSpeedDialog = false }) {
                        Text("Cancel", color = Color(0xFF00E5FF))
                    }
                },
                containerColor = Color(0xFF131A26)
            )
        }

        // Video Info Dialog
        if (showInfoDialog) {
            AlertDialog(
                onDismissRequest = { showInfoDialog = false },
                title = { Text("Video Details", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Title: ${video.title}", color = Color.White, fontSize = 13.sp)
                        Text("Duration: ${video.durationFormatted}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text("Resolution: ${video.resolution}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text("Folder: ${video.folderName}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text("Location: ${video.path}", color = Color.Gray, fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showInfoDialog = false }) {
                        Text("OK", color = Color(0xFF00E5FF))
                    }
                },
                containerColor = Color(0xFF131A26)
            )
        }

        if (showAudioTracks) {
            AlertDialog(
                onDismissRequest = { showAudioTracks = false },
                title = { Text("Audio track", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    if (audioTrackOptions.isEmpty()) {
                        Text("No alternate audio tracks are available for this video.", color = Color.White.copy(alpha = 0.8f))
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            audioTrackOptions.forEach { option ->
                                TextButton(
                                    onClick = {
                                        exoPlayer.trackSelectionParameters =
                                            exoPlayer.trackSelectionParameters.buildUpon()
                                                .setOverrideForType(TrackSelectionOverride(option.group, option.index))
                                                .build()
                                        showAudioTracks = false
                                    }
                                ) {
                                    Text(option.label, color = Color(0xFF00E5FF))
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showAudioTracks = false }) {
                        Text("Close", color = Color(0xFF00E5FF))
                    }
                },
                containerColor = Color(0xFF131A26)
            )
        }

        if (showDeleteConfirm) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirm = false },
                title = { Text("Delete this video?", color = Color.White, fontWeight = FontWeight.Bold) },
                text = { Text("This removes the video from device storage.", color = Color.White.copy(alpha = 0.8f)) },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showDeleteConfirm = false
                            onDeleteVideo()
                            onClose()
                        }
                    ) { Text("Delete", color = Color(0xFFFF334B)) }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel", color = Color.White) }
                },
                containerColor = Color(0xFF131A26)
            )
        }
    }
}

private data class AudioTrackOption(
    val group: TrackGroup,
    val index: Int,
    val label: String
)
