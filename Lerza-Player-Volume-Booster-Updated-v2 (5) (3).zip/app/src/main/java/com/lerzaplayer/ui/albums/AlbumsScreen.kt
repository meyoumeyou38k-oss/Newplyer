package com.lerzaplayer.ui.albums

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow

data class AlbumGroup(
    val albumName: String,
    val songs: List<SongItem>
)

@Composable
fun AlbumsScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem, List<SongItem>, Int) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var selectedAlbum by remember { mutableStateOf<AlbumGroup?>(null) }

    BackHandler(enabled = selectedAlbum != null) {
        selectedAlbum = null
    }

    if (selectedAlbum != null) {
        val album = selectedAlbum!!
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(colors.background)
        ) {
            Surface(
                color = colors.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { selectedAlbum = null }) {
                            Icon(
                                imageVector = LerzaIcons.ArrowBack,
                                contentDescription = "Back",
                                tint = colors.textPrimary
                            )
                        }
                        Column {
                            Text(
                                text = album.albumName,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${album.songs.size} tracks",
                                fontSize = 12.sp,
                                color = colors.textSecondary
                            )
                        }
                    }

                    if (album.songs.isNotEmpty()) {
                        Button(
                            onClick = { onSongClick(album.songs.first(), album.songs, 0) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60F2)),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(LerzaIcons.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Play All", fontSize = 13.sp)
                        }
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                items(album.songs, key = { it.id }) { song ->
                    val idx = album.songs.indexOf(song)
                    SongItemRow(
                        song = song,
                        isPlaying = isPlaying,
                        isCurrent = currentSong?.id == song.id,
                        isMultiSelectActive = false,
                        isSelected = false,
                        onSongClick = { onSongClick(song, album.songs, idx) },
                        onSongLongClick = {},
                        onToggleSelect = {},
                        onToggleFavorite = { onToggleFavorite(song) },
                        onPlayNext = { onSongClick(song, album.songs, idx) },
                        onAddToQueue = {},
                        onAddToPlaylist = {},
                        onHideInVault = { onHideInVault(song) },
                        onDelete = { onDelete(song) }
                    )
                }
            }
        }
        return
    }

    val albumGroups = remember(songs) {
        songs.groupBy { if (it.album.isBlank()) "Unknown Album" else it.album }
            .map { (name, list) -> AlbumGroup(name, list) }
            .sortedByDescending { it.songs.size }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(albumGroups, key = { it.albumName }) { group ->
            val firstArt = group.songs.firstOrNull()?.albumArtUri
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.card),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedAlbum = group }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFFE91E63), Color(0xFF673AB7))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (firstArt != null) {
                            AsyncImage(
                                model = firstArt,
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(
                                imageVector = LerzaIcons.MusicNote,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = group.albumName,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${group.songs.size}",
                                fontSize = 13.sp,
                                color = colors.textSecondary
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        group.songs.take(2).forEach { song ->
                            Text(
                                text = "♬ ${song.title}",
                                fontSize = 12.sp,
                                color = colors.textSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}
