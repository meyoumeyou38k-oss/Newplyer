package com.lerzaplayer.ui.playlists

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow

@Composable
fun PlaylistsScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem, List<SongItem>, Int) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var selectedPlaylistTitle by remember { mutableStateOf<String?>(null) }
    var selectedPlaylistSongs by remember { mutableStateOf<List<SongItem>>(emptyList()) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    val customPlaylists = remember { mutableStateListOf<String>() }

    BackHandler(enabled = selectedPlaylistTitle != null) {
        selectedPlaylistTitle = null
        selectedPlaylistSongs = emptyList()
    }

    if (selectedPlaylistTitle != null) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(colors.background)
        ) {
            Surface(
                color = colors.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { selectedPlaylistTitle = null }) {
                            Icon(
                                imageVector = LerzaIcons.ArrowBack,
                                contentDescription = "Back",
                                tint = colors.textPrimary
                            )
                        }
                        Column {
                            Text(
                                text = selectedPlaylistTitle ?: "Playlist",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${selectedPlaylistSongs.size} tracks",
                                fontSize = 12.sp,
                                color = colors.textSecondary
                            )
                        }
                    }

                    if (selectedPlaylistSongs.isNotEmpty()) {
                        Button(
                            onClick = { onSongClick(selectedPlaylistSongs.first(), selectedPlaylistSongs, 0) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60F2)),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(LerzaIcons.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Play All", fontSize = 13.sp)
                        }
                    }
                }
            }

            if (selectedPlaylistSongs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No songs in this playlist yet.", color = colors.textSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    items(selectedPlaylistSongs, key = { it.id }) { song ->
                        val idx = selectedPlaylistSongs.indexOf(song)
                        SongItemRow(
                            song = song,
                            isPlaying = isPlaying,
                            isCurrent = currentSong?.id == song.id,
                            isMultiSelectActive = false,
                            isSelected = false,
                            onSongClick = { onSongClick(song, selectedPlaylistSongs, idx) },
                            onSongLongClick = {},
                            onToggleSelect = {},
                            onToggleFavorite = { onToggleFavorite(song) },
                            onPlayNext = { onSongClick(song, selectedPlaylistSongs, idx) },
                            onAddToQueue = {},
                            onAddToPlaylist = {},
                            onHideInVault = { onHideInVault(song) },
                            onDelete = { onDelete(song) }
                        )
                    }
                }
            }
        }
        return
    }

    val likedSongs = remember(songs) { songs.filter { it.isFavorite } }
    val recentlyPlayed = remember(songs) { songs.take(20) }
    val mostPlayed = remember(songs) { songs.sortedByDescending { it.duration }.take(15) }
    val withLyrics = remember(songs) { songs }

    val sadSongs = remember(songs) {
        songs.filter { s ->
            listOf("sad", "dard", "gham", "judai", "bewafa", "chorr", "dil", "slow", "tears").any { kw ->
                s.title.contains(kw, ignoreCase = true) || s.artist.contains(kw, ignoreCase = true)
            }
        }.ifEmpty { songs.take(12) }
    }

    val punjabiHits = remember(songs) {
        songs.filter { s ->
            listOf("sidhu", "moose", "praak", "ammy", "diljit", "punjabi", "jatt", "ishtar", "qismat", "dhillon", "aujla").any { kw ->
                s.title.contains(kw, ignoreCase = true) || s.artist.contains(kw, ignoreCase = true)
            }
        }.ifEmpty { songs.take(10) }
    }

    val romanticSongs = remember(songs) {
        songs.filter { s ->
            listOf("ishq", "mohabbat", "pyaar", "humsafar", "romantic", "dholna", "kaun hoyega", "love").any { kw ->
                s.title.contains(kw, ignoreCase = true) || s.artist.contains(kw, ignoreCase = true)
            }
        }.ifEmpty { songs.take(8) }
    }

    val remixParty = remember(songs) {
        songs.filter { s ->
            listOf("remix", "bass", "dnm", "dj", "party", "club", "mix", "dance").any { kw ->
                s.title.contains(kw, ignoreCase = true)
            }
        }.ifEmpty { songs.take(6) }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = colors.card),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showCreateDialog = true }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = LerzaIcons.Add,
                        contentDescription = "Add new",
                        tint = Color(0xFF1E60F2),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Add new",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        }

        item {
            PlaylistCardRow(
                title = "Liked songs",
                count = likedSongs.size,
                icon = LerzaIcons.Favorite,
                previewSongs = likedSongs.take(2),
                gradient = listOf(Color(0xFFFF334B), Color(0xFF880E4F)),
                coverUri = likedSongs.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Liked songs"
                    selectedPlaylistSongs = likedSongs
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "Recently played",
                count = recentlyPlayed.size,
                icon = LerzaIcons.SwapVert,
                previewSongs = recentlyPlayed.take(2),
                gradient = listOf(Color(0xFF00B0FF), Color(0xFF0D47A1)),
                coverUri = recentlyPlayed.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Recently played"
                    selectedPlaylistSongs = recentlyPlayed
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "Most played",
                count = mostPlayed.size,
                icon = LerzaIcons.Tune,
                previewSongs = mostPlayed.take(2),
                gradient = listOf(Color(0xFFFF6D00), Color(0xFFBF360C)),
                coverUri = mostPlayed.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Most played"
                    selectedPlaylistSongs = mostPlayed
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "With Lyrics",
                count = withLyrics.size,
                icon = LerzaIcons.Lyrics,
                previewSongs = withLyrics.take(2),
                gradient = listOf(Color(0xFF00E5FF), Color(0xFF006064)),
                coverUri = withLyrics.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "With Lyrics"
                    selectedPlaylistSongs = withLyrics
                }
            )
        }

        item {
            Text(
                text = "SMART AUTO PLAYLISTS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = Color(0xFF1E60F2),
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
        }

        item {
            PlaylistCardRow(
                title = "Sad Songs Special",
                count = sadSongs.size,
                icon = LerzaIcons.Audiotrack,
                previewSongs = sadSongs.take(2),
                gradient = listOf(Color(0xFF7E57C2), Color(0xFF311B92)),
                coverUri = sadSongs.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Sad Songs Special"
                    selectedPlaylistSongs = sadSongs
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "Punjabi Hits",
                count = punjabiHits.size,
                icon = LerzaIcons.Headphones,
                previewSongs = punjabiHits.take(2),
                gradient = listOf(Color(0xFFFF9100), Color(0xFFE65100)),
                coverUri = punjabiHits.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Punjabi Hits"
                    selectedPlaylistSongs = punjabiHits
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "Romantic & Soulful",
                count = romanticSongs.size,
                icon = LerzaIcons.Favorite,
                previewSongs = romanticSongs.take(2),
                gradient = listOf(Color(0xFFEC407A), Color(0xFF880E4F)),
                coverUri = romanticSongs.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Romantic & Soulful"
                    selectedPlaylistSongs = romanticSongs
                }
            )
        }

        item {
            PlaylistCardRow(
                title = "Remix & Bass Party",
                count = remixParty.size,
                icon = LerzaIcons.Tune,
                previewSongs = remixParty.take(2),
                gradient = listOf(Color(0xFF00E676), Color(0xFF1B5E20)),
                coverUri = remixParty.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = "Remix & Bass Party"
                    selectedPlaylistSongs = remixParty
                }
            )
        }

        items(customPlaylists) { name ->
            val customSongs = remember(songs, name) { songs.shuffled().take(10) }
            PlaylistCardRow(
                title = name,
                count = customSongs.size,
                icon = LerzaIcons.PlaylistAdd,
                previewSongs = customSongs.take(2),
                gradient = listOf(Color(0xFF1E60F2), Color(0xFF0D47A1)),
                coverUri = customSongs.firstOrNull()?.albumArtUri,
                onClick = {
                    selectedPlaylistTitle = name
                    selectedPlaylistSongs = customSongs
                }
            )
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create New Playlist", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    label = { Text("Playlist Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newPlaylistName.isNotBlank()) {
                            customPlaylists.add(newPlaylistName.trim())
                            newPlaylistName = ""
                            showCreateDialog = false
                        }
                    }
                ) {
                    Text("Create", fontWeight = FontWeight.Bold, color = Color(0xFF1E60F2))
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel", color = colors.textSecondary)
                }
            }
        )
    }
}

@Composable
fun PlaylistCardRow(
    title: String,
    count: Int,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    previewSongs: List<SongItem>,
    gradient: List<Color>,
    coverUri: Uri? = null,
    onClick: () -> Unit
) {
    val colors = LocalLerzaColors.current
    Card(
        colors = CardDefaults.cardColors(containerColor = colors.card),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(gradient)),
                contentAlignment = Alignment.Center
            ) {
                if (coverUri != null) {
                    AsyncImage(
                        model = coverUri,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (count > 0) "$count" else "No songs yet",
                        fontSize = 12.sp,
                        color = colors.textSecondary
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                if (previewSongs.isNotEmpty()) {
                    previewSongs.take(2).forEach { song ->
                        Text(
                            text = "♬ ${song.title}",
                            fontSize = 12.sp,
                            color = colors.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                } else {
                    Text(
                        text = "Tap to open and play tracks",
                        fontSize = 12.sp,
                        color = colors.textSecondary.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}
