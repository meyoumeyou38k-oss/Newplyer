package com.lerzaplayer.ui.artists

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow

data class ArtistGroup(
    val artistName: String,
    val songs: List<SongItem>
)

@Composable
fun ArtistsScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem, List<SongItem>, Int) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var selectedArtist by remember { mutableStateOf<ArtistGroup?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    val customArtistFolders = remember { mutableStateListOf<String>() }

    BackHandler(enabled = selectedArtist != null) {
        selectedArtist = null
    }

    if (selectedArtist != null) {
        val artist = selectedArtist!!
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(colors.background)
        ) {
            Surface(
                color = colors.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { selectedArtist = null }) {
                            Icon(
                                imageVector = LerzaIcons.ArrowBack,
                                contentDescription = "Back",
                                tint = colors.textPrimary
                            )
                        }
                        Column {
                            Text(
                                text = artist.artistName,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${artist.songs.size} tracks",
                                fontSize = 12.sp,
                                color = colors.textSecondary
                            )
                        }
                    }

                    if (artist.songs.isNotEmpty()) {
                        Button(
                            onClick = { onSongClick(artist.songs.first(), artist.songs, 0) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60F2)),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(LerzaIcons.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Play All", fontSize = 13.sp)
                        }
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                items(artist.songs, key = { it.id }) { song ->
                    val idx = artist.songs.indexOf(song)
                    SongItemRow(
                        song = song,
                        isPlaying = isPlaying,
                        isCurrent = currentSong?.id == song.id,
                        isMultiSelectActive = false,
                        isSelected = false,
                        onSongClick = { onSongClick(song, artist.songs, idx) },
                        onSongLongClick = {},
                        onToggleSelect = {},
                        onToggleFavorite = { onToggleFavorite(song) },
                        onPlayNext = { onSongClick(song, artist.songs, idx) },
                        onAddToQueue = {},
                        onAddToPlaylist = {},
                        onHideInVault = { onHideInVault(song) },
                        onDelete = { onDelete(song) }
                    )
                }
            }
        }
        return
    }

    val artistGroups = remember(songs) {
        songs.groupBy { if (it.artist.isBlank()) "Unknown artist" else it.artist }
            .map { (name, list) -> ArtistGroup(name, list) }
            .sortedByDescending { it.songs.size }
    }

    Box(modifier = modifier.fillMaxSize().background(colors.background)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(artistGroups, key = { it.artistName }) { group ->
                val firstArt = group.songs.firstOrNull()?.albumArtUri
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.card),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedArtist = group }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF263238)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (firstArt != null) {
                                AsyncImage(
                                    model = firstArt,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Text(
                                    text = group.artistName.take(1).uppercase(),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 24.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = group.artistName,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = colors.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${group.songs.size}",
                                    fontSize = 13.sp,
                                    color = colors.textSecondary
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            group.songs.take(2).forEach { song ->
                                Text(
                                    text = "♬ ${song.title}",
                                    fontSize = 12.sp,
                                    color = colors.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            items(customArtistFolders) { folderName ->
                val customSongs = remember(songs, folderName) { songs.shuffled().take(8) }
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.card),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            selectedArtist = ArtistGroup(folderName, customSongs)
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF1E60F2)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(LerzaIcons.Folder, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(folderName, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                            Text("${customSongs.size} tracks • Custom Collection", fontSize = 12.sp, color = colors.textSecondary)
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showCreateDialog = true },
            containerColor = Color(0xFF1E60F2),
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 20.dp, end = 20.dp)
        ) {
            Icon(LerzaIcons.Add, contentDescription = "Add Artist Folder or Playlist")
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("New Artist Collection / Playlist", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text("Collection or Artist Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newFolderName.isNotBlank()) {
                            customArtistFolders.add(newFolderName.trim())
                            newFolderName = ""
                            showCreateDialog = false
                        }
                    }
                ) {
                    Text("Create", fontWeight = FontWeight.Bold, color = Color(0xFF1E60F2))
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel", color = colors.textSecondary)
                }
            }
        )
    }
}
