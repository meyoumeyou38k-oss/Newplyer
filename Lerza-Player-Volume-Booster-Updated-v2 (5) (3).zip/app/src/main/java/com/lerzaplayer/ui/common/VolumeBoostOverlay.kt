package com.lerzaplayer.ui.common

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.lerzaplayer.theme.LocalLerzaColors
import kotlinx.coroutines.delay
import kotlin.math.abs

private val VolumeBoostSteps = listOf(100, 150, 200, 300)

@Composable
fun VolumeBoostOverlay(
    visible: Boolean,
    boostPercent: Int,
    requestId: Int,
    onPercentChange: (Int) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current

    LaunchedEffect(requestId, visible) {
        if (visible) {
            delay(1_800)
            onDismiss()
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .zIndex(100f),
        contentAlignment = Alignment.TopCenter
    ) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn() + slideInVertically(initialOffsetY = { -it / 2 }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { -it / 2 })
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF101826), Color(0xFF172B3D))
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = Color(0xFF00E5FF).copy(alpha = 0.65f),
                        shape = RoundedCornerShape(22.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.VolumeUp,
                        contentDescription = "Volume boost",
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(25.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Volume Booster",
                            color = Color.White,
                            fontSize = 14.sp,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "Device keys • hides automatically",
                            color = colors.textSecondary.copy(alpha = 0.9f),
                            fontSize = 10.sp
                        )
                    }
                    Text(
                        text = "$boostPercent%",
                        color = Color(0xFF00E5FF),
                        fontSize = 18.sp
                    )
                }

                Slider(
                    value = boostPercent.toFloat(),
                    onValueChange = { rawValue ->
                        val snapped = VolumeBoostSteps.minByOrNull {
                            abs(it - rawValue)
                        } ?: 100
                        if (snapped != boostPercent) onPercentChange(snapped)
                    },
                    valueRange = 100f..300f,
                    colors = androidx.compose.material3.SliderDefaults.colors(
                        thumbColor = Color(0xFF00E5FF),
                        activeTrackColor = Color(0xFF00E5FF),
                        inactiveTrackColor = Color.White.copy(alpha = 0.22f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                LinearProgressIndicator(
                    progress = { ((boostPercent - 100) / 200f).coerceIn(0f, 1f) },
                    color = Color(0xFF00E5FF),
                    trackColor = Color.White.copy(alpha = 0.12f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 2.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    VolumeBoostSteps.forEach { step ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (boostPercent == step) {
                                        Color(0xFF00E5FF).copy(alpha = 0.22f)
                                    } else {
                                        Color.White.copy(alpha = 0.08f)
                                    }
                                )
                                .clickable { onPercentChange(step) }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${step}%",
                                color = if (boostPercent == step) {
                                    Color(0xFF00E5FF)
                                } else {
                                    Color.White.copy(alpha = 0.75f)
                                },
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}