package com.lerzaplayer.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.lerzaplayer.theme.LocalLerzaColors

@Composable
fun WallpaperBackground(
    wallpaperUri: String?,
    opacity: Float,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val colors = LocalLerzaColors.current

    Box(modifier = modifier.fillMaxSize()) {
        if (!wallpaperUri.isNullOrEmpty()) {
            AsyncImage(
                model = wallpaperUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        alpha = 1.0f
                    }
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        colors.background.copy(alpha = opacity.coerceIn(0.2f, 0.95f))
                    )
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                colors.background,
                                colors.surface.copy(alpha = 0.95f)
                            )
                        )
                    )
            )
        }
        content()
    }
}
