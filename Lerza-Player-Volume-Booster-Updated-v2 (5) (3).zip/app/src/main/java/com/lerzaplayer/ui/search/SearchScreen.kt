package com.lerzaplayer.ui.search

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow

@Composable
fun SearchScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onBack: () -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onAddToQueue: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var query by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    BackHandler {
        onBack()
    }

    LaunchedEffect(Unit) {
        try {
            focusRequester.requestFocus()
        } catch (_: Exception) {}
    }

    var selectedFilterCategory by remember { mutableStateOf("All") }

    fun smartMatch(q: String, target: String): Boolean {
        if (q.isBlank()) return true
        val cleanQ = q.trim().lowercase()
        val cleanT = target.lowercase()
        if (cleanT.contains(cleanQ)) return true

        // Subsequence match (e.g. "sdhu" matches "Sidhu Moose Wala", "nusrt" matches "Nusrat")
        var qi = 0
        for (ch in cleanT) {
            if (qi < cleanQ.length && ch == cleanQ[qi]) {
                qi++
            }
        }
        if (qi == cleanQ.length) return true

        // Word token match with 1-character typo tolerance
        val qTokens = cleanQ.split(" ", "_", "-", ".").filter { it.length >= 2 }
        val tTokens = cleanT.split(" ", "_", "-", ".").filter { it.length >= 2 }
        for (qt in qTokens) {
            for (tt in tTokens) {
                if (tt.contains(qt) || qt.contains(tt)) return true
                if (qt.length >= 4 && tt.length >= 4 && kotlin.math.abs(qt.length - tt.length) <= 1) {
                    var diff = 0
                    val minLen = minOf(qt.length, tt.length)
                    for (i in 0 until minLen) {
                        if (qt[i] != tt[i]) diff++
                    }
                    if (diff <= 1) return true
                }
            }
        }
        return false
    }

    val filteredSongs = remember(query, songs, selectedFilterCategory) {
        if (query.isBlank() && selectedFilterCategory == "All") emptyList()
        else {
            val q = query.trim().lowercase()
            songs.filter { song ->
                val categoryPass = when (selectedFilterCategory) {
                    "Sad" -> listOf("sad", "dard", "gham", "judai", "dil", "slow", "bewafa").any { kw -> song.title.contains(kw, true) || song.artist.contains(kw, true) }
                    "Punjabi" -> listOf("sidhu", "moose", "praak", "ammy", "diljit", "punjabi", "jatt", "ishtar").any { kw -> song.title.contains(kw, true) || song.artist.contains(kw, true) }
                    "Remix" -> listOf("remix", "bass", "dj", "party", "dance", "beat").any { kw -> song.title.contains(kw, true) }
                    "Songs", "All" -> true
                    else -> true
                }
                categoryPass && (q.isBlank() || smartMatch(q, song.title) || smartMatch(q, song.artist) || smartMatch(q, song.album) || smartMatch(q, song.path))
            }
        }
    }

    val matchedArtists = remember(query, songs) {
        if (query.isBlank()) emptyList()
        else {
            val q = query.trim().lowercase()
            songs.map { it.artist }
                .distinct()
                .filter { smartMatch(q, it) }
                .take(6)
        }
    }

    val filteredVideos = remember(query, videos, selectedFilterCategory) {
        if (query.isBlank() || selectedFilterCategory == "Songs" || selectedFilterCategory == "Artists") emptyList()
        else {
            val q = query.trim().lowercase()
            videos.filter { smartMatch(q, it.title) }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        Surface(
            color = colors.surface,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = LerzaIcons.ArrowBack,
                            contentDescription = "Back",
                            tint = colors.textPrimary
                        )
                    }

                    TextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = {
                            Text(
                                text = "Search songs, artists, Punjabi, Sad mixes...",
                                color = colors.textSecondary,
                                fontSize = 14.sp
                            )
                        },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            cursorColor = Color(0xFF1E60F2)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(focusRequester)
                    )

                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(
                                imageVector = LerzaIcons.Close,
                                contentDescription = "Clear",
                                tint = colors.textSecondary
                            )
                        }
                    }
                }

                // AI Search Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val filterChips = listOf("All", "Songs", "Artists", "Videos", "Sad", "Punjabi", "Remix")
                    filterChips.forEach { chip ->
                        val isSelected = selectedFilterCategory == chip
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) Color(0xFF1E60F2) else colors.card)
                                .clickable { selectedFilterCategory = chip }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = chip,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.White else colors.textSecondary
                            )
                        }
                    }
                }
            }
        }

        if (query.isBlank() && selectedFilterCategory == "All") {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable { onBack() },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.Search,
                        contentDescription = null,
                        tint = colors.textSecondary.copy(alpha = 0.4f),
                        modifier = Modifier.size(56.dp)
                    )
                    Text(
                        text = "Smart Search across ${songs.size} songs & ${videos.size} videos",
                        color = colors.textSecondary,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Supports typos, partial artist names & mood keywords",
                        color = colors.textSecondary.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 90.dp)
            ) {
                if (matchedArtists.isNotEmpty() && selectedFilterCategory != "Videos") {
                    item {
                        Text(
                            text = "MATCHED ARTISTS (${matchedArtists.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E5FF),
                            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 6.dp)
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 16.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            matchedArtists.forEach { artistName ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(colors.card)
                                        .clickable { query = artistName }
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF1E60F2)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = artistName.take(1).uppercase(),
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }
                                        Text(
                                            text = artistName,
                                            fontSize = 13.sp,
                                            color = colors.textPrimary,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                if (filteredVideos.isNotEmpty()) {
                    item {
                        Text(
                            text = "VIDEOS (${filteredVideos.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E60F2),
                            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp)
                        )
                    }

                    items(filteredVideos, key = { "v_${it.id}" }) { video ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onVideoClick(video) }
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp, 36.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(colors.card),
                                contentAlignment = Alignment.Center
                            ) {
                                AsyncImage(
                                    model = video.contentUri,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = video.title,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = colors.textPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = video.resolution,
                                    fontSize = 12.sp,
                                    color = colors.textSecondary
                                )
                            }
                        }
                    }
                }

                if (filteredSongs.isNotEmpty()) {
                    item {
                        Text(
                            text = "SONGS (${filteredSongs.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E60F2),
                            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp)
                        )
                    }

                    items(filteredSongs, key = { "s_${it.id}" }) { song ->
                        SongItemRow(
                            song = song,
                            isPlaying = isPlaying,
                            isCurrent = currentSong?.id == song.id,
                            isMultiSelectActive = false,
                            isSelected = false,
                            onSongClick = { onSongClick(song) },
                            onSongLongClick = {},
                            onToggleSelect = {},
                            onToggleFavorite = { onToggleFavoriteSong(song) },
                            onPlayNext = { onSongClick(song) },
                            onAddToQueue = { onAddToQueue(song) },
                            onAddToPlaylist = {},
                            onHideInVault = {},
                            onDelete = {}
                        )
                    }
                }

                if (filteredSongs.isEmpty() && filteredVideos.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 60.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No matches found for \"$query\"",
                                color = colors.textSecondary,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
