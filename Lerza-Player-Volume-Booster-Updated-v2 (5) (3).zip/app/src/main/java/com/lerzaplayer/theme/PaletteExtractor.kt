package com.lerzaplayer.theme

import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import kotlin.math.abs

data class DynamicArtPalette(
    val dominantColor: Color,
    val accentColor: Color,
    val deepDarkColor: Color
)

object PaletteExtractor {

    fun extractPalette(bitmap: Bitmap?, seedKey: Long): DynamicArtPalette {
        if (bitmap != null) {
            try {
                val w = bitmap.width
                val h = bitmap.height
                val p1 = bitmap.getPixel(w / 4, h / 4)
                val p2 = bitmap.getPixel(w / 2, h / 2)
                val p3 = bitmap.getPixel(3 * w / 4, 3 * h / 4)

                val c1 = Color(p1)
                val c2 = Color(p2)
                val c3 = Color(p3)

                val dominant = if (isVibrant(c1)) c1 else if (isVibrant(c2)) c2 else c3
                val accent = if (c2 != dominant && isVibrant(c2)) c2 else if (c3 != dominant) c3 else Color(0xFF00E5FF)
                val deep = Color(
                    red = (dominant.red * 0.15f).coerceIn(0.04f, 0.2f),
                    green = (dominant.green * 0.15f).coerceIn(0.04f, 0.2f),
                    blue = (dominant.blue * 0.15f).coerceIn(0.05f, 0.25f),
                    alpha = 1f
                )
                return DynamicArtPalette(dominant, accent, deep)
            } catch (_: Exception) {}
        }

        val hash = abs(seedKey.hashCode())
        val hueList = listOf(
            Triple(Color(0xFF6C5CE7), Color(0xFFA29BFE), Color(0xFF0F0C29)),
            Triple(Color(0xFF00B4D8), Color(0xFF90E0EF), Color(0xFF03071E)),
            Triple(Color(0xFFFF416C), Color(0xFFFF4B2B), Color(0xFF1A0815)),
            Triple(Color(0xFF00B09B), Color(0xFF96C93D), Color(0xFF061A14)),
            Triple(Color(0xFF8E2DE2), Color(0xFF4A00E0), Color(0xFF120524)),
            Triple(Color(0xFFFA709A), Color(0xFFFEE140), Color(0xFF230D18)),
            Triple(Color(0xFF1E60F2), Color(0xFF00E5FF), Color(0xFF090E17))
        )
        val picked = hueList[hash % hueList.size]
        return DynamicArtPalette(picked.first, picked.second, picked.third)
    }

    private fun isVibrant(color: Color): Boolean {
        val max = maxOf(color.red, color.green, color.blue)
        val min = minOf(color.red, color.green, color.blue)
        val saturation = if (max == 0f) 0f else (max - min) / max
        return saturation > 0.25f && max > 0.2f
    }
}
