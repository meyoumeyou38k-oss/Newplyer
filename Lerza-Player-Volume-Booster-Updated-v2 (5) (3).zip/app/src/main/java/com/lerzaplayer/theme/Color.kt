package com.lerzaplayer.theme

import androidx.compose.ui.graphics.Color

data class LerzaColorPalette(
    val primary: Color,
    val background: Color,
    val surface: Color,
    val card: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val isDark: Boolean
)

val AmoledBlackPalette = LerzaColorPalette(
    primary = Color(0xFF00E5FF),
    background = Color(0xFF000000),
    surface = Color(0xFF0D0D11),
    card = Color(0xFF16161D),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFF888899),
    isDark = true
)

val PureWhitePalette = LerzaColorPalette(
    primary = Color(0xFF1E60F2),
    background = Color(0xFFFFFFFF),
    surface = Color(0xFFF5F6FA),
    card = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF111827),
    textSecondary = Color(0xFF6B7280),
    isDark = false
)

val SoftRosePalette = LerzaColorPalette(
    primary = Color(0xFFFF4081),
    background = Color(0xFFFFF0F5),
    surface = Color(0xFFFFE4E1),
    card = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF4A1525),
    textSecondary = Color(0xFF9E4860),
    isDark = false
)

val MintSagePalette = LerzaColorPalette(
    primary = Color(0xFF00C853),
    background = Color(0xFFF0FDF4),
    surface = Color(0xFFDCFCE7),
    card = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF052E16),
    textSecondary = Color(0xFF166534),
    isDark = false
)

val PastelSkyPalette = LerzaColorPalette(
    primary = Color(0xFF00B0FF),
    background = Color(0xFFF0F9FF),
    surface = Color(0xFFE0F2FE),
    card = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF0C4A6E),
    textSecondary = Color(0xFF0369A1),
    isDark = false
)

val SoftLavenderPalette = LerzaColorPalette(
    primary = Color(0xFF7C3AED),
    background = Color(0xFFFAF5FF),
    surface = Color(0xFFF3E8FF),
    card = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF3B0764),
    textSecondary = Color(0xFF6B21A8),
    isDark = false
)

val SunsetAmberPalette = LerzaColorPalette(
    primary = Color(0xFFFF6D00),
    background = Color(0xFFFFFBEB),
    surface = Color(0xFFFEF3C7),
    card = Color(0xFFFFFFFF),
    textPrimary = Color(0xFF451A03),
    textSecondary = Color(0xFF92400E),
    isDark = false
)
