package com.lerzaplayer.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf

val LocalLerzaColors = staticCompositionLocalOf { PureWhitePalette }

@Composable
fun LerzaPlayerTheme(
    themeName: String = "Pure White",
    content: @Composable () -> Unit
) {
    val palette = when (themeName) {
        "AMOLED Black" -> AmoledBlackPalette
        "Pure White" -> PureWhitePalette
        "Soft Rose" -> SoftRosePalette
        "Mint Sage" -> MintSagePalette
        "Pastel Sky" -> PastelSkyPalette
        "Soft Lavender" -> SoftLavenderPalette
        "Sunset Amber" -> SunsetAmberPalette
        else -> PureWhitePalette
    }

    val materialColors = if (palette.isDark) {
        darkColorScheme(
            primary = palette.primary,
            background = palette.background,
            surface = palette.surface,
            onPrimary = palette.background,
            onBackground = palette.textPrimary,
            onSurface = palette.textPrimary
        )
    } else {
        lightColorScheme(
            primary = palette.primary,
            background = palette.background,
            surface = palette.surface,
            onPrimary = palette.background,
            onBackground = palette.textPrimary,
            onSurface = palette.textPrimary
        )
    }

    CompositionLocalProvider(LocalLerzaColors provides palette) {
        MaterialTheme(
            colorScheme = materialColors,
            content = content
        )
    }
}
