package com.lerzaplayer.playback

import android.content.Intent
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.lerzaplayer.data.repository.ThumbnailExtractor
import kotlinx.coroutines.*

class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var playerManager: PlayerManager

    override fun onCreate() {
        super.onCreate()
        playerManager = PlayerManager.getInstance(this)
        mediaSession = MediaSession.Builder(this, playerManager.exoPlayer).build()

        serviceScope.launch {
            playerManager.currentSong.collect {
                updateNotification()
            }
        }
        serviceScope.launch {
            playerManager.isPlaying.collect {
                updateNotification()
            }
        }
        serviceScope.launch {
            playerManager.currentPosition.collect {
                updateNotification()
            }
        }
    }

    private fun updateNotification() {
        val song = playerManager.currentSong.value
        val isPlaying = playerManager.isPlaying.value

        serviceScope.launch(Dispatchers.IO) {
            val art = if (song != null) {
                ThumbnailExtractor.getSongCover(this@PlaybackService, song.contentUri, song.id)
            } else null

            val notif = NotificationHelper.buildMediaNotification(
                this@PlaybackService,
                song,
                isPlaying,
                art,
                playerManager.currentPosition.value,
                playerManager.duration.value
            )
            withContext(Dispatchers.Main) {
                if (isPlaying || song != null) {
                    startForeground(NotificationHelper.NOTIFICATION_ID, notif)
                } else {
                    stopForeground(STOP_FOREGROUND_DETACH)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(
            NotificationHelper.NOTIFICATION_ID,
            NotificationHelper.buildMediaNotification(
                this,
                playerManager.currentSong.value,
                playerManager.isPlaying.value,
                null,
                playerManager.currentPosition.value,
                playerManager.duration.value
            )
        )
        when (intent?.action) {
            ACTION_PLAY -> playerManager.play()
            ACTION_PAUSE -> playerManager.pause()
            ACTION_NEXT -> playerManager.playNextTrack()
            ACTION_PREV -> playerManager.playPreviousTrack()
            ACTION_STOP -> {
                playerManager.pause()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        serviceScope.cancel()
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.lerzaplayer.ACTION_PLAY"
        const val ACTION_PAUSE = "com.lerzaplayer.ACTION_PAUSE"
        const val ACTION_NEXT = "com.lerzaplayer.ACTION_NEXT"
        const val ACTION_PREV = "com.lerzaplayer.ACTION_PREV"
        const val ACTION_STOP = "com.lerzaplayer.ACTION_STOP"
    }
}
