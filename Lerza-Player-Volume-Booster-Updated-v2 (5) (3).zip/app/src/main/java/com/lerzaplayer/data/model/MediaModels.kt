package com.lerzaplayer.data.model

import android.net.Uri

enum class MediaType {
    AUDIO,
    VIDEO
}

data class SongItem(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val contentUri: Uri,
    val albumArtUri: Uri? = null,
    val size: Long = 0L,
    val dateAdded: Long = 0L,
    val path: String = "",
    val mimeType: String = "audio/mpeg",
    val bitRate: Int = 0,
    val isFavorite: Boolean = false,
    val hasLyrics: Boolean = true
) {
    val durationFormatted: String
        get() {
            val totalSec = duration / 1000
            val min = totalSec / 60
            val sec = totalSec % 60
            return "%d:%02d".format(min, sec)
        }

    val codecLabel: String
        get() {
            return when {
                mimeType.contains("mp4") || mimeType.contains("m4a") -> "M4A"
                mimeType.contains("flac") -> "FLAC"
                mimeType.contains("wav") -> "WAV"
                mimeType.contains("ogg") -> "OGG"
                else -> "MP3"
            }
        }

    val folderName: String
        get() {
            if (path.isEmpty()) return "Internal Storage"
            val parts = path.split("/")
            return if (parts.size >= 2) parts[parts.size - 2] else "Music"
        }
}

data class LyricLine(
    val timestampMs: Long,
    val text: String,
    val timeFormatted: String
)

data class SongLyrics(
    val songId: Long,
    val lines: List<LyricLine>,
    val isGenerated: Boolean = false
)

data class PlaylistItem(
    val id: Long,
    val name: String,
    val songCount: Int,
    val isSmart: Boolean = false,
    val iconType: String = "playlist"
)

data class VideoItem(
    val id: Long,
    val title: String,
    val duration: Long,
    val contentUri: Uri,
    val size: Long = 0L,
    val dateAdded: Long = 0L,
    val path: String = "",
    val folderName: String = "Videos",
    val resolution: String = "HD",
    val isFavorite: Boolean = false
) {
    val durationFormatted: String
        get() {
            val totalSec = duration / 1000
            val hours = totalSec / 3600
            val min = (totalSec % 3600) / 60
            val sec = totalSec % 60
            return if (hours > 0) {
                "%d:%02d:%02d".format(hours, min, sec)
            } else {
                "%d:%02d".format(min, sec)
            }
        }
}

data class AlbumItem(
    val id: Long,
    val name: String,
    val artist: String,
    val songCount: Int,
    val albumArtUri: Uri? = null
)

data class ArtistItem(
    val id: Long,
    val name: String,
    val trackCount: Int,
    val albumCount: Int
)

data class FolderItem(
    val path: String,
    val name: String,
    val songCount: Int,
    val videoCount: Int
)

enum class SortOption(val displayName: String) {
    DATE_ADDED_DESC("Date Added"),
    TITLE_ASC("Title (A-Z)"),
    ARTIST_ASC("Artist"),
    DURATION_DESC("Duration"),
    SIZE_DESC("File Size")
}

enum class ViewMode {
    LIST,
    GRID
}

enum class VaultLockType {
    PIN,
    PATTERN
}

data class WallpaperPreset(
    val id: String,
    val name: String,
    val primaryColor: Long,
    val secondaryColor: Long,
    val previewGradient: List<Long>,
    val imageUrl: String? = null
)
