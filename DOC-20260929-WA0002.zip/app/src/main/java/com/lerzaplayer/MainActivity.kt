package com.lerzaplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.FavoriteEntity
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.repository.DeletionResult
import com.lerzaplayer.data.repository.MediaRepository
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaPlayerTheme
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.theme.ThemeManager
import com.lerzaplayer.ui.home.HomeScreen
import com.lerzaplayer.ui.player.FullPlayerScreen
import com.lerzaplayer.ui.player.VideoPlayerScreen
import com.lerzaplayer.ui.search.SearchScreen
import com.lerzaplayer.ui.settings.SettingsScreen
import com.lerzaplayer.ui.settings.ThemeScreen
import com.lerzaplayer.ui.vault.VaultScreen
import com.lerzaplayer.ui.update.UpdateDialog
import com.lerzaplayer.update.AppUpdateManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

enum class AppDestination {
    HOME,
    SETTINGS,
    VAULT,
    SEARCH,
    THEME
}

class MainActivity : ComponentActivity() {
    private lateinit var mediaRepository: MediaRepository
    private lateinit var playerManager: PlayerManager
    private var isVolumePopupVisible by mutableStateOf(false)
    private var currentVolumePercent by mutableIntStateOf(100)
    private var volumeDismissJob: Job? = null
    private var pendingDeleteEntity: RecentlyDeletedEntity? = null

    // پرمیشن لانچر برائے میڈیا اور نوٹیفکیشن
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (::mediaRepository.isInitialized) mediaRepository.refreshMedia()
    }

    // 🌟 ایپ انسٹال کرنے والی پرمیشن لانچر (Request Install Packages Launcher)
    private val installPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        // پرمیشن کا نتیجہ ملنے پر
    }

    private val scopedStorageDeleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            pendingDeleteEntity?.let { entity ->
                lifecycleScope.launch {
                    mediaRepository.confirmPendingDeletion(entity)
                    Toast.makeText(this@MainActivity, "Moved to Recently Deleted (30 days)", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            pendingDeleteEntity?.let { entity ->
                lifecycleScope.launch {
                    mediaRepository.cancelPendingDeletion(entity)
                }
            }
        }
        pendingDeleteEntity = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ThemeManager.init(this)

        val app = application as LerzaApp
        mediaRepository = MediaRepository(this)
        playerManager = app.playerManager
        playerManager.syncVolumeFromSystem()
        currentVolumePercent = playerManager.loudnessGain.value

        // 🌟 ایپ شروع ہوتے ہی تمام مطلوبہ پرمیشنز طلب کریں (بشمول انسٹال پرمیشن)
        requestRequiredPermissions()

        // 🌟 ایپ سٹارٹ ہوتے ہی بیک گراؤنڈ میں لائیو Vercel ویب سائٹ سے اپڈیٹ چیک کریں
        lifecycleScope.launch {
            try {
                AppUpdateManager.checkForUpdates(this@MainActivity)
            } catch (_: Exception) {}
        }

        setContent {
            val prefManager = app.preferenceManager
            val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
            val scope = rememberCoroutineScope()
            val songs by mediaRepository.getSongsFlow(songSort).collectAsState(initial = emptyList())
            val videos by mediaRepository.getVideosFlow(SortOption.DATE_ADDED_DESC).collectAsState(initial = emptyList())
            val recentlyDeleted by mediaRepository.getRecentlyDeletedFlow().collectAsState(initial = emptyList())
            val activeLoudnessGain by playerManager.loudnessGain.collectAsState()

            LaunchedEffect(activeLoudnessGain) {
                currentVolumePercent = activeLoudnessGain
            }

            var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
            var isFullPlayerVisible by remember { mutableStateOf(false) }
            var activePlayingVideo by remember { mutableStateOf<VideoItem?>(null) }
            var songToDeleteConfirm by remember { mutableStateOf<SongItem?>(null) }
            var videoToDeleteConfirm by remember { mutableStateOf<VideoItem?>(null) }

            BackHandler(enabled = activePlayingVideo != null) {
                activePlayingVideo = null
            }
            BackHandler(enabled = activePlayingVideo == null && isFullPlayerVisible) {
                isFullPlayerVisible = false
            }
            BackHandler(enabled = activePlayingVideo == null && !isFullPlayerVisible && currentDestination != AppDestination.HOME) {
                currentDestination = if (currentDestination == AppDestination.THEME) AppDestination.SETTINGS else AppDestination.HOME
            }

            LerzaPlayerTheme(themeColor = ThemeManager.currentThemeColor) {
                val themeColors = LocalLerzaColors.current
                SideEffect {
                    window.statusBarColor = themeColors.surface.toArgb()
                    window.navigationBarColor = themeColors.background.toArgb()
                    WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !themeColors.isDark
                    WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !themeColors.isDark
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    when (currentDestination) {
                        AppDestination.HOME -> {
                            HomeScreen(
                                songs = songs,
                                videos = videos,
                                playerManager = playerManager,
                                prefManager = prefManager,
                                onSearchClick = { currentDestination = AppDestination.SEARCH },
                                onSettingsClick = { currentDestination = AppDestination.SETTINGS },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                onSongClick = { song ->
                                    playerManager.playSong(song, songs)
                                    isFullPlayerVisible = true
                                },
                                onVideoClick = { video ->
                                    activePlayingVideo = video
                                },
                                onSongDelete = { song ->
                                    songToDeleteConfirm = song
                                }
                            )
                        }
                        AppDestination.SETTINGS -> {
                            SettingsScreen(
                                prefManager = prefManager,
                                playerManager = playerManager,
                                onBackClick = { currentDestination = AppDestination.HOME },
                                onOpenThemeSelector = { currentDestination = AppDestination.THEME },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                recentlyDeletedCount = recentlyDeleted.size
                            )
                        }
                        AppDestination.THEME -> {
                            ThemeScreen(
                                onBackClick = { currentDestination = AppDestination.SETTINGS }
                            )
                        }
                        AppDestination.VAULT -> {
                            VaultScreen(
                                onBackClick = { currentDestination = AppDestination.HOME },
                                onPlaySong = { song ->
                                    playerManager.playSong(song)
                                    isFullPlayerVisible = true
                                }
                            )
                        }
                        AppDestination.SEARCH -> {
                            SearchScreen(
                                songs = songs,
                                videos = videos,
                                onBackClick = { currentDestination = AppDestination.HOME },
                                onSongClick = { song ->
                                    playerManager.playSong(song, songs)
                                    isFullPlayerVisible = true
                                },
                                onVideoClick = { video ->
                                    activePlayingVideo = video
                                }
                            )
                        }
                    }

                    // Bottom Mini Player
                    if (currentDestination == AppDestination.HOME && !isFullPlayerVisible && activePlayingVideo == null) {
                        MiniPlayer(
                            playerManager = playerManager,
                            onClick = { isFullPlayerVisible = true },
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                        )
                    }

                    // Full Screen Music Player
                    AnimatedVisibility(
                        visible = isFullPlayerVisible,
                        enter = slideInVertically(initialOffsetY = { it }),
                        exit = slideOutVertically(targetOffsetY = { it })
                    ) {
                        FullPlayerScreen(
                            playerManager = playerManager,
                            onClose = { isFullPlayerVisible = false },
                            onToggleFavorite = { song ->
                                scope.launch {
                                    val favDao = AppDatabase.getDatabase(this@MainActivity).favoriteDao()
                                    if (song.isFavorite) {
                                        favDao.removeFavorite(song.id, "AUDIO")
                                    } else {
                                        favDao.addFavorite(FavoriteEntity(song.id, "AUDIO"))
                                    }
                                }
                            }
                        )
                    }

                    // Video Player Overlay
                    activePlayingVideo?.let { vid ->
                        VideoPlayerScreen(
                            video = vid,
                            onClose = { activePlayingVideo = null },
                            onPreviousVideo = {
                                val index = videos.indexOfFirst { it.id == vid.id }
                                if (index > 0) activePlayingVideo = videos[index - 1]
                            },
                            onNextVideo = {
                                val index = videos.indexOfFirst { it.id == vid.id }
                                if (index >= 0 && index < videos.lastIndex) {
                                    activePlayingVideo = videos[index + 1]
                                }
                            },
                            onPlayAsAudio = {
                                playerManager.playSong(
                                    SongItem(
                                        id = vid.id,
                                        title = vid.title,
                                        artist = "Video audio",
                                        album = vid.folderName,
                                        duration = vid.duration,
                                        contentUri = vid.contentUri,
                                        albumArtUri = vid.contentUri,
                                        size = vid.size,
                                        path = vid.path,
                                        mimeType = "audio/*"
                                    )
                                )
                                activePlayingVideo = null
                                isFullPlayerVisible = true
                            },
                            onDeleteVideo = {
                                videoToDeleteConfirm = vid
                            }
                        )
                    }

                    // Global Volume Popup
                    AnimatedVisibility(
                        visible = isVolumePopupVisible,
                        enter = fadeIn() + slideInVertically(initialOffsetY = { -50 }),
                        exit = fadeOut() + slideOutVertically(targetOffsetY = { -50 }),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 48.dp)
                    ) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.85f)),
                            modifier = Modifier
                                .padding(horizontal = 24.dp)
                                .fillMaxWidth(0.85f)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Volume Boost: $currentVolumePercent%",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Slider(
                                    value = currentVolumePercent.toFloat(),
                                    onValueChange = { newValue ->
                                        currentVolumePercent = newValue.toInt()
                                        playerManager.setLoudnessGain(currentVolumePercent)
                                        triggerVolumePopup()
                                    },
                                    valueRange = 1f..300f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = themeColors.primary,
                                        activeTrackColor = themeColors.primary
                                    )
                                )
                            }
                        }
                    }

                    // 🌟 IN-APP OTA UPDATE DIALOG POPUP (Without Chrome!)
                    val activeUpdate by AppUpdateManager.availableUpdate.collectAsState()
                    activeUpdate?.let { updateInfo ->
                        UpdateDialog(
                            updateInfo = updateInfo,
                            onDismiss = { AppUpdateManager.dismissUpdate() }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::playerManager.isInitialized) {
            playerManager.syncVolumeFromSystem()
            currentVolumePercent = playerManager.loudnessGain.value
        }
    }

    private fun triggerVolumePopup() {
        isVolumePopupVisible = true
        volumeDismissJob?.cancel()
        volumeDismissJob = lifecycleScope.launch {
            delay(1500)
            isVolumePopupVisible = false
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                playerManager.syncVolumeFromSystem()
                val targetVol = (playerManager.loudnessGain.value + 10).coerceAtMost(300)
                currentVolumePercent = targetVol
                playerManager.setLoudnessGain(targetVol)
                triggerVolumePopup()
                return true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                playerManager.syncVolumeFromSystem()
                val targetVol = (playerManager.loudnessGain.value - 10).coerceAtLeast(1)
                currentVolumePercent = targetVol
                playerManager.setLoudnessGain(targetVol)
                triggerVolumePopup()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    /**
     * 🌟 تمام مطلوبہ پرمیشنز بشمول انسٹال پرمیشن مانگنے کا فنکشن
     */
    private fun requestRequiredPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }

        // Manage All Files Access (Android 11+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        startActivity(intent)
                    } catch (_: Exception) {}
                }
            }
        }

        // 🌟 خودکار طریقہ: شروع میں ہی ایپ انسٹال کرنے والی پرمیشن مانگیں (Android 8.0+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!packageManager.canRequestPackageInstalls()) {
                try {
                    val installIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    installPermissionLauncher.launch(installIntent)
                } catch (_: Exception) {}
            }
        }
    }
}