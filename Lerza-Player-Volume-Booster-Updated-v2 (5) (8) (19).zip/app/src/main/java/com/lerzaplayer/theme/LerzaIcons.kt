package com.lerzaplayer.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object LerzaIcons {

    val Play: ImageVector = ImageVector.Builder(
        name = "Play",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(8f, 5f)
            verticalLineTo(19f)
            lineTo(19f, 12f)
            close()
        }
    }.build()

    val Pause: ImageVector = ImageVector.Builder(
        name = "Pause",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 19f)
            horizontalLineTo(10f)
            verticalLineTo(5f)
            horizontalLineTo(6f)
            verticalLineTo(19f)
            close()
            moveTo(14f, 5f)
            verticalLineTo(19f)
            horizontalLineTo(18f)
            verticalLineTo(5f)
            horizontalLineTo(14f)
            close()
        }
    }.build()

    val SkipNext: ImageVector = ImageVector.Builder(
        name = "SkipNext",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 18f)
            lineTo(14.5f, 12f)
            lineTo(6f, 6f)
            verticalLineTo(18f)
            close()
            moveTo(16f, 6f)
            verticalLineTo(18f)
            horizontalLineTo(18f)
            verticalLineTo(6f)
            horizontalLineTo(16f)
            close()
        }
    }.build()

    val SkipPrevious: ImageVector = ImageVector.Builder(
        name = "SkipPrevious",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 6f)
            horizontalLineTo(8f)
            verticalLineTo(18f)
            horizontalLineTo(6f)
            close()
            moveTo(9.5f, 12f)
            lineTo(18f, 18f)
            verticalLineTo(6f)
            lineTo(9.5f, 12f)
            close()
        }
    }.build()

    val Shuffle: ImageVector = ImageVector.Builder(
        name = "Shuffle",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(10.59f, 9.17f)
            lineTo(5.41f, 4f)
            lineTo(4f, 5.41f)
            lineTo(9.17f, 10.59f)
            lineTo(10.59f, 9.17f)
            close()
            moveTo(14.5f, 4f)
            lineTo(16.54f, 6.04f)
            lineTo(4f, 18.59f)
            lineTo(5.41f, 20f)
            lineTo(17.96f, 7.46f)
            lineTo(20f, 9.5f)
            verticalLineTo(4f)
            horizontalLineTo(14.5f)
            close()
            moveTo(14.83f, 13.41f)
            lineTo(13.42f, 14.83f)
            lineTo(16.55f, 17.95f)
            lineTo(14.5f, 20f)
            horizontalLineTo(20f)
            verticalLineTo(14.5f)
            lineTo(17.96f, 16.54f)
            lineTo(14.83f, 13.41f)
            close()
        }
    }.build()

    val Repeat: ImageVector = ImageVector.Builder(
        name = "Repeat",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(7f, 7f)
            horizontalLineTo(17f)
            verticalLineTo(10f)
            lineTo(21f, 6f)
            lineTo(17f, 2f)
            verticalLineTo(5f)
            horizontalLineTo(5f)
            verticalLineTo(11f)
            horizontalLineTo(7f)
            verticalLineTo(7f)
            close()
            moveTo(17f, 17f)
            horizontalLineTo(7f)
            verticalLineTo(14f)
            lineTo(3f, 18f)
            lineTo(7f, 22f)
            verticalLineTo(19f)
            horizontalLineTo(19f)
            verticalLineTo(13f)
            horizontalLineTo(17f)
            verticalLineTo(17f)
            close()
        }
    }.build()

    val RepeatOne: ImageVector = ImageVector.Builder(
        name = "RepeatOne",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(7f, 7f)
            horizontalLineTo(17f)
            verticalLineTo(10f)
            lineTo(21f, 6f)
            lineTo(17f, 2f)
            verticalLineTo(5f)
            horizontalLineTo(5f)
            verticalLineTo(11f)
            horizontalLineTo(7f)
            verticalLineTo(7f)
            close()
            moveTo(17f, 17f)
            horizontalLineTo(7f)
            verticalLineTo(14f)
            lineTo(3f, 18f)
            lineTo(7f, 22f)
            verticalLineTo(19f)
            horizontalLineTo(19f)
            verticalLineTo(13f)
            horizontalLineTo(17f)
            verticalLineTo(17f)
            close()
        }
        path(fill = SolidColor(Color.White)) {
            moveTo(13f, 15f)
            verticalLineTo(9f)
            horizontalLineTo(12f)
            lineTo(10f, 10f)
            verticalLineTo(11f)
            lineTo(11.5f, 10.25f)
            verticalLineTo(15f)
            horizontalLineTo(13f)
            close()
        }
    }.build()

    val QueueMusic: ImageVector = ImageVector.Builder(
        name = "QueueMusic",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(15f, 6f)
            horizontalLineTo(3f)
            verticalLineTo(8f)
            horizontalLineTo(15f)
            verticalLineTo(6f)
            close()
            moveTo(15f, 10f)
            horizontalLineTo(3f)
            verticalLineTo(12f)
            horizontalLineTo(15f)
            verticalLineTo(10f)
            close()
            moveTo(3f, 16f)
            horizontalLineTo(11f)
            verticalLineTo(14f)
            horizontalLineTo(3f)
            verticalLineTo(16f)
            close()
            moveTo(17f, 6f)
            verticalLineTo(14.18f)
            curveTo(16.69f, 14.07f, 16.35f, 14f, 16f, 14f)
            curveTo(14.34f, 14f, 13f, 15.34f, 13f, 17f)
            curveTo(13f, 18.66f, 14.34f, 20f, 16f, 20f)
            curveTo(17.66f, 20f, 19f, 18.66f, 19f, 17f)
            verticalLineTo(8f)
            horizontalLineTo(22f)
            verticalLineTo(6f)
            horizontalLineTo(17f)
            close()
        }
    }.build()

    val Tune: ImageVector = ImageVector.Builder(
        name = "Tune",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(3f, 17f)
            verticalLineTo(19f)
            horizontalLineTo(9f)
            verticalLineTo(17f)
            horizontalLineTo(3f)
            close()
            moveTo(3f, 5f)
            verticalLineTo(7f)
            horizontalLineTo(13f)
            verticalLineTo(5f)
            horizontalLineTo(3f)
            close()
            moveTo(13f, 21f)
            verticalLineTo(19f)
            horizontalLineTo(21f)
            verticalLineTo(17f)
            horizontalLineTo(13f)
            verticalLineTo(15f)
            horizontalLineTo(11f)
            verticalLineTo(21f)
            horizontalLineTo(13f)
            close()
            moveTo(7f, 9f)
            verticalLineTo(11f)
            horizontalLineTo(3f)
            verticalLineTo(13f)
            horizontalLineTo(7f)
            verticalLineTo(15f)
            horizontalLineTo(9f)
            verticalLineTo(9f)
            horizontalLineTo(7f)
            close()
            moveTo(21f, 13f)
            verticalLineTo(11f)
            horizontalLineTo(11f)
            verticalLineTo(13f)
            horizontalLineTo(21f)
            close()
            moveTo(15f, 9f)
            horizontalLineTo(17f)
            verticalLineTo(7f)
            horizontalLineTo(21f)
            verticalLineTo(5f)
            horizontalLineTo(17f)
            verticalLineTo(3f)
            horizontalLineTo(15f)
            verticalLineTo(9f)
            close()
        }
    }.build()

    val MusicNote: ImageVector = ImageVector.Builder(
        name = "MusicNote",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f)
            verticalLineTo(13.55f)
            curveTo(11.41f, 13.21f, 10.73f, 13f, 10f, 13f)
            curveTo(7.79f, 13f, 6f, 14.79f, 6f, 17f)
            curveTo(6f, 19.21f, 7.79f, 21f, 10f, 21f)
            curveTo(12.21f, 21f, 14f, 19.21f, 14f, 17f)
            verticalLineTo(7f)
            horizontalLineTo(18f)
            verticalLineTo(3f)
            horizontalLineTo(12f)
            close()
        }
    }.build()

    val Lyrics: ImageVector = ImageVector.Builder(
        name = "Lyrics",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f)
            verticalLineTo(12.55f)
            curveTo(11.41f, 12.21f, 10.73f, 12f, 10f, 12f)
            curveTo(7.79f, 12f, 6f, 13.79f, 6f, 16f)
            curveTo(6f, 18.21f, 7.79f, 20f, 10f, 20f)
            curveTo(12.21f, 20f, 14f, 18.21f, 14f, 16f)
            verticalLineTo(7f)
            horizontalLineTo(18f)
            verticalLineTo(3f)
            horizontalLineTo(12f)
            close()
            moveTo(3f, 6f)
            horizontalLineTo(9f)
            verticalLineTo(8f)
            horizontalLineTo(3f)
            close()
            moveTo(3f, 10f)
            horizontalLineTo(9f)
            verticalLineTo(12f)
            horizontalLineTo(3f)
            close()
        }
    }.build()

    val LockOpen: ImageVector = ImageVector.Builder(
        name = "LockOpen",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 17f)
            curveTo(13.1f, 17f, 14f, 16.1f, 14f, 15f)
            curveTo(14f, 13.9f, 13.1f, 13f, 12f, 13f)
            curveTo(10.9f, 13f, 10f, 13.9f, 10f, 15f)
            curveTo(10f, 16.1f, 10.9f, 17f, 12f, 17f)
            close()
            moveTo(18f, 8f)
            horizontalLineTo(17f)
            verticalLineTo(6f)
            curveTo(17f, 3.24f, 14.76f, 1f, 12f, 1f)
            curveTo(9.24f, 1f, 7f, 3.24f, 7f, 6f)
            horizontalLineTo(8.9f)
            curveTo(8.9f, 4.29f, 10.29f, 2.9f, 12f, 2.9f)
            curveTo(13.71f, 2.9f, 15.1f, 4.29f, 15.1f, 6f)
            verticalLineTo(8f)
            horizontalLineTo(6f)
            curveTo(4.9f, 8f, 4f, 8.9f, 4f, 10f)
            verticalLineTo(20f)
            curveTo(4f, 21.1f, 4.9f, 22f, 6f, 22f)
            horizontalLineTo(18f)
            curveTo(19.1f, 22f, 20f, 21.1f, 20f, 20f)
            verticalLineTo(10f)
            curveTo(20f, 8.9f, 19.1f, 8f, 18f, 8f)
            close()
            moveTo(18f, 20f)
            horizontalLineTo(6f)
            verticalLineTo(10f)
            horizontalLineTo(18f)
            verticalLineTo(20f)
            close()
        }
    }.build()

    val ScreenRotation: ImageVector = ImageVector.Builder(
        name = "ScreenRotation",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(16.48f, 2.52f)
            curveTo(17.26f, 3.3f, 17.65f, 4.28f, 17.65f, 5.26f)
            horizontalLineTo(19.65f)
            curveTo(19.65f, 3.74f, 19.06f, 2.22f, 17.89f, 1.05f)
            curveTo(15.55f, -1.29f, 11.75f, -1.29f, 9.41f, 1.05f)
            lineTo(8f, 2.46f)
            verticalLineTo(0f)
            horizontalLineTo(6f)
            verticalLineTo(6f)
            horizontalLineTo(12f)
            verticalLineTo(4f)
            horizontalLineTo(9.41f)
            lineTo(10.82f, 2.59f)
            curveTo(12.38f, 1.03f, 14.92f, 1.03f, 16.48f, 2.52f)
            close()
            moveTo(7.52f, 21.48f)
            curveTo(6.74f, 20.7f, 6.35f, 19.72f, 6.35f, 18.74f)
            horizontalLineTo(4.35f)
            curveTo(4.35f, 20.26f, 4.94f, 21.78f, 6.11f, 22.95f)
            curveTo(8.45f, 25.29f, 12.25f, 25.29f, 14.59f, 22.95f)
            lineTo(16f, 21.54f)
            verticalLineTo(24f)
            horizontalLineTo(18f)
            verticalLineTo(18f)
            horizontalLineTo(12f)
            verticalLineTo(20f)
            horizontalLineTo(14.59f)
            lineTo(13.18f, 21.41f)
            curveTo(11.62f, 22.97f, 9.08f, 22.97f, 7.52f, 21.48f)
            close()
        }
    }.build()

    val AspectRatio: ImageVector = ImageVector.Builder(
        name = "AspectRatio",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(19f, 4f)
            horizontalLineTo(5f)
            curveTo(3.9f, 4f, 3f, 4.9f, 3f, 6f)
            verticalLineTo(18f)
            curveTo(3f, 19.1f, 3.9f, 20f, 5f, 20f)
            horizontalLineTo(19f)
            curveTo(20.1f, 20f, 21f, 19.1f, 21f, 18f)
            verticalLineTo(6f)
            curveTo(21f, 4.9f, 20.1f, 4f, 19f, 4f)
            close()
            moveTo(19f, 18f)
            horizontalLineTo(5f)
            verticalLineTo(6f)
            horizontalLineTo(19f)
            verticalLineTo(18f)
            close()
            moveTo(5f, 7f)
            horizontalLineTo(9f)
            verticalLineTo(9f)
            horizontalLineTo(7f)
            verticalLineTo(11f)
            horizontalLineTo(5f)
            verticalLineTo(7f)
            close()
            moveTo(19f, 17f)
            horizontalLineTo(15f)
            verticalLineTo(15f)
            horizontalLineTo(17f)
            verticalLineTo(13f)
            horizontalLineTo(19f)
            verticalLineTo(17f)
            close()
        }
    }.build()

    val Folder: ImageVector = ImageVector.Builder(
        name = "Folder",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(10f, 4f)
            horizontalLineTo(4f)
            curveTo(2.9f, 4f, 2f, 4.9f, 2f, 6f)
            verticalLineTo(18f)
            curveTo(2f, 19.1f, 2.9f, 20f, 4f, 20f)
            horizontalLineTo(20f)
            curveTo(21.1f, 20f, 22f, 19.1f, 22f, 18f)
            verticalLineTo(8f)
            curveTo(22f, 6.9f, 21.1f, 6f, 20f, 6f)
            horizontalLineTo(12f)
            lineTo(10f, 4f)
            close()
        }
    }.build()

    val Videocam: ImageVector = ImageVector.Builder(
        name = "Videocam",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(17f, 10.5f)
            verticalLineTo(7f)
            curveTo(17f, 6.45f, 16.55f, 6f, 16f, 6f)
            horizontalLineTo(4f)
            curveTo(3.45f, 6f, 3f, 6.45f, 3f, 7f)
            verticalLineTo(17f)
            curveTo(3f, 17.55f, 3.45f, 18f, 4f, 18f)
            horizontalLineTo(16f)
            curveTo(16.55f, 18f, 17f, 17.55f, 17f, 17f)
            verticalLineTo(13.5f)
            lineTo(21f, 17.5f)
            verticalLineTo(6.5f)
            lineTo(17f, 10.5f)
            close()
        }
    }.build()

    val Audiotrack: ImageVector = ImageVector.Builder(
        name = "Audiotrack",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f)
            verticalLineTo(13.55f)
            curveTo(11.41f, 13.21f, 10.73f, 13f, 10f, 13f)
            curveTo(7.79f, 13f, 6f, 14.79f, 6f, 17f)
            curveTo(6f, 19.21f, 7.79f, 21f, 10f, 21f)
            curveTo(12.21f, 21f, 14f, 19.21f, 14f, 17f)
            verticalLineTo(7f)
            horizontalLineTo(18f)
            verticalLineTo(3f)
            horizontalLineTo(12f)
            close()
        }
    }.build()

    val SwapVert: ImageVector = ImageVector.Builder(
        name = "SwapVert",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(16f, 17.01f)
            verticalLineTo(10f)
            horizontalLineTo(14f)
            verticalLineTo(17.01f)
            horizontalLineTo(11f)
            lineTo(15f, 21f)
            lineTo(19f, 17.01f)
            horizontalLineTo(16f)
            close()
            moveTo(9f, 3f)
            lineTo(5f, 6.99f)
            horizontalLineTo(8f)
            verticalLineTo(14f)
            horizontalLineTo(10f)
            verticalLineTo(6.99f)
            horizontalLineTo(13f)
            lineTo(9f, 3f)
            close()
        }
    }.build()

    val ViewList: ImageVector = ImageVector.Builder(
        name = "ViewList",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(4f, 14f)
            horizontalLineTo(8f)
            verticalLineTo(10f)
            horizontalLineTo(4f)
            verticalLineTo(14f)
            close()
            moveTo(4f, 19f)
            horizontalLineTo(8f)
            verticalLineTo(15f)
            horizontalLineTo(4f)
            verticalLineTo(19f)
            close()
            moveTo(4f, 9f)
            horizontalLineTo(8f)
            verticalLineTo(5f)
            horizontalLineTo(4f)
            verticalLineTo(9f)
            close()
            moveTo(9f, 14f)
            horizontalLineTo(21f)
            verticalLineTo(10f)
            horizontalLineTo(9f)
            verticalLineTo(14f)
            close()
            moveTo(9f, 19f)
            horizontalLineTo(21f)
            verticalLineTo(15f)
            horizontalLineTo(9f)
            verticalLineTo(19f)
            close()
            moveTo(9f, 5f)
            verticalLineTo(9f)
            horizontalLineTo(21f)
            verticalLineTo(5f)
            horizontalLineTo(9f)
            close()
        }
    }.build()

    val GridView: ImageVector = ImageVector.Builder(
        name = "GridView",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(3f, 3f)
            verticalLineTo(11f)
            horizontalLineTo(11f)
            verticalLineTo(3f)
            horizontalLineTo(3f)
            close()
            moveTo(9f, 9f)
            horizontalLineTo(5f)
            verticalLineTo(5f)
            horizontalLineTo(9f)
            verticalLineTo(9f)
            close()
            moveTo(13f, 3f)
            verticalLineTo(11f)
            horizontalLineTo(21f)
            verticalLineTo(3f)
            horizontalLineTo(13f)
            close()
            moveTo(19f, 9f)
            horizontalLineTo(15f)
            verticalLineTo(5f)
            horizontalLineTo(19f)
            verticalLineTo(9f)
            close()
            moveTo(3f, 13f)
            verticalLineTo(21f)
            horizontalLineTo(11f)
            verticalLineTo(13f)
            horizontalLineTo(3f)
            close()
            moveTo(9f, 19f)
            horizontalLineTo(5f)
            verticalLineTo(15f)
            horizontalLineTo(9f)
            verticalLineTo(19f)
            close()
            moveTo(13f, 13f)
            verticalLineTo(21f)
            horizontalLineTo(21f)
            verticalLineTo(13f)
            horizontalLineTo(13f)
            close()
            moveTo(19f, 19f)
            horizontalLineTo(15f)
            verticalLineTo(15f)
            horizontalLineTo(19f)
            verticalLineTo(19f)
            close()
        }
    }.build()

    val VisibilityOff: ImageVector = ImageVector.Builder(
        name = "VisibilityOff",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 7f)
            curveTo(13.37f, 7f, 14.59f, 7.57f, 15.48f, 8.48f)
            lineTo(18.31f, 5.65f)
            curveTo(16.63f, 4.35f, 14.47f, 3.5f, 12f, 3.5f)
            curveTo(7f, 3.5f, 2.73f, 6.61f, 1f, 11f)
            curveTo(1.88f, 13.23f, 3.37f, 15.11f, 5.25f, 16.42f)
            lineTo(7.7f, 13.97f)
            curveTo(7.26f, 13.39f, 7f, 12.72f, 7f, 12f)
            curveTo(7f, 9.24f, 9.24f, 7f, 12f, 7f)
            close()
            moveTo(2f, 4.27f)
            lineTo(4.28f, 6.55f)
            lineTo(4.73f, 7f)
            curveTo(3.08f, 8.3f, 1.78f, 10.02f, 1f, 12f)
            curveTo(2.73f, 16.39f, 7f, 19.5f, 12f, 19.5f)
            curveTo(13.55f, 19.5f, 15.03f, 19.2f, 16.38f, 18.66f)
            lineTo(16.73f, 19.01f)
            lineTo(19.73f, 22.01f)
            lineTo(21f, 20.74f)
            lineTo(3.27f, 3f)
            lineTo(2f, 4.27f)
            close()
        }
    }.build()

    val Palette: ImageVector = ImageVector.Builder(
        name = "Palette",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f)
            curveTo(6.5f, 3f, 2f, 6.5f, 2f, 12f)
            curveTo(2f, 15.5f, 4.5f, 18.5f, 8f, 19.5f)
            curveTo(8.5f, 19.6f, 9f, 19.2f, 9f, 18.7f)
            verticalLineTo(17.5f)
            curveTo(9f, 16.1f, 10.1f, 15f, 11.5f, 15f)
            horizontalLineTo(13f)
            curveTo(17.4f, 15f, 21f, 11.4f, 21f, 7f)
            curveTo(21f, 4.8f, 17f, 3f, 12f, 3f)
            close()
            moveTo(6.5f, 11.5f)
            curveTo(5.7f, 11.5f, 5f, 10.8f, 5f, 10f)
            curveTo(5f, 9.2f, 5.7f, 8.5f, 6.5f, 8.5f)
            curveTo(7.3f, 8.5f, 8f, 9.2f, 8f, 10f)
            curveTo(8f, 10.8f, 7.3f, 11.5f, 6.5f, 11.5f)
            close()
            moveTo(9.5f, 7.5f)
            curveTo(8.7f, 7.5f, 8f, 6.8f, 8f, 6f)
            curveTo(8f, 5.2f, 8.7f, 4.5f, 9.5f, 4.5f)
            curveTo(10.3f, 4.5f, 11f, 5.2f, 11f, 6f)
            curveTo(11f, 6.8f, 10.3f, 7.5f, 9.5f, 7.5f)
            close()
            moveTo(14.5f, 7.5f)
            curveTo(13.7f, 7.5f, 13f, 6.8f, 13f, 6f)
            curveTo(13f, 5.2f, 13.7f, 4.5f, 14.5f, 4.5f)
            curveTo(15.3f, 4.5f, 16f, 5.2f, 16f, 6f)
            curveTo(16f, 6.8f, 15.3f, 7.5f, 14.5f, 7.5f)
            close()
            moveTo(17.5f, 11.5f)
            curveTo(16.7f, 11.5f, 16f, 10.8f, 16f, 10f)
            curveTo(16f, 9.2f, 16.7f, 8.5f, 17.5f, 8.5f)
            curveTo(18.3f, 8.5f, 19f, 9.2f, 19f, 10f)
            curveTo(19f, 10.8f, 18.3f, 11.5f, 17.5f, 11.5f)
            close()
        }
    }.build()

    val Wallpaper: ImageVector = ImageVector.Builder(
        name = "Wallpaper",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(4f, 4f)
            horizontalLineTo(7f)
            verticalLineTo(2f)
            horizontalLineTo(4f)
            curveTo(2.9f, 2f, 2f, 2.9f, 2f, 4f)
            verticalLineTo(7f)
            horizontalLineTo(4f)
            verticalLineTo(4f)
            close()
            moveTo(4f, 17f)
            horizontalLineTo(2f)
            verticalLineTo(20f)
            curveTo(2f, 21.1f, 2.9f, 22f, 4f, 22f)
            horizontalLineTo(7f)
            verticalLineTo(20f)
            horizontalLineTo(4f)
            verticalLineTo(17f)
            close()
            moveTo(20f, 20f)
            horizontalLineTo(17f)
            verticalLineTo(22f)
            horizontalLineTo(20f)
            curveTo(21.1f, 22f, 22f, 21.1f, 22f, 20f)
            verticalLineTo(17f)
            horizontalLineTo(20f)
            verticalLineTo(20f)
            close()
            moveTo(20f, 4f)
            verticalLineTo(7f)
            horizontalLineTo(22f)
            verticalLineTo(4f)
            curveTo(22f, 2.9f, 21.1f, 2f, 20f, 2f)
            horizontalLineTo(17f)
            verticalLineTo(4f)
            horizontalLineTo(20f)
            close()
            moveTo(10f, 13f)
            lineTo(7f, 17f)
            horizontalLineTo(17f)
            lineTo(13.5f, 12.5f)
            lineTo(11f, 15.5f)
            lineTo(10f, 13f)
            close()
        }
    }.build()

    val AddPhoto: ImageVector = ImageVector.Builder(
        name = "AddPhoto",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(19f, 7f)
            verticalLineTo(4f)
            horizontalLineTo(17f)
            verticalLineTo(7f)
            horizontalLineTo(14f)
            verticalLineTo(9f)
            horizontalLineTo(17f)
            verticalLineTo(12f)
            horizontalLineTo(19f)
            verticalLineTo(9f)
            horizontalLineTo(22f)
            verticalLineTo(7f)
            horizontalLineTo(19f)
            close()
            moveTo(16f, 11.5f)
            verticalLineTo(14f)
            horizontalLineTo(5f)
            verticalLineTo(5f)
            horizontalLineTo(13.5f)
            verticalLineTo(3f)
            horizontalLineTo(5f)
            curveTo(3.9f, 3f, 3f, 3.9f, 3f, 5f)
            verticalLineTo(19f)
            curveTo(3f, 20.1f, 3.9f, 21f, 5f, 21f)
            horizontalLineTo(19f)
            curveTo(20.1f, 21f, 21f, 20.1f, 21f, 19f)
            verticalLineTo(11.5f)
            horizontalLineTo(16f)
            close()
        }
    }.build()

    val Pattern: ImageVector = ImageVector.Builder(
        name = "Pattern",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 6f)
            horizontalLineTo(8f)
            verticalLineTo(8f)
            horizontalLineTo(6f)
            close()
            moveTo(11f, 6f)
            horizontalLineTo(13f)
            verticalLineTo(8f)
            horizontalLineTo(11f)
            close()
            moveTo(16f, 6f)
            horizontalLineTo(18f)
            verticalLineTo(8f)
            horizontalLineTo(16f)
            close()
            moveTo(6f, 11f)
            horizontalLineTo(8f)
            verticalLineTo(13f)
            horizontalLineTo(6f)
            close()
            moveTo(11f, 11f)
            horizontalLineTo(13f)
            verticalLineTo(13f)
            horizontalLineTo(11f)
            close()
            moveTo(16f, 11f)
            horizontalLineTo(18f)
            verticalLineTo(13f)
            horizontalLineTo(16f)
            close()
            moveTo(6f, 16f)
            horizontalLineTo(8f)
            verticalLineTo(18f)
            horizontalLineTo(6f)
            close()
            moveTo(11f, 16f)
            horizontalLineTo(13f)
            verticalLineTo(18f)
            horizontalLineTo(11f)
            close()
            moveTo(16f, 16f)
            horizontalLineTo(18f)
            verticalLineTo(18f)
            horizontalLineTo(16f)
            close()
        }
    }.build()

    val Backspace: ImageVector = ImageVector.Builder(
        name = "Backspace",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(22f, 3f)
            horizontalLineTo(7f)
            curveTo(6.31f, 3f, 5.7f, 3.43f, 5.42f, 4.07f)
            lineTo(0f, 12f)
            lineTo(5.42f, 19.93f)
            curveTo(5.7f, 20.57f, 6.31f, 21f, 7f, 21f)
            horizontalLineTo(22f)
            curveTo(23.1f, 21f, 24f, 20.1f, 24f, 19f)
            verticalLineTo(5f)
            curveTo(24f, 3.9f, 23.1f, 3f, 22f, 3f)
            close()
            moveTo(19f, 15.59f)
            lineTo(17.59f, 17f)
            lineTo(14f, 13.41f)
            lineTo(10.41f, 17f)
            lineTo(9f, 15.59f)
            lineTo(12.59f, 12f)
            lineTo(9f, 8.41f)
            lineTo(10.41f, 7f)
            lineTo(14f, 10.59f)
            lineTo(17.59f, 7f)
            lineTo(19f, 8.41f)
            lineTo(15.41f, 12f)
            lineTo(19f, 15.59f)
            close()
        }
    }.build()

    val Restore: ImageVector = ImageVector.Builder(
        name = "Restore",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(13f, 3f)
            curveTo(8.03f, 3f, 4f, 7.03f, 4f, 12f)
            horizontalLineTo(1f)
            lineTo(4.89f, 15.89f)
            lineTo(5f, 16f)
            lineTo(9f, 12f)
            horizontalLineTo(6f)
            curveTo(6f, 8.13f, 9.13f, 5f, 13f, 5f)
            curveTo(16.87f, 5f, 20f, 8.13f, 20f, 12f)
            curveTo(20f, 15.87f, 16.87f, 19f, 13f, 19f)
            curveTo(11.07f, 19f, 9.32f, 18.21f, 8.06f, 16.94f)
            lineTo(6.64f, 18.36f)
            curveTo(8.27f, 20f, 10.51f, 21f, 13f, 21f)
            curveTo(17.97f, 21f, 22f, 16.97f, 22f, 12f)
            curveTo(22f, 7.03f, 17.97f, 3f, 13f, 3f)
            close()
            moveTo(12f, 8f)
            verticalLineTo(13f)
            lineTo(16.28f, 15.54f)
            lineTo(17f, 14.33f)
            lineTo(13.5f, 12.25f)
            verticalLineTo(8f)
            horizontalLineTo(12f)
            close()
        }
    }.build()

    val KeyboardArrowDown: ImageVector = ImageVector.Builder(
        name = "KeyboardArrowDown",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(7.41f, 8.59f)
            lineTo(12f, 13.17f)
            lineTo(16.59f, 8.59f)
            lineTo(18f, 10f)
            lineTo(12f, 16f)
            lineTo(6f, 10f)
            close()
        }
    }.build()

    val Favorite: ImageVector = ImageVector.Builder(
        name = "Favorite",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 21.35f)
            lineTo(10.55f, 20.03f)
            curveTo(5.4f, 15.36f, 2f, 12.28f, 2f, 8.5f)
            curveTo(2f, 5.42f, 4.42f, 3f, 7.5f, 3f)
            curveTo(9.24f, 3f, 10.91f, 3.81f, 12f, 5.09f)
            curveTo(13.09f, 3.81f, 14.76f, 3f, 16.5f, 3f)
            curveTo(19.58f, 3f, 22f, 5.42f, 22f, 8.5f)
            curveTo(22f, 12.28f, 18.6f, 15.36f, 13.45f, 20.04f)
            lineTo(12f, 21.35f)
            close()
        }
    }.build()

    val FavoriteBorder: ImageVector = ImageVector.Builder(
        name = "FavoriteBorder",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(16.5f, 3f)
            curveTo(14.76f, 3f, 13.09f, 3.81f, 12f, 5.09f)
            curveTo(10.91f, 3.81f, 9.24f, 3f, 7.5f, 3f)
            curveTo(4.42f, 3f, 2f, 5.42f, 2f, 8.5f)
            curveTo(2f, 12.28f, 5.4f, 15.36f, 10.55f, 20.04f)
            lineTo(12f, 21.35f)
            lineTo(13.45f, 20.03f)
            curveTo(18.6f, 15.36f, 22f, 12.28f, 22f, 8.5f)
            curveTo(22f, 5.42f, 19.58f, 3f, 16.5f, 3f)
            close()
            moveTo(12.1f, 18.55f)
            lineTo(12f, 18.65f)
            lineTo(11.9f, 18.55f)
            curveTo(7.14f, 14.24f, 4f, 11.39f, 4f, 8.5f)
            curveTo(4f, 6.5f, 5.5f, 5f, 7.5f, 5f)
            curveTo(9.04f, 5f, 10.54f, 5.99f, 11.07f, 7.36f)
            horizontalLineTo(12.94f)
            curveTo(13.46f, 5.99f, 14.96f, 5f, 16.5f, 5f)
            curveTo(18.5f, 5f, 20f, 6.5f, 20f, 8.5f)
            curveTo(20f, 11.39f, 16.86f, 14.24f, 12.1f, 18.55f)
            close()
        }
    }.build()

    val MoreVert: ImageVector = ImageVector.Builder(
        name = "MoreVert",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 8f)
            curveTo(13.1f, 8f, 14f, 7.1f, 14f, 6f)
            curveTo(14f, 4.9f, 13.1f, 4f, 12f, 4f)
            curveTo(10.9f, 4f, 10f, 4.9f, 10f, 6f)
            curveTo(10f, 7.1f, 10.9f, 8f, 12f, 8f)
            close()
            moveTo(12f, 10f)
            curveTo(10.9f, 10f, 10f, 10.9f, 10f, 12f)
            curveTo(10f, 13.1f, 10.9f, 14f, 12f, 14f)
            curveTo(13.1f, 14f, 14f, 13.1f, 14f, 12f)
            curveTo(14f, 10.9f, 13.1f, 10f, 12f, 10f)
            close()
            moveTo(12f, 16f)
            curveTo(10.9f, 16f, 10f, 16.9f, 10f, 18f)
            curveTo(10f, 19.1f, 10.9f, 20f, 12f, 20f)
            curveTo(13.1f, 20f, 14f, 19.1f, 14f, 18f)
            curveTo(14f, 16.9f, 13.1f, 16f, 12f, 16f)
            close()
        }
    }.build()

    val Close: ImageVector = ImageVector.Builder(
        name = "Close",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(19f, 6.41f)
            lineTo(17.59f, 5f)
            lineTo(12f, 10.59f)
            lineTo(6.41f, 5f)
            lineTo(5f, 6.41f)
            lineTo(10.59f, 12f)
            lineTo(5f, 17.59f)
            lineTo(6.41f, 19f)
            lineTo(12f, 13.41f)
            lineTo(17.59f, 19f)
            lineTo(19f, 17.59f)
            lineTo(13.41f, 12f)
            close()
        }
    }.build()

    val PlayArrow: ImageVector = ImageVector.Builder(
        name = "PlayArrow",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(8f, 5f)
            verticalLineTo(19f)
            lineTo(19f, 12f)
            close()
        }
    }.build()

    val ArrowBack: ImageVector = ImageVector.Builder(
        name = "ArrowBack",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(20f, 11f)
            horizontalLineTo(7.83f)
            lineTo(13.42f, 5.41f)
            lineTo(12f, 4f)
            lineTo(4f, 12f)
            lineTo(12f, 20f)
            lineTo(13.41f, 18.59f)
            lineTo(7.83f, 13f)
            horizontalLineTo(20f)
            verticalLineTo(11f)
            close()
        }
    }.build()

    val ArrowDropDown: ImageVector = ImageVector.Builder(
        name = "ArrowDropDown",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(7f, 10f)
            lineTo(12f, 15f)
            lineTo(17f, 10f)
            close()
        }
    }.build()

    val CheckCircle: ImageVector = ImageVector.Builder(
        name = "CheckCircle",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 2f)
            curveTo(6.48f, 2f, 2f, 6.48f, 2f, 12f)
            curveTo(2f, 17.52f, 6.48f, 22f, 12f, 22f)
            curveTo(17.52f, 22f, 22f, 17.52f, 22f, 12f)
            curveTo(22f, 6.48f, 17.52f, 2f, 12f, 2f)
            close()
            moveTo(10f, 17f)
            lineTo(5f, 12f)
            lineTo(6.41f, 10.59f)
            lineTo(10f, 14.17f)
            lineTo(17.59f, 6.58f)
            lineTo(19f, 8f)
            lineTo(10f, 17f)
            close()
        }
    }.build()

    val Check: ImageVector = ImageVector.Builder(
        name = "Check",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(9f, 16.17f)
            lineTo(4.83f, 12f)
            lineTo(3.41f, 13.41f)
            lineTo(9f, 19f)
            lineTo(21f, 7f)
            lineTo(19.59f, 5.59f)
            close()
        }
    }.build()

    val Lock: ImageVector = ImageVector.Builder(
        name = "Lock",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(18f, 8f)
            horizontalLineTo(17f)
            verticalLineTo(6f)
            curveTo(17f, 3.24f, 14.76f, 1f, 12f, 1f)
            curveTo(9.24f, 1f, 7f, 3.24f, 7f, 6f)
            verticalLineTo(8f)
            horizontalLineTo(6f)
            curveTo(4.9f, 8f, 4f, 8.9f, 4f, 10f)
            verticalLineTo(20f)
            curveTo(4f, 21.1f, 4.9f, 22f, 6f, 22f)
            horizontalLineTo(18f)
            curveTo(19.1f, 22f, 20f, 21.1f, 20f, 20f)
            verticalLineTo(10f)
            curveTo(20f, 8.9f, 19.1f, 8f, 18f, 8f)
            close()
            moveTo(9f, 6f)
            curveTo(9f, 4.34f, 10.34f, 3f, 12f, 3f)
            curveTo(13.66f, 3f, 15f, 4.34f, 15f, 6f)
            verticalLineTo(8f)
            horizontalLineTo(9f)
            verticalLineTo(6f)
            close()
        }
    }.build()

    val Add: ImageVector = ImageVector.Builder(
        name = "Add",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(19f, 13f)
            horizontalLineTo(13f)
            verticalLineTo(19f)
            horizontalLineTo(11f)
            verticalLineTo(13f)
            horizontalLineTo(5f)
            verticalLineTo(11f)
            horizontalLineTo(11f)
            verticalLineTo(5f)
            horizontalLineTo(13f)
            verticalLineTo(11f)
            horizontalLineTo(19f)
            verticalLineTo(13f)
            close()
        }
    }.build()

    val Delete: ImageVector = ImageVector.Builder(
        name = "Delete",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 19f)
            curveTo(6f, 20.1f, 6.9f, 21f, 8f, 21f)
            horizontalLineTo(16f)
            curveTo(17.1f, 21f, 18f, 20.1f, 18f, 19f)
            verticalLineTo(7f)
            horizontalLineTo(6f)
            verticalLineTo(19f)
            close()
            moveTo(19f, 4f)
            horizontalLineTo(15.5f)
            lineTo(14.5f, 3f)
            horizontalLineTo(9.5f)
            lineTo(8.5f, 4f)
            horizontalLineTo(5f)
            verticalLineTo(6f)
            horizontalLineTo(19f)
            verticalLineTo(4f)
            close()
        }
    }.build()

    val Refresh: ImageVector = ImageVector.Builder(
        name = "Refresh",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(17.65f, 6.35f)
            curveTo(16.2f, 4.9f, 14.21f, 4f, 12f, 4f)
            curveTo(7.58f, 4f, 4.01f, 7.58f, 4.01f, 12f)
            curveTo(4.01f, 16.42f, 7.58f, 20f, 12f, 20f)
            curveTo(15.73f, 20f, 18.84f, 17.45f, 19.73f, 14f)
            horizontalLineTo(17.65f)
            curveTo(16.83f, 16.33f, 14.61f, 18f, 12f, 18f)
            curveTo(8.69f, 18f, 6f, 15.31f, 6f, 12f)
            curveTo(6f, 8.69f, 8.69f, 6f, 12f, 6f)
            curveTo(13.66f, 6f, 15.14f, 6.69f, 16.22f, 7.78f)
            lineTo(13f, 11f)
            horizontalLineTo(20f)
            verticalLineTo(4f)
            lineTo(17.65f, 6.35f)
            close()
        }
    }.build()

    val Search: ImageVector = ImageVector.Builder(
        name = "Search",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(15.5f, 14f)
            horizontalLineTo(14.71f)
            lineTo(14.43f, 13.73f)
            curveTo(15.41f, 12.59f, 16f, 11.11f, 16f, 9.5f)
            curveTo(16f, 5.91f, 13.09f, 3f, 9.5f, 3f)
            curveTo(5.91f, 3f, 3f, 5.91f, 3f, 9.5f)
            curveTo(3f, 13.09f, 5.91f, 16f, 9.5f, 16f)
            curveTo(11.11f, 16f, 12.59f, 15.41f, 13.73f, 14.43f)
            lineTo(14f, 14.71f)
            verticalLineTo(15.5f)
            lineTo(19f, 20.49f)
            lineTo(20.49f, 19f)
            lineTo(15.5f, 14f)
            close()
            moveTo(9.5f, 14f)
            curveTo(7.01f, 14f, 5f, 11.99f, 5f, 9.5f)
            curveTo(5f, 7.01f, 7.01f, 5f, 9.5f, 5f)
            curveTo(11.99f, 5f, 14f, 7.01f, 14f, 9.5f)
            curveTo(14f, 11.99f, 11.99f, 14f, 9.5f, 14f)
            close()
        }
    }.build()

    val Settings: ImageVector = ImageVector.Builder(
        name = "Settings",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(19.14f, 12.94f)
            curveTo(19.18f, 12.63f, 19.21f, 12.32f, 19.21f, 12f)
            curveTo(19.21f, 11.68f, 19.18f, 11.37f, 19.14f, 11.06f)
            lineTo(21.41f, 9.28f)
            curveTo(21.61f, 9.12f, 21.67f, 8.83f, 21.54f, 8.6f)
            lineTo(19.4f, 4.88f)
            curveTo(19.27f, 4.65f, 18.99f, 4.56f, 18.76f, 4.65f)
            lineTo(16.08f, 5.73f)
            curveTo(15.53f, 5.31f, 14.93f, 4.96f, 14.28f, 4.7f)
            lineTo(13.88f, 1.84f)
            curveTo(13.84f, 1.58f, 13.62f, 1.39f, 13.36f, 1.39f)
            horizontalLineTo(9.06f)
            curveTo(8.8f, 1.39f, 8.58f, 1.58f, 8.54f, 1.84f)
            lineTo(8.14f, 4.7f)
            curveTo(7.49f, 4.96f, 6.89f, 5.31f, 6.34f, 5.73f)
            lineTo(3.66f, 4.65f)
            curveTo(3.43f, 4.56f, 3.15f, 4.65f, 3.02f, 4.88f)
            lineTo(0.88f, 8.6f)
            curveTo(0.75f, 8.83f, 0.81f, 9.12f, 1.01f, 9.28f)
            lineTo(3.28f, 11.06f)
            curveTo(3.24f, 11.37f, 3.21f, 11.68f, 3.21f, 12f)
            curveTo(3.21f, 12.32f, 3.24f, 12.63f, 3.28f, 12.94f)
            lineTo(1.01f, 14.72f)
            curveTo(0.81f, 14.88f, 0.75f, 15.17f, 0.88f, 15.4f)
            lineTo(3.02f, 19.12f)
            curveTo(3.15f, 19.35f, 3.43f, 19.44f, 3.66f, 19.35f)
            lineTo(6.34f, 18.27f)
            curveTo(6.89f, 18.69f, 7.49f, 19.04f, 8.14f, 19.3f)
            lineTo(8.54f, 22.16f)
            curveTo(8.58f, 22.42f, 8.8f, 22.61f, 9.06f, 22.61f)
            horizontalLineTo(13.36f)
            curveTo(13.62f, 22.61f, 13.84f, 22.42f, 13.88f, 22.16f)
            lineTo(14.28f, 19.3f)
            curveTo(14.93f, 19.04f, 15.53f, 18.69f, 16.08f, 18.27f)
            lineTo(18.76f, 19.35f)
            curveTo(18.99f, 19.44f, 19.27f, 19.35f, 19.4f, 19.12f)
            lineTo(21.54f, 15.4f)
            curveTo(21.67f, 15.17f, 21.61f, 14.88f, 21.41f, 14.72f)
            lineTo(19.14f, 12.94f)
            close()
            moveTo(11.21f, 15.5f)
            curveTo(9.28f, 15.5f, 7.71f, 13.93f, 7.71f, 12f)
            curveTo(7.71f, 10.07f, 9.28f, 8.5f, 11.21f, 8.5f)
            curveTo(13.14f, 8.5f, 14.71f, 10.07f, 14.71f, 12f)
            curveTo(14.71f, 13.93f, 13.14f, 15.5f, 11.21f, 15.5f)
            close()
        }
    }.build()

    val FastRewind: ImageVector = ImageVector.Builder(
        name = "FastRewind",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(11f, 18f)
            verticalLineTo(6f)
            lineTo(2.5f, 12f)
            lineTo(11f, 18f)
            close()
            moveTo(20.5f, 6f)
            lineTo(12f, 12f)
            lineTo(20.5f, 18f)
            verticalLineTo(6f)
            close()
        }
    }.build()

    val FastForward: ImageVector = ImageVector.Builder(
        name = "FastForward",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(4f, 18f)
            lineTo(12.5f, 12f)
            lineTo(4f, 6f)
            verticalLineTo(18f)
            close()
            moveTo(13f, 6f)
            verticalLineTo(18f)
            lineTo(21.5f, 12f)
            lineTo(13f, 6f)
            close()
        }
    }.build()

    val Speed: ImageVector = ImageVector.Builder(
        name = "Speed",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(20.38f, 8.57f)
            lineTo(18.55f, 10.4f)
            curveTo(19.45f, 11.96f, 19.99f, 13.77f, 20f, 15.69f)
            curveTo(20.02f, 17.84f, 19.23f, 19.9f, 17.78f, 21.46f)
            curveTo(16.32f, 23.03f, 14.32f, 23.95f, 12.16f, 24f)
            curveTo(10.01f, 24.05f, 7.97f, 23.23f, 6.44f, 21.73f)
            curveTo(4.91f, 20.24f, 4.01f, 18.22f, 3.99f, 16.07f)
            curveTo(3.97f, 13.91f, 4.83f, 11.85f, 6.36f, 10.37f)
            curveTo(7.88f, 8.89f, 9.94f, 8.1f, 12.09f, 8.13f)
            curveTo(13.43f, 8.15f, 14.73f, 8.49f, 15.89f, 9.13f)
            lineTo(17.73f, 7.29f)
            curveTo(16.04f, 6.37f, 14.12f, 5.95f, 12.16f, 6.09f)
            curveTo(6.8f, 6.49f, 2.47f, 10.82f, 2.07f, 16.18f)
            curveTo(1.61f, 22.37f, 6.55f, 27.5f, 12.69f, 27.5f)
            curveTo(18.52f, 27.5f, 23.33f, 23.01f, 23.88f, 17.32f)
            curveTo(24.08f, 15.35f, 23.63f, 13.38f, 22.61f, 11.66f)
            lineTo(20.38f, 8.57f)
            close()
            moveTo(10.59f, 15.41f)
            curveTo(10.22f, 15.78f, 10f, 16.29f, 10f, 16.82f)
            curveTo(10f, 17.92f, 10.9f, 18.82f, 12f, 18.82f)
            curveTo(12.53f, 18.82f, 13.04f, 18.6f, 13.41f, 18.23f)
            lineTo(18f, 13.64f)
            lineTo(10.59f, 15.41f)
            close()
        }
    }.build()

    val Headphones: ImageVector = ImageVector.Builder(
        name = "Headphones",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f)
            curveTo(7.03f, 3f, 3f, 7.03f, 3f, 12f)
            verticalLineTo(18f)
            curveTo(3f, 19.66f, 4.34f, 21f, 6f, 21f)
            horizontalLineTo(9f)
            verticalLineTo(13f)
            horizontalLineTo(5f)
            verticalLineTo(12f)
            curveTo(5f, 8.13f, 8.13f, 5f, 12f, 5f)
            curveTo(15.87f, 5f, 19f, 8.13f, 19f, 12f)
            verticalLineTo(13f)
            horizontalLineTo(15f)
            verticalLineTo(21f)
            horizontalLineTo(18f)
            curveTo(19.66f, 21f, 21f, 19.66f, 21f, 18f)
            verticalLineTo(12f)
            curveTo(21f, 7.03f, 16.97f, 3f, 12f, 3f)
            close()
        }
    }.build()

    val Info: ImageVector = ImageVector.Builder(
        name = "Info",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 2f)
            curveTo(6.48f, 2f, 2f, 6.48f, 2f, 12f)
            curveTo(2f, 17.52f, 6.48f, 22f, 12f, 22f)
            curveTo(17.52f, 22f, 22f, 17.52f, 22f, 12f)
            curveTo(22f, 6.48f, 17.52f, 2f, 12f, 2f)
            close()
            moveTo(13f, 17f)
            horizontalLineTo(11f)
            verticalLineTo(11f)
            horizontalLineTo(13f)
            verticalLineTo(17f)
            close()
            moveTo(13f, 9f)
            horizontalLineTo(11f)
            verticalLineTo(7f)
            horizontalLineTo(13f)
            verticalLineTo(9f)
            close()
        }
    }.build()

    val Share: ImageVector = ImageVector.Builder(
        name = "Share",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(18f, 16.08f)
            curveTo(17.24f, 16.08f, 16.56f, 16.38f, 16.04f, 16.85f)
            lineTo(8.91f, 12.7f)
            curveTo(8.96f, 12.47f, 9f, 12.24f, 9f, 12f)
            curveTo(9f, 11.76f, 8.96f, 11.53f, 8.91f, 11.3f)
            lineTo(15.96f, 7.19f)
            curveTo(16.5f, 7.69f, 17.21f, 8f, 18f, 8f)
            curveTo(19.66f, 8f, 21f, 6.66f, 21f, 5f)
            curveTo(21f, 3.34f, 19.66f, 2f, 18f, 2f)
            curveTo(16.34f, 2f, 15f, 3.34f, 15f, 5f)
            curveTo(15f, 5.24f, 15.04f, 5.47f, 15.09f, 5.7f)
            lineTo(8.04f, 9.81f)
            curveTo(7.5f, 9.31f, 6.79f, 9f, 6f, 9f)
            curveTo(4.34f, 9f, 3f, 10.34f, 3f, 12f)
            curveTo(3f, 13.66f, 4.34f, 15f, 6f, 15f)
            curveTo(6.79f, 15f, 7.5f, 14.69f, 8.04f, 14.19f)
            lineTo(15.16f, 18.35f)
            curveTo(15.11f, 18.56f, 15.08f, 18.78f, 15.08f, 19f)
            curveTo(15.08f, 20.61f, 16.39f, 21.92f, 18f, 21.92f)
            curveTo(19.61f, 21.92f, 20.92f, 20.61f, 20.92f, 19f)
            curveTo(20.92f, 17.39f, 19.61f, 16.08f, 18f, 16.08f)
            close()
        }
    }.build()

    val PlaylistAdd: ImageVector = ImageVector.Builder(
        name = "PlaylistAdd",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(14f, 10f)
            horizontalLineTo(2f)
            verticalLineTo(12f)
            horizontalLineTo(14f)
            verticalLineTo(10f)
            close()
            moveTo(14f, 6f)
            horizontalLineTo(2f)
            verticalLineTo(8f)
            horizontalLineTo(14f)
            verticalLineTo(6f)
            close()
            moveTo(2f, 16f)
            horizontalLineTo(10f)
            verticalLineTo(14f)
            horizontalLineTo(2f)
            verticalLineTo(16f)
            close()
            moveTo(18f, 14f)
            verticalLineTo(10f)
            horizontalLineTo(16f)
            verticalLineTo(14f)
            horizontalLineTo(12f)
            verticalLineTo(16f)
            horizontalLineTo(16f)
            verticalLineTo(20f)
            horizontalLineTo(18f)
            verticalLineTo(16f)
            horizontalLineTo(22f)
            verticalLineTo(14f)
            horizontalLineTo(18f)
            close()
        }
    }.build()

    val Shield: ImageVector = ImageVector.Builder(
        name = "Shield",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 1f)
            lineTo(3f, 5f)
            verticalLineTo(11f)
            curveTo(3f, 16.55f, 6.84f, 21.74f, 12f, 23f)
            curveTo(17.16f, 21.74f, 21f, 16.55f, 21f, 11f)
            verticalLineTo(5f)
            lineTo(12f, 1f)
            close()
        }
    }.build()

    val VolumeUp: ImageVector = ImageVector.Builder(
        name = "VolumeUp",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(3f, 9f)
            verticalLineTo(15f)
            horizontalLineTo(7f)
            lineTo(12f, 20f)
            verticalLineTo(4f)
            lineTo(7f, 9f)
            horizontalLineTo(3f)
            close()
            moveTo(16.5f, 12f)
            curveTo(16.5f, 10.23f, 15.48f, 8.71f, 14f, 7.97f)
            verticalLineTo(16.02f)
            curveTo(15.48f, 15.29f, 16.5f, 13.77f, 16.5f, 12f)
            close()
            moveTo(14f, 3.23f)
            verticalLineTo(5.29f)
            curveTo(16.89f, 6.15f, 19f, 8.83f, 19f, 12f)
            curveTo(19f, 15.17f, 16.89f, 17.85f, 14f, 18.71f)
            verticalLineTo(20.77f)
            curveTo(18.01f, 19.86f, 21f, 16.28f, 21f, 12f)
            curveTo(21f, 7.72f, 18.01f, 4.14f, 14f, 3.23f)
            close()
        }
    }.build()

    val VolumeDown: ImageVector = ImageVector.Builder(
        name = "VolumeDown",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(18.5f, 12f)
            curveTo(18.5f, 10.23f, 17.48f, 8.71f, 16f, 7.97f)
            verticalLineTo(16.02f)
            curveTo(17.48f, 15.29f, 18.5f, 13.77f, 18.5f, 12f)
            close()
            moveTo(5f, 9f)
            verticalLineTo(15f)
            horizontalLineTo(9f)
            lineTo(14f, 20f)
            verticalLineTo(4f)
            lineTo(9f, 9f)
            horizontalLineTo(5f)
            close()
        }
    }.build()

    val VolumeOff: ImageVector = ImageVector.Builder(
        name = "VolumeOff",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(16.5f, 12f)
            curveTo(16.5f, 11.23f, 16.21f, 10.53f, 15.73f, 9.98f)
            lineTo(18.23f, 7.48f)
            curveTo(19.33f, 8.73f, 20f, 10.29f, 20f, 12f)
            curveTo(20f, 15.17f, 17.89f, 17.85f, 15f, 18.71f)
            verticalLineTo(16.65f)
            curveTo(16.76f, 15.89f, 18f, 14.09f, 18f, 12f)
            close()
            moveTo(4.27f, 3f)
            lineTo(3f, 4.27f)
            lineTo(7.73f, 9f)
            horizontalLineTo(4f)
            verticalLineTo(15f)
            horizontalLineTo(8f)
            lineTo(13f, 20f)
            verticalLineTo(14.27f)
            lineTo(17.73f, 19f)
            curveTo(16.89f, 19.66f, 15.98f, 20.15f, 15f, 20.44f)
            verticalLineTo(22.5f)
            curveTo(16.54f, 22.14f, 17.98f, 21.41f, 19.23f, 20.5f)
            lineTo(20.73f, 22f)
            lineTo(22f, 20.73f)
            lineTo(4.27f, 3f)
            close()
            moveTo(13f, 4f)
            lineTo(10.86f, 6.14f)
            lineTo(13f, 8.28f)
            verticalLineTo(4f)
            close()
        }
    }.build()
}
