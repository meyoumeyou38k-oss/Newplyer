# Lerza Player Pro - Android source and build guide
## Build
```bash
chmod +x ./gradlew
./gradlew assembleDebug
```
The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.
