package com.lerzaplayer.theme

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.ui.graphics.vector.ImageVector

object LerzaIcons {
    // Playback Controls
    val Play: ImageVector = Icons.Rounded.PlayArrow
    val PlayArrow: ImageVector = Icons.Rounded.PlayArrow
    val Pause: ImageVector = Icons.Rounded.Pause
    val SkipNext: ImageVector = Icons.Rounded.SkipNext
    val SkipPrevious: ImageVector = Icons.Rounded.SkipPrevious
    val FastRewind: ImageVector = Icons.Rounded.FastRewind
    val FastForward: ImageVector = Icons.Rounded.FastForward
    val Shuffle: ImageVector = Icons.Rounded.Shuffle
    val Repeat: ImageVector = Icons.Rounded.Repeat
    val RepeatOne: ImageVector = Icons.Rounded.RepeatOne

    // Navigation & Actions
    val ArrowBack: ImageVector = Icons.AutoMirrored.Rounded.ArrowBack
    val KeyboardArrowDown: ImageVector = Icons.Rounded.KeyboardArrowDown
    val ArrowDropDown: ImageVector = Icons.Rounded.ArrowDropDown
    val MoreVert: ImageVector = Icons.Rounded.MoreVert
    val Close: ImageVector = Icons.Rounded.Close
    val Check: ImageVector = Icons.Rounded.Check
    val CheckCircle: ImageVector = Icons.Rounded.CheckCircle
    val Add: ImageVector = Icons.Rounded.Add
    val Refresh: ImageVector = Icons.Rounded.Refresh
    val Search: ImageVector = Icons.Rounded.Search
    val Settings: ImageVector = Icons.Rounded.Settings
    val Share: ImageVector = Icons.Rounded.Share
    val Delete: ImageVector = Icons.Rounded.Delete
    val Restore: ImageVector = Icons.Rounded.Restore
    val VisibilityOff: ImageVector = Icons.Rounded.VisibilityOff

    // Media & Player Extras
    val Favorite: ImageVector = Icons.Rounded.Favorite
    val FavoriteBorder: ImageVector = Icons.Rounded.FavoriteBorder
    val Tune: ImageVector = Icons.Rounded.Tune
    val Speed: ImageVector = Icons.Rounded.Speed
    val Headphones: ImageVector = Icons.Rounded.Headphones
    val Info: ImageVector = Icons.Rounded.Info
    val Lock: ImageVector = Icons.Rounded.Lock
    val LockOpen: ImageVector = Icons.Rounded.LockOpen
    val ScreenRotation: ImageVector = Icons.Rounded.ScreenRotation
    val AspectRatio: ImageVector = Icons.Rounded.AspectRatio
    val SwapVert: ImageVector = Icons.AutoMirrored.Rounded.Sort
    val ViewList: ImageVector = Icons.AutoMirrored.Rounded.ViewList
    val GridView: ImageVector = Icons.Rounded.GridView

    // Library & Folders
    val Folder: ImageVector = Icons.Rounded.Folder
    val Videocam: ImageVector = Icons.Rounded.Videocam
    val Audiotrack: ImageVector = Icons.Rounded.Audiotrack
    val MusicNote: ImageVector = Icons.Rounded.MusicNote
    val Lyrics: ImageVector = Icons.AutoMirrored.Rounded.Notes
    val QueueMusic: ImageVector = Icons.AutoMirrored.Rounded.QueueMusic
    val PlaylistAdd: ImageVector = Icons.AutoMirrored.Rounded.PlaylistAdd
}
