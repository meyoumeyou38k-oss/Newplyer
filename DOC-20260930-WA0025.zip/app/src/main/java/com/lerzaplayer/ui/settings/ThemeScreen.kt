package com.lerzaplayer.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.*
import kotlinx.coroutines.launch

data class LarkColorCircle(
    val id: String,
    val title: String,
    val circleColor: Color,
    val isNone: Boolean = false
)

// یہاں پہلے دو بلینک/وائٹ کلرز کی جگہ 2 نئے اور پیارے کلرز (Emerald اور Neon Red) لگا دیے گئے ہیں
val THEME_CIRCLES = listOf(
    LarkColorCircle("Emerald", "Emerald Green", Color(0xFF10B981)),
    LarkColorCircle("NeonRed", "Neon Crimson", Color(0xFFFF3366)),
    LarkColorCircle("Green", "Mint Green", LarkGreen),
    LarkColorCircle("Blue", "Lerza Blue", LerzaBlue),
    LarkColorCircle("Purple", "Royal Purple", LarkPurple),
    LarkColorCircle("Orange", "Sunset Orange", LarkOrange),
    LarkColorCircle("Red", "Crimson Red", LarkRed),
    LarkColorCircle("Pink", "Rose Pink", LarkPink),
    LarkColorCircle("Cyan", "Ocean Cyan", LarkCyan),
    LarkColorCircle("Amber", "Golden Amber", LarkAmber),
    LarkColorCircle("Lavender", "Soft Lavender", Color(0xFF9C27B0))
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current
    val currentThemeColor = ThemeManager.currentThemeColor
    val currentThemeName = ThemeManager.currentThemeName
    val currentMode = ThemeManager.currentThemeMode
    val wallpaperUri by prefManager.wallpaperUriFlow.collectAsState(initial = null)
    val wallpaperOpacity by prefManager.wallpaperOpacityFlow.collectAsState(initial = 0.75f)
    val songDensity by prefManager.songItemDensityFlow.collectAsState(initial = 1.20f)

    var liveDensity by remember { mutableFloatStateOf(1.20f) }
    LaunchedEffect(songDensity) { liveDensity = songDensity }

    var liveOpacity by remember { mutableFloatStateOf(0.75f) }
    LaunchedEffect(wallpaperOpacity) { liveOpacity = wallpaperOpacity }

    val animatedColor by animateColorAsState(
        targetValue = currentThemeColor,
        animationSpec = tween(300),
        label = "ThemePreviewColor"
    )
    val onTextColor = getContrastTextColor(animatedColor)

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            scope.launch { prefManager.setWallpaperUri(uri.toString()) }
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = colors.onBackground, // لائٹ اور ڈارک تھیم کے مطابق آئی بکس کا کلر
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Theme &",
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.onBackground, // لائٹ میں ڈارک اور ڈارک میں وائٹ ہو جائے گا
                            lineHeight = 22.sp
                        )
                        Text(
                            text = "Customization",
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.onBackground, // لائٹ میں ڈارک اور ڈارک میں وائٹ ہو جائے گا
                            lineHeight = 22.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = animatedColor,
                    shadowElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = onTextColor
                        )
                        Column {
                            Text(
                                text = "Lerza",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = onTextColor,
                                lineHeight = 13.sp
                            )
                            Text(
                                text = currentThemeName.replace("Lerza", "").trim().ifEmpty { "Theme" },
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = onTextColor,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Phone Mockup Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(235.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, Color(0xFF1E2633), RoundedCornerShape(24.dp))
                    .background(Color(0xFF0F1520))
            ) {
                if (!wallpaperUri.isNullOrBlank()) {
                    AsyncImage(
                        model = wallpaperUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0xFF142033), Color(0xFF1A1513), Color(0xFF0D1017))
                                )
                            )
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = liveOpacity.coerceIn(0.15f, 0.95f)))
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LERZA PLAYER",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp,
                            color = Color.White
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                            Icon(Icons.Default.Tune, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = animatedColor
                        ) {
                            Text(
                                text = "Songs",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = onTextColor,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFF1F2633).copy(alpha = 0.85f)
                        ) {
                            Text(
                                text = "Videos",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF94A3B8),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFF1F2633).copy(alpha = 0.85f)
                        ) {
                            Text(
                                text = "Playlists",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF94A3B8),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    val mockThumb = (32f * liveDensity).coerceIn(28f, 44f).dp
                    val mockPad = (2.5f * liveDensity).coerceIn(1.5f, 6f).dp
                    val mockTitleSize = (11f * liveDensity).coerceIn(10.5f, 14.5f).sp

                    Column(modifier = Modifier.fillMaxWidth()) {
                        listOf(
                            Triple("Dil Laga Liya Maine", "Alka Yagnik & Udit Narayan", "4:31"),
                            Triple("Yeh Raaten Yeh Mausam", "Sanam ft. Simran Sehgal", "3:45"),
                            Triple("Unko Bhi Humse Mohabbat", "ReGa Music", "3:12")
                        ).forEachIndexed { index, (title, artist, dur) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = mockPad),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(mockThumb)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(animatedColor.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MusicNote,
                                        contentDescription = null,
                                        tint = animatedColor,
                                        modifier = Modifier.size((16f * liveDensity).coerceIn(14f, 22f).dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = title,
                                        fontSize = mockTitleSize,
                                        fontWeight = FontWeight.Bold,
                                        color = if (index == 0) animatedColor else Color.White,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = artist,
                                        fontSize = 9.5.sp,
                                        color = Color(0xFF94A3B8),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = dur,
                                    fontSize = 10.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFF141A23).copy(alpha = 0.92f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(32.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(animatedColor.copy(alpha = 0.3f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.MusicNote,
                                        contentDescription = null,
                                        tint = animatedColor,
                                        modifier = Modifier.size(10.dp)
                                    )
                                }
                                Text(
                                    "Dil Laga Liya Maine",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White,
                                    maxLines = 1
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(animatedColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = onTextColor,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 2. Wallpaper & Opacity Card
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = Color(0xFF121824),
                border = BorderStroke(1.dp, Color(0xFF1E2633)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                tint = animatedColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Wallpaper & Opacity",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = animatedColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${(liveOpacity * 100).toInt()}% Opacity",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = animatedColor,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { photoPickerLauncher.launch(arrayOf("image/*")) },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = animatedColor,
                                contentColor = onTextColor
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (wallpaperUri.isNullOrBlank()) "Choose Photo" else "Change Photo",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (!wallpaperUri.isNullOrBlank()) {
                            Button(
                                onClick = {
                                    scope.launch { prefManager.setWallpaperUri(null) }
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF2A151D),
                                    contentColor = Color(0xFFF43F5E)
                                ),
                                border = BorderStroke(1.dp, Color(0xFFF43F5E).copy(alpha = 0.4f)),
                                modifier = Modifier.height(44.dp)
                            ) {
                                Text(
                                    text = "Remove",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Overlay Dimming",
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8)
                            )
                            Text(
                                text = "${(liveOpacity * 100).toInt()}%",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Slider(
                            value = liveOpacity,
                            onValueChange = { newValue ->
                                liveOpacity = newValue
                                scope.launch { prefManager.setWallpaperOpacity(newValue) }
                            },
                            valueRange = 0.15f..0.95f,
                            colors = SliderDefaults.colors(
                                thumbColor = animatedColor,
                                activeTrackColor = animatedColor,
                                inactiveTrackColor = Color(0xFF263244)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // 3. Song Size & Thickness Card
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = Color(0xFF121824),
                border = BorderStroke(1.dp, Color(0xFF1E2633)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = animatedColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Song Size & Thickness",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        val densityLabel = when {
                            liveDensity < 0.95f -> "Compact (85%)"
                            liveDensity < 1.10f -> "Normal (100%)"
                            liveDensity < 1.25f -> "Comfortable (120%)"
                            else -> "Extra Bold (140%)"
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = animatedColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = densityLabel,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = animatedColor,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Slider(
                        value = liveDensity,
                        onValueChange = { newValue ->
                            liveDensity = newValue
                            scope.launch { prefManager.setSongItemDensity(newValue) }
                        },
                        valueRange = 0.85f..1.40f,
                        colors = SliderDefaults.colors(
                            thumbColor = animatedColor,
                            activeTrackColor = animatedColor,
                            inactiveTrackColor = Color(0xFF263244)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // 4. Dark / Light / System Mode Bar
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF121824),
                border = BorderStroke(1.dp, Color(0xFF1E2633)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(
                        "Dark" to Icons.Default.DarkMode,
                        "Light" to Icons.Default.LightMode,
                        "System" to Icons.Default.SettingsBrightness
                    ).forEach { (mode, icon) ->
                        val isSelected = currentMode == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(22.dp))
                                .background(if (isSelected) animatedColor else Color.Transparent)
                                .clickable { ThemeManager.setMode(context, mode) },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isSelected) onTextColor else Color(0xFF94A3B8),
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = mode,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) onTextColor else Color(0xFF94A3B8)
                                )
                            }
                        }
                    }
                }
            }

            // 5. Theme Palette Circles
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                THEME_CIRCLES.forEach { circleItem ->
                    val isSel = !currentThemeName.equals("None", ignoreCase = true) &&
                            currentThemeColor.value == circleItem.circleColor.value
                    val checkColor = getContrastTextColor(circleItem.circleColor)

                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(circleItem.circleColor)
                            .border(
                                width = if (isSel) 2.5.dp else 1.dp,
                                color = if (isSel) Color.White else Color.White.copy(alpha = 0.2f),
                                shape = CircleShape
                            )
                            .clickable {
                                ThemeManager.setTheme(context, circleItem.circleColor, circleItem.id)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSel) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = checkColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
