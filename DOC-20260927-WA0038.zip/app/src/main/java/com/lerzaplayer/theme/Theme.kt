package com.lerzaplayer.theme

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

// مکمل Palette کلاس جس میں ہر اسکرین کے لیے رنگ موجود ہیں
data class LerzaColorPalette(
    val primary: Color,
    val primaryVariant: Color,
    val accent: Color,
    val secondary: Color = accent,
    val card: Color,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val divider: Color,
    val isDark: Boolean
)

// ری ایکٹو تھیم مینیجر جو پوری ایپ کو ایک سیکنڈ میں ریفریش کرتا ہے
object ThemeManager {
    private const val PREFS_NAME = "lerza_theme_prefs"
    private const val KEY_COLOR = "selected_theme_color"
    private const val KEY_NAME = "selected_theme_name"

    // یہ اسٹیٹ جیسے ہی بدلے گی، پوری ایپ کا رنگ خود بخود تبدیل ہو جائے گا
    var currentThemeColor by mutableStateOf(LerzaBlue)
    var currentThemeName by mutableStateOf("Blue")

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedColor = prefs.getInt(KEY_COLOR, LerzaBlue.toArgb())
        val savedName = prefs.getString(KEY_NAME, "Blue") ?: "Blue"
        currentThemeColor = Color(savedColor)
        currentThemeName = savedName
    }

    fun setTheme(context: Context, color: Color, name: String = "") {
        currentThemeColor = color
        currentThemeName = name.ifEmpty { "Custom" }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putInt(KEY_COLOR, color.toArgb())
            .putString(KEY_NAME, currentThemeName)
            .apply()
    }
}

val LocalLerzaColors = staticCompositionLocalOf {
    LerzaColorPalette(
        primary = LerzaBlue,
        primaryVariant = LerzaBlueDark,
        accent = LerzaBlue,
        secondary = LerzaBlue,
        card = DarkSurface,
        background = DarkBackground,
        surface = DarkSurface,
        surfaceVariant = DarkSurfaceVariant,
        textPrimary = DarkTextPrimary,
        textSecondary = DarkTextSecondary,
        divider = DarkDivider,
        isDark = true
    )
}

object LerzaTheme {
    val colors: LerzaColorPalette
        @Composable
        @ReadOnlyComposable
        get() = LocalLerzaColors.current
}

// نام کے مطابق رنگ منتخب کرنا
fun getColorByThemeName(themeName: String): Color {
    return when (themeName.lowercase()) {
        "green" -> LarkGreen
        "purple" -> LarkPurple
        "orange" -> LarkOrange
        "red" -> LarkRed
        "pink" -> LarkPink
        "cyan" -> LarkCyan
        "amber", "yellow" -> LarkAmber
        "blue", "default" -> LerzaBlue
        else -> LerzaBlue
    }
}

// مرکزی کلر پیلیٹ بنانے کا فنکشن
fun getLerzaPalette(themeColor: Color, isDark: Boolean = true): LerzaColorPalette {
    return if (isDark) {
        LerzaColorPalette(
            primary = themeColor,
            primaryVariant = themeColor.copy(alpha = 0.8f),
            accent = themeColor,
            secondary = themeColor,
            card = DarkSurface,
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurfaceVariant,
            textPrimary = DarkTextPrimary,
            textSecondary = DarkTextSecondary,
            divider = DarkDivider,
            isDark = true
        )
    } else {
        LerzaColorPalette(
            primary = themeColor,
            primaryVariant = themeColor.copy(alpha = 0.8f),
            accent = themeColor,
            secondary = themeColor,
            card = LightSurface,
            background = LightBackground,
            surface = LightSurface,
            surfaceVariant = LightSurfaceVariant,
            textPrimary = LightTextPrimary,
            textSecondary = LightTextSecondary,
            divider = LightDivider,
            isDark = false
        )
    }
}

fun buildLarkTheme(
    themeColor: Color = ThemeManager.currentThemeColor,
    isDark: Boolean = true
): LerzaColorPalette {
    return getLerzaPalette(themeColor, isDark)
}

fun buildLarkTheme(
    themeName: String,
    isDark: Boolean = true
): LerzaColorPalette {
    return getLerzaPalette(getColorByThemeName(themeName), isDark)
}

@Composable
fun LerzaPlayerTheme(
    themeName: String = ThemeManager.currentThemeName,
    themeColor: Color? = null,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // اگر مخصوص رنگ نہ دیا گیا ہو تو یہ لائیو ری ایکٹو ThemeManager سے رنگ لے گا
    val activeColor = themeColor ?: ThemeManager.currentThemeColor
    val lerzaPalette = getLerzaPalette(activeColor, darkTheme)

    val materialColorScheme = if (darkTheme) {
        darkColorScheme(
            primary = lerzaPalette.primary,
            secondary = lerzaPalette.accent,
            tertiary = lerzaPalette.primaryVariant,
            background = lerzaPalette.background,
            surface = lerzaPalette.surface,
            surfaceVariant = lerzaPalette.surfaceVariant,
            onPrimary = Color.White,
            onBackground = lerzaPalette.textPrimary,
            onSurface = lerzaPalette.textPrimary
        )
    } else {
        lightColorScheme(
            primary = lerzaPalette.primary,
            secondary = lerzaPalette.accent,
            tertiary = lerzaPalette.primaryVariant,
            background = lerzaPalette.background,
            surface = lerzaPalette.surface,
            surfaceVariant = lerzaPalette.surfaceVariant,
            onPrimary = Color.White,
            onBackground = lerzaPalette.textPrimary,
            onSurface = lerzaPalette.textPrimary
        )
    }

    CompositionLocalProvider(
        LocalLerzaColors provides lerzaPalette
    ) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            content = content
        )
    }
}