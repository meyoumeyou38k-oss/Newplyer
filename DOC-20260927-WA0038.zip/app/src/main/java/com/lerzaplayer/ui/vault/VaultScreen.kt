package com.lerzaplayer.ui.vault

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.vault.VaultManager
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultScreen(
    vaultManager: VaultManager,
    onBack: () -> Unit,
    onPlayMedia: (VaultMediaEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current

    val isUnlocked by vaultManager.isUnlocked.collectAsState()
    val vaultMedia by vaultManager.vaultMediaFlow.collectAsState(initial = emptyList())
    val savedLockType by vaultManager.lockTypeFlow.collectAsState(initial = VaultLockType.PIN)
    val savedPinHash by vaultManager.pinFlow.collectAsState(initial = null)
    val savedPatternHash by vaultManager.patternFlow.collectAsState(initial = null)

    val isFirstTime = savedPinHash == null && savedPatternHash == null

    var lockType by remember { mutableStateOf(savedLockType) }
    var enteredPin by remember { mutableStateOf("") }
    var patternNodes by remember { mutableStateOf<List<Int>>(emptyList()) }
    var isPatternVisible by remember { mutableStateOf(true) }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var failedAttempts by remember { mutableIntStateOf(0) }
    var isConfirmStep by remember { mutableStateOf(false) }
    var tempPinFirst by remember { mutableStateOf("") }
    var tempPatternFirst by remember { mutableStateOf<List<Int>>(emptyList()) }

    var mainTab by remember { mutableStateOf("AUDIO") } // AUDIO, VIDEO
    var audioSubTab by remember { mutableStateOf("All") } // All, WhatsApp Audio, Recordings, Call Recordings, Songs

    var showVaultSettings by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }

    // آٹو ہائیڈ اسٹیٹس
    var autoHideWhatsApp by remember { mutableStateOf(true) }
    var autoHideCalls by remember { mutableStateOf(true) }
    var autoHideRecordings by remember { mutableStateOf(true) }

    // جیسے ہی بیک دبائیں، والٹ فوری لاک ہو جائے
    BackHandler {
        vaultManager.lockVault()
        onBack()
    }

    // فائلز کو امپورٹ کرنے کا پلس (+) لانچر
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            Toast.makeText(context, "${uris.size} file(s) imported to Vault", Toast.LENGTH_SHORT).show()
        }
    }

    // لاک کی اسٹیٹس کا تعین
    LaunchedEffect(savedLockType) {
        if (!isFirstTime) {
            lockType = savedLockType
        }
    }

    // آٹو ان لاک جب 4 ہندسوں کا پن مکمل ہو
    LaunchedEffect(enteredPin) {
        if (enteredPin.length == 4) {
            if (isFirstTime) {
                if (!isConfirmStep) {
                    tempPinFirst = enteredPin
                    enteredPin = ""
                    isConfirmStep = true
                    errorMessage = null
                } else {
                    if (enteredPin == tempPinFirst) {
                        vaultManager.updatePin(enteredPin)
                        vaultManager.verifyPin(enteredPin)
                        enteredPin = ""
                        isConfirmStep = false
                        errorMessage = null
                    } else {
                        errorMessage = "PINs do not match. Try again."
                        enteredPin = ""
                        isConfirmStep = false
                        tempPinFirst = ""
                    }
                }
            } else {
                val success = vaultManager.verifyPin(enteredPin)
                if (success) {
                    failedAttempts = 0
                    errorMessage = null
                    enteredPin = ""
                } else {
                    failedAttempts += 1
                    errorMessage = "Incorrect PIN"
                    enteredPin = ""
                }
            }
        }
    }

    Scaffold(
        topBar = {
            Surface(
                color = Color(0xFF0C0E10),
                modifier = Modifier.statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(onClick = {
                            vaultManager.lockVault()
                            onBack()
                        }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        Text(
                            text = if (isUnlocked) "Hidden files" else "Private Vault",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    if (isUnlocked) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { showVaultSettings = true }) {
                                Icon(Icons.Default.Tune, contentDescription = "Vault Settings", tint = Color.White)
                            }
                            IconButton(onClick = { vaultManager.lockVault() }) {
                                Icon(Icons.Default.Lock, contentDescription = "Lock", tint = Color(0xFFFF5252))
                            }
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (isUnlocked) {
                FloatingActionButton(
                    onClick = {
                        val mime = if (mainTab == "AUDIO") "audio/*" else "video/*"
                        filePickerLauncher.launch(arrayOf(mime))
                    },
                    containerColor = Color(0xFF2979FF),
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Files", modifier = Modifier.size(28.dp))
                }
            }
        },
        containerColor = Color(0xFF0C0E10)
    ) { padding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (!isUnlocked) {
                // لاک اسکرین (PIN / Modern 3x3 Pattern)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    // شائنی والٹ شیلڈ
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF2979FF).copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = Color(0xFF2979FF),
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = if (isFirstTime) {
                            if (!isConfirmStep) "Generate Vault Password" else "Confirm Your Password"
                        } else {
                            if (lockType == VaultLockType.PIN) "Enter Vault PIN" else "Draw Unlock Pattern"
                        },
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Text(
                        text = if (isFirstTime) "Select PIN or Pattern to secure your private media" else "Protected by Hardware Keystore",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // نیا یوزر ہونے پر پن یا پیٹرن چننے کا ٹوگل
                    if (isFirstTime && !isConfirmStep) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(24.dp))
                                .background(Color(0xFF1B2228))
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = lockType == VaultLockType.PIN,
                                onClick = { lockType = VaultLockType.PIN },
                                label = { Text("4-Digit PIN") }
                            )
                            FilterChip(
                                selected = lockType == VaultLockType.PATTERN,
                                onClick = { lockType = VaultLockType.PATTERN },
                                label = { Text("3x3 Pattern") }
                            )
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                    }

                    // 1. PIN موڈ
                    if (lockType == VaultLockType.PIN) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(bottom = 24.dp)
                        ) {
                            repeat(4) { idx ->
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (idx < enteredPin.length) Color(0xFF2979FF) else Color.Transparent
                                        )
                                        .border(2.dp, Color(0xFF2979FF), CircleShape)
                                )
                            }
                        }

                        // کی پیڈ
                        Column(
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val numRows = listOf(
                                listOf("1", "2", "3"),
                                listOf("4", "5", "6"),
                                listOf("7", "8", "9"),
                                listOf("PAT", "0", "DEL")
                            )
                            numRows.forEach { row ->
                                Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                                    row.forEach { key ->
                                        Box(
                                            modifier = Modifier
                                                .size(64.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF171B1E))
                                                .clickable {
                                                    when (key) {
                                                        "DEL" -> if (enteredPin.isNotEmpty()) enteredPin = enteredPin.dropLast(1)
                                                        "PAT" -> {
                                                            lockType = VaultLockType.PATTERN
                                                            enteredPin = ""
                                                            errorMessage = null
                                                        }
                                                        else -> if (enteredPin.length < 4) enteredPin += key
                                                    }
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (key == "DEL") {
                                                Icon(Icons.Default.Backspace, contentDescription = "Delete", tint = Color.White)
                                            } else if (key == "PAT") {
                                                Icon(Icons.Default.Pattern, contentDescription = "Switch Pattern", tint = Color(0xFF2979FF))
                                            } else {
                                                Text(key, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        // 2. نیو زمانے کا گلوئنگ 3x3 پیٹرن
                        Row(
                            modifier = Modifier.padding(bottom = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = if (isConfirmStep) "Draw pattern again to confirm" else "Connect at least 4 dots",
                                fontSize = 13.sp,
                                color = Color(0xFF2979FF),
                                fontWeight = FontWeight.SemiBold
                            )
                            IconButton(onClick = { isPatternVisible = !isPatternVisible }) {
                                Icon(
                                    imageVector = if (isPatternVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Toggle Visibility",
                                    tint = Color.Gray,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        val latestPattern = rememberUpdatedState(patternNodes)

                        Canvas(
                            modifier = Modifier
                                .size(240.dp)
                                .pointerInput(Unit) {
                                    fun nodeAt(pos: Offset): Int? {
                                        val cell = size.width / 3f
                                        val col = (pos.x / cell).toInt().coerceIn(0, 2)
                                        val row = (pos.y / cell).toInt().coerceIn(0, 2)
                                        val center = Offset(col * cell + cell / 2f, row * cell + cell / 2f)
                                        val distSq = (pos.x - center.x) * (pos.x - center.x) + (pos.y - center.y) * (pos.y - center.y)
                                        return if (distSq <= (cell * 0.42f) * (cell * 0.42f)) row * 3 + col + 1 else null
                                    }
                                    fun addPoint(p: Offset) {
                                        val n = nodeAt(p) ?: return
                                        if (n !in latestPattern.value) {
                                            patternNodes = latestPattern.value + n
                                        }
                                    }
                                    detectDragGestures(
                                        onDragStart = ::addPoint,
                                        onDrag = { change, _ ->
                                            change.consume()
                                            addPoint(change.position)
                                        },
                                        onDragEnd = {
                                            // خودکار ویریفائی جب پیٹرن مکمل ڈرا ہو
                                            val drawn = patternNodes
                                            if (drawn.size >= 4) {
                                                if (isFirstTime) {
                                                    if (!isConfirmStep) {
                                                        tempPatternFirst = drawn
                                                        patternNodes = emptyList()
                                                        isConfirmStep = true
                                                    } else {
                                                        if (drawn == tempPatternFirst) {
                                                            scope.launch {
                                                                vaultManager.updatePattern(drawn)
                                                                vaultManager.verifyPattern(drawn)
                                                            }
                                                            patternNodes = emptyList()
                                                            isConfirmStep = false
                                                        } else {
                                                            errorMessage = "Patterns do not match. Start again."
                                                            patternNodes = emptyList()
                                                            isConfirmStep = false
                                                        }
                                                    }
                                                } else {
                                                    scope.launch {
                                                        val ok = vaultManager.verifyPattern(drawn)
                                                        if (!ok) {
                                                            failedAttempts += 1
                                                            errorMessage = "Incorrect pattern"
                                                        } else {
                                                            failedAttempts = 0
                                                        }
                                                        patternNodes = emptyList()
                                                    }
                                                }
                                            } else {
                                                patternNodes = emptyList()
                                            }
                                        }
                                    )
                                }
                        ) {
                            val cell = size.width / 3f
                            val centers = (1..9).map { node ->
                                val r = (node - 1) / 3
                                val c = (node - 1) % 3
                                Offset(c * cell + cell / 2f, r * cell + cell / 2f)
                            }

                            // نیون گلوئنگ لائنز
                            if (isPatternVisible) {
                                patternNodes.zipWithNext().forEach { (from, to) ->
                                    drawLine(
                                        brush = Brush.linearGradient(listOf(Color(0xFF00E5FF), Color(0xFF2979FF))),
                                        start = centers[from - 1],
                                        end = centers[to - 1],
                                        strokeWidth = 10f,
                                        cap = StrokeCap.Round
                                    )
                                }
                            }

                            // ماڈرن ڈوٹس
                            centers.forEachIndexed { i, c ->
                                val selected = (i + 1) in patternNodes
                                drawCircle(
                                    color = if (selected && isPatternVisible) Color(0xFF2979FF) else Color(0xFF1E2832),
                                    radius = cell * 0.28f,
                                    center = c
                                )
                                drawCircle(
                                    color = if (selected && isPatternVisible) Color.White else Color(0xFF6B7280),
                                    radius = cell * 0.09f,
                                    center = c
                                )
                            }
                        }

                        TextButton(
                            onClick = {
                                lockType = VaultLockType.PIN
                                patternNodes = emptyList()
                                isConfirmStep = false
                            },
                            modifier = Modifier.padding(top = 10.dp)
                        ) {
                            Text("Switch to 4-Digit PIN", color = Color(0xFF2979FF))
                        }
                    }

                    if (errorMessage != null) {
                        Text(
                            text = errorMessage ?: "",
                            color = Color(0xFFFF5252),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 12.dp)
                        )
                    }

                    // 6 غلط کوششوں کے بعد فارگوٹ پاسورڈ آپشن
                    if (failedAttempts >= 6) {
                        Spacer(modifier = Modifier.height(10.dp))
                        TextButton(onClick = { showResetDialog = true }) {
                            Text("Forgot Lock? Reset Security", color = Color(0xFFFFB020), fontSize = 13.sp)
                        }
                    }
                }
            } else {
                // والٹ کا اندرونی حصہ (Unlocked State) - Screenshot 4 کے مطابق
                Column(modifier = Modifier.fillMaxSize()) {
                    // 1. Audio / Video کے دو مین ٹیبز
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color(0xFF171B1E))
                            .padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (mainTab == "AUDIO") Color(0xFF2979FF) else Color.Transparent)
                                .clickable { mainTab = "AUDIO" }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Headphones, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Text("Audio", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (mainTab == "VIDEO") Color(0xFF2979FF) else Color.Transparent)
                                .clickable { mainTab = "VIDEO" }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Text("Video", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                            }
                        }
                    }

                    // 2. آڈیو کے ذیلی فولڈرز (All, WhatsApp Audio, Recordings, Call Recordings, Songs)
                    if (mainTab == "AUDIO") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("All", "WhatsApp Audio", "Recordings", "Call Recordings", "Songs").forEach { tab ->
                                val isSel = audioSubTab == tab
                                Surface(
                                    onClick = { audioSubTab = tab },
                                    shape = RoundedCornerShape(18.dp),
                                    color = if (isSel) Color(0xFF2979FF) else Color(0xFF1B2228),
                                    contentColor = if (isSel) Color.White else Color.Gray
                                ) {
                                    Text(
                                        text = tab,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    // فائلز کی فلٹرنگ
                    val displayedList = remember(vaultMedia, mainTab, audioSubTab) {
                        vaultMedia.filter { item ->
                            if (mainTab == "VIDEO") item.mediaType == "VIDEO"
                            else {
                                if (item.mediaType != "AUDIO") return@filter false
                                val path = item.originalPath.lowercase()
                                when (audioSubTab) {
                                    "WhatsApp Audio" -> path.contains("whatsapp")
                                    "Recordings" -> path.contains("record") && !path.contains("call")
                                    "Call Recordings" -> path.contains("call")
                                    "Songs" -> !path.contains("whatsapp") && !path.contains("record")
                                    else -> true
                                }
                            }
                        }
                    }

                    if (displayedList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(54.dp))
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("No hidden files in this section", color = Color.Gray, fontSize = 14.sp)
                                Text("Tap + to add files from storage", color = Color.Gray.copy(alpha = 0.6f), fontSize = 12.sp)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(displayedList) { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF171B1E))
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF2979FF).copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (item.mediaType == "AUDIO") Icons.Default.MusicNote else Icons.Default.Videocam,
                                            contentDescription = null,
                                            tint = Color(0xFF2979FF),
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.originalName, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(
                                            text = if (item.originalPath.contains("WhatsApp", true)) "WhatsApp Audio" else "Private Media",
                                            color = Color.Gray,
                                            fontSize = 11.sp
                                        )
                                    }

                                    IconButton(onClick = { onPlayMedia(item) }) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color(0xFF2979FF))
                                    }

                                    IconButton(onClick = {
                                        scope.launch {
                                            vaultManager.restoreMedia(item)
                                            Toast.makeText(context, "Restored back to phone", Toast.LENGTH_SHORT).show()
                                        }
                                    }) {
                                        Icon(Icons.Default.Restore, contentDescription = "Restore", tint = Color(0xFF00E676))
                                    }

                                    IconButton(onClick = {
                                        scope.launch {
                                            vaultManager.deletePermanently(item)
                                            Toast.makeText(context, "Deleted permanently", Toast.LENGTH_SHORT).show()
                                        }
                                    }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color(0xFFFF5252))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // والٹ سیٹنگز باٹم شیٹ (آٹو ہائیڈ ٹوگلز اور چینج پاسورڈ)
    if (showVaultSettings) {
        ModalBottomSheet(
            onDismissRequest = { showVaultSettings = false },
            containerColor = Color(0xFF171B1E),
            contentColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Vault Privacy & Auto-Hide", fontSize = 18.sp, fontWeight = FontWeight.Bold)

                // 1. WhatsApp Auto-Hide
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Auto-hide WhatsApp audio", fontSize = 14.sp)
                        Text("Hide voice notes and media automatically", fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(checked = autoHideWhatsApp, onCheckedChange = { autoHideWhatsApp = it })
                }

                // 2. Call Recordings Auto-Hide
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Auto-hide Call recordings", fontSize = 14.sp)
                        Text("Keep phone call audios strictly in Vault", fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(checked = autoHideCalls, onCheckedChange = { autoHideCalls = it })
                }

                // 3. Sound Recordings Auto-Hide
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Auto-hide Sound recordings", fontSize = 14.sp)
                        Text("Hide device voice recorder files", fontSize = 11.sp, color = Color.Gray)
                    }
                    Switch(checked = autoHideRecordings, onCheckedChange = { autoHideRecordings = it })
                }

                Divider(color = Color.White.copy(alpha = 0.1f))

                // پاسورڈ / پیٹرن تبدیل کرنے کا بٹن
                Button(
                    onClick = {
                        showVaultSettings = false
                        scope.launch {
                            vaultManager.resetVaultLock()
                            isConfirmStep = false
                            enteredPin = ""
                            patternNodes = emptyList()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2979FF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Change Lock Type (PIN / Pattern)")
                }
            }
        }
    }

    // فارگوٹ پاسورڈ کا ری سیٹ ڈائیلاگ
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset Vault Lock", fontWeight = FontWeight.Bold) },
            text = {
                Text("You can now create a new PIN or Pattern. Your hidden media files will remain safely stored inside the vault.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            vaultManager.resetVaultLock()
                            failedAttempts = 0
                            enteredPin = ""
                            patternNodes = emptyList()
                            isConfirmStep = false
                            errorMessage = null
                            showResetDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252))
                ) {
                    Text("Create New Lock")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("Cancel") }
            },
            containerColor = Color(0xFF171B1E)
        )
    }
}