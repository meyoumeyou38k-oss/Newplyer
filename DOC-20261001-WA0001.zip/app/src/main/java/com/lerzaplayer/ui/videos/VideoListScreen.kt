package com.lerzaplayer.ui.videos

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import com.lerzaplayer.ads.NativeAdFeedItem
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.model.ViewMode
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors

@Composable
fun VideoListScreen(
    videos: List<VideoItem>,
    viewMode: ViewMode,
    onVideoClick: (VideoItem) -> Unit,
    onViewModeToggle: () -> Unit,
    onScanDevice: () -> Unit,
    onToggleFavorite: (VideoItem) -> Unit,
    onHideInVault: (VideoItem) -> Unit,
    onDelete: (VideoItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${videos.size} Videos Available",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textSecondary
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onScanDevice,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(
                        imageVector = LerzaIcons.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Scan", fontSize = 11.sp)
                }

                IconButton(
                    onClick = onViewModeToggle,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (viewMode == ViewMode.GRID) LerzaIcons.ViewList else LerzaIcons.GridView,
                        contentDescription = "Toggle View",
                        tint = colors.textPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        if (viewMode == ViewMode.GRID) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 90.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(videos, key = { _, video -> video.id }) { index, video ->
                    VideoGridCard(
                        video = video,
                        onClick = { onVideoClick(video) },
                        onToggleFavorite = { onToggleFavorite(video) },
                        onHideInVault = { onHideInVault(video) },
                        onDelete = { onDelete(video) }
                    )
                    if (index == 3 || index == 14 || index == 23) {
                        NativeAdFeedItem()
                    }
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 90.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(videos, key = { _, video -> video.id }) { index, video ->
                    VideoListRow(
                        video = video,
                        onClick = { onVideoClick(video) },
                        onToggleFavorite = { onToggleFavorite(video) },
                        onHideInVault = { onHideInVault(video) },
                        onDelete = { onDelete(video) }
                    )
                    if (index == 3 || index == 14 || index == 23) {
                        NativeAdFeedItem()
                    }
                }
            }
        }
    }
}

@Composable
fun VideoGridCard(
    video: VideoItem,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onHideInVault: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = LocalLerzaColors.current
    var menuExpanded by remember { mutableStateOf(false) }
    var showDetailsDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.card)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .background(Color.Black)
        ) {
            AsyncImage(
                model = video.contentUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color.Black.copy(alpha = 0.78f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = video.durationFormatted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF00B0FF))
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "HD",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = video.title,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = video.folderName,
                    fontSize = 11.5.sp,
                    color = colors.textSecondary
                )
            }

            Box {
                Surface(
                    shape = CircleShape,
                    color = colors.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(32.dp)
                ) {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Icon(
                            imageVector = LerzaIcons.MoreVert,
                            contentDescription = "Options",
                            tint = colors.textPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(colors.surface)
                ) {
                    VideoActionItem(
                        icon = LerzaIcons.Info,
                        title = "Video Info",
                        accentColor = colors.primary,
                        onClick = {
                            menuExpanded = false
                            showDetailsDialog = true
                        }
                    )
                    VideoActionItem(
                        icon = if (video.isFavorite) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                        title = if (video.isFavorite) "Remove Favorite" else "Add to Favorites",
                        accentColor = Color(0xFFFF334B),
                        onClick = {
                            menuExpanded = false
                            onToggleFavorite()
                        }
                    )
                    VideoActionItem(
                        icon = LerzaIcons.VisibilityOff,
                        title = "Hide in Vault",
                        accentColor = Color(0xFF9C27B0),
                        onClick = {
                            menuExpanded = false
                            onHideInVault()
                        }
                    )
                    HorizontalDivider(color = colors.card, thickness = 0.6.dp)
                    VideoActionItem(
                        icon = LerzaIcons.Delete,
                        title = "Delete",
                        accentColor = Color(0xFFFF334B),
                        textColor = Color(0xFFFF334B),
                        onClick = {
                            menuExpanded = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }

    if (showDetailsDialog) {
        AlertDialog(
            onDismissRequest = { showDetailsDialog = false },
            title = {
                Text(
                    text = "Video Details",
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Title: ${video.title}", color = colors.textPrimary, fontSize = 13.sp)
                    Text("Folder: ${video.folderName}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Duration: ${video.durationFormatted}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Resolution: ${video.resolution}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Path: ${video.path}", color = colors.textSecondary.copy(alpha = 0.7f), fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showDetailsDialog = false }) {
                    Text("Close", color = Color(0xFF1E60F2))
                }
            },
            containerColor = colors.surface
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VideoListRow(
    video: VideoItem,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onHideInVault: () -> Unit,
    onDelete: () -> Unit
) {
    val colors = LocalLerzaColors.current
    var menuExpanded by remember { mutableStateOf(false) }
    var showDetailsDialog by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = { onClick() },
                onLongClick = { menuExpanded = true }
            )
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(width = 84.dp, height = 52.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Color.Black)
        ) {
            AsyncImage(
                model = video.contentUri,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(3.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color.Black.copy(alpha = 0.78f))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = video.durationFormatted,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = video.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "Device Videos • ${video.folderName}",
                fontSize = 12.sp,
                color = colors.textSecondary
            )
        }

        Box {
            Surface(
                shape = CircleShape,
                color = colors.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(34.dp)
            ) {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.fillMaxSize()
                ) {
                    Icon(
                        imageVector = LerzaIcons.MoreVert,
                        contentDescription = "Options",
                        tint = colors.textPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                modifier = Modifier.background(colors.surface)
            ) {
                VideoActionItem(
                    icon = LerzaIcons.Info,
                    title = "Video Info",
                    accentColor = colors.primary,
                    onClick = {
                        menuExpanded = false
                        showDetailsDialog = true
                    }
                )
                VideoActionItem(
                    icon = if (video.isFavorite) LerzaIcons.Favorite else LerzaIcons.FavoriteBorder,
                    title = if (video.isFavorite) "Remove Favorite" else "Add to Favorites",
                    accentColor = Color(0xFFFF334B),
                    onClick = {
                        menuExpanded = false
                        onToggleFavorite()
                    }
                )
                VideoActionItem(
                    icon = LerzaIcons.VisibilityOff,
                    title = "Hide in Vault",
                    accentColor = Color(0xFF9C27B0),
                    onClick = {
                        menuExpanded = false
                        onHideInVault()
                    }
                )
                HorizontalDivider(color = colors.card, thickness = 0.6.dp)
                VideoActionItem(
                    icon = LerzaIcons.Delete,
                    title = "Delete",
                    accentColor = Color(0xFFFF334B),
                    textColor = Color(0xFFFF334B),
                    onClick = {
                        menuExpanded = false
                        onDelete()
                    }
                )
            }
        }
    }

    if (showDetailsDialog) {
        AlertDialog(
            onDismissRequest = { showDetailsDialog = false },
            title = {
                Text(
                    text = "Video Details",
                    color = colors.textPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Title: ${video.title}", color = colors.textPrimary, fontSize = 13.sp)
                    Text("Folder: ${video.folderName}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Duration: ${video.durationFormatted}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Resolution: ${video.resolution}", color = colors.textSecondary, fontSize = 12.sp)
                    Text("Path: ${video.path}", color = colors.textSecondary.copy(alpha = 0.7f), fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showDetailsDialog = false }) {
                    Text("Close", color = Color(0xFF1E60F2))
                }
            },
            containerColor = colors.surface
        )
    }
}

/**
 * Modern styled action item for video dropdown menus with rounded colored icon badge
 */
@Composable
private fun VideoActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    accentColor: Color,
    textColor: Color? = null,
    onClick: () -> Unit
) {
    val finalTextColor = textColor ?: LocalLerzaColors.current.textPrimary
    DropdownMenuItem(
        text = {
            Text(
                text = title,
                color = finalTextColor,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Medium
            )
        },
        leadingIcon = {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
        },
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
    )
}