package com.lerzaplayer.ui.settings

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.model.Song
import com.lerzaplayer.theme.DarkBackground
import com.lerzaplayer.theme.DarkSurface
import com.lerzaplayer.theme.DarkTextSecondary
import com.lerzaplayer.theme.ThemeManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit = {},
    onBack: (() -> Unit)? = null,
    prefManager: Any? = null,

    // MainActivity.kt کے پیرامیٹرز کے عین مطابق
    onOpenEqualizer: () -> Unit = {},
    onScanMedia: () -> Unit = {},
    onOpenVault: () -> Unit = {},
    recentlyDeleted: List<Any> = emptyList(),
    onPlayRecentlyDeleted: (Any) -> Unit = {},
    onRestoreRecentlyDeleted: (Any) -> Unit = {},
    onPermanentlyDeleteRecentlyDeleted: (Any) -> Unit = {},

    // اضافی نیویگیشن سپورٹ
    onNavigateToTheme: () -> Unit = {},
    onNavigateToEqualizer: () -> Unit = onOpenEqualizer,
    onNavigateToVault: () -> Unit = onOpenVault,
    onNavigateToTrash: () -> Unit = {},
    onNavigateToScan: () -> Unit = onScanMedia
) {
    val handleBack = {
        onBack?.invoke() ?: onNavigateBack()
    }

    val context = LocalContext.current
    val activeColor = ThemeManager.currentThemeColor

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = handleBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground
                )
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(Modifier.height(4.dp)) }

            // 1. Personalized & Appearance
            item {
                SettingsSectionTitle("PERSONALIZATION")
                SettingsCard {
                    SettingsItem(
                        icon = Icons.Default.Palette,
                        title = "Theme & Appearance",
                        subtitle = "Select app colors, dark mode and custom wallpapers",
                        accentColor = activeColor,
                        onClick = onNavigateToTheme
                    )
                }
            }

            // 2. Audio & Playback
            item {
                SettingsSectionTitle("AUDIO & PLAYBACK")
                SettingsCard {
                    SettingsItem(
                        icon = Icons.Default.GraphicEq,
                        title = "Sound Equalizer & Bass",
                        subtitle = "10-Band EQ, Bass Boost and Reverb effects",
                        accentColor = activeColor,
                        onClick = onOpenEqualizer
                    )
                    Divider(color = Color.White.copy(alpha = 0.08f), thickness = 0.8.dp)
                    SettingsItem(
                        icon = Icons.Default.Timer,
                        title = "Sleep Timer",
                        subtitle = "Automatically turn off music when you sleep",
                        accentColor = activeColor,
                        onClick = {}
                    )
                }
            }

            // 3. Privacy & Security
            item {
                SettingsSectionTitle("PRIVACY & RECOVERY")
                SettingsCard {
                    SettingsItem(
                        icon = Icons.Default.Lock,
                        title = "Private Vault (Hide Songs)",
                        subtitle = "PIN / Pattern protected hidden media",
                        accentColor = activeColor,
                        onClick = onOpenVault
                    )
                    Divider(color = Color.White.copy(alpha = 0.08f), thickness = 0.8.dp)
                    SettingsItem(
                        icon = Icons.Default.DeleteSweep,
                        title = "Recently Deleted (Trash)",
                        subtitle = "${recentlyDeleted.size} songs currently in recovery",
                        accentColor = activeColor,
                        onClick = onNavigateToTrash
                    )
                }
            }

            // 4. Library & System
            item {
                SettingsSectionTitle("LIBRARY & FILES")
                SettingsCard {
                    SettingsItem(
                        icon = Icons.Default.Refresh,
                        title = "Scan Media Library",
                        subtitle = "Rescan internal storage for new music files",
                        accentColor = activeColor,
                        onClick = onScanMedia
                    )
                    Divider(color = Color.White.copy(alpha = 0.08f), thickness = 0.8.dp)
                    SettingsItem(
                        icon = Icons.Default.Info,
                        title = "App Version",
                        subtitle = "Lerza Player Pro v2.4 (Lark Style Engine)",
                        accentColor = activeColor,
                        onClick = {}
                    )
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun SettingsSectionTitle(title: String) {
    Text(
        text = title,
        color = Color.White.copy(alpha = 0.5f),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 8.dp, bottom = 6.dp)
    )
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth()
        ) {
            content()
        }
    }
}

@Composable
private fun SettingsItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = DarkTextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.3f),
            modifier = Modifier.size(20.dp)
        )
    }
}