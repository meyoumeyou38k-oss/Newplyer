package com.lerzaplayer.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.*
import kotlinx.coroutines.launch

data class LarkColorCircle(
    val id: String,
    val title: String,
    val circleColor: Color,
    val isNone: Boolean = false
)

val THEME_CIRCLES = listOf(
    // 1. None بٹن اب خالص وائٹ (Pure White) ہے
    LarkColorCircle("None", "Pure White", Color(0xFFFFFFFF), isNone = true),
    // 2. باقی تمام رنگین تھیمز
    LarkColorCircle("Green", "Mint Green", LarkGreen),
    LarkColorCircle("Blue", "Lerza Blue", LerzaBlue),
    LarkColorCircle("Purple", "Royal Purple", LarkPurple),
    LarkColorCircle("Orange", "Sunset Orange", LarkOrange),
    LarkColorCircle("Red", "Crimson Red", LarkRed),
    LarkColorCircle("Pink", "Rose Pink", LarkPink),
    LarkColorCircle("Cyan", "Ocean Cyan", LarkCyan),
    LarkColorCircle("Amber", "Golden Amber", LarkAmber)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val colors = LocalLerzaColors.current
    val currentThemeColor = ThemeManager.currentThemeColor
    val currentThemeName = ThemeManager.currentThemeName
    val currentMode = ThemeManager.currentThemeMode

    val wallpaperUri by prefManager.wallpaperUriFlow.collectAsState(initial = null)
    val wallpaperOpacity by prefManager.wallpaperOpacityFlow.collectAsState(initial = 0.75f)

    val animatedColor by animateColorAsState(
        targetValue = currentThemeColor,
        animationSpec = tween(350),
        label = "ThemePreviewColor"
    )

    val onTextColor = getContrastTextColor(animatedColor)

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            scope.launch {
                prefManager.setWallpaperUri(uri.toString())
            }
        }
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(onClick = onBack) {
                        Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                    }
                    Text(
                        text = "Theme",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = animatedColor,
                    contentColor = onTextColor
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Menu, contentDescription = null, modifier = Modifier.size(14.dp), tint = onTextColor)
                        Text(currentThemeName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = onTextColor)
                    }
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // 1. پریویو کارڈ جس پر اب LERZA PLAYER لکھا ہے
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.88f)
                    .weight(1f)
                    .clip(RoundedCornerShape(28.dp))
                    .border(2.dp, animatedColor.copy(alpha = 0.45f), RoundedCornerShape(28.dp))
                    .background(colors.background)
            ) {
                if (!wallpaperUri.isNullOrBlank()) {
                    AsyncImage(
                        model = wallpaperUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = wallpaperOpacity))
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LERZA PLAYER", // تبدیل شدہ نام
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp,
                            color = colors.textPrimary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Search, contentDescription = null, tint = colors.textSecondary, modifier = Modifier.size(16.dp))
                            Icon(Icons.Default.Tune, contentDescription = null, tint = colors.textSecondary, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = animatedColor,
                            contentColor = onTextColor
                        ) {
                            Text("Songs", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = onTextColor, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = colors.card,
                            contentColor = colors.textSecondary
                        ) {
                            Text("Videos", fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = colors.card,
                            contentColor = colors.textSecondary
                        ) {
                            Text("Playlists", fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    listOf(
                        "Crazy In Love With Your Smile" to "Don Juan",
                        "Heart Skips A Beat" to "Hariel",
                        "Beach Memories" to "Nattan",
                        "Can't Stop This Feeling" to "Henrique & Juliano",
                        "Blue Eyes That Saw My Soul" to "Mc Poze"
                    ).forEach { (title, artist) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(animatedColor.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = animatedColor, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = title,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = colors.textPrimary,
                                    maxLines = 1
                                )
                                Text(text = artist, fontSize = 9.sp, color = colors.textSecondary, maxLines = 1)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Dark / Light / System Mode
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = colors.card,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(
                        "Dark" to Icons.Default.DarkMode,
                        "Light" to Icons.Default.LightMode,
                        "System" to Icons.Default.SettingsBrightness
                    ).forEach { (mode, icon) ->
                        val isSelected = currentMode == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(24.dp))
                                .background(if (isSelected) animatedColor else Color.Transparent)
                                .clickable {
                                    ThemeManager.setMode(context, mode)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isSelected) onTextColor else colors.textSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = mode,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) onTextColor else colors.textSecondary
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // وال پیپر اوپیسٹی سلائیڈر
            if (!wallpaperUri.isNullOrBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Opacity: ${(wallpaperOpacity * 100).toInt()}%",
                        color = colors.textSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.width(76.dp)
                    )
                    Slider(
                        value = wallpaperOpacity,
                        onValueChange = { scope.launch { prefManager.setWallpaperOpacity(it) } },
                        valueRange = 0.2f..0.95f,
                        colors = SliderDefaults.colors(
                            thumbColor = animatedColor,
                            activeTrackColor = animatedColor
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { scope.launch { prefManager.setWallpaperUri(null) } }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Remove Wallpaper", tint = Color(0xFFFF5252))
                    }
                }
            }

            // 3. کلر سرکلز (None سفید رنگ میں + تمام رنگ)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp)
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // فوٹو چننے کا آئیکن
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(colors.card)
                        .border(1.5.dp, animatedColor.copy(alpha = 0.5f), CircleShape)
                        .clickable { photoPickerLauncher.launch(arrayOf("image/*")) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = "Pick Wallpaper",
                        tint = animatedColor,
                        modifier = Modifier.size(22.dp)
                    )
                }

                THEME_CIRCLES.forEach { circleItem ->
                    val isSel = if (circleItem.isNone) {
                        currentThemeName.equals("None", ignoreCase = true)
                    } else {
                        !currentThemeName.equals("None", ignoreCase = true) &&
                                currentThemeColor.value == circleItem.circleColor.value
                    }

                    val checkColor = if (circleItem.isNone) Color(0xFF101418) else getContrastTextColor(circleItem.circleColor)

                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(circleItem.circleColor)
                            .border(
                                width = if (isSel) 3.dp else 1.dp,
                                color = if (isSel) (if (circleItem.isNone) Color(0xFF101418) else Color.White) else Color.White.copy(alpha = 0.25f),
                                shape = CircleShape
                            )
                            .clickable {
                                if (circleItem.isNone) {
                                    // None پر کلک کرنے سے سفید اور پیور لائٹ موڈ ہو جائے گا
                                    ThemeManager.setTheme(context, Color.Transparent, "None")
                                    ThemeManager.setMode(context, "Light")
                                } else {
                                    ThemeManager.setTheme(context, circleItem.circleColor, circleItem.id)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (circleItem.isNone && !isSel) {
                            Text("None", fontSize = 10.sp, color = Color(0xFF101418), fontWeight = FontWeight.Bold)
                        } else if (isSel) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = checkColor,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}