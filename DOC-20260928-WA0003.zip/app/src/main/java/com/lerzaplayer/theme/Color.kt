package com.lerzaplayer.theme

import androidx.compose.ui.graphics.Color

// Default Brand Colors
val LerzaBlue = Color(0xFF2196F3)
val LerzaBlueDark = Color(0xFF1976D2)
val LerzaBlueLight = Color(0xFFBBDEFB)

// Lark Player / Material Accent Colors
val LarkGreen = Color(0xFF1DB954)
val LarkGreenDark = Color(0xFF15883e)
val LarkPurple = Color(0xFF8E24AA)
val LarkOrange = Color(0xFFFF6D00)
val LarkRed = Color(0xFFE53935)
val LarkPink = Color(0xFFD81B60)
val LarkCyan = Color(0xFF00ACC1)
val LarkAmber = Color(0xFFFFB300)

// Neutral Dark Shades (Dark Theme)
val DarkBackground = Color(0xFF0F1115)
val DarkSurface = Color(0xFF161922)
val DarkSurfaceVariant = Color(0xFF222634)
val DarkTextPrimary = Color(0xFFFFFFFF)
val DarkTextSecondary = Color(0xFF9E9E9E)
val DarkDivider = Color(0xFF2B2F3E)

// Neutral Light Shades (Light Theme)
val LightBackground = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEEEEE)
val LightTextPrimary = Color(0xFF1A1A1A)
val LightTextSecondary = Color(0xFF757575)
val LightDivider = Color(0xFFE0E0E0)