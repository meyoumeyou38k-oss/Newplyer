package com.lerzaplayer.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object LerzaIcons {

    val SkipNext: ImageVector = ImageVector.Builder(
        name = "SkipNext",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 18f)
            lineTo(14.5f, 12f)
            lineTo(6f, 6f)
            close()
            moveTo(16f, 6f)
            horizontalLineTo(18f)
            verticalLineTo(18f)
            horizontalLineTo(16f)
            close()
        }
    }.build()

    val SkipPrevious: ImageVector = ImageVector.Builder(
        name = "SkipPrevious",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 6f)
            horizontalLineTo(8f)
            verticalLineTo(18f)
            horizontalLineTo(6f)
            close()
            moveTo(9.5f, 12f)
            lineTo(18f, 18f)
            lineTo(18f, 6f)
            close()
        }
    }.build()

    val Shuffle: ImageVector = ImageVector.Builder(
        name = "Shuffle",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(10.59f, 9.17f)
            lineTo(5.41f, 4f)
            lineTo(4f, 5.41f)
            lineTo(9.17f, 10.59f)
            close()
            moveTo(14.5f, 4f)
            lineTo(16.54f, 6.04f)
            lineTo(4f, 18.59f)
            lineTo(5.41f, 20f)
            lineTo(17.96f, 7.46f)
            lineTo(20f, 9.5f)
            lineTo(20f, 4f)
            close()
            moveTo(14.83f, 13.41f)
            lineTo(13.42f, 14.82f)
            lineTo(16.55f, 17.95f)
            lineTo(14.5f, 20f)
            lineTo(20f, 20f)
            lineTo(20f, 14.5f)
            lineTo(17.96f, 16.54f)
            close()
        }
    }.build()

    val Repeat: ImageVector = ImageVector.Builder(
        name = "Repeat",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(7f, 7f)
            horizontalLineTo(17f)
            verticalLineTo(10f)
            lineTo(21f, 6f)
            lineTo(17f, 2f)
            verticalLineTo(5f)
            horizontalLineTo(5f)
            verticalLineTo(11f)
            horizontalLineTo(7f)
            verticalLineTo(7f)
            close()
            moveTo(17f, 17f)
            horizontalLineTo(7f)
            verticalLineTo(14f)
            lineTo(3f, 18f)
            lineTo(7f, 22f)
            verticalLineTo(19f)
            horizontalLineTo(19f)
            verticalLineTo(13f)
            horizontalLineTo(17f)
            verticalLineTo(17f)
            close()
        }
    }.build()

    val RepeatOne: ImageVector = ImageVector.Builder(
        name = "RepeatOne",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(7f, 7f)
            horizontalLineTo(17f)
            verticalLineTo(10f)
            lineTo(21f, 6f)
            lineTo(17f, 2f)
            verticalLineTo(5f)
            horizontalLineTo(5f)
            verticalLineTo(11f)
            horizontalLineTo(7f)
            verticalLineTo(7f)
            close()
            moveTo(17f, 17f)
            horizontalLineTo(7f)
            verticalLineTo(14f)
            lineTo(3f, 18f)
            lineTo(7f, 22f)
            verticalLineTo(19f)
            horizontalLineTo(19f)
            verticalLineTo(13f)
            horizontalLineTo(17f)
            verticalLineTo(17f)
            close()
            moveTo(13f, 15f)
            verticalLineTo(9f)
            horizontalLineTo(11.5f)
            verticalLineTo(10f)
            horizontalLineTo(12f)
            verticalLineTo(15f)
            close()
        }
    }.build()

    val QueueMusic: ImageVector = ImageVector.Builder(
        name = "QueueMusic",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(15f, 6f)
            horizontalLineTo(3f)
            verticalLineTo(8f)
            horizontalLineTo(15f)
            verticalLineTo(6f)
            close()
            moveTo(15f, 10f)
            horizontalLineTo(3f)
            verticalLineTo(12f)
            horizontalLineTo(15f)
            verticalLineTo(10f)
            close()
            moveTo(3f, 16f)
            horizontalLineTo(11f)
            verticalLineTo(14f)
            horizontalLineTo(3f)
            verticalLineTo(16f)
            close()
            moveTo(17f, 6f)
            verticalLineTo(13.18f)
            curveTo(16.53f, 13.07f, 16.03f, 13f, 15.5f, 13f)
            curveTo(13.57f, 13f, 12f, 14.57f, 12f, 16.5f)
            reflectiveCurveTo(13.57f, 20f, 15.5f, 20f)
            reflectiveCurveTo(19f, 18.43f, 19f, 16.5f)
            verticalLineTo(8f)
            horizontalLineTo(22f)
            verticalLineTo(6f)
            horizontalLineTo(17f)
            close()
        }
    }.build()

    val Tune: ImageVector = ImageVector.Builder(
        name = "Tune",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(3f, 17f)
            verticalLineTo(19f)
            horizontalLineTo(9f)
            verticalLineTo(17f)
            horizontalLineTo(3f)
            close()
            moveTo(3f, 5f)
            verticalLineTo(7f)
            horizontalLineTo(13f)
            verticalLineTo(5f)
            horizontalLineTo(3f)
            close()
            moveTo(13f, 21f)
            verticalLineTo(19f)
            horizontalLineTo(21f)
            verticalLineTo(17f)
            horizontalLineTo(13f)
            verticalLineTo(15f)
            horizontalLineTo(11f)
            verticalLineTo(21f)
            horizontalLineTo(13f)
            close()
            moveTo(7f, 9f)
            verticalLineTo(11f)
            horizontalLineTo(3f)
            verticalLineTo(13f)
            horizontalLineTo(7f)
            verticalLineTo(15f)
            horizontalLineTo(9f)
            verticalLineTo(9f)
            horizontalLineTo(7f)
            close()
            moveTo(21f, 13f)
            verticalLineTo(11f)
            horizontalLineTo(11f)
            verticalLineTo(13f)
            horizontalLineTo(21f)
            close()
            moveTo(17f, 9f)
            horizontalLineTo(19f)
            verticalLineTo(7f)
            horizontalLineTo(21f)
            verticalLineTo(5f)
            horizontalLineTo(19f)
            verticalLineTo(3f)
            horizontalLineTo(17f)
            verticalLineTo(9f)
            close()
        }
    }.build()

    val MusicNote: ImageVector = ImageVector.Builder(
        name = "MusicNote",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f)
            verticalLineTo(13.55f)
            curveTo(11.41f, 13.21f, 10.73f, 13f, 10f, 13f)
            curveTo(7.79f, 13f, 6f, 14.79f, 6f, 17f)
            reflectiveCurveTo(7.79f, 21f, 10f, 21f)
            reflectiveCurveTo(14f, 19.21f, 14f, 17f)
            verticalLineTo(7f)
            horizontalLineTo(18f)
            verticalLineTo(3f)
            horizontalLineTo(12f)
            close()
        }
    }.build()

    val Lyrics: ImageVector = ImageVector.Builder(
        name = "Lyrics",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(20f, 2f)
            horizontalLineTo(4f)
            curveTo(2.9f, 2f, 2f, 2.9f, 2f, 4f)
            verticalLineTo(22f)
            lineTo(6f, 18f)
            horizontalLineTo(20f)
            curveTo(21.1f, 18f, 22f, 17.1f, 22f, 16f)
            verticalLineTo(4f)
            curveTo(22f, 2.9f, 21.1f, 2f, 20f, 2f)
            close()
            moveTo(20f, 16f)
            horizontalLineTo(5.17f)
            lineTo(4f, 17.17f)
            verticalLineTo(4f)
            horizontalLineTo(20f)
            verticalLineTo(16f)
            close()
        }
    }.build()

    val LockOpen: ImageVector = ImageVector.Builder(
        name = "LockOpen",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(18f, 8f)
            horizontalLineTo(17f)
            verticalLineTo(6f)
            curveTo(17f, 3.24f, 14.76f, 1f, 12f, 1f)
            reflectiveCurveTo(7f, 3.24f, 7f, 6f)
            horizontalLineTo(9f)
            curveTo(9f, 4.34f, 10.34f, 3f, 12f, 3f)
            reflectiveCurveTo(15f, 4.34f, 15f, 6f)
            verticalLineTo(8f)
            horizontalLineTo(6f)
            curveTo(4.9f, 8f, 4f, 8.9f, 4f, 10f)
            verticalLineTo(20f)
            curveTo(4f, 21.1f, 4.9f, 22f, 6f, 22f)
            horizontalLineTo(18f)
            curveTo(19.1f, 22f, 20f, 21.1f, 20f, 20f)
            verticalLineTo(10f)
            curveTo(20f, 8.9f, 19.1f, 8f, 18f, 8f)
            close()
        }
    }.build()

    val ScreenRotation: ImageVector = ImageVector.Builder(
        name = "ScreenRotation",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(16.48f, 2.52f)
            curveTo(18.06f, 4.09f, 19f, 6.27f, 19f, 8.65f)
            horizontalLineTo(21f)
            curveTo(21f, 5.76f, 19.86f, 3.12f, 17.89f, 1.15f)
            lineTo(16.48f, 2.52f)
            close()
            moveTo(7.52f, 21.48f)
            curveTo(5.94f, 19.91f, 5f, 17.73f, 5f, 15.35f)
            horizontalLineTo(3f)
            curveTo(3f, 18.24f, 4.14f, 20.88f, 6.11f, 22.85f)
            lineTo(7.52f, 21.48f)
            close()
            moveTo(14.83f, 4.83f)
            lineTo(4.83f, 14.83f)
            curveTo(4.35f, 15.31f, 4.35f, 16.09f, 4.83f, 16.57f)
            lineTo(7.43f, 19.17f)
            curveTo(7.91f, 19.65f, 8.69f, 19.65f, 9.17f, 19.17f)
            lineTo(19.17f, 9.17f)
            curveTo(19.65f, 8.69f, 19.65f, 7.91f, 19.17f, 7.43f)
            lineTo(16.57f, 4.83f)
            curveTo(16.09f, 4.35f, 15.31f, 4.35f, 14.83f, 4.83f)
            close()
        }
    }.build()

    val Folder: ImageVector = ImageVector.Builder(
        name = "Folder",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(10f, 4f)
            horizontalLineTo(4f)
            curveTo(2.9f, 4f, 2f, 4.9f, 2f, 6f)
            verticalLineTo(18f)
            curveTo(2f, 19.1f, 2.9f, 20f, 4f, 20f)
            horizontalLineTo(20f)
            curveTo(21.1f, 20f, 22f, 19.1f, 22f, 18f)
            verticalLineTo(8f)
            curveTo(22f, 6.9f, 21.1f, 6f, 20f, 6f)
            horizontalLineTo(12f)
            lineTo(10f, 4f)
            close()
        }
    }.build()

    val Videocam: ImageVector = ImageVector.Builder(
        name = "Videocam",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(17f, 10.5f)
            verticalLineTo(7f)
            curveTo(17f, 6.45f, 16.55f, 6f, 16f, 6f)
            horizontalLineTo(4f)
            curveTo(3.45f, 6f, 3f, 6.45f, 3f, 7f)
            verticalLineTo(17f)
            curveTo(3f, 17.55f, 3.45f, 18f, 4f, 18f)
            horizontalLineTo(16f)
            curveTo(16.55f, 18f, 17f, 17.55f, 17f, 17f)
            verticalLineTo(13.5f)
            lineTo(21f, 17.5f)
            verticalLineTo(6.5f)
            lineTo(17f, 10.5f)
            close()
        }
    }.build()

    val Audiotrack: ImageVector = MusicNote

    val SwapVert: ImageVector = ImageVector.Builder(
        name = "SwapVert",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(16f, 17.01f)
            verticalLineTo(10f)
            horizontalLineTo(14f)
            verticalLineTo(17.01f)
            horizontalLineTo(11f)
            lineTo(15f, 21f)
            lineTo(19f, 17.01f)
            horizontalLineTo(16f)
            close()
            moveTo(9f, 3f)
            lineTo(5f, 6.99f)
            horizontalLineTo(8f)
            verticalLineTo(14f)
            horizontalLineTo(10f)
            verticalLineTo(6.99f)
            horizontalLineTo(13f)
            lineTo(9f, 3f)
            close()
        }
    }.build()

    val ViewList: ImageVector = ImageVector.Builder(
        name = "ViewList",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(4f, 14f)
            horizontalLineTo(8f)
            verticalLineTo(10f)
            horizontalLineTo(4f)
            verticalLineTo(14f)
            close()
            moveTo(4f, 19f)
            horizontalLineTo(8f)
            verticalLineTo(15f)
            horizontalLineTo(4f)
            verticalLineTo(19f)
            close()
            moveTo(4f, 9f)
            horizontalLineTo(8f)
            verticalLineTo(5f)
            horizontalLineTo(4f)
            verticalLineTo(9f)
            close()
            moveTo(9f, 14f)
            horizontalLineTo(21f)
            verticalLineTo(10f)
            horizontalLineTo(9f)
            verticalLineTo(14f)
            close()
            moveTo(9f, 19f)
            horizontalLineTo(21f)
            verticalLineTo(15f)
            horizontalLineTo(9f)
            verticalLineTo(19f)
            close()
            moveTo(9f, 5f)
            verticalLineTo(9f)
            horizontalLineTo(21f)
            verticalLineTo(5f)
            horizontalLineTo(9f)
            close()
        }
    }.build()

    val GridView: ImageVector = ImageVector.Builder(
        name = "GridView",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(3f, 3f)
            verticalLineTo(11f)
            horizontalLineTo(11f)
            verticalLineTo(3f)
            horizontalLineTo(3f)
            close()
            moveTo(3f, 13f)
            verticalLineTo(21f)
            horizontalLineTo(11f)
            verticalLineTo(13f)
            horizontalLineTo(3f)
            close()
            moveTo(13f, 3f)
            verticalLineTo(11f)
            horizontalLineTo(21f)
            verticalLineTo(3f)
            horizontalLineTo(13f)
            close()
            moveTo(13f, 13f)
            verticalLineTo(21f)
            horizontalLineTo(21f)
            verticalLineTo(13f)
            horizontalLineTo(13f)
            close()
        }
    }.build()

    val VisibilityOff: ImageVector = ImageVector.Builder(
        name = "VisibilityOff",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 7f)
            curveTo(14.76f, 7f, 17f, 9.24f, 17f, 12f)
            curveTo(17f, 12.64f, 16.87f, 13.26f, 16.64f, 13.82f)
            lineTo(19.57f, 16.75f)
            curveTo(21.07f, 15.5f, 22.27f, 13.86f, 23f, 12f)
            curveTo(21.27f, 7.61f, 17f, 4.5f, 12f, 4.5f)
            curveTo(10.6f, 4.5f, 9.26f, 4.75f, 8.02f, 5.2f)
            lineTo(10.18f, 7.36f)
            curveTo(10.74f, 7.13f, 11.36f, 7f, 12f, 7f)
            close()
            moveTo(2f, 4.27f)
            lineTo(4.28f, 6.55f)
            curveTo(2.88f, 7.84f, 1.77f, 9.8f, 1f, 12f)
            curveTo(2.73f, 16.39f, 7f, 19.5f, 12f, 19.5f)
            curveTo(13.55f, 19.5f, 15.03f, 19.2f, 16.38f, 18.65f)
            lineTo(19.73f, 22f)
            lineTo(21f, 20.73f)
            lineTo(3.27f, 3f)
            lineTo(2f, 4.27f)
            close()
        }
    }.build()

    val Palette: ImageVector = ImageVector.Builder(
        name = "Palette",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f)
            curveTo(7.03f, 3f, 3f, 7.03f, 3f, 12f)
            curveTo(3f, 16.97f, 7.03f, 21f, 12f, 21f)
            curveTo(12.83f, 21f, 13.5f, 20.33f, 13.5f, 19.5f)
            curveTo(13.5f, 19.11f, 13.35f, 18.76f, 13.11f, 18.49f)
            curveTo(12.88f, 18.23f, 12.73f, 17.88f, 12.73f, 17.5f)
            curveTo(12.73f, 16.67f, 13.4f, 16f, 14.23f, 16f)
            horizontalLineTo(16f)
            curveTo(18.76f, 16f, 21f, 13.76f, 21f, 11f)
            curveTo(21f, 6.58f, 16.97f, 3f, 12f, 3f)
            close()
        }
    }.build()

    val Wallpaper: ImageVector = ImageVector.Builder(
        name = "Wallpaper",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(4f, 4f)
            horizontalLineTo(7f)
            verticalLineTo(2f)
            horizontalLineTo(4f)
            curveTo(2.9f, 2f, 2f, 2.9f, 2f, 4f)
            verticalLineTo(7f)
            horizontalLineTo(4f)
            verticalLineTo(4f)
            close()
            moveTo(4f, 17f)
            horizontalLineTo(2f)
            verticalLineTo(20f)
            curveTo(2f, 21.1f, 2.9f, 22f, 4f, 22f)
            horizontalLineTo(7f)
            verticalLineTo(20f)
            horizontalLineTo(4f)
            verticalLineTo(17f)
            close()
            moveTo(20f, 20f)
            horizontalLineTo(17f)
            verticalLineTo(22f)
            horizontalLineTo(20f)
            curveTo(21.1f, 22f, 22f, 21.1f, 22f, 20f)
            verticalLineTo(17f)
            horizontalLineTo(20f)
            verticalLineTo(20f)
            close()
            moveTo(20f, 4f)
            verticalLineTo(7f)
            horizontalLineTo(22f)
            verticalLineTo(4f)
            curveTo(22f, 2.9f, 21.1f, 2f, 20f, 2f)
            horizontalLineTo(17f)
            verticalLineTo(4f)
            horizontalLineTo(20f)
            close()
            moveTo(10f, 13f)
            lineTo(7f, 17f)
            horizontalLineTo(17f)
            lineTo(13.5f, 12.5f)
            lineTo(11f, 15.5f)
            lineTo(10f, 13f)
            close()
        }
    }.build()

    val AddPhoto: ImageVector = ImageVector.Builder(
        name = "AddPhoto",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(19f, 7f)
            verticalLineTo(4f)
            horizontalLineTo(17f)
            verticalLineTo(7f)
            horizontalLineTo(14f)
            verticalLineTo(9f)
            horizontalLineTo(17f)
            verticalLineTo(12f)
            horizontalLineTo(19f)
            verticalLineTo(9f)
            horizontalLineTo(22f)
            verticalLineTo(7f)
            horizontalLineTo(19f)
            close()
            moveTo(16f, 11.5f)
            verticalLineTo(14f)
            horizontalLineTo(5f)
            verticalLineTo(5f)
            horizontalLineTo(13.5f)
            verticalLineTo(3f)
            horizontalLineTo(5f)
            curveTo(3.9f, 3f, 3f, 3.9f, 3f, 5f)
            verticalLineTo(19f)
            curveTo(3f, 20.1f, 3.9f, 21f, 5f, 21f)
            horizontalLineTo(19f)
            curveTo(20.1f, 21f, 21f, 20.1f, 21f, 19f)
            verticalLineTo(11.5f)
            horizontalLineTo(16f)
            close()
        }
    }.build()

    val Pattern: ImageVector = ImageVector.Builder(
        name = "Pattern",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 6f)
            horizontalLineTo(8f)
            verticalLineTo(8f)
            horizontalLineTo(6f)
            close()
            moveTo(11f, 6f)
            horizontalLineTo(13f)
            verticalLineTo(8f)
            horizontalLineTo(11f)
            close()
            moveTo(16f, 6f)
            horizontalLineTo(18f)
            verticalLineTo(8f)
            horizontalLineTo(16f)
            close()
            moveTo(6f, 11f)
            horizontalLineTo(8f)
            verticalLineTo(13f)
            horizontalLineTo(6f)
            close()
            moveTo(11f, 11f)
            horizontalLineTo(13f)
            verticalLineTo(13f)
            horizontalLineTo(11f)
            close()
            moveTo(16f, 11f)
            horizontalLineTo(18f)
            verticalLineTo(13f)
            horizontalLineTo(16f)
            close()
            moveTo(6f, 16f)
            horizontalLineTo(8f)
            verticalLineTo(18f)
            horizontalLineTo(6f)
            close()
            moveTo(11f, 16f)
            horizontalLineTo(13f)
            verticalLineTo(18f)
            horizontalLineTo(11f)
            close()
            moveTo(16f, 16f)
            horizontalLineTo(18f)
            verticalLineTo(18f)
            horizontalLineTo(16f)
            close()
        }
    }.build()

    val Backspace: ImageVector = ImageVector.Builder(
        name = "Backspace",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(22f, 3f)
            horizontalLineTo(7f)
            curveTo(6.31f, 3f, 5.7f, 3.43f, 5.42f, 4.07f)
            lineTo(0f, 12f)
            lineTo(5.42f, 19.93f)
            curveTo(5.7f, 20.57f, 6.31f, 21f, 7f, 21f)
            horizontalLineTo(22f)
            curveTo(23.1f, 21f, 24f, 20.1f, 24f, 19f)
            verticalLineTo(5f)
            curveTo(24f, 3.9f, 23.1f, 3f, 22f, 3f)
            close()
            moveTo(19f, 15.59f)
            lineTo(17.59f, 17f)
            lineTo(14f, 13.41f)
            lineTo(10.41f, 17f)
            lineTo(9f, 15.59f)
            lineTo(12.59f, 12f)
            lineTo(9f, 8.41f)
            lineTo(10.41f, 7f)
            lineTo(14f, 10.59f)
            lineTo(17.59f, 7f)
            lineTo(19f, 8.41f)
            lineTo(15.41f, 12f)
            lineTo(19f, 15.59f)
            close()
        }
    }.build()

    val Restore: ImageVector = ImageVector.Builder(
        name = "Restore",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(13f, 3f)
            curveTo(8.03f, 3f, 4f, 7.03f, 4f, 12f)
            horizontalLineTo(1f)
            lineTo(4.89f, 15.89f)
            lineTo(5f, 16f)
            lineTo(9f, 12f)
            horizontalLineTo(6f)
            curveTo(6f, 8.13f, 9.13f, 5f, 13f, 5f)
            curveTo(16.87f, 5f, 20f, 8.13f, 20f, 12f)
            curveTo(20f, 15.87f, 16.87f, 19f, 13f, 19f)
            curveTo(11.07f, 19f, 9.32f, 18.21f, 8.06f, 16.94f)
            lineTo(6.64f, 18.36f)
            curveTo(8.27f, 20f, 10.51f, 21f, 13f, 21f)
            curveTo(17.97f, 21f, 22f, 16.97f, 22f, 12f)
            curveTo(22f, 7.03f, 17.97f, 3f, 13f, 3f)
            close()
            moveTo(12f, 8f)
            verticalLineTo(13f)
            lineTo(16.28f, 15.54f)
            lineTo(17f, 14.33f)
            lineTo(13.5f, 12.25f)
            verticalLineTo(8f)
            horizontalLineTo(12f)
            close()
        }
    }.build()
}
