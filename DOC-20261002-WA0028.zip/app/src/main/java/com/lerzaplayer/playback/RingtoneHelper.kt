package com.lerzaplayer.playback

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import com.lerzaplayer.data.model.SongItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

object RingtoneHelper {
    suspend fun setSongAsRingtone(context: Context, song: SongItem) = withContext(Dispatchers.IO) {
        // 1. Export file to public Ringtones directory so phone always has it in ringtone selector
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Audio.Media.DISPLAY_NAME, "${song.title}.mp3")
                    put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
                    put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_RINGTONES)
                    put(MediaStore.Audio.Media.IS_RINGTONE, 1)
                }
                val newUri = context.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                if (newUri != null) {
                    context.contentResolver.openInputStream(song.contentUri)?.use { input ->
                        context.contentResolver.openOutputStream(newUri)?.use { output ->
                            input.copyTo(output)
                        }
                    }
                }
            } else {
                val ringtonesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RINGTONES)
                if (!ringtonesDir.exists()) ringtonesDir.mkdirs()
                val destFile = File(ringtonesDir, "${song.title}.mp3")
                File(song.path).copyTo(destFile, overwrite = true)
            }
        } catch (_: Exception) {}

        // 2. Set as default ringtone if WRITE_SETTINGS is allowed
        withContext(Dispatchers.Main) {
            val canWrite = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.System.canWrite(context)
            } else {
                true
            }

            if (canWrite) {
                try {
                    RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, song.contentUri)
                    Toast.makeText(context, "Ringtone set successfully!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Saved to Ringtones folder!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(
                    context,
                    "Saved to Ringtones! To set as default, enable 'Modify system settings'. (If greyed out, tap 3-dots in App Info -> 'Allow restricted settings')",
                    Toast.LENGTH_LONG
                ).show()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                            data = Uri.parse("package:${context.packageName}")
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(intent)
                    } catch (_: Exception) {}
                }
            }
        }
    }
}
