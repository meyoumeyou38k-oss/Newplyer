package com.lerzaplayer.data.language

import androidx.compose.runtime.compositionLocalOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    URDU("ur", "Urdu", "اردو"),
    HINDI("hi", "Hindi", "हिन्दी");

    companion object {
        fun fromCode(code: String): AppLanguage {
            return entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: ENGLISH
        }
    }
}

data class AppStrings(
    // Bottom Tabs
    val tabVideos: String,
    val tabSongs: String,
    val tabPlaylists: String,
    val tabFolders: String,
    val tabAlbums: String,
    val tabArtists: String,

    // Header & Search
    val searchPlaceholder: String,
    val settingsTitle: String,

    // Settings Main
    val playtimeTitle: String,
    val backupRestoreTitle: String,
    val themeTitle: String,
    val sleepTimerTitle: String,
    val equalizerTitle: String,
    val vaultTitle: String,
    val recentlyDeletedTitle: String,
    val soundQualityTitle: String,
    val notificationsTitle: String,
    val languageTitle: String,
    val checkForUpdatesTitle: String,
    val aboutTitle: String,

    // Sound Quality & Effects
    val hiResTitle: String,
    val hiResDesc: String,
    val spatialSurroundTitle: String,
    val spatialSurroundDesc: String,
    val gaplessTitle: String,
    val gaplessDesc: String,
    val autoPauseTitle: String,
    val autoPauseDesc: String,
    val crossfadeTitle: String,
    val crossfadeDesc: String,
    val vocalBoosterTitle: String,
    val vocalBoosterDesc: String,

    // Player & Controls
    val volumeBooster: String,
    val volumeBoost5x: String,
    val playAsAudio: () -> String,
    val floatingPip: String,
    val previous: String,
    val next: String,
    val play: String,
    val pause: String,
    val delete: String,
    val cancel: String
)

val EnglishStrings = AppStrings(
    tabVideos = "Videos",
    tabSongs = "Songs",
    tabPlaylists = "Playlists",
    tabFolders = "Folders",
    tabAlbums = "Albums",
    tabArtists = "Artists",
    searchPlaceholder = "Search songs, videos, artists...",
    settingsTitle = "Settings",
    playtimeTitle = "Playtime",
    backupRestoreTitle = "Backup & restore",
    themeTitle = "Theme & style",
    sleepTimerTitle = "Sleep timer",
    equalizerTitle = "Audio Equalizer & Bass",
    vaultTitle = "Hidden files (Vault)",
    recentlyDeletedTitle = "Recently deleted",
    soundQualityTitle = "Sound Quality & Audio Effects",
    notificationsTitle = "Notification settings",
    languageTitle = "Language",
    checkForUpdatesTitle = "Check for Updates",
    aboutTitle = "About LerzaPlayer",
    hiResTitle = "High-Res Audio Output",
    hiResDesc = "24-bit / 192kHz Studio Master Output",
    spatialSurroundTitle = "3D Spatial Surround Virtualizer",
    spatialSurroundDesc = "Expands soundstage for headphones and earphones",
    gaplessTitle = "Gapless Playback",
    gaplessDesc = "Continuous flow without silence between tracks",
    autoPauseTitle = "Headphone Safety Auto-Pause",
    autoPauseDesc = "Automatically pause when unplugging headphones",
    crossfadeTitle = "Song Crossfade Transition",
    crossfadeDesc = "Fade out ending song while fading in next track",
    vocalBoosterTitle = "Vocal Clarity Booster",
    vocalBoosterDesc = "Enhance speech and vocal clarity in music and videos",
    volumeBooster = "Volume Booster",
    volumeBoost5x = "5X Audio Boost (Up to 300%)",
    playAsAudio = { "Play as Audio" },
    floatingPip = "Floating window (PiP)",
    previous = "Previous",
    next = "Next",
    play = "Play",
    pause = "Pause",
    delete = "Delete",
    cancel = "Cancel"
)

val UrduStrings = AppStrings(
    tabVideos = "ویڈیوز",
    tabSongs = "گانے",
    tabPlaylists = "پلے لسٹس",
    tabFolders = "فولڈرز",
    tabAlbums = "البمز",
    tabArtists = "فنکار",
    searchPlaceholder = "گانے، ویڈیوز، فنکار تلاش کریں...",
    settingsTitle = "ترتیبات",
    playtimeTitle = "پلے ٹائم",
    backupRestoreTitle = "بیک اپ اور بحالی",
    themeTitle = "تھیم اور انداز",
    sleepTimerTitle = "سلیپ ٹائمر",
    equalizerTitle = "آڈیو ایکویلائزر اور باس",
    vaultTitle = "چھپی ہوئی فائلیں (والٹ)",
    recentlyDeletedTitle = "حال ہی میں حذف شدہ",
    soundQualityTitle = "صوتی معیار اور آڈیو اثرات",
    notificationsTitle = "نوٹیفکیشن کی ترتیبات",
    languageTitle = "زبان (Language)",
    checkForUpdatesTitle = "اپ ڈیٹس چیک کریں",
    aboutTitle = "لرزا پلیئر کے بارے میں",
    hiResTitle = "ہائی ریزولوشن آڈیو آؤٹ پٹ",
    hiResDesc = "24-بٹ / 192 کلو ہرٹز اسٹوڈیو ماسٹر آؤٹ پٹ",
    spatialSurroundTitle = "تھری ڈی اسپیشل سراؤنڈ ورچوئلائزر",
    spatialSurroundDesc = "ہیڈ فونز اور ایئرفونز کے لیے ساؤنڈ اسٹیج کو وسیع کرتا ہے",
    gaplessTitle = "گیپ لیس پلے بیک",
    gaplessDesc = "ٹریکس کے درمیان خاموشی کے بغیر تسلسل",
    autoPauseTitle = "ہیڈ فون الگ ہونے پر خودکار توقف",
    autoPauseDesc = "ہیڈ فون اتارنے پر خودکار پلے بند ہو جائے گا",
    crossfadeTitle = "سونگ کراس فیڈ ٹرانزیشن",
    crossfadeDesc = "اگلے گانے کو مدہم کرتے ہوئے ملانا",
    vocalBoosterTitle = "ووکل کلیرٹی بوسٹر",
    vocalBoosterDesc = "گانے اور ویڈیو میں آواز کو صاف اور واضح بنائیں",
    volumeBooster = "والیوم بوسٹر",
    volumeBoost5x = "5 گنا زبردست بوسٹ (300% تک)",
    playAsAudio = { "بطور آڈیو چلائیں" },
    floatingPip = "فلوٹنگ ونڈو (PiP)",
    previous = "پچھلا",
    next = "اگلا",
    play = "چلائیں",
    pause = "روکیں",
    delete = "حذف کریں",
    cancel = "منسوخ کریں"
)

val HindiStrings = AppStrings(
    tabVideos = "वीडियो",
    tabSongs = "गाने",
    tabPlaylists = "प्लेलिस्ट",
    tabFolders = "फ़ोल्डर",
    tabAlbums = "एल्बम",
    tabArtists = "कलाकार",
    searchPlaceholder = "गाने, वीडियो, कलाकार खोजें...",
    settingsTitle = "सेटिंग्स",
    playtimeTitle = "प्ले टाइम",
    backupRestoreTitle = "बैकअप और रीस्टोर",
    themeTitle = "थीम और स्टाइल",
    sleepTimerTitle = "स्लीप टाइमर",
    equalizerTitle = "ऑडियो इक्वलाइज़र और बास",
    vaultTitle = "छिपी हुई फ़ाइलें (वॉल्ट)",
    recentlyDeletedTitle = "हाल ही में हटाए गए",
    soundQualityTitle = "ध्वनि गुणवत्ता और ऑडियो प्रभाव",
    notificationsTitle = "सूचना सेटिंग्स",
    languageTitle = "भाषा (Language)",
    checkForUpdatesTitle = "अपडेट की जाँच करें",
    aboutTitle = "लरज़ा प्लेयर के बारे में",
    hiResTitle = "हाई-रेस ऑडियो आउटपुट",
    hiResDesc = "24-बिट / 192kHz स्टूडियो मास्टर आउटपुट",
    spatialSurroundTitle = "3D स्थानिक सराउंड वर्चुअलाइज़र",
    spatialSurroundDesc = "हेडफ़ोन और इयरफ़ोन के लिए साउंडस्टेज का विस्तार करता है",
    gaplessTitle = "गैपलेस प्लेबैक",
    gaplessDesc = "ट्रैक्स के बीच बिना रुकावट निरंतर प्रवाह",
    autoPauseTitle = "हेडफ़ोन सुरक्षा ऑटो-पॉज़",
    autoPauseDesc = "हेडफ़ोन अनप्लग करने पर स्वचालित रूप से रोकें",
    crossfadeTitle = "सॉन्ग क्रॉसफ़ेड ट्रांज़िशन",
    crossfadeDesc = "अगले ट्रैक में सहज फेड ट्रांज़िशन",
    vocalBoosterTitle = "वोकल क्लैरिटी बूस्टर",
    vocalBoosterDesc = "संगीत और वीडियो में आवाज़ को स्पष्ट और साफ़ बनाएं",
    volumeBooster = "वॉल्यूम बूस्टर",
    volumeBoost5x = "5 गुना शक्तिशाली बूस्ट (300% तक)",
    playAsAudio = { "ऑडियो के रूप में चलाएं" },
    floatingPip = "फ्लोटिंग विंडो (PiP)",
    previous = "पिछला",
    next = "अगला",
    play = "चलाएं",
    pause = "रोकें",
    delete = "हटाएं",
    cancel = "रद्द करें"
)

object LanguageManager {
    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    val strings: AppStrings
        get() = when (_currentLanguage.value) {
            AppLanguage.ENGLISH -> EnglishStrings
            AppLanguage.URDU -> UrduStrings
            AppLanguage.HINDI -> HindiStrings
        }

    fun setLanguage(lang: AppLanguage) {
        _currentLanguage.value = lang
    }

    fun getStringsFor(lang: AppLanguage): AppStrings {
        return when (lang) {
            AppLanguage.ENGLISH -> EnglishStrings
            AppLanguage.URDU -> UrduStrings
            AppLanguage.HINDI -> HindiStrings
        }
    }
}

val LocalAppStrings = compositionLocalOf { EnglishStrings }
