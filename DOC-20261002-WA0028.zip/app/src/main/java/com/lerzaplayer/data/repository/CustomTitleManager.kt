package com.lerzaplayer.data.repository

import android.content.Context
import android.content.SharedPreferences

object CustomTitleManager {
    private const val PREF_NAME = "lerza_custom_titles"
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        }
    }

    fun setTitle(mediaId: Long, newTitle: String) {
        prefs?.edit()?.putString("title_$mediaId", newTitle.trim())?.apply()
    }

    fun getTitle(mediaId: Long, defaultTitle: String): String {
        return prefs?.getString("title_$mediaId", defaultTitle) ?: defaultTitle
    }

    fun getAllCustomTitles(): Map<Long, String> {
        val map = mutableMapOf<Long, String>()
        prefs?.all?.forEach { (key, value) ->
            if (key.startsWith("title_") && value is String) {
                key.removePrefix("title_").toLongOrNull()?.let { id ->
                    map[id] = value
                }
            }
        }
        return map
    }
}
