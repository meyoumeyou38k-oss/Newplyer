package com.lerzaplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.repository.MediaRepository
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaPlayerTheme
import com.lerzaplayer.ui.home.HomeScreen
import com.lerzaplayer.ui.player.VideoPlayerScreen
import com.lerzaplayer.ui.search.SearchScreen
import com.lerzaplayer.ui.settings.SettingsScreen
import com.lerzaplayer.ui.vault.VaultScreen
import kotlinx.coroutines.launch

enum class AppDestination { HOME, SETTINGS, VAULT, SEARCH }

class MainActivity : ComponentActivity() {
    private lateinit var mediaRepository: MediaRepository
    private lateinit var playerManager: PlayerManager

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (::mediaRepository.isInitialized) mediaRepository.refreshMedia()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as LerzaApp
        mediaRepository = MediaRepository(this)
        playerManager = app.playerManager
        requestPermissions()

        setContent {
            val prefManager = app.preferenceManager
            val currentTheme by prefManager.themeFlow.collectAsState(initial = "AMOLED Black")
            val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
            val songs by mediaRepository.getSongsFlow(songSort).collectAsState(initial = emptyList())
            val videos by mediaRepository.getVideosFlow(SortOption.DATE_ADDED_DESC).collectAsState(initial = emptyList())
            val recentlyDeleted by mediaRepository.getRecentlyDeletedFlow().collectAsState(initial = emptyList())
            val scope = rememberCoroutineScope()

            var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
            var activePlayingVideo by remember { mutableStateOf<VideoItem?>(null) }

            LerzaPlayerTheme(themeName = currentTheme) {
                Box(modifier = Modifier.fillMaxSize()) {
                    when (currentDestination) {
                        AppDestination.HOME -> {
                            HomeScreen(
                                songs = songs,
                                videos = videos,
                                playerManager = playerManager,
                                prefManager = prefManager,
                                onSearchClick = { currentDestination = AppDestination.SEARCH },
                                onSettingsClick = { currentDestination = AppDestination.SETTINGS },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                onExpandFullPlayer = {},
                                onPlayVideo = { vid -> activePlayingVideo = vid },
                                onToggleFavoriteSong = {},
                                onToggleFavoriteVideo = {},
                                onHideSongInVault = { song -> scope.launch { app.vaultManager.hideSong(song) } },
                                onHideVideoInVault = {},
                                onDeleteSong = { song -> scope.launch { mediaRepository.deleteMedia(song) } },
                                onDeleteVideo = {},
                                onScanDevice = { mediaRepository.refreshMedia() }
                            )
                        }
                        AppDestination.SETTINGS -> {
                            SettingsScreen(
                                prefManager = prefManager,
                                onBack = { currentDestination = AppDestination.HOME },
                                onOpenEqualizer = {},
                                onScanMedia = { mediaRepository.refreshMedia() },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                recentlyDeleted = recentlyDeleted,
                                onPlayRecentlyDeleted = {},
                                onRestoreRecentlyDeleted = { item -> scope.launch { mediaRepository.restoreRecentlyDeleted(item) } },
                                onPermanentlyDeleteRecentlyDeleted = { item -> scope.launch { mediaRepository.permanentlyDeleteRecentlyDeleted(item) } }
                            )
                        }
                        AppDestination.VAULT -> {
                            VaultScreen(
                                vaultManager = app.vaultManager,
                                onBack = { currentDestination = AppDestination.HOME }
                            )
                        }
                        AppDestination.SEARCH -> {
                            SearchScreen(
                                songs = songs,
                                videos = videos,
                                currentSong = playerManager.currentSong.collectAsState().value,
                                isPlaying = playerManager.isPlaying.collectAsState().value,
                                onSongClick = { playerManager.playSong(it) },
                                onVideoClick = { vid -> activePlayingVideo = vid },
                                onBack = { currentDestination = AppDestination.HOME },
                                onToggleFavoriteSong = {},
                                onAddToQueue = { playerManager.addToQueue(it) }
                            )
                        }
                    }

                    activePlayingVideo?.let { vid ->
                        VideoPlayerScreen(
                            video = vid,
                            onClose = { activePlayingVideo = null },
                            onPlayAsAudio = {
                                activePlayingVideo = null
                            }
                        )
                    }
                }
            }
        }
    }

    private fun requestPermissions() {
        val perms = if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.POST_NOTIFICATIONS
            )
        } else {
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }
        val needed = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
    }
}
