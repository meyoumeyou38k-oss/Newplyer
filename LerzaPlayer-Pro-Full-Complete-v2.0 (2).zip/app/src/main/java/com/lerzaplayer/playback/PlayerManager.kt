package com.lerzaplayer.playback

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.lerzaplayer.data.model.SongItem
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PlayerManager private constructor(private val context: Context) {
    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context).build()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val _currentSong = MutableStateFlow<SongItem?>(null)
    val currentSong: StateFlow<SongItem?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition: StateFlow<Long> = _currentPosition.asStateFlow()

    private val _duration = MutableStateFlow(0L)
    val duration: StateFlow<Long> = _duration.asStateFlow()

    private val _queue = MutableStateFlow<List<SongItem>>(emptyList())
    val queue: StateFlow<List<SongItem>> = _queue.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { _isPlaying.value = playing }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) { _duration.value = exoPlayer.duration.coerceAtLeast(0L) }
                else if (state == Player.STATE_ENDED) { playNextTrack() }
            }
        })
        scope.launch {
            while (isActive) {
                if (exoPlayer.isPlaying) {
                    _currentPosition.value = exoPlayer.currentPosition
                    _duration.value = exoPlayer.duration.coerceAtLeast(0L)
                }
                delay(400)
            }
        }
    }

    fun playSongList(songs: List<SongItem>, startIndex: Int) {
        if (songs.isEmpty() || startIndex !in songs.indices) return
        _queue.value = songs
        _currentIndex.value = startIndex
        val song = songs[startIndex]
        _currentSong.value = song
        exoPlayer.setMediaItem(MediaItem.fromUri(song.contentUri))
        exoPlayer.prepare()
        exoPlayer.play()
        ContextCompat.startForegroundService(context, Intent(context, PlaybackService::class.java))
    }

    fun playSong(song: SongItem) = playSongList(listOf(song), 0)
    fun playNext(song: SongItem) {
        val list = _queue.value.toMutableList()
        val insertIndex = (_currentIndex.value + 1).coerceIn(0, list.size)
        list.add(insertIndex, song)
        _queue.value = list
    }
    fun addToQueue(song: SongItem) { _queue.value = _queue.value + song }
    fun play() = exoPlayer.play()
    fun pause() = exoPlayer.pause()
    fun playPause() = if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
    fun seekTo(posMs: Long) { exoPlayer.seekTo(posMs); _currentPosition.value = posMs }

    fun playNextTrack() {
        val q = _queue.value
        if (q.isEmpty()) return
        val nextIdx = (_currentIndex.value + 1) % q.size
        _currentIndex.value = nextIdx
        val nextSong = q[nextIdx]
        _currentSong.value = nextSong
        exoPlayer.setMediaItem(MediaItem.fromUri(nextSong.contentUri))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun playPreviousTrack() {
        val q = _queue.value
        if (q.isEmpty()) return
        val prevIdx = if (_currentIndex.value > 0) _currentIndex.value - 1 else q.size - 1
        _currentIndex.value = prevIdx
        val prevSong = q[prevIdx]
        _currentSong.value = prevSong
        exoPlayer.setMediaItem(MediaItem.fromUri(prevSong.contentUri))
        exoPlayer.prepare()
        exoPlayer.play()
    }

    fun clearQueue() {
        _queue.value = emptyList()
        _currentSong.value = null
        exoPlayer.stop()
    }

    companion object {
        @Volatile private var INSTANCE: PlayerManager? = null
        fun getInstance(ctx: Context): PlayerManager = INSTANCE ?: synchronized(this) {
            INSTANCE ?: PlayerManager(ctx.applicationContext).also { INSTANCE = it }
        }
    }
}
