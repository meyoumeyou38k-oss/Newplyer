package com.lerzaplayer.playback

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import com.lerzaplayer.data.repository.ThumbnailExtractor
import kotlinx.coroutines.*

class MediaDownloadMonitor(context: Context) {
    private val appContext = context.applicationContext
    private val resolver = appContext.contentResolver
    private val preferences = appContext.getSharedPreferences("media_download_monitor_v2", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val seenIds = preferences.getStringSet("seen_ids", emptySet())?.toMutableSet() ?: mutableSetOf()
    private var scanJob: Job? = null

    @Volatile private var isStarted = false

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean, uri: Uri?) { scheduleScan() }
        override fun onChange(selfChange: Boolean) { scheduleScan() }
    }

    @Synchronized
    fun start() {
        if (isStarted || !hasMediaPermission()) return
        if (!preferences.getBoolean("initialized", false)) {
            val existing = queryExistingIds()
            synchronized(seenIds) { seenIds.addAll(existing) }
            persistSeenIds()
            preferences.edit().putBoolean("initialized", true).apply()
        }
        try {
            resolver.registerContentObserver(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, true, observer)
            resolver.registerContentObserver(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, observer)
            isStarted = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @Synchronized
    fun stop() {
        if (!isStarted) return
        runCatching { resolver.unregisterContentObserver(observer) }
        isStarted = false
    }

    private fun hasMediaPermission(): Boolean {
        val audioPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        val videoPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return appContext.checkSelfPermission(audioPermission) == PackageManager.PERMISSION_GRANTED ||
                appContext.checkSelfPermission(videoPermission) == PackageManager.PERMISSION_GRANTED
    }

    @Synchronized
    private fun scheduleScan() {
        scanJob?.cancel()
        scanJob = scope.launch {
            delay(800)
            scanAudio()
            scanVideos()
        }
    }

    private suspend fun scanAudio() = withContext(Dispatchers.IO) {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.IS_MUSIC,
            MediaStore.Audio.Media.DURATION
        )
        runCatching {
            resolver.query(collection, projection, null, null, "${MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val isMusicCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_MUSIC)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

                var count = 0
                while (cursor.moveToNext() && count < 5) {
                    if (cursor.getInt(isMusicCol) == 0 || cursor.getLong(durCol) <= 10000L) continue
                    val id = cursor.getLong(idCol)
                    if (!markAsNew("audio", id)) continue
                    val title = cursor.getString(titleCol) ?: "New Song"
                    val artist = cursor.getString(artistCol) ?: "Unknown Artist"
                    val mediaUri = ContentUris.withAppendedId(collection, id)
                    val artwork = ThumbnailExtractor.getSongCover(appContext, mediaUri, id)

                    NotificationHelper.showNewMediaNotification(
                        context = appContext,
                        heading = "New Song Downloaded!",
                        title = title,
                        detail = "Artist: $artist   Tap to play",
                        thumbnail = artwork,
                        mediaKey = "audio:$id"
                    )
                    count++
                }
            }
        }
    }

    private suspend fun scanVideos() = withContext(Dispatchers.IO) {
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE)
        runCatching {
            resolver.query(collection, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                var count = 0
                while (cursor.moveToNext() && count < 5) {
                    val id = cursor.getLong(idCol)
                    if (!markAsNew("video", id)) continue
                    val title = cursor.getString(titleCol) ?: "New Video"
                    val mediaUri = ContentUris.withAppendedId(collection, id)
                    val thumbnail = ThumbnailExtractor.getVideoThumbnail(appContext, mediaUri, id)

                    NotificationHelper.showNewMediaNotification(
                        context = appContext,
                        heading = "New Video Downloaded!",
                        title = title,
                        detail = "Tap to play in Full HD",
                        thumbnail = thumbnail,
                        mediaKey = "video:$id"
                    )
                    count++
                }
            }
        }
    }

    private fun markAsNew(type: String, id: Long): Boolean {
        val key = "$type:$id"
        val added = synchronized(seenIds) { seenIds.add(key) }
        if (added) persistSeenIds()
        return added
    }

    private fun queryExistingIds(): Set<String> {
        val result = mutableSetOf<String>()
        listOf(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to MediaStore.Audio.Media._ID,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI to MediaStore.Video.Media._ID
        ).forEach { (collection, idCol) ->
            val type = if (collection == MediaStore.Audio.Media.EXTERNAL_CONTENT_URI) "audio" else "video"
            runCatching {
                resolver.query(collection, arrayOf(idCol), null, null, null)?.use { cursor ->
                    val index = cursor.getColumnIndexOrThrow(idCol)
                    while (cursor.moveToNext()) {
                        result.add("$type:${cursor.getLong(index)}")
                    }
                }
            }
        }
        return result
    }

    private fun persistSeenIds() {
        synchronized(seenIds) {
            preferences.edit().putStringSet("seen_ids", HashSet(seenIds)).apply()
        }
    }

    fun release() {
        stop()
        scope.cancel()
    }
}
