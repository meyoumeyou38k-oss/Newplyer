package com.lerzaplayer.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object LerzaIcons {
    val Play: ImageVector = ImageVector.Builder("Play", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(8f, 5f); verticalLineTo(19f); lineTo(19f, 12f); close()
        }
    }.build()

    val Pause: ImageVector = ImageVector.Builder("Pause", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 19f); horizontalLineTo(10f); verticalLineTo(5f); horizontalLineTo(6f); close()
            moveTo(14f, 5f); verticalLineTo(19f); horizontalLineTo(18f); verticalLineTo(5f); close()
        }
    }.build()

    val PlayArrow: ImageVector = Play

    val SkipNext: ImageVector = ImageVector.Builder("SkipNext", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 18f); lineTo(14.5f, 12f); lineTo(6f, 6f); close()
            moveTo(16f, 6f); verticalLineTo(18f); horizontalLineTo(18f); verticalLineTo(6f); close()
        }
    }.build()

    val SkipPrevious: ImageVector = ImageVector.Builder("SkipPrevious", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 6f); horizontalLineTo(8f); verticalLineTo(18f); horizontalLineTo(6f); close()
            moveTo(9.5f, 12f); lineTo(18f, 18f); verticalLineTo(6f); close()
        }
    }.build()

    val FastRewind: ImageVector = ImageVector.Builder("FastRewind", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(11f, 18f); verticalLineTo(6f); lineTo(2.5f, 12f); close()
            moveTo(20.5f, 6f); lineTo(12f, 12f); lineTo(20.5f, 18f); close()
        }
    }.build()

    val FastForward: ImageVector = ImageVector.Builder("FastForward", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(4f, 18f); lineTo(12.5f, 12f); lineTo(4f, 6f); close()
            moveTo(13f, 6f); verticalLineTo(18f); lineTo(21.5f, 12f); close()
        }
    }.build()

    val Headphones: ImageVector = ImageVector.Builder("Headphones", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 3f); curveTo(7.03f, 3f, 3f, 7.03f, 3f, 12f); verticalLineTo(18f); horizontalLineTo(9f); verticalLineTo(13f); horizontalLineTo(5f); verticalLineTo(12f); curveTo(5f, 8.13f, 8.13f, 5f, 12f, 5f); curveTo(15.87f, 5f, 19f, 8.13f, 19f, 12f); verticalLineTo(13f); horizontalLineTo(15f); verticalLineTo(18f); horizontalLineTo(21f); verticalLineTo(12f); curveTo(21f, 7.03f, 16.97f, 3f, 12f, 3f); close()
        }
    }.build()

    val Lock: ImageVector = ImageVector.Builder("Lock", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(18f, 8f); horizontalLineTo(17f); verticalLineTo(6f); curveTo(17f, 3.24f, 14.76f, 1f, 12f, 1f); curveTo(9.24f, 1f, 7f, 3.24f, 7f, 6f); verticalLineTo(8f); horizontalLineTo(6f); verticalLineTo(20f); horizontalLineTo(18f); close()
            moveTo(9f, 6f); curveTo(9f, 4.34f, 10.34f, 3f, 12f, 3f); curveTo(13.66f, 3f, 15f, 4.34f, 15f, 6f); verticalLineTo(8f); horizontalLineTo(9f); close()
        }
    }.build()

    val LockOpen: ImageVector = Lock
    val Shield: ImageVector = Lock
    val Delete: ImageVector = ImageVector.Builder("Delete", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(6f, 19f); horizontalLineTo(18f); verticalLineTo(7f); horizontalLineTo(6f); close()
            moveTo(19f, 4f); horizontalLineTo(15.5f); lineTo(14.5f, 3f); horizontalLineTo(9.5f); lineTo(8.5f, 4f); horizontalLineTo(5f); verticalLineTo(6f); horizontalLineTo(19f); close()
        }
    }.build()

    val Favorite: ImageVector = ImageVector.Builder("Favorite", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 21.35f); lineTo(10.55f, 20.03f); curveTo(5.4f, 15.36f, 2f, 12.28f, 2f, 8.5f); curveTo(2f, 5.42f, 4.42f, 3f, 7.5f, 3f); curveTo(9.24f, 3f, 10.91f, 3.81f, 12f, 5.09f); curveTo(13.09f, 3.81f, 14.76f, 3f, 16.5f, 3f); curveTo(19.58f, 3f, 22f, 5.42f, 22f, 8.5f); curveTo(22f, 12.28f, 18.6f, 15.36f, 13.45f, 20.04f); close()
        }
    }.build()

    val FavoriteBorder: ImageVector = Favorite
    val MoreVert: ImageVector = ImageVector.Builder("MoreVert", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(12f, 8f); curveTo(13.1f, 8f, 14f, 7.1f, 14f, 6f); curveTo(14f, 4.9f, 13.1f, 4f, 12f, 4f); curveTo(10.9f, 4f, 10f, 4.9f, 10f, 6f); curveTo(10f, 7.1f, 10.9f, 8f, 12f, 8f); close()
            moveTo(12f, 10f); curveTo(10.9f, 10f, 10f, 10.9f, 10f, 12f); curveTo(10f, 13.1f, 10.9f, 14f, 12f, 14f); curveTo(13.1f, 14f, 14f, 13.1f, 14f, 12f); curveTo(14f, 10.9f, 13.1f, 10f, 12f, 10f); close()
            moveTo(12f, 16f); curveTo(10.9f, 16f, 10f, 16.9f, 10f, 18f); curveTo(10f, 19.1f, 10.9f, 20f, 12f, 20f); curveTo(13.1f, 20f, 14f, 19.1f, 14f, 18f); curveTo(14f, 16.9f, 13.1f, 16f, 12f, 16f); close()
        }
    }.build()

    val ArrowBack: ImageVector = ImageVector.Builder("ArrowBack", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(20f, 11f); horizontalLineTo(7.83f); lineTo(13.42f, 5.41f); lineTo(12f, 4f); lineTo(4f, 12f); lineTo(12f, 20f); lineTo(13.41f, 18.59f); lineTo(7.83f, 13f); horizontalLineTo(20f); close()
        }
    }.build()

    val Close: ImageVector = ImageVector.Builder("Close", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(19f, 6.41f); lineTo(17.59f, 5f); lineTo(12f, 10.59f); lineTo(6.41f, 5f); lineTo(5f, 6.41f); lineTo(10.59f, 12f); lineTo(5f, 17.59f); lineTo(6.41f, 19f); lineTo(12f, 13.41f); lineTo(17.59f, 19f); lineTo(19f, 17.59f); lineTo(13.41f, 12f); close()
        }
    }.build()

    val Search: ImageVector = ImageVector.Builder("Search", 24.dp, 24.dp, 24f, 24f).apply {
        path(fill = SolidColor(Color.White)) {
            moveTo(15.5f, 14f); lineTo(20.49f, 19f); lineTo(19f, 20.49f); lineTo(14f, 15.5f); curveTo(12.59f, 16f, 11.11f, 16f, 9.5f, 16f); curveTo(5.91f, 16f, 3f, 13.09f, 3f, 9.5f); curveTo(3f, 5.91f, 5.91f, 3f, 9.5f, 3f); curveTo(13.09f, 3f, 16f, 5.91f, 16f, 9.5f); curveTo(16f, 11.11f, 15.41f, 12.59f, 14.43f, 13.73f); close()
        }
    }.build()

    val Settings: ImageVector = Search
    val Speed: ImageVector = Search
    val Tune: ImageVector = Search
    val Restore: ImageVector = ArrowBack
    val Check: ImageVector = Play
    val CheckCircle: ImageVector = Play
    val Shuffle: ImageVector = Play
    val Repeat: ImageVector = Play
    val RepeatOne: ImageVector = Play
    val QueueMusic: ImageVector = Play
    val Lyrics: ImageVector = Play
    val Audiotrack: ImageVector = Play
    val MusicNote: ImageVector = Play
    val Videocam: ImageVector = Play
    val Folder: ImageVector = Play
    val SwapVert: ImageVector = ArrowBack
    val ArrowDropDown: ImageVector = ArrowBack
    val ViewList: ImageVector = Play
    val GridView: ImageVector = Play
    val VisibilityOff: ImageVector = Play
    val Palette: ImageVector = Play
    val Wallpaper: ImageVector = Play
    val AddPhoto: ImageVector = Play
    val Pattern: ImageVector = Play
    val Backspace: ImageVector = Close
    val KeyboardArrowDown: ImageVector = ArrowBack
    val ScreenRotation: ImageVector = Play
    val AspectRatio: ImageVector = Play
    val Info: ImageVector = Play
    val Share: ImageVector = Play
    val PlaylistAdd: ImageVector = Play
    val Refresh: ImageVector = ArrowBack
    val Add: ImageVector = Play
}
