package com.lerzaplayer.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class LerzaColorPalette(
    val primary: Color, val background: Color, val surface: Color,
    val card: Color, val textPrimary: Color, val textSecondary: Color, val isDark: Boolean
)

val AmoledBlackPalette = LerzaColorPalette(
    primary = Color(0xFF00E5FF), background = Color(0xFF000000), surface = Color(0xFF0D0D11),
    card = Color(0xFF16161D), textPrimary = Color(0xFFFFFFFF), textSecondary = Color(0xFF888899), isDark = true
)

val PureWhitePalette = LerzaColorPalette(
    primary = Color(0xFF1E60F2), background = Color(0xFFFFFFFF), surface = Color(0xFFF5F6FA),
    card = Color(0xFFFFFFFF), textPrimary = Color(0xFF111827), textSecondary = Color(0xFF6B7280), isDark = false
)

val LocalLerzaColors = staticCompositionLocalOf { PureWhitePalette }

@Composable
fun LerzaPlayerTheme(themeName: String = "AMOLED Black", content: @Composable () -> Unit) {
    val palette = if (themeName == "Pure White") PureWhitePalette else AmoledBlackPalette
    val materialColors = if (palette.isDark) {
        darkColorScheme(primary = palette.primary, background = palette.background, surface = palette.surface)
    } else {
        lightColorScheme(primary = palette.primary, background = palette.background, surface = palette.surface)
    }
    CompositionLocalProvider(LocalLerzaColors provides palette) {
        MaterialTheme(colorScheme = materialColors, content = content)
    }
}
