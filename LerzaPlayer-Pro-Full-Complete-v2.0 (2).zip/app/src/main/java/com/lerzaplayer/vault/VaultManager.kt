package com.lerzaplayer.vault

import android.content.Context
import android.media.MediaScannerConnection
import com.lerzaplayer.data.database.AppDatabase
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VaultLockType
import com.lerzaplayer.data.preferences.PreferenceManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import java.security.MessageDigest

class VaultManager private constructor(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val vaultDao = db.vaultDao()
    private val prefManager = PreferenceManager(context)

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    val vaultMediaFlow: Flow<List<VaultMediaEntity>> = vaultDao.getAllVaultMedia()
    val lockTypeFlow: Flow<VaultLockType> = prefManager.vaultLockTypeFlow
    val pinFlow: Flow<String?> = prefManager.vaultPinFlow
    val patternFlow: Flow<String?> = prefManager.vaultPatternFlow

    private val vaultDir: File by lazy {
        File(context.filesDir, "vault_storage").apply { if (!exists()) mkdirs() }
    }

    fun hashInput(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(input.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val saved = prefManager.vaultPinFlow.first()
        if (saved == null) {
            prefManager.setVaultPin(hashInput(pin))
            _isUnlocked.value = true
            return true
        }
        val match = hashInput(pin) == saved
        if (match) _isUnlocked.value = true
        return match
    }

    suspend fun verifyPattern(points: List<Int>): Boolean {
        val raw = points.joinToString("-")
        val saved = prefManager.vaultPatternFlow.first()
        if (saved == null) {
            prefManager.setVaultPattern(hashInput(raw))
            _isUnlocked.value = true
            return true
        }
        val match = hashInput(raw) == saved
        if (match) _isUnlocked.value = true
        return match
    }

    fun lockVault() { _isUnlocked.value = false }
    fun onAppBackgrounded() { _isUnlocked.value = false }

    suspend fun hideSong(song: SongItem) = withContext(Dispatchers.IO) {
        val src = File(song.path)
        if (!src.exists()) return@withContext
        val enc = File(vaultDir, "vault_${song.id}.bin")
        src.copyTo(enc, overwrite = true)
        src.delete()
        try { context.contentResolver.delete(song.contentUri, null, null) } catch (_: Exception) {}
        vaultDao.insertVaultMedia(
            VaultMediaEntity(song.path, enc.absolutePath, song.title, "AUDIO", song.duration, enc.length())
        )
    }

    suspend fun restoreMedia(entity: VaultMediaEntity) = withContext(Dispatchers.IO) {
        val enc = File(entity.encryptedPath)
        val dst = File(entity.originalPath)
        if (enc.exists()) {
            dst.parentFile?.mkdirs()
            enc.copyTo(dst, overwrite = true)
            enc.delete()
            MediaScannerConnection.scanFile(context, arrayOf(dst.absolutePath), null, null)
            vaultDao.deleteVaultMedia(entity)
        }
    }

    suspend fun deletePermanently(entity: VaultMediaEntity) = withContext(Dispatchers.IO) {
        runCatching { File(entity.encryptedPath).delete() }
        vaultDao.deleteVaultMedia(entity)
    }

    suspend fun restoreAllMedia(list: List<VaultMediaEntity>) = list.forEach { restoreMedia(it) }
    suspend fun resetVaultLock() {
        prefManager.setVaultPin(null)
        prefManager.setVaultPattern(null)
        _isUnlocked.value = false
    }
    suspend fun updatePin(pin: String) { prefManager.setVaultPin(hashInput(pin)) }
    suspend fun updatePattern(points: List<Int>) { prefManager.setVaultPattern(hashInput(points.joinToString("-"))) }

    companion object {
        @Volatile private var INSTANCE: VaultManager? = null
        fun getInstance(ctx: Context): VaultManager = INSTANCE ?: synchronized(this) {
            INSTANCE ?: VaultManager(ctx.applicationContext).also { INSTANCE = it }
        }
    }
}
