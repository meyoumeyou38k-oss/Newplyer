package com.lerzaplayer.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ThumbnailExtractor {
    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = maxMemory / 6
    private val memoryCache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int = bitmap.byteCount / 1024
    }

    suspend fun getSongCover(context: Context, audioUri: Uri, songId: Long): Bitmap? = withContext(Dispatchers.IO) {
        val cacheKey = "song_$songId"
        memoryCache.get(cacheKey)?.let { return@withContext it }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val bmp = context.contentResolver.loadThumbnail(audioUri, Size(160, 160), null)
                if (bmp != null) {
                    memoryCache.put(cacheKey, bmp)
                    return@withContext bmp
                }
            }
        } catch (_: Exception) {}

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, audioUri)
            val artBytes = retriever.embeddedPicture
            if (artBytes != null) {
                val opts = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.RGB_565
                    inSampleSize = 2
                }
                val bmp = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.size, opts)
                if (bmp != null) {
                    memoryCache.put(cacheKey, bmp)
                    return@withContext bmp
                }
            }
        } catch (_: Exception) {} finally {
            try { retriever.release() } catch (_: Exception) {}
        }
        null
    }

    suspend fun getVideoThumbnail(context: Context, videoUri: Uri, videoId: Long): Bitmap? = withContext(Dispatchers.IO) {
        val cacheKey = "vid_$videoId"
        memoryCache.get(cacheKey)?.let { return@withContext it }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val bmp = context.contentResolver.loadThumbnail(videoUri, Size(240, 160), null)
                if (bmp != null) {
                    memoryCache.put(cacheKey, bmp)
                    return@withContext bmp
                }
            }
        } catch (_: Exception) {}

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, videoUri)
            val bmp = retriever.getFrameAtTime(500000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            if (bmp != null) {
                memoryCache.put(cacheKey, bmp)
                return@withContext bmp
            }
        } catch (_: Exception) {} finally {
            try { retriever.release() } catch (_: Exception) {}
        }
        null
    }
}
