package com.lerzaplayer.data.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY name ASC")
    fun getAllPlaylists(): Flow<List<PlaylistEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long
    @Delete
    suspend fun deletePlaylist(playlist: PlaylistEntity)
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites ORDER BY addedAt DESC")
    fun getAllFavorites(): Flow<List<FavoriteEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(fav: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE mediaId = :id AND mediaType = :type")
    suspend fun removeFavorite(id: Long, type: String)
}

@Dao
interface VaultDao {
    @Query("SELECT * FROM vault_media ORDER BY hiddenAt DESC")
    fun getAllVaultMedia(): Flow<List<VaultMediaEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaultMedia(media: VaultMediaEntity)
    @Delete
    suspend fun deleteVaultMedia(media: VaultMediaEntity)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM play_history ORDER BY playedAt DESC LIMIT 100")
    fun getRecentHistory(): Flow<List<PlayHistoryEntity>>
}

@Dao
interface LyricsDao {
    @Query("SELECT * FROM song_lyrics WHERE songId = :songId")
    suspend fun getLyrics(songId: Long): LyricsEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLyrics(lyrics: LyricsEntity)
}

@Dao
interface RecentlyDeletedDao {
    @Query("SELECT * FROM recently_deleted WHERE deletedAt >= :since ORDER BY deletedAt DESC")
    fun getRecent(since: Long): Flow<List<RecentlyDeletedEntity>>
    @Insert
    suspend fun insert(item: RecentlyDeletedEntity): Long
    @Delete
    suspend fun delete(item: RecentlyDeletedEntity)
    @Query("DELETE FROM recently_deleted WHERE deletedAt < :before")
    suspend fun deleteExpired(before: Long)
}
