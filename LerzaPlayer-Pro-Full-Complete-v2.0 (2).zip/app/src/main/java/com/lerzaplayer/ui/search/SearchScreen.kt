package com.lerzaplayer.ui.search

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow

@Composable
fun SearchScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onBack: () -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onAddToQueue: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var query by remember { mutableStateOf("") }
    val predictions = listOf("Sidhu Moose Wala", "Diljit Dosanjh", "Sad Songs", "Punjabi Remix", "Atif Aslam", "Arijit Singh")

    BackHandler { onBack() }

    Column(modifier = modifier.fillMaxSize().background(colors.background)) {
        Surface(color = colors.surface, modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary) }
                    TextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Search songs, typos, artists...", fontSize = 14.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    predictions.forEach { pred ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(colors.card)
                                .clickable { query = pred }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(pred, fontSize = 11.sp, color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        val filtered = songs.filter {
            query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true)
        }

        LazyColumn(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            items(filtered, key = { it.id }) { song ->
                SongItemRow(
                    song = song,
                    isPlaying = isPlaying,
                    isCurrent = currentSong?.id == song.id,
                    isMultiSelectActive = false,
                    isSelected = false,
                    onSongClick = { onSongClick(song) },
                    onSongLongClick = {},
                    onToggleSelect = {},
                    onToggleFavorite = { onToggleFavoriteSong(song) },
                    onPlayNext = { onSongClick(song) },
                    onAddToQueue = { onAddToQueue(song) },
                    onAddToPlaylist = {},
                    onHideInVault = {},
                    onDelete = {}
                )
            }
        }
    }
}
