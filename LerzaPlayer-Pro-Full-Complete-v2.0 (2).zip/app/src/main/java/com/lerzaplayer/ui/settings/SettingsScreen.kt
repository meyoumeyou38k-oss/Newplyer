package com.lerzaplayer.ui.settings

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onScanMedia: () -> Unit,
    onOpenVault: () -> Unit = {},
    recentlyDeleted: List<RecentlyDeletedEntity> = emptyList(),
    onPlayRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onRestoreRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onPermanentlyDeleteRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showTrashSheet by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Surface(color = colors.surface, modifier = Modifier.statusBarsPadding()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) { Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary) }
                    Text("Settings & Control Center", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = colors.textPrimary)
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        LazyColumn(modifier = modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = colors.card), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Recently Deleted (30 Days)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
                        Text("${recentlyDeleted.size} items in trash bin", fontSize = 12.sp, color = colors.textSecondary)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(onClick = { showTrashSheet = true }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E60F2))) {
                            Text("Open Trash Recovery")
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = colors.card), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Private Vault", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
                        Text("AES-256 pattern & PIN protection", fontSize = 12.sp, color = colors.textSecondary)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(onClick = onOpenVault, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))) {
                            Text("Open Private Vault", color = Color.Black)
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = colors.card), shape = RoundedCornerShape(16.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Library Rescan", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = colors.textPrimary)
                        Text("Scan device for new music & videos", fontSize = 12.sp, color = colors.textSecondary)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(onClick = onScanMedia) { Text("Rescan Media") }
                    }
                }
            }
        }
    }
}
