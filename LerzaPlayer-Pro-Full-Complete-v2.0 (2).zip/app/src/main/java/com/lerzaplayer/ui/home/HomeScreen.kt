package com.lerzaplayer.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.ui.common.SongItemRow

@Composable
fun HomeScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    playerManager: PlayerManager,
    prefManager: PreferenceManager,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onOpenVault: () -> Unit,
    onExpandFullPlayer: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onToggleFavoriteVideo: (VideoItem) -> Unit,
    onHideSongInVault: (SongItem) -> Unit,
    onHideVideoInVault: (VideoItem) -> Unit,
    onDeleteSong: (SongItem) -> Unit,
    onDeleteVideo: (VideoItem) -> Unit,
    onScanDevice: () -> Unit
) {
    val isPlaying by playerManager.isPlaying.collectAsState()
    val currentSong by playerManager.currentSong.collectAsState()

    LazyColumn(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        items(songs, key = { it.id }) { song ->
            SongItemRow(
                song = song,
                isPlaying = isPlaying,
                isCurrent = currentSong?.id == song.id,
                isMultiSelectActive = false,
                isSelected = false,
                onSongClick = { playerManager.playSong(song) },
                onSongLongClick = {},
                onToggleSelect = {},
                onToggleFavorite = { onToggleFavoriteSong(song) },
                onPlayNext = { playerManager.playNext(song) },
                onAddToQueue = { playerManager.addToQueue(song) },
                onAddToPlaylist = {},
                onHideInVault = { onHideSongInVault(song) },
                onDelete = { onDeleteSong(song) }
            )
        }
    }
}
