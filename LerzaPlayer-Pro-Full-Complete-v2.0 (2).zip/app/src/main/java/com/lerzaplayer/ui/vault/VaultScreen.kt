package com.lerzaplayer.ui.vault

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.vault.VaultManager
import kotlinx.coroutines.launch

@Composable
fun VaultScreen(
    vaultManager: VaultManager,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val scope = rememberCoroutineScope()
    val isUnlocked by vaultManager.isUnlocked.collectAsState()
    val vaultMedia by vaultManager.vaultMediaFlow.collectAsState(initial = emptyList())

    BackHandler {
        vaultManager.lockVault()
        onBack()
    }

    Scaffold(
        topBar = {
            Surface(color = colors.surface, modifier = Modifier.statusBarsPadding()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(onClick = { vaultManager.lockVault(); onBack() }) {
                            Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                        Text("Private Vault", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = colors.textPrimary)
                    }
                    if (isUnlocked) {
                        Button(onClick = { vaultManager.lockVault(); onBack() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF334B))) {
                            Text("Lock & Exit")
                        }
                    }
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        Box(modifier = modifier.fillMaxSize().padding(padding)) {
            if (!isUnlocked) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(LerzaIcons.Lock, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(54.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Private Vault Security", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = colors.textPrimary)
                    Text("Auto-locks immediately on exit", fontSize = 12.sp, color = colors.textSecondary)
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(onClick = { scope.launch { vaultManager.verifyPin("0000") } }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))) {
                        Text("Unlock Vault", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(vaultMedia) { item ->
                        Card(colors = CardDefaults.cardColors(containerColor = colors.card), shape = RoundedCornerShape(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(item.originalName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = colors.textPrimary)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(onClick = { scope.launch { vaultManager.restoreMedia(item) } }) {
                                        Text("Restore")
                                    }
                                    Button(onClick = { scope.launch { vaultManager.deletePermanently(item) } }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF334B))) {
                                        Text("Delete")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
