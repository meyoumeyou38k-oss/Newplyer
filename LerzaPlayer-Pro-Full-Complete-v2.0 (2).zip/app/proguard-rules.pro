# ProGuard rules
-keep class com.lerzaplayer.data.database.** { *; }
-keep class com.lerzaplayer.playback.** { *; }
-dontwarn androidx.media3.**
