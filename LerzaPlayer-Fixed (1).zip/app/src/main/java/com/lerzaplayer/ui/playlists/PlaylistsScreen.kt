package com.lerzaplayer.ui.playlists

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LocalLerzaColors

@Composable
fun PlaylistsScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem, List<SongItem>, Int) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    Box(modifier = modifier.fillMaxSize().background(colors.background), contentAlignment = Alignment.Center) {
        Text("Playlists (${songs.size} songs)", color = colors.textPrimary)
    }
}
