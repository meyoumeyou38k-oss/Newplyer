package com.lerzaplayer.ui.albums

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.theme.LocalLerzaColors

@Composable
fun AlbumsScreen(
    songs: List<SongItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem, List<SongItem>, Int) -> Unit,
    onToggleFavorite: (SongItem) -> Unit,
    onHideInVault: (SongItem) -> Unit,
    onDelete: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    Box(modifier = modifier.fillMaxSize().background(colors.background), contentAlignment = Alignment.Center) {
        Text("Albums Library", color = colors.textPrimary)
    }
}
