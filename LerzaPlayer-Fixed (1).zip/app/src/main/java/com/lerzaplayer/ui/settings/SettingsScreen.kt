package com.lerzaplayer.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.data.database.RecentlyDeletedEntity
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors

@Composable
fun SettingsScreen(
    prefManager: PreferenceManager,
    onBack: () -> Unit,
    onOpenEqualizer: () -> Unit,
    onScanMedia: () -> Unit,
    onOpenVault: () -> Unit = {},
    recentlyDeleted: List<RecentlyDeletedEntity> = emptyList(),
    onRestoreRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    onPermanentlyDeleteRecentlyDeleted: (RecentlyDeletedEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current

    Scaffold(
        topBar = {
            Surface(
                color = colors.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                    }
                    Text(
                        text = "Settings",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = colors.card),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "LERZA PLAYER PRO",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF1E60F2)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Version 1.0.0 • Hardware Accelerated",
                            fontSize = 12.sp,
                            color = colors.textSecondary
                        )
                    }
                }
            }
        }
    }
}
