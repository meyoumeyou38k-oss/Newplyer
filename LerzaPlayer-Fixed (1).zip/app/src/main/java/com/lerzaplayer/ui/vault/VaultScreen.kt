package com.lerzaplayer.ui.vault

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lerzaplayer.data.database.VaultMediaEntity
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.vault.VaultManager

@Composable
fun VaultScreen(
    vaultManager: VaultManager,
    onBack: () -> Unit,
    onPlayMedia: (VaultMediaEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current

    Scaffold(
        topBar = {
            Surface(
                color = colors.surface,
                modifier = Modifier.statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                    }
                    Text(
                        text = "Private Vault",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = colors.textPrimary
                    )
                }
            }
        },
        containerColor = colors.background
    ) { padding ->
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.Center
        ) {
            Text("Vault Protected", color = colors.textPrimary)
        }
    }
}
