package com.lerzaplayer.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.theme.LerzaIcons
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.SongItemRow

@Composable
fun SearchScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    currentSong: SongItem?,
    isPlaying: Boolean,
    onSongClick: (SongItem) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onBack: () -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onAddToQueue: (SongItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    var query by remember { mutableStateOf("") }

    val filteredSongs = remember(query, songs) {
        if (query.isBlank()) emptyList()
        else songs.filter { it.title.contains(query, ignoreCase = true) || it.artist.contains(query, ignoreCase = true) }
    }

    Column(modifier = modifier.fillMaxSize().background(colors.background)) {
        Surface(color = colors.surface, modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(LerzaIcons.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                }
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search songs and artists...") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filteredSongs, key = { it.id }) { song ->
                SongItemRow(
                    song = song,
                    isPlaying = isPlaying,
                    isCurrent = currentSong?.id == song.id,
                    isMultiSelectActive = false,
                    isSelected = false,
                    onSongClick = { onSongClick(song) },
                    onSongLongClick = {},
                    onToggleSelect = {},
                    onToggleFavorite = { onToggleFavoriteSong(song) },
                    onPlayNext = { onSongClick(song) },
                    onAddToQueue = { onAddToQueue(song) },
                    onAddToPlaylist = {},
                    onHideInVault = {},
                    onDelete = {}
                )
            }
        }
    }
}
