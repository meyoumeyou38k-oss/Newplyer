package com.lerzaplayer.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lerzaplayer.data.model.*
import com.lerzaplayer.data.preferences.PreferenceManager
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LocalLerzaColors
import com.lerzaplayer.ui.common.AutoHidingHeader
import com.lerzaplayer.ui.common.TabsRow
import com.lerzaplayer.ui.player.MiniPlayer
import com.lerzaplayer.ui.songs.SongListScreen
import com.lerzaplayer.ui.videos.VideoListScreen
import com.lerzaplayer.ui.playlists.PlaylistsScreen
import com.lerzaplayer.ui.folders.FoldersScreen
import com.lerzaplayer.ui.albums.AlbumsScreen
import com.lerzaplayer.ui.artists.ArtistsScreen
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    songs: List<SongItem>,
    videos: List<VideoItem>,
    playerManager: PlayerManager,
    prefManager: PreferenceManager,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onOpenVault: () -> Unit,
    onExpandFullPlayer: () -> Unit,
    onPlayVideo: (VideoItem) -> Unit,
    onToggleFavoriteSong: (SongItem) -> Unit,
    onToggleFavoriteVideo: (VideoItem) -> Unit,
    onHideSongInVault: (SongItem) -> Unit,
    onHideVideoInVault: (VideoItem) -> Unit,
    onDeleteSong: (SongItem) -> Unit,
    onDeleteVideo: (VideoItem) -> Unit,
    onScanDevice: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalLerzaColors.current
    val scope = rememberCoroutineScope()
    val currentSong by playerManager.currentSong.collectAsState()
    val isPlaying by playerManager.isPlaying.collectAsState()
    val songSort by prefManager.songSortFlow.collectAsState(initial = SortOption.DATE_ADDED_DESC)
    val videoViewMode by prefManager.videoViewModeFlow.collectAsState(initial = ViewMode.GRID)
    val pagerState = rememberPagerState(initialPage = 1, pageCount = { 6 })

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            AutoHidingHeader(
                visible = true,
                onSearchClick = onSearchClick,
                onSettingsClick = onSettingsClick
            )
            TabsRow(
                selectedTab = pagerState.currentPage,
                onTabSelected = { index -> scope.launch { pagerState.animateScrollToPage(index) } }
            )
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f)
            ) { page ->
                when (page) {
                    0 -> VideoListScreen(
                        videos = videos,
                        viewMode = videoViewMode,
                        onVideoClick = onPlayVideo,
                        onViewModeToggle = {},
                        onScanDevice = onScanDevice,
                        onToggleFavorite = onToggleFavoriteVideo,
                        onHideInVault = onHideVideoInVault,
                        onDelete = onDeleteVideo
                    )
                    1 -> SongListScreen(
                        songs = songs,
                        currentSong = currentSong,
                        isPlaying = isPlaying,
                        currentSort = songSort,
                        selectedSongIds = emptySet(),
                        isMultiSelectMode = false,
                        onSongClick = { song, index ->
                            playerManager.playSongList(songs, index)
                            onExpandFullPlayer()
                        },
                        onToggleSelect = {},
                        onStartMultiSelect = {},
                        onSortChanged = { scope.launch { prefManager.setSongSort(it) } },
                        onToggleFavorite = onToggleFavoriteSong,
                        onPlayNext = { playerManager.playNext(it) },
                        onAddToQueue = { playerManager.addToQueue(it) },
                        onAddToPlaylist = {},
                        onHideInVault = onHideSongInVault,
                        onDelete = onDeleteSong
                    )
                    2 -> PlaylistsScreen(songs, currentSong, isPlaying, { s, l, i -> playerManager.playSongList(l, i); onExpandFullPlayer() }, onToggleFavoriteSong, onHideSongInVault, onDeleteSong)
                    3 -> FoldersScreen(songs, currentSong, isPlaying, { s, l, i -> playerManager.playSongList(l, i); onExpandFullPlayer() }, onToggleFavoriteSong, onHideSongInVault, onDeleteSong)
                    4 -> AlbumsScreen(songs, currentSong, isPlaying, { s, l, i -> playerManager.playSongList(l, i); onExpandFullPlayer() }, onToggleFavoriteSong, onHideSongInVault, onDeleteSong)
                    else -> ArtistsScreen(songs, currentSong, isPlaying, { s, l, i -> playerManager.playSongList(l, i); onExpandFullPlayer() }, onToggleFavoriteSong, onHideSongInVault, onDeleteSong)
                }
            }
        }

        if (currentSong != null) {
            MiniPlayer(
                currentSong = currentSong,
                isPlaying = isPlaying,
                onExpand = onExpandFullPlayer,
                onPlayPause = { playerManager.playPause() },
                onNext = { playerManager.playNextTrack() },
                onOpenQueue = onExpandFullPlayer,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}
