package com.lerzaplayer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.lerzaplayer.data.model.SongItem
import com.lerzaplayer.data.model.SortOption
import com.lerzaplayer.data.model.VideoItem
import com.lerzaplayer.data.repository.MediaRepository
import com.lerzaplayer.playback.PlayerManager
import com.lerzaplayer.theme.LerzaPlayerTheme
import com.lerzaplayer.ui.home.HomeScreen
import com.lerzaplayer.ui.player.FullPlayerScreen
import com.lerzaplayer.ui.player.VideoPlayerScreen
import com.lerzaplayer.ui.search.SearchScreen
import com.lerzaplayer.ui.settings.SettingsScreen
import com.lerzaplayer.ui.vault.VaultScreen

enum class AppDestination {
    HOME,
    SETTINGS,
    VAULT,
    SEARCH
}

class MainActivity : ComponentActivity() {
    private lateinit var mediaRepository: MediaRepository
    private lateinit var playerManager: PlayerManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as LerzaApp
        mediaRepository = MediaRepository(this)
        playerManager = app.playerManager

        setContent {
            val prefManager = app.preferenceManager
            val currentTheme by prefManager.themeFlow.collectAsState(initial = "Pure White")
            val songs by mediaRepository.getSongsFlow(SortOption.DATE_ADDED_DESC).collectAsState(initial = emptyList())
            val videos by mediaRepository.getVideosFlow(SortOption.DATE_ADDED_DESC).collectAsState(initial = emptyList())
            var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
            var isFullPlayerVisible by remember { mutableStateOf(false) }
            var activePlayingVideo by remember { mutableStateOf<VideoItem?>(null) }

            LerzaPlayerTheme(themeName = currentTheme) {
                Box(modifier = Modifier.fillMaxSize()) {
                    when (currentDestination) {
                        AppDestination.HOME -> {
                            HomeScreen(
                                songs = songs,
                                videos = videos,
                                playerManager = playerManager,
                                prefManager = prefManager,
                                onSearchClick = { currentDestination = AppDestination.SEARCH },
                                onSettingsClick = { currentDestination = AppDestination.SETTINGS },
                                onOpenVault = { currentDestination = AppDestination.VAULT },
                                onExpandFullPlayer = { isFullPlayerVisible = true },
                                onPlayVideo = { video ->
                                    playerManager.pause()
                                    activePlayingVideo = video
                                },
                                onToggleFavoriteSong = {},
                                onToggleFavoriteVideo = {},
                                onHideSongInVault = {},
                                onHideVideoInVault = {},
                                onDeleteSong = {},
                                onDeleteVideo = {},
                                onScanDevice = { mediaRepository.refreshMedia() }
                            )
                        }
                        AppDestination.SETTINGS -> {
                            SettingsScreen(
                                prefManager = prefManager,
                                onBack = { currentDestination = AppDestination.HOME },
                                onOpenEqualizer = { isFullPlayerVisible = true },
                                onScanMedia = { mediaRepository.refreshMedia() },
                                onOpenVault = { currentDestination = AppDestination.VAULT }
                            )
                        }
                        AppDestination.VAULT -> {
                            VaultScreen(
                                vaultManager = app.vaultManager,
                                onBack = { currentDestination = AppDestination.HOME }
                            )
                        }
                        AppDestination.SEARCH -> {
                            val curSong by playerManager.currentSong.collectAsState()
                            val isPlaying by playerManager.isPlaying.collectAsState()
                            SearchScreen(
                                songs = songs,
                                videos = videos,
                                currentSong = curSong,
                                isPlaying = isPlaying,
                                onSongClick = { playerManager.playSong(it); isFullPlayerVisible = true },
                                onVideoClick = { activePlayingVideo = it },
                                onBack = { currentDestination = AppDestination.HOME },
                                onToggleFavoriteSong = {},
                                onAddToQueue = { playerManager.addToQueue(it) }
                            )
                        }
                    }

                    if (isFullPlayerVisible) {
                        FullPlayerScreen(
                            playerManager = playerManager,
                            onCollapse = { isFullPlayerVisible = false }
                        )
                    }

                    activePlayingVideo?.let { vid ->
                        VideoPlayerScreen(
                            video = vid,
                            onClose = { activePlayingVideo = null }
                        )
                    }
                }
            }
        }
    }
}
