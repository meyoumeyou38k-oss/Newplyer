# Lerza Player Pro - Android Project

## Fixed Build Error
- Fixed app/src/main/res/drawable/ic_launcher_foreground.xml:
  Resolved AAPT2 ParseError 'Content is not allowed in trailing section' by replacing the broken hybrid with a clean Android vector drawable.

## How to Build in GitHub Actions:
1. Extract or commit this directory to your repository root (meyoumeyou38k-oss/Newplyer).
2. Push to main branch.
3. GitHub Actions workflow .github/workflows/android-build.yml will run ./gradlew assembleDebug and output Lerza-Player-debug.apk in Artifacts!
